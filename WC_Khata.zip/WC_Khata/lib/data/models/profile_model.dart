class ProfileModel {
  final int? id;
  final String? name;
  final String? email;
  final String? address;
  final String? phone;
  final String currency;
  final String startDay;
  final String language;
  final String? photoPath;

  /// Administrator / owner of the business (shown on the business card).
  final String? ownerName;
  final String? designation;
  final String? tagline;
  final String? website;
  final String? whatsapp;
  final DateTime createdAt;
  final DateTime updatedAt;

  const ProfileModel({
    this.id,
    this.name,
    this.email,
    this.address,
    this.phone,
    this.currency = 'USD',
    this.startDay = 'Sunday',
    this.language = 'en',
    this.photoPath,
    this.ownerName,
    this.designation,
    this.tagline,
    this.website,
    this.whatsapp,
    required this.createdAt,
    required this.updatedAt,
  });

  ProfileModel copyWith({
    String? name,
    String? email,
    String? address,
    String? phone,
    String? currency,
    String? startDay,
    String? language,
    String? photoPath,
    String? ownerName,
    String? designation,
    String? tagline,
    String? website,
    String? whatsapp,
    bool clearPhoto = false,
  }) {
    return ProfileModel(
      id: id,
      name: name ?? this.name,
      email: email ?? this.email,
      address: address ?? this.address,
      phone: phone ?? this.phone,
      currency: currency ?? this.currency,
      startDay: startDay ?? this.startDay,
      language: language ?? this.language,
      photoPath: clearPhoto ? null : (photoPath ?? this.photoPath),
      ownerName: ownerName ?? this.ownerName,
      designation: designation ?? this.designation,
      tagline: tagline ?? this.tagline,
      website: website ?? this.website,
      whatsapp: whatsapp ?? this.whatsapp,
      createdAt: createdAt,
      updatedAt: DateTime.now(),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      if (id != null) 'id': id,
      'name': name,
      'email': email,
      'address': address,
      'phone': phone,
      'currency': currency,
      'start_day': startDay,
      'language': language,
      'photo_path': photoPath,
      'owner_name': ownerName,
      'designation': designation,
      'tagline': tagline,
      'website': website,
      'whatsapp': whatsapp,
      'created_at': createdAt.toIso8601String(),
      'updated_at': updatedAt.toIso8601String(),
    };
  }

  factory ProfileModel.fromMap(Map<String, dynamic> map) {
    return ProfileModel(
      id: map['id'] as int?,
      name: map['name'] as String?,
      email: map['email'] as String?,
      address: map['address'] as String?,
      phone: map['phone'] as String?,
      currency: map['currency'] as String? ?? 'USD',
      startDay: map['start_day'] as String? ?? 'Sunday',
      language: map['language'] as String? ?? 'en',
      photoPath: map['photo_path'] as String?,
      ownerName: map['owner_name'] as String?,
      designation: map['designation'] as String?,
      tagline: map['tagline'] as String?,
      website: map['website'] as String?,
      whatsapp: map['whatsapp'] as String?,
      createdAt: DateTime.parse(map['created_at'] as String),
      updatedAt: DateTime.parse(map['updated_at'] as String),
    );
  }
}
