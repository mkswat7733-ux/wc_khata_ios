class BillModel {
  final int? id;
  final String name;
  final double amount;
  final DateTime dueDate;
  final String? repeatRule;
  final String status; // paid | pending | overdue
  final bool reminderEnabled;
  final int? accountId;
  final String? notes;
  final DateTime createdAt;
  final DateTime updatedAt;

  const BillModel({
    this.id,
    required this.name,
    required this.amount,
    required this.dueDate,
    this.repeatRule,
    this.status = 'pending',
    this.reminderEnabled = true,
    this.accountId,
    this.notes,
    required this.createdAt,
    required this.updatedAt,
  });

  BillModel copyWith({String? status}) {
    return BillModel(
      id: id,
      name: name,
      amount: amount,
      dueDate: dueDate,
      repeatRule: repeatRule,
      status: status ?? this.status,
      reminderEnabled: reminderEnabled,
      accountId: accountId,
      notes: notes,
      createdAt: createdAt,
      updatedAt: DateTime.now(),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      if (id != null) 'id': id,
      'name': name,
      'amount': amount,
      'due_date': dueDate.toIso8601String(),
      'repeat_rule': repeatRule,
      'status': status,
      'reminder_enabled': reminderEnabled ? 1 : 0,
      'account_id': accountId,
      'notes': notes,
      'created_at': createdAt.toIso8601String(),
      'updated_at': updatedAt.toIso8601String(),
    };
  }

  factory BillModel.fromMap(Map<String, dynamic> map) {
    return BillModel(
      id: map['id'] as int?,
      name: map['name'] as String,
      amount: (map['amount'] as num).toDouble(),
      dueDate: DateTime.parse(map['due_date'] as String),
      repeatRule: map['repeat_rule'] as String?,
      status: map['status'] as String? ?? 'pending',
      reminderEnabled: (map['reminder_enabled'] as int? ?? 1) == 1,
      accountId: map['account_id'] as int?,
      notes: map['notes'] as String?,
      createdAt: DateTime.parse(map['created_at'] as String),
      updatedAt: DateTime.parse(map['updated_at'] as String),
    );
  }
}
