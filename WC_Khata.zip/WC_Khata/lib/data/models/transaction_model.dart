enum TransactionType { income, expense, transfer, personSend, personReceive }

extension TransactionTypeX on TransactionType {
  String get value => name;

  static TransactionType fromValue(String value) {
    return TransactionType.values.firstWhere((e) => e.name == value);
  }
}

class TransactionModel {
  final int? id;
  final TransactionType type;
  final double amount;
  final int accountId;
  final int? toAccountId; // only for transfers
  final int? categoryId; // null for transfers
  final String? source; // income source label
  final String? paymentMethod;
  final String? frequency;
  final DateTime date;
  final String? note;
  final DateTime createdAt;
  final DateTime updatedAt;

  const TransactionModel({
    this.id,
    required this.type,
    required this.amount,
    required this.accountId,
    this.toAccountId,
    this.categoryId,
    this.source,
    this.paymentMethod,
    this.frequency,
    required this.date,
    this.note,
    required this.createdAt,
    required this.updatedAt,
  });

  Map<String, dynamic> toMap() {
    return {
      if (id != null) 'id': id,
      'type': type.value,
      'amount': amount,
      'account_id': accountId,
      'to_account_id': toAccountId,
      'category_id': categoryId,
      'source': source,
      'payment_method': paymentMethod,
      'frequency': frequency,
      'date': date.toIso8601String(),
      'note': note,
      'created_at': createdAt.toIso8601String(),
      'updated_at': updatedAt.toIso8601String(),
    };
  }

  factory TransactionModel.fromMap(Map<String, dynamic> map) {
    return TransactionModel(
      id: map['id'] as int?,
      type: TransactionTypeX.fromValue(map['type'] as String),
      amount: (map['amount'] as num).toDouble(),
      accountId: map['account_id'] as int,
      toAccountId: map['to_account_id'] as int?,
      categoryId: map['category_id'] as int?,
      source: map['source'] as String?,
      paymentMethod: map['payment_method'] as String?,
      frequency: map['frequency'] as String?,
      date: DateTime.parse(map['date'] as String),
      note: map['note'] as String?,
      createdAt: DateTime.parse(map['created_at'] as String),
      updatedAt: DateTime.parse(map['updated_at'] as String),
    );
  }
}
