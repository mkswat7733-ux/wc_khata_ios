class SubscriptionModel {
  final int? id;
  final String name;
  final double amount;
  final String billingCycle; // weekly | monthly | yearly
  final DateTime nextPaymentDate;
  final int? accountId;
  final int? categoryId;
  final bool reminderEnabled;
  final bool isActive;
  final DateTime createdAt;
  final DateTime updatedAt;

  const SubscriptionModel({
    this.id,
    required this.name,
    required this.amount,
    this.billingCycle = 'monthly',
    required this.nextPaymentDate,
    this.accountId,
    this.categoryId,
    this.reminderEnabled = true,
    this.isActive = true,
    required this.createdAt,
    required this.updatedAt,
  });

  Map<String, dynamic> toMap() {
    return {
      if (id != null) 'id': id,
      'name': name,
      'amount': amount,
      'billing_cycle': billingCycle,
      'next_payment_date': nextPaymentDate.toIso8601String(),
      'account_id': accountId,
      'category_id': categoryId,
      'reminder_enabled': reminderEnabled ? 1 : 0,
      'is_active': isActive ? 1 : 0,
      'created_at': createdAt.toIso8601String(),
      'updated_at': updatedAt.toIso8601String(),
    };
  }

  factory SubscriptionModel.fromMap(Map<String, dynamic> map) {
    return SubscriptionModel(
      id: map['id'] as int?,
      name: map['name'] as String,
      amount: (map['amount'] as num).toDouble(),
      billingCycle: map['billing_cycle'] as String? ?? 'monthly',
      nextPaymentDate: DateTime.parse(map['next_payment_date'] as String),
      accountId: map['account_id'] as int?,
      categoryId: map['category_id'] as int?,
      reminderEnabled: (map['reminder_enabled'] as int? ?? 1) == 1,
      isActive: (map['is_active'] as int? ?? 1) == 1,
      createdAt: DateTime.parse(map['created_at'] as String),
      updatedAt: DateTime.parse(map['updated_at'] as String),
    );
  }
}
