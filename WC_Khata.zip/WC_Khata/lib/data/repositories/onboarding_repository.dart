import 'package:package_info_plus/package_info_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Tracks whether the user has completed the one-time first-launch
/// onboarding flow.
///
/// This is a local-only UI-flow flag, never authentication itself — it only
/// decides what [SplashScreen] navigates to next:
///
///   registrationComplete == false -> OnboardingScreen (every NEW install)
///   registrationComplete == true  -> LaunchGate (every launch after that)
///
/// Rules:
///   * Fresh install (also after uninstall -> install again, any number of
///     times)            -> onboarding is shown.
///   * App update (Play Store / installing a newer build over the old one)
///                       -> onboarding is NOT shown, straight to Home.
///
/// Android can bring old saved settings back into a reinstalled app (its own
/// cloud backup / phone-to-phone transfer), which would wrongly say
/// "registration complete" on a brand-new install. So the flag is trusted only
/// when it belongs to THIS install: the phone's "first installed" time of the
/// app is saved next to it. A reinstall always has a new install time, an
/// update never changes it.
class OnboardingRepository {
  static const _keyRegistrationComplete = 'registration_complete';
  static const _keyInstallTime = 'install_time_ms';

  Future<bool> isRegistrationComplete() async {
    final prefs = await SharedPreferences.getInstance();
    final flag = prefs.getBool(_keyRegistrationComplete) ?? false;

    DateTime? installed;
    DateTime? updated;
    try {
      final info = await PackageInfo.fromPlatform();
      installed = info.installTime;
      updated = info.updateTime;
    } catch (_) {}

    // The phone did not tell us the install time: keep the old behaviour.
    if (installed == null) return flag;

    final installMs = installed.millisecondsSinceEpoch;
    final storedMs = prefs.getInt(_keyInstallTime);

    bool isNewInstall;
    if (storedMs != null) {
      // Same install time as last time -> same install (maybe updated).
      isNewInstall = storedMs != installMs;
    } else {
      // No install time saved yet: either a brand-new install, or an
      // existing user opening the first version that knows about this.
      // On a fresh install "installed" and "last updated" are the same
      // moment; after an update they are not.
      isNewInstall = updated == null || updated.difference(installed).abs() < const Duration(seconds: 5);
    }

    await prefs.setInt(_keyInstallTime, installMs);
    if (isNewInstall) {
      await prefs.setBool(_keyRegistrationComplete, false);
      return false;
    }
    return flag;
  }

  Future<void> setRegistrationComplete() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_keyRegistrationComplete, true);
    try {
      final info = await PackageInfo.fromPlatform();
      final t = info.installTime;
      if (t != null) await prefs.setInt(_keyInstallTime, t.millisecondsSinceEpoch);
    } catch (_) {}
  }
}
