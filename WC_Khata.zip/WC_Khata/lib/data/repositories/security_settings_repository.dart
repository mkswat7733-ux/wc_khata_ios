import 'package:sqflite/sqflite.dart';
import '../../core/database/app_database.dart';
import '../../core/database/database_constants.dart';
import '../../core/security/password_service.dart';

class SecuritySettingsRepository {
  Future<Database> get _db async => AppDatabase.instance.database;

  Future<Map<String, dynamic>?> _getRow() async {
    final db = await _db;
    final rows = await db.query(DBConstants.tableSecuritySettings, limit: 1);
    return rows.isEmpty ? null : rows.first;
  }

  Future<bool> isPasswordEnabled() async {
    final row = await _getRow();
    return row != null && (row['password_enabled'] as int) == 1;
  }

  Future<void> enablePassword(String password) async {
    final db = await _db;
    final salt = PasswordService.generateSalt();
    final hash = PasswordService.hash(password, salt);
    final existing = await _getRow();
    final data = {
      'password_enabled': 1,
      'password_hash': hash,
      'password_salt': salt,
      'updated_at': DateTime.now().toIso8601String(),
    };
    if (existing == null) {
      await db.insert(DBConstants.tableSecuritySettings, data);
    } else {
      await db.update(DBConstants.tableSecuritySettings, data,
          where: 'id = ?', whereArgs: [existing['id']]);
    }
  }

  Future<bool> verifyPassword(String password) async {
    final row = await _getRow();
    if (row == null || row['password_hash'] == null || row['password_salt'] == null) return false;
    return PasswordService.verify(password, row['password_salt'] as String, row['password_hash'] as String);
  }

  Future<void> changePassword(String currentPassword, String newPassword) async {
    final valid = await verifyPassword(currentPassword);
    if (!valid) throw StateError('Current password is incorrect');
    await enablePassword(newPassword);
  }

  Future<void> removePassword(String currentPassword) async {
    final valid = await verifyPassword(currentPassword);
    if (!valid) throw StateError('Current password is incorrect');
    final db = await _db;
    final existing = await _getRow();
    if (existing != null) {
      await db.update(
        DBConstants.tableSecuritySettings,
        {
          'password_enabled': 0,
          'password_hash': null,
          'password_salt': null,
          'updated_at': DateTime.now().toIso8601String(),
        },
        where: 'id = ?',
        whereArgs: [existing['id']],
      );
    }
  }
}
