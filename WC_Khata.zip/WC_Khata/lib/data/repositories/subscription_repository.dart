import 'package:sqflite/sqflite.dart';
import '../../core/database/app_database.dart';
import '../../core/database/database_constants.dart';
import '../../core/services/notification_service.dart';
import '../models/subscription_model.dart';
import '../models/transaction_model.dart';
import 'transaction_repository.dart';

class SubscriptionRepository {
  final TransactionRepository _txRepo = TransactionRepository();

  Future<Database> get _db async => AppDatabase.instance.database;

  Future<List<SubscriptionModel>> getAll() async {
    final db = await _db;
    final rows = await db.query(
      DBConstants.tableSubscriptions,
      where: 'is_active = ?',
      whereArgs: [1],
      orderBy: 'next_payment_date ASC',
    );
    return rows.map(SubscriptionModel.fromMap).toList();
  }

  /// Inserts the subscription, then schedules its next-payment
  /// reminder (see [NotificationService]) now that it has a real id.
  Future<int> create(SubscriptionModel sub) async {
    final db = await _db;
    final id = await db.insert(DBConstants.tableSubscriptions, sub.toMap());
    await NotificationService.instance.scheduleSubscriptionNotification(
      SubscriptionModel.fromMap({...sub.toMap(), 'id': id}),
    );
    return id;
  }

  /// Updates the subscription, then re-schedules its reminder —
  /// covers a changed billing date, a toggled reminder switch, or a
  /// cancelled (inactive) subscription.
  Future<void> update(SubscriptionModel sub) async {
    final db = await _db;
    await db.update(DBConstants.tableSubscriptions, sub.toMap(), where: 'id = ?', whereArgs: [sub.id]);
    await NotificationService.instance.scheduleSubscriptionNotification(sub);
  }

  Future<void> delete(int id) async {
    final db = await _db;
    await db.delete(DBConstants.tableSubscriptions, where: 'id = ?', whereArgs: [id]);
    await NotificationService.instance.cancelSubscriptionNotification(id);
  }

  /// Rolls [date] forward by exactly one billing cycle.
  DateTime _nextCycleDate(DateTime date, String billingCycle) {
    switch (billingCycle) {
      case 'weekly':
        return date.add(const Duration(days: 7));
      case 'yearly':
        return DateTime(date.year + 1, date.month, date.day);
      case 'monthly':
      default:
        final month = date.month == 12 ? 1 : date.month + 1;
        final year = date.month == 12 ? date.year + 1 : date.year;
        // Clamp so e.g. Jan 31 -> Feb 28 instead of overflowing into March.
        final lastDayOfNextMonth = DateTime(year, month + 1, 0).day;
        return DateTime(year, month, date.day > lastDayOfNextMonth ? lastDayOfNextMonth : date.day);
    }
  }

  /// Pays a subscription for real: posts a proper Expense transaction
  /// against [accountId] (so the account balance, History, Reports and
  /// Transactions all pick it up exactly like any other expense), then
  /// rolls the subscription's due date forward to its next cycle —
  /// unlike a one-off Bill, a Subscription keeps recurring, so it stays
  /// on the list instead of being removed, and simply drops out of the
  /// "payable" total until it becomes due again next cycle.
  ///
  /// [amount] optionally overrides the subscription's saved price for
  /// just this one payment (e.g. a plan renewed at a different price
  /// than usual) — the recurring subscription amount itself is left
  /// untouched for future cycles.
  Future<void> paySubscription(SubscriptionModel sub, {required int accountId, double? amount}) async {
    final now = DateTime.now();
    await _txRepo.create(TransactionModel(
      type: TransactionType.expense,
      amount: amount ?? sub.amount,
      accountId: accountId,
      categoryId: sub.categoryId,
      note: 'Subscription Payment: ${sub.name}',
      date: now,
      createdAt: now,
      updatedAt: now,
    ));
    final nextDate = _nextCycleDate(sub.nextPaymentDate, sub.billingCycle);
    final db = await _db;
    await db.update(
      DBConstants.tableSubscriptions,
      {
        'next_payment_date': nextDate.toIso8601String(),
        'account_id': accountId,
        'updated_at': now.toIso8601String(),
      },
      where: 'id = ?',
      whereArgs: [sub.id],
    );
    // Reschedules the reminder for the new cycle — a paid subscription
    // keeps recurring, so its next due date still needs one.
    await NotificationService.instance.scheduleSubscriptionNotification(
      SubscriptionModel.fromMap({...sub.toMap(), 'next_payment_date': nextDate.toIso8601String(), 'account_id': accountId}),
    );
  }
}
