import 'package:sqflite/sqflite.dart';
import '../../core/database/app_database.dart';
import '../../core/database/database_constants.dart';
import '../models/profile_model.dart';

class ProfileRepository {
  Future<Database> get _db async => AppDatabase.instance.database;

  Future<ProfileModel> getOrCreate() async {
    final db = await _db;
    final rows = await db.query(DBConstants.tableProfile, limit: 1);
    if (rows.isNotEmpty) return ProfileModel.fromMap(rows.first);
    final now = DateTime.now();
    final profile = ProfileModel(createdAt: now, updatedAt: now);
    final id = await db.insert(DBConstants.tableProfile, profile.toMap());
    return ProfileModel.fromMap({...profile.toMap(), 'id': id});
  }

  Future<void> save(ProfileModel profile) async {
    final db = await _db;
    if (profile.id == null) {
      await db.insert(DBConstants.tableProfile, profile.toMap());
    } else {
      await db.update(DBConstants.tableProfile, profile.toMap(), where: 'id = ?', whereArgs: [profile.id]);
    }
  }
}
