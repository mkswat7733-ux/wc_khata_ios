import 'dart:async';
import 'package:flutter/material.dart';
import '../../app/theme/app_theme.dart';
import '../../core/utils/currency_formatter.dart';

/// Read-only (not editable) text box that shows a cost price.
/// The value is hidden by default ("••••••"). The eye button on the right
/// reveals it, and it hides itself again automatically after [autoHide].
class HiddenCostBox extends StatefulWidget {
  final String label;
  final double value;
  final double scale;
  final Duration autoHide;

  /// Called whenever the value is revealed / hidden (also on auto-hide), so
  /// the parent can show or blank related figures such as profit.
  final ValueChanged<bool>? onVisibilityChanged;
  const HiddenCostBox({
    super.key,
    required this.value,
    this.label = 'Cost Price / Unit',
    this.scale = 1,
    this.autoHide = const Duration(seconds: 5),
    this.onVisibilityChanged,
  });

  @override
  State<HiddenCostBox> createState() => _HiddenCostBoxState();
}

class _HiddenCostBoxState extends State<HiddenCostBox> {
  bool _visible = false;
  Timer? _timer;

  void _toggle() {
    _timer?.cancel();
    setState(() => _visible = !_visible);
    widget.onVisibilityChanged?.call(_visible);
    if (_visible) {
      _timer = Timer(widget.autoHide, () {
        if (!mounted) return;
        setState(() => _visible = false);
        widget.onVisibilityChanged?.call(false);
      });
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.scale;
    return InputDecorator(
      decoration: InputDecoration(
        labelText: widget.label,
        filled: true,
        fillColor: AppColors.lightBackground,
        prefixIcon: Icon(Icons.lock_outline_rounded, size: 19 * s, color: AppColors.lightTextSecondary),
        suffixIcon: IconButton(
          tooltip: _visible ? 'Hide cost price' : 'Show cost price',
          onPressed: _toggle,
          icon: Icon(_visible ? Icons.visibility_off_rounded : Icons.visibility_rounded, size: 21 * s, color: AppColors.primary),
        ),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14 * s), borderSide: BorderSide.none),
      ),
      child: Text(
        _visible ? CurrencyFormatter.formatCompact(widget.value) : '••••••',
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: TextStyle(fontSize: 14 * s, fontWeight: FontWeight.w900, letterSpacing: _visible ? 0 : 2, color: AppColors.lightTextPrimary),
      ),
    );
  }
}
