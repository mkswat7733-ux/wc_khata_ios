import 'dart:typed_data';
import 'dart:io';

import 'package:flutter/services.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import '../../core/utils/currency_formatter.dart';
import 'bill_context.dart';
import '../settings/template_service.dart';
import '../../data/repositories/profile_repository.dart';

/// Builds a proper A4 "mart style" sales invoice.
class InvoicePdfBuilder {
  InvoicePdfBuilder._();

  static const _blue = PdfColor.fromInt(0xFF2F6FED);
  static const _lightBlue = PdfColor.fromInt(0xFFEAF1FF);
  static const _border = PdfColor.fromInt(0xFFD0D5DD);
  static const _muted = PdfColor.fromInt(0xFF667085);
  static const _green = PdfColor.fromInt(0xFF12805C);
  static const _red = PdfColor.fromInt(0xFFD92D20);
  static const _orange = PdfColor.fromInt(0xFFB54708);

  static Future<Uint8List> build(BillContext b) async {
    final template = await TemplateService.instance.active(TemplateKind.invoice);
    final blue = PdfColor.fromInt(template.accent);
    pw.MemoryImage? logo;
    final profile = await ProfileRepository().getOrCreate();
    final logoPath = template.logoPath ?? profile.photoPath;
    if (logoPath != null && logoPath.trim().isNotEmpty) {
      try { logo = pw.MemoryImage(await File(logoPath).readAsBytes()); } catch (_) {}
    }
    final regular = pw.Font.ttf(await rootBundle.load('assets/fonts/NotoSans-Regular.ttf'));
    final naskh = pw.Font.ttf(await rootBundle.load('assets/fonts/NotoNaskhArabic-Regular.ttf'));
    final doc = pw.Document(
      title: 'Invoice ${b.invoiceId}',
      author: b.businessName,
      theme: pw.ThemeData.withFont(base: regular, bold: regular, italic: regular, boldItalic: regular, fontFallback: [naskh]),
    );

    final sale = b.sale;
    final symbol = CurrencyFormatter.defaultSymbol;
    final statusText = b.isPaid ? 'PAID' : (b.isPartial ? 'PARTIAL' : 'UNPAID');
    final statusColor = b.isPaid ? _green : (b.isPartial ? _orange : _red);

    pw.Widget cell(String text, {pw.Alignment align = pw.Alignment.centerLeft, PdfColor? color, double size = 9, PdfColor? bg}) {
      return pw.Container(
        color: bg,
        alignment: align,
        padding: const pw.EdgeInsets.symmetric(horizontal: 6, vertical: 6),
        child: pw.Text(text, style: pw.TextStyle(fontSize: size, color: color ?? PdfColors.black)),
      );
    }

    final rows = <pw.TableRow>[
      pw.TableRow(
        repeat: true,
        decoration: pw.BoxDecoration(color: blue),
        children: [
          cell('#', align: pw.Alignment.center, color: PdfColors.white, size: 9.5),
          cell('PRODUCT DESCRIPTION', color: PdfColors.white, size: 9.5),
          cell('UNIT', align: pw.Alignment.center, color: PdfColors.white, size: 9.5),
          cell('QTY', align: pw.Alignment.centerRight, color: PdfColors.white, size: 9.5),
          cell('RATE', align: pw.Alignment.centerRight, color: PdfColors.white, size: 9.5),
          cell('AMOUNT', align: pw.Alignment.centerRight, color: PdfColors.white, size: 9.5),
        ],
      ),
      for (var i = 0; i < sale.lines.length; i++)
        pw.TableRow(
          decoration: pw.BoxDecoration(color: i.isOdd ? const PdfColor.fromInt(0xFFF8FAFC) : PdfColors.white),
          children: [
            cell('${i + 1}', align: pw.Alignment.center),
            cell(sale.lines[i].item.name),
            cell(sale.lines[i].item.unit, align: pw.Alignment.center),
            cell(BillContext.qty(sale.lines[i].qty), align: pw.Alignment.centerRight),
            cell(BillContext.money(sale.lines[i].unitPrice), align: pw.Alignment.centerRight),
            cell(BillContext.money(sale.lines[i].total), align: pw.Alignment.centerRight),
          ],
        ),
    ];

    pw.Widget infoBox(String title, List<pw.Widget> children) => pw.Expanded(
          child: pw.Container(
            padding: const pw.EdgeInsets.all(10),
            decoration: pw.BoxDecoration(border: pw.Border.all(color: _border, width: 0.8), borderRadius: pw.BorderRadius.circular(5)),
            child: pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                pw.Text(title, style: const pw.TextStyle(fontSize: 8, color: _muted)),
                pw.SizedBox(height: 5),
                ...children,
              ],
            ),
          ),
        );

    pw.Widget totalRow(String label, String value, {bool strong = false, PdfColor? color, PdfColor? bg}) => pw.Container(
          color: bg,
          padding: const pw.EdgeInsets.symmetric(horizontal: 10, vertical: 6),
          child: pw.Row(
            mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
            children: [
              pw.Text(label, style: pw.TextStyle(fontSize: strong ? 11 : 9.5, color: color ?? PdfColors.black)),
              pw.Text(value, style: pw.TextStyle(fontSize: strong ? 12 : 9.5, color: color ?? PdfColors.black)),
            ],
          ),
        );

    doc.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.fromLTRB(32, 30, 32, 36),
        header: (ctx) {
          if (ctx.pageNumber > 1) {
            return pw.Container(
              margin: const pw.EdgeInsets.only(bottom: 10),
              padding: const pw.EdgeInsets.only(bottom: 6),
              decoration: const pw.BoxDecoration(border: pw.Border(bottom: pw.BorderSide(color: _border, width: 0.8))),
              child: pw.Row(
                mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                children: [
                  pw.Text(b.businessName, style: const pw.TextStyle(fontSize: 9, color: _muted)),
                  pw.Text('Invoice ${b.invoiceId}', style: const pw.TextStyle(fontSize: 9, color: _muted)),
                ],
              ),
            );
          }
          return pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Row(
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                children: [
                  pw.Expanded(
                    child: pw.Column(
                      crossAxisAlignment: pw.CrossAxisAlignment.start,
                      children: [
                        if (template.showBusiness || (template.showLogo && logo != null)) pw.Row(
                          crossAxisAlignment: pw.CrossAxisAlignment.start,
                          children: [
                            if (template.showLogo && logo != null) pw.Padding(padding: const pw.EdgeInsets.only(right: 8), child: pw.Image(logo!, width: 34, height: 34)),
                            if (template.showBusiness) pw.Expanded(child: pw.Text(b.businessName, style: pw.TextStyle(fontSize: 22, color: blue))),
                          ],
                        ),
                        if (template.showBusiness && b.address != null) pw.Padding(padding: const pw.EdgeInsets.only(top: 3), child: pw.Text(b.address!, style: const pw.TextStyle(fontSize: 9, color: _muted))),
                        if (template.showBusiness && b.email != null) pw.Padding(padding: const pw.EdgeInsets.only(top: 2), child: pw.Text(b.email!, style: const pw.TextStyle(fontSize: 9, color: _muted))),
                      ],
                    ),
                  ),
                  pw.Container(
                    padding: const pw.EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                    decoration: pw.BoxDecoration(color: blue, borderRadius: pw.BorderRadius.circular(5)),
                    child: pw.Text(template.title, style: const pw.TextStyle(fontSize: 14, color: PdfColors.white)),
                  ),
                ],
              ),
              pw.SizedBox(height: 10),
              pw.Divider(color: blue, thickness: 1.5),
              pw.SizedBox(height: 10),
              pw.Row(
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                children: [
                  if (template.showCustomer) infoBox(b.billToLabel, [
                    pw.Text(b.customerName ?? b.fallbackParty, style: const pw.TextStyle(fontSize: 11)),
                    if (b.customerPhone != null) pw.Padding(padding: const pw.EdgeInsets.only(top: 3), child: pw.Text(b.customerPhone!, style: const pw.TextStyle(fontSize: 9, color: _muted))),
                    if ((b.customerAddress ?? '').isNotEmpty) pw.Padding(padding: const pw.EdgeInsets.only(top: 3), child: pw.Text(b.customerAddress!, style: const pw.TextStyle(fontSize: 9, color: _muted))),
                  ]),
                  if (template.showCustomer && (template.showInvoiceNumber || template.showDate)) pw.SizedBox(width: 10),
                  if (template.showInvoiceNumber || template.showDate) infoBox('INVOICE DETAILS', [
                    if (template.showInvoiceNumber) pw.Row(mainAxisAlignment: pw.MainAxisAlignment.spaceBetween, children: [
                      pw.Text('Invoice No', style: const pw.TextStyle(fontSize: 9, color: _muted)),
                      pw.Text(b.invoiceId, style: const pw.TextStyle(fontSize: 9.5)),
                    ]),
                    if (template.showInvoiceNumber && template.showDate) pw.SizedBox(height: 3),
                    if (template.showDate) pw.Row(mainAxisAlignment: pw.MainAxisAlignment.spaceBetween, children: [
                      pw.Text('Date', style: const pw.TextStyle(fontSize: 9, color: _muted)),
                      pw.Text(BillContext.dateTime(sale.date), style: const pw.TextStyle(fontSize: 9.5)),
                    ]),
                  ]),
                  if ((template.showCustomer || template.showInvoiceNumber || template.showDate) && template.showPaymentStatus) pw.SizedBox(width: 10),
                  if (template.showPaymentStatus) pw.Container(
                    width: 82,
                    padding: const pw.EdgeInsets.symmetric(vertical: 14),
                    decoration: pw.BoxDecoration(
                      border: pw.Border.all(color: statusColor, width: 1.4),
                      borderRadius: pw.BorderRadius.circular(5),
                    ),
                    child: pw.Center(child: pw.Text(statusText, style: pw.TextStyle(fontSize: 14, color: statusColor))),
                  ),
                ],
              ),
              pw.SizedBox(height: 14),
            ],
          );
        },
        footer: (ctx) => pw.Container(
          padding: const pw.EdgeInsets.only(top: 6),
          decoration: const pw.BoxDecoration(border: pw.Border(top: pw.BorderSide(color: _border, width: 0.8))),
          child: pw.Row(
            mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
            children: [
              pw.Text('Computer generated invoice  |  Powered by WebdSoft Company', style: const pw.TextStyle(fontSize: 8, color: _muted)),
              pw.Text('Page ${ctx.pageNumber} of ${ctx.pagesCount}', style: const pw.TextStyle(fontSize: 8, color: _muted)),
            ],
          ),
        ),
        build: (ctx) => [
          pw.Align(
            alignment: pw.Alignment.centerRight,
            child: pw.Padding(padding: const pw.EdgeInsets.only(bottom: 4), child: pw.Text('Amounts in $symbol', style: const pw.TextStyle(fontSize: 8, color: _muted))),
          ),
          if (template.showItems) pw.Table(
            columnWidths: const {
              0: pw.FixedColumnWidth(28),
              1: pw.FlexColumnWidth(4),
              2: pw.FixedColumnWidth(46),
              3: pw.FixedColumnWidth(50),
              4: pw.FixedColumnWidth(72),
              5: pw.FixedColumnWidth(80),
            },
            border: const pw.TableBorder(
              top: pw.BorderSide(color: _border, width: 0.8),
              bottom: pw.BorderSide(color: _border, width: 0.8),
              left: pw.BorderSide(color: _border, width: 0.8),
              right: pw.BorderSide(color: _border, width: 0.8),
              horizontalInside: pw.BorderSide(color: _border, width: 0.4),
              verticalInside: pw.BorderSide(color: _border, width: 0.4),
            ),
            children: rows,
          ),
          pw.SizedBox(height: 12),
          pw.Row(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Expanded(
                child: pw.Column(
                  crossAxisAlignment: pw.CrossAxisAlignment.start,
                  children: [
                    pw.Text('Total Products: ${sale.lines.length}', style: const pw.TextStyle(fontSize: 9.5)),
                    pw.SizedBox(height: 3),
                    pw.Text('Total Quantity: ${BillContext.qty(b.totalQty)}', style: const pw.TextStyle(fontSize: 9.5)),
                    pw.SizedBox(height: 14),
                  ],
                ),
              ),
              pw.SizedBox(width: 16),
              if (template.showTotals) pw.Container(
                width: 215,
                decoration: pw.BoxDecoration(border: pw.Border.all(color: _border, width: 0.8), borderRadius: pw.BorderRadius.circular(5)),
                child: pw.Column(
                  children: [
                    totalRow('Subtotal', BillContext.money(sale.subtotal)),
                    if (template.showDiscount && sale.discountAmount > 0) totalRow('Discount', '- ${BillContext.money(sale.discountAmount)}', color: _red),
                    if (template.showTax && sale.taxAmount > 0) totalRow('Tax (${sale.taxRate.toStringAsFixed(2)}%)', BillContext.money(sale.taxAmount)),
                    totalRow('TOTAL', BillContext.money(sale.total), strong: true, color: blue, bg: PdfColor.fromInt((template.accent & 0x00FFFFFF) | 0x10000000)),
                    if (template.showPaid) totalRow('Paid', BillContext.money(sale.paid)),
                    if (template.showBalance) totalRow(b.isPaid ? 'Balance' : 'Balance Due', BillContext.money(b.balance < 0 ? 0 : b.balance), color: b.isPaid ? _green : _red),
                  ],
                ),
              ),
            ],
          ),
          if (template.showNotes && template.showFooterMessage) pw.Padding(
            padding: const pw.EdgeInsets.only(top: 18),
            child: pw.Text(template.thankYouMessage, style: pw.TextStyle(fontSize: 10, color: blue)),
          ),
          if (template.showSignature) pw.SizedBox(height: 46),
          if (template.showSignature) pw.Row(
            mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
            children: [
              _signature('${b.partyRole} Signature'),
              _signature('Authorized Signature'),
            ],
          ),
        ],
      ),
    );

    return doc.save();
  }

  static pw.Widget _signature(String label) => pw.Column(
        children: [
          pw.Container(width: 140, height: 0.8, color: PdfColors.grey600),
          pw.SizedBox(height: 4),
          pw.Text(label, style: const pw.TextStyle(fontSize: 8.5, color: _muted)),
        ],
      );
}
