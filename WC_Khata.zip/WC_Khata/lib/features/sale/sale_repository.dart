import '../../core/services/data_events.dart';
import 'package:sqflite/sqflite.dart';
import '../../core/services/notification_service.dart';
import '../../core/database/app_database.dart';
import '../../core/database/database_constants.dart';
import '../items/item_repository.dart';
import 'sale_calculator.dart';
import 'sale_settlement.dart';

class SaleLine {
  final ItemRecord item;
  double qty;
  double unitPrice;
  double unitCost;
  /// Real catalogue retail price (kept separate from the bill price).
  final double retailPrice;
  SaleLine({required this.item, this.qty = 1, double? unitPrice, double? unitCost, double? retailPrice})
      : unitPrice = unitPrice ?? item.price,
        unitCost = unitCost ?? item.purchaseUnitPrice,
        retailPrice = retailPrice ?? item.price;
  double get total => qty * unitPrice;
  double get totalCost => qty * unitCost;
  /// Line profit (negative = loss) before bill-level discount/tax.
  double get lineProfit => total - totalCost;
  SaleLine copy() => SaleLine(item: item, qty: qty, unitPrice: unitPrice, unitCost: unitCost, retailPrice: retailPrice);
}

class SavedSale {
  final int id;
  final String invoiceNo;
  final double total;
  final double paid;
  final String paymentType;
  final DateTime date;
  final int? customerId;
  final List<SaleLine> lines;
  final double subtotal;
  final double discountAmount;
  final double taxRate;
  final double taxAmount;

  /// What was paid when the sale itself was saved (before any later customer
  /// receipts). [paid] is the live figure including later receipts. Editing a
  /// sale must start from [invoicePaid], never from [paid].
  final double? invoicePaid;
  const SavedSale({required this.id, required this.invoiceNo, required this.total, required this.paid, required this.paymentType, required this.date, required this.customerId, required this.lines, this.subtotal = 0, this.discountAmount = 0, this.taxRate = 0, this.taxAmount = 0, this.invoicePaid});

  SavedSale withPaid(double newPaid) => SavedSale(id: id, invoiceNo: invoiceNo, total: total, paid: newPaid, paymentType: paymentType, date: date, customerId: customerId, lines: lines, subtotal: subtotal, discountAmount: discountAmount, taxRate: taxRate, taxAmount: taxAmount, invoicePaid: invoicePaid ?? paid);
}


class SaleSummary {
  final int id; final String invoiceNo; final double total; final double paid; final String paymentType; final DateTime date; final String? customerName;
  const SaleSummary({required this.id,required this.invoiceNo,required this.total,required this.paid,required this.paymentType,required this.date,required this.customerName});
}

class SaleRepository {
  Future<ItemRecord?> findItemByBarcode(String code) async {
    final db = await AppDatabase.instance.database;
    final rows = await db.rawQuery('''SELECT i.*, c.name AS category_name FROM ${DBConstants.tableItems} i LEFT JOIN ${DBConstants.tableItemCategories} c ON c.id=i.category_id WHERE i.barcode=? LIMIT 1''', [code.trim()]);
    if (rows.isEmpty) return null;
    final r = rows.first;
    return ItemRecord(id: r['id'] as int, name: r['name'] as String, categoryId: r['category_id'] as int?, category: (r['category_name'] as String?) ?? 'General', unit: r['unit'] as String, qty: (r['qty'] as num).toDouble(), lowStock: (r['low_stock'] as num).toDouble(), price: (r['price'] as num).toDouble(), imagePath: r['image_path'] as String?, barcode: r['barcode'] as String?, supplierId: r['supplier_id'] as int?, purchaseType: r['purchase_type'] as String?, purchaseAmount: (r['purchase_amount'] as num?)?.toDouble() ?? 0, purchaseUnitPrice: (r['purchase_unit_price'] as num?)?.toDouble() ?? 0, purchasePaid: (r['purchase_paid'] as num?)?.toDouble() ?? 0, purchaseDate: r['purchase_date'] == null ? null : DateTime.tryParse(r['purchase_date'] as String), trackStock: ((r['track_stock'] as num?) ?? 1) != 0, outerUnit: r['outer_unit'] as String?, innerUnit: r['inner_unit'] as String?, unitsPerOuter: (r['units_per_outer'] as num?)?.toDouble() ?? 1);
  }

  Future<SavedSale> saveSale({required List<SaleLine> lines, int? customerId, required String paymentType, required double paidAmount, double? totalOverride, double discountAmount = 0}) async {
    try {
    if (lines.isEmpty) throw ArgumentError('Add at least one product.');
    final db = await AppDatabase.instance.database;
    final calc = SaleCalc.compute(
      subtotal: lines.fold<double>(0, (sum, line) => sum + line.total),
      cogs: lines.fold<double>(0, (sum, line) => sum + line.totalCost),
      discount: discountAmount,
      totalOverride: totalOverride,
    );
    final calculatedTotal = calc.subtotal;
    final safeDiscount = calc.discount;
    const safeTaxRate = 0.0; // tax system removed
    const calculatedTax = 0.0;
    final total = calc.total;
    if (paymentType == 'credit' && customerId == null) throw ArgumentError('Customer is required for credit sale.');
    if (paidAmount < 0 || paidAmount > total) throw ArgumentError('Invalid paid amount.');
    final now = DateTime.now();
    final invoiceNo = 'INV-${DateFormatLike(now)}-${now.microsecondsSinceEpoch.toString().substring(8)}';
    late int saleId;
    final affectedItemIds = <int>{};
    final stockBeforeSale = <int, double>{};
    await db.transaction((txn) async {
      // Validate the complete requested quantity per item before writing
      // anything. This prevents duplicate cart lines from overselling stock.
      final requested = <int, double>{};
      for (final line in lines) {
        if (line.qty <= 0) throw ArgumentError('Invalid quantity for ${line.item.name}.');
        requested[line.item.id] = (requested[line.item.id] ?? 0) + line.qty;
      }
      for (final entry in requested.entries) {
        final rows = await txn.query(DBConstants.tableItems, columns: ['name', 'qty', 'track_stock'], where: 'id=?', whereArgs: [entry.key], limit: 1);
        if (rows.isEmpty) throw ArgumentError('Product not found.');
        if (((rows.first['track_stock'] as num?) ?? 1) == 0) continue; // quantity not managed
        final available = (rows.first['qty'] as num).toDouble();
        stockBeforeSale[entry.key] = available;
        if (available <= 0) throw ArgumentError('Out of stock: ${rows.first['name']}.');
        if (entry.value > available + 0.000001) throw ArgumentError('Not enough stock for ${rows.first['name']}. Available: $available.');
      }
      saleId = await txn.insert(DBConstants.tableSaleInvoices, {'invoice_no': invoiceNo, 'customer_id': customerId, 'payment_type': paymentType, 'total': total, 'subtotal': calculatedTotal, 'discount_amount': safeDiscount, 'tax_rate': safeTaxRate, 'tax_amount': calculatedTax, 'paid_amount': paidAmount, 'date': now.toIso8601String(), 'created_at': now.toIso8601String()});
      for (final line in lines) {
        await txn.insert(DBConstants.tableSaleItems, {'sale_id': saleId, 'item_id': line.item.id, 'item_name': line.item.name, 'qty': line.qty, 'unit_price': line.unitPrice, 'unit_cost': line.unitCost, 'total': line.total});
        await txn.rawUpdate('UPDATE ${DBConstants.tableItems} SET qty = qty - ?, updated_at = ? WHERE id=? AND track_stock = 1', [line.qty, now.toIso8601String(), line.item.id]);
        affectedItemIds.add(line.item.id);
      }
    });
    for (final itemId in affectedItemIds) {
      final item = await _itemById(itemId);
      if (item != null) {
        final before = stockBeforeSale[itemId];
        final crossedIntoLow = before != null && item.lowStock > 0 && before > item.lowStock && item.qty <= item.lowStock;
        await NotificationService.instance.syncLowStockForItem(item, createEvent: crossedIntoLow);
      }
    }
    return SavedSale(id: saleId, invoiceNo: invoiceNo, total: total, paid: paidAmount, paymentType: paymentType, date: now, customerId: customerId, lines: lines.map((e) => e.copy()).toList(), subtotal: calculatedTotal, discountAmount: safeDiscount, taxRate: safeTaxRate, taxAmount: calculatedTax);
      } finally {
      DataEvents.changed();
    }
  }




  Future<SavedSale> updateSale({required int id, required List<SaleLine> lines, int? customerId, required String paymentType, required double paidAmount, double? totalOverride, double discountAmount = 0}) async {
    try {
    if (lines.isEmpty) throw ArgumentError('Add at least one product.');
    final db = await AppDatabase.instance.database;
    final calc = SaleCalc.compute(
      subtotal: lines.fold<double>(0, (sum, line) => sum + line.total),
      cogs: lines.fold<double>(0, (sum, line) => sum + line.totalCost),
      discount: discountAmount,
      totalOverride: totalOverride,
    );
    final calculatedTotal = calc.subtotal;
    final safeDiscount = calc.discount;
    const safeTaxRate = 0.0; // tax system removed
    const calculatedTax = 0.0;
    final total = calc.total;
    if (paymentType == 'credit' && customerId == null) throw ArgumentError('Customer is required for credit sale.');
    if (paidAmount < 0 || paidAmount > total) throw ArgumentError('Invalid paid amount.');
    final invoiceRows = await db.query(DBConstants.tableSaleInvoices, where: 'id=?', whereArgs: [id], limit: 1);
    if (invoiceRows.isEmpty) throw ArgumentError('Sale not found.');
    final oldInvoice = invoiceRows.first;
    final oldInvoiceNo = oldInvoice['invoice_no'] as String;
    final now = DateTime.now();
    final affectedItemIds = <int>{};
    final stockBeforeSale = <int, double>{};
    await db.transaction((txn) async {
      final oldLines = await txn.query(DBConstants.tableSaleItems, where: 'sale_id=?', whereArgs: [id]);
      for (final old in oldLines) {
        affectedItemIds.add(old['item_id'] as int);
        final oldQty = (old['qty'] as num).toDouble();
        await txn.rawUpdate('UPDATE ${DBConstants.tableItems} SET qty = qty + ?, updated_at = ? WHERE id = ? AND track_stock = 1', [oldQty, now.toIso8601String(), old['item_id']]);
      }
      final requested = <int, double>{};
      for (final line in lines) {
        if (line.qty <= 0) throw ArgumentError('Invalid quantity for ${line.item.name}.');
        requested[line.item.id] = (requested[line.item.id] ?? 0) + line.qty;
      }
      for (final entry in requested.entries) {
        final itemRows = await txn.query(DBConstants.tableItems, columns: ['name', 'qty', 'track_stock'], where: 'id=?', whereArgs: [entry.key], limit: 1);
        if (itemRows.isEmpty) throw ArgumentError('Product not found.');
        if (((itemRows.first['track_stock'] as num?) ?? 1) == 0) continue; // quantity not managed
        final available = (itemRows.first['qty'] as num).toDouble();
        stockBeforeSale[entry.key] = available;
        if (available <= 0) throw ArgumentError('Out of stock: ${itemRows.first['name']}.');
        if (entry.value > available + 0.000001) throw ArgumentError('Not enough stock for ${itemRows.first['name']}. Available: $available.');
      }
      await txn.update(DBConstants.tableSaleInvoices, {'customer_id': customerId, 'payment_type': paymentType, 'total': total, 'subtotal': calculatedTotal, 'discount_amount': safeDiscount, 'tax_rate': safeTaxRate, 'tax_amount': calculatedTax, 'paid_amount': paidAmount, 'date': now.toIso8601String()}, where: 'id=?', whereArgs: [id]);
      await txn.delete(DBConstants.tableSaleItems, where: 'sale_id=?', whereArgs: [id]);
      for (final line in lines) {
        affectedItemIds.add(line.item.id);
        await txn.insert(DBConstants.tableSaleItems, {'sale_id': id, 'item_id': line.item.id, 'item_name': line.item.name, 'qty': line.qty, 'unit_price': line.unitPrice, 'unit_cost': line.unitCost, 'total': line.total});
        await txn.rawUpdate('UPDATE ${DBConstants.tableItems} SET qty = qty - ?, updated_at = ? WHERE id = ? AND track_stock = 1', [line.qty, now.toIso8601String(), line.item.id]);
      }
      // Replace the sale-linked ledger/account transactions so edits remain connected.
      // Reverse the cash/account effect of the old sale BEFORE removing its
      // rows, otherwise the account balance would count the old payment twice
      // once the edited sale re-posts its own entries.
      Future<void> reverseCash(int cashId) async {
        final cash = await txn.query(DBConstants.tableTransactions, where: 'id = ?', whereArgs: [cashId], limit: 1);
        if (cash.isEmpty) return;
        final amount = (cash.first['amount'] as num).toDouble();
        final accountId = cash.first['account_id'] as int;
        final isIncome = cash.first['type'] == 'income';
        await txn.rawUpdate('UPDATE ${DBConstants.tableAccounts} SET current_balance = current_balance + ?, updated_at = ? WHERE id = ?', [isIncome ? -amount : amount, now.toIso8601String(), accountId]);
        await txn.delete(DBConstants.tableTransactions, where: 'id = ?', whereArgs: [cashId]);
      }
      final oldLedgerRows = await txn.query(DBConstants.tableLedgerTransactions, columns: ['id', 'cash_transaction_id'], where: 'note IN (?, ?)', whereArgs: ['Sale $oldInvoiceNo', 'Payment for $oldInvoiceNo']);
      for (final r in oldLedgerRows) {
        final cashId = r['cash_transaction_id'] as int?;
        if (cashId != null) await reverseCash(cashId);
      }
      await txn.delete(DBConstants.tableLedgerTransactions, where: 'note IN (?, ?)', whereArgs: ['Sale $oldInvoiceNo', 'Payment for $oldInvoiceNo']);
      final oldCashRows = await txn.query(DBConstants.tableTransactions, columns: ['id'], where: 'source = ? AND note = ?', whereArgs: ['Sale', oldInvoiceNo]);
      for (final r in oldCashRows) {
        await reverseCash(r['id'] as int);
      }
    });
    for (final itemId in affectedItemIds) {
      final item = await _itemById(itemId);
      if (item != null) {
        final before = stockBeforeSale[itemId];
        final crossedIntoLow = before != null && item.lowStock > 0 && before > item.lowStock && item.qty <= item.lowStock;
        await NotificationService.instance.syncLowStockForItem(item, createEvent: crossedIntoLow);
      }
    }
    return SavedSale(id:id, invoiceNo:oldInvoiceNo, total:total, paid:paidAmount, paymentType:paymentType, date:now, customerId:customerId, lines:lines.map((e)=>e.copy()).toList(), subtotal:calculatedTotal, discountAmount:safeDiscount, taxRate:safeTaxRate, taxAmount:calculatedTax);
      } finally {
      DataEvents.changed();
    }
  }
  Future<SavedSale?> getSaleById(int saleId) async {
    final db = await AppDatabase.instance.database;
    final invoiceRows = await db.query(DBConstants.tableSaleInvoices, where: 'id = ?', whereArgs: [saleId], limit: 1);
    if (invoiceRows.isEmpty) return null;
    final r = invoiceRows.first;
    final lineRows = await db.query(DBConstants.tableSaleItems, where: 'sale_id = ?', whereArgs: [saleId], orderBy: 'id ASC');
    final lines = <SaleLine>[];
    for (final row in lineRows) {
      final itemId = row['item_id'] as int;
      final itemRows = await db.rawQuery('SELECT i.*, c.name AS category_name FROM ${DBConstants.tableItems} i LEFT JOIN ${DBConstants.tableItemCategories} c ON c.id=i.category_id WHERE i.id=? LIMIT 1', [itemId]);
      if (itemRows.isEmpty) {
        // The product was deleted after this sale. Keep the invoice line from the
        // saved sale snapshot so old bills still show every item and the right total.
        final snap = ItemRecord(id: itemId, name: row['item_name'] as String, categoryId: null, category: 'General', unit: '', qty: 0, lowStock: 0, price: (row['unit_price'] as num).toDouble(), imagePath: null, barcode: null, supplierId: null, purchaseType: null, purchaseAmount: 0, purchaseUnitPrice: (row['unit_cost'] as num?)?.toDouble() ?? 0, purchasePaid: 0, purchaseDate: null);
        lines.add(SaleLine(item: snap, qty: (row['qty'] as num).toDouble(), unitPrice: (row['unit_price'] as num).toDouble(), unitCost: (row['unit_cost'] as num?)?.toDouble() ?? 0, retailPrice: (row['unit_price'] as num).toDouble()));
        continue;
      }
      final ir = itemRows.first;
      final item = ItemRecord(
        id: itemId,
        name: row['item_name'] as String,
        categoryId: ir['category_id'] as int?,
        category: (ir['category_name'] as String?) ?? 'General',
        unit: ir['unit'] as String,
        qty: (ir['qty'] as num).toDouble(),
        lowStock: (ir['low_stock'] as num).toDouble(),
        price: (row['unit_price'] as num).toDouble(),
        imagePath: ir['image_path'] as String?,
        barcode: ir['barcode'] as String?,
        supplierId: ir['supplier_id'] as int?,
        purchaseType: ir['purchase_type'] as String?,
        purchaseAmount: (ir['purchase_amount'] as num?)?.toDouble() ?? 0,
        purchaseUnitPrice: (ir['purchase_unit_price'] as num?)?.toDouble() ?? 0,
        purchasePaid: (ir['purchase_paid'] as num?)?.toDouble() ?? 0,
        purchaseDate: ir['purchase_date'] == null ? null : DateTime.tryParse(ir['purchase_date'] as String),
        trackStock: ((ir['track_stock'] as num?) ?? 1) != 0,
        outerUnit: ir['outer_unit'] as String?, innerUnit: ir['inner_unit'] as String?, unitsPerOuter: (ir['units_per_outer'] as num?)?.toDouble() ?? 1,
      );
      lines.add(SaleLine(item: item, qty: (row['qty'] as num).toDouble(), unitPrice: (row['unit_price'] as num).toDouble(), unitCost: (row['unit_cost'] as num?)?.toDouble() ?? item.purchaseUnitPrice, retailPrice: (ir['price'] as num).toDouble()));
    }
    final settled = await SaleSettlement.paidBySale(db);
    final rawPaid = (r['paid_amount'] as num).toDouble();
    return SavedSale(
      id: saleId,
      invoiceNo: r['invoice_no'] as String,
      total: (r['total'] as num).toDouble(),
      paid: settled[saleId] ?? rawPaid,
      invoicePaid: rawPaid,
      paymentType: r['payment_type'] as String,
      date: DateTime.parse(r['date'] as String),
      customerId: r['customer_id'] as int?,
      lines: lines,
      subtotal: (r['subtotal'] as num?)?.toDouble() ?? (r['total'] as num).toDouble(),
      discountAmount: (r['discount_amount'] as num?)?.toDouble() ?? 0,
      taxRate: (r['tax_rate'] as num?)?.toDouble() ?? 0,
      taxAmount: (r['tax_amount'] as num?)?.toDouble() ?? 0,
    );
  }
  /// Live paid amount of one invoice (sale-time payment + later receipts).
  Future<double> settledPaid(int saleId) async {
    final db = await AppDatabase.instance.database;
    final settled = await SaleSettlement.paidBySale(db);
    return settled[saleId] ?? 0;
  }

  Future<ItemRecord?> _itemById(int id) async {
    final db = await AppDatabase.instance.database;
    final rows = await db.rawQuery('SELECT i.*, c.name AS category_name FROM ${DBConstants.tableItems} i LEFT JOIN ${DBConstants.tableItemCategories} c ON c.id=i.category_id WHERE i.id=? LIMIT 1', [id]);
    if (rows.isEmpty) return null;
    final r = rows.first;
    return ItemRecord(
      id: r['id'] as int, name: r['name'] as String, categoryId: r['category_id'] as int?,
      category: (r['category_name'] as String?) ?? 'General', unit: r['unit'] as String,
      qty: (r['qty'] as num).toDouble(), lowStock: (r['low_stock'] as num).toDouble(),
      price: (r['price'] as num).toDouble(), imagePath: r['image_path'] as String?, barcode: r['barcode'] as String?,
      supplierId: r['supplier_id'] as int?, purchaseType: r['purchase_type'] as String?,
      purchaseAmount: (r['purchase_amount'] as num?)?.toDouble() ?? 0, purchaseUnitPrice: (r['purchase_unit_price'] as num?)?.toDouble() ?? 0,
      purchasePaid: (r['purchase_paid'] as num?)?.toDouble() ?? 0,
      purchaseDate: r['purchase_date'] == null ? null : DateTime.tryParse(r['purchase_date'] as String),
      trackStock: ((r['track_stock'] as num?) ?? 1) != 0,
      outerUnit: r['outer_unit'] as String?, innerUnit: r['inner_unit'] as String?, unitsPerOuter: (r['units_per_outer'] as num?)?.toDouble() ?? 1,
    );
  }

  Future<double> sumSalesInRange(DateTime from, DateTime to) async {
    final db = await AppDatabase.instance.database;
    final rows = await db.rawQuery(
      'SELECT COALESCE(SUM(total), 0) AS total FROM ${DBConstants.tableSaleInvoices} WHERE date >= ? AND date <= ?',
      [from.toIso8601String(), to.toIso8601String()],
    );
    return (rows.first['total'] as num).toDouble();
  }

  Future<List<SaleSummary>> recentSales({int limit=50}) async {
    final db=await AppDatabase.instance.database;
    final rows=await db.rawQuery('''SELECT s.*, p.name AS customer_name FROM ${DBConstants.tableSaleInvoices} s LEFT JOIN ${DBConstants.tableLedgerParties} p ON p.id=s.customer_id ORDER BY s.date DESC, s.id DESC LIMIT ?''',[limit]);
    final settled = await SaleSettlement.paidBySale(db);
    return rows.map((r)=>SaleSummary(id:r['id'] as int,invoiceNo:r['invoice_no'] as String,total:(r['total'] as num).toDouble(),paid:settled[r['id'] as int]??(r['paid_amount'] as num).toDouble(),paymentType:r['payment_type'] as String,date:DateTime.parse(r['date'] as String),customerName:r['customer_name'] as String?)).toList();
  }
  Future<double> todayTotal() async { final db=await AppDatabase.instance.database; final now=DateTime.now(); final start=DateTime(now.year,now.month,now.day).toIso8601String(); final end=DateTime(now.year,now.month,now.day,23,59,59,999).toIso8601String(); final r=await db.rawQuery('SELECT COALESCE(SUM(total),0) total FROM ${DBConstants.tableSaleInvoices} WHERE date>=? AND date<=?',[start,end]); return (r.first['total'] as num).toDouble(); }
  /// Realized profit/loss, calculated PER INVOICE:
  ///   invoice result = (total - tax) - cost of goods sold
  /// A bill sold below cost is a loss; a bill above cost is a profit.
  /// [profit] = sum of all profitable bills, [loss] = sum of all loss bills,
  /// [net] = profit - loss. COGS uses the cost snapshot stored on every sale
  /// line, so later item price edits never rewrite history.
  Future<({double profit, double loss, double net})> profitLossInRange(DateTime from, DateTime to) async {
    final db = await AppDatabase.instance.database;
    final rows = await db.rawQuery('''
      SELECT
        (COALESCE(s.total, 0) - COALESCE(s.tax_amount, 0)) - COALESCE(c.cogs, 0) AS result
      FROM ${DBConstants.tableSaleInvoices} s
      LEFT JOIN (
        SELECT sale_id, SUM(COALESCE(qty, 0) * COALESCE(unit_cost, 0)) AS cogs
        FROM ${DBConstants.tableSaleItems}
        GROUP BY sale_id
      ) c ON c.sale_id = s.id
      WHERE s.date >= ? AND s.date <= ?
    ''', [from.toIso8601String(), to.toIso8601String()]);
    double profit = 0;
    double loss = 0;
    for (final r in rows) {
      final v = (r['result'] as num?)?.toDouble() ?? 0;
      if (v > 0.005) {
        profit += v;
      } else if (v < -0.005) {
        loss += -v;
      }
    }
    profit = SaleCalc.r2(profit);
    loss = SaleCalc.r2(loss);
    return (profit: profit, loss: loss, net: SaleCalc.r2(profit - loss));
  }

  Future<int> todayCashSales() async {
    final db=await AppDatabase.instance.database;
    final now=DateTime.now();
    final start=DateTime(now.year,now.month,now.day).toIso8601String();
    final end=DateTime(now.year,now.month,now.day,23,59,59,999).toIso8601String();
    final r=await db.rawQuery('SELECT COUNT(*) c FROM ${DBConstants.tableSaleInvoices} WHERE payment_type=? AND date>=? AND date<=?',['cash',start,end]);
    return (r.first['c'] as num).toInt();
  }

  Future<int> todayCreditSales() async {
    final db=await AppDatabase.instance.database;
    final now=DateTime.now();
    final start=DateTime(now.year,now.month,now.day).toIso8601String();
    final end=DateTime(now.year,now.month,now.day,23,59,59,999).toIso8601String();
    final r=await db.rawQuery('SELECT COUNT(*) c FROM ${DBConstants.tableSaleInvoices} WHERE payment_type=? AND date>=? AND date<=?',['credit',start,end]);
    return (r.first['c'] as num).toInt();
  }

  Future<int> todayCustomers() async { final db=await AppDatabase.instance.database; final now=DateTime.now(); final start=DateTime(now.year,now.month,now.day).toIso8601String(); final end=DateTime(now.year,now.month,now.day,23,59,59,999).toIso8601String(); final r=await db.rawQuery('SELECT COUNT(DISTINCT customer_id) c FROM ${DBConstants.tableSaleInvoices} WHERE customer_id IS NOT NULL AND date>=? AND date<=?',[start,end]); return (r.first['c'] as num).toInt(); }

  Future<List<Map<String, Object?>>> getCustomers() async {
    final db = await AppDatabase.instance.database;
    return db.query(DBConstants.tableLedgerParties, where: 'type=?', whereArgs: ['customer'], orderBy: 'name COLLATE NOCASE');
  }
}

String DateFormatLike(DateTime d) => '${d.year.toString().padLeft(4, '0')}${d.month.toString().padLeft(2, '0')}${d.day.toString().padLeft(2, '0')}';
