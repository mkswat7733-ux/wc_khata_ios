import 'package:sqflite/sqflite.dart';

import '../../core/database/database_constants.dart';

/// Single source of truth for "how much of each customer invoice has really
/// been paid".
///
/// An invoice stores only what was paid AT THE TIME of the sale
/// (`paid_amount`). Money the customer hands over later is recorded in the
/// customer ledger as a manual "Receive" entry, so every screen that shows an
/// invoice's Paid / Balance must add those later receipts back in, otherwise
/// the khata is cleared but the report still shows the bill as pending.
///
/// Later receipts are applied oldest-debt-first (FIFO) per customer, where a
/// customer's debts are their unpaid invoice balances plus any manual
/// "Pay" (opening / old balance) entries. The result is always derived from
/// the live ledger, so editing or deleting a receipt immediately corrects
/// every report.
class SaleSettlement {
  SaleSettlement._();

  static double _r2(double v) => (v * 100).roundToDouble() / 100;

  /// sale invoice id -> amount really received so far (never above total).
  static Future<Map<int, double>> paidBySale(DatabaseExecutor db) async {
    final invoices = await db.query(
      DBConstants.tableSaleInvoices,
      columns: ['id', 'customer_id', 'total', 'paid_amount', 'date'],
      orderBy: 'date ASC, id ASC',
    );
    final result = <int, double>{};
    final byCustomer = <int, List<Map<String, Object?>>>{};
    for (final r in invoices) {
      final id = r['id'] as int;
      result[id] = (r['paid_amount'] as num?)?.toDouble() ?? 0;
      final customerId = r['customer_id'] as int?;
      if (customerId != null) byCustomer.putIfAbsent(customerId, () => []).add(r);
    }
    if (byCustomer.isEmpty) return result;

    final manual = await db.query(
      DBConstants.tableLedgerTransactions,
      columns: ['party_id', 'type', 'amount', 'date'],
      where: 'COALESCE(is_system, 0) = 0 AND deleted_at IS NULL',
      orderBy: 'date ASC, id ASC',
    );
    final pool = <int, double>{};
    final oldDebts = <int, List<_Debt>>{};
    for (final m in manual) {
      final partyId = m['party_id'] as int;
      if (!byCustomer.containsKey(partyId)) continue;
      final amount = (m['amount'] as num?)?.toDouble() ?? 0;
      if (m['type'] == 'receive') {
        pool[partyId] = (pool[partyId] ?? 0) + amount;
      } else {
        oldDebts.putIfAbsent(partyId, () => []).add(
          _Debt(DateTime.tryParse(m['date'] as String? ?? '') ?? DateTime(2000), null, amount),
        );
      }
    }

    for (final entry in byCustomer.entries) {
      var money = pool[entry.key] ?? 0;
      if (money <= 0.004) continue;
      final debts = <_Debt>[...?oldDebts[entry.key]];
      for (final inv in entry.value) {
        final id = inv['id'] as int;
        final total = (inv['total'] as num?)?.toDouble() ?? 0;
        final outstanding = total - (result[id] ?? 0);
        if (outstanding > 0.004) {
          debts.add(_Debt(DateTime.tryParse(inv['date'] as String? ?? '') ?? DateTime(2000), id, outstanding));
        }
      }
      debts.sort((a, b) => a.date.compareTo(b.date));
      for (final d in debts) {
        if (money <= 0.004) break;
        final take = money < d.amount ? money : d.amount;
        money -= take;
        if (d.saleId != null) result[d.saleId!] = _r2((result[d.saleId!] ?? 0) + take);
      }
    }
    return result;
  }
}

class _Debt {
  final DateTime date;
  final int? saleId;
  final double amount;
  const _Debt(this.date, this.saleId, this.amount);
}
