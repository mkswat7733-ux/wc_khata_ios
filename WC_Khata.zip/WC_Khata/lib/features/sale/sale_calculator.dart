/// Single source of truth for every sale formula in the app.
///
///   subtotal = sum(qty * sale price)
///   discount = clamp(discount, 0, subtotal)
///   total    = subtotal - discount        (what the customer pays)
///   cogs     = sum(qty * cost price)      (cost snapshot of the sale)
///   profit   = total - cogs               (negative value = LOSS)
///
/// If the user manually overrides the final bill total, that value becomes
/// the total and profit/loss is calculated from it.
/// (The tax system has been removed from the app.)
class SaleBreakdown {
  final double subtotal;
  final double discount;
  final double total;
  final double cogs;
  final double profit;
  final bool isOverridden;

  const SaleBreakdown({
    required this.subtotal,
    required this.discount,
    required this.total,
    required this.cogs,
    required this.profit,
    required this.isOverridden,
  });

  bool get isLoss => profit < -0.005;
  bool get isProfit => profit > 0.005;
  double get profitAbs => profit.abs();
}

class SaleCalc {
  SaleCalc._();

  /// Rounds to 2 decimals so stored values never carry float noise.
  static double r2(double v) => (v * 100).roundToDouble() / 100;

  static SaleBreakdown compute({
    required double subtotal,
    required double cogs,
    double discount = 0,
    double? totalOverride,
  }) {
    final sub = r2(subtotal < 0 ? 0 : subtotal);
    final disc = r2(discount.clamp(0, sub).toDouble());
    final overridden = totalOverride != null;
    final total = overridden ? r2(totalOverride < 0 ? 0 : totalOverride) : r2(sub - disc);
    final cost = r2(cogs);
    return SaleBreakdown(
      subtotal: sub,
      discount: disc,
      total: total,
      cogs: cost,
      profit: r2(total - cost),
      isOverridden: overridden,
    );
  }
}
