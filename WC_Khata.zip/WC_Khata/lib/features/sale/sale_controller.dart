import 'package:flutter/foundation.dart';
import 'sale_repository.dart';
import '../reports/profit_loss_service.dart';

class SaleController extends ChangeNotifier {
  final SaleRepository _repo = SaleRepository();
  bool isLoading=true; bool hasLoadedOnce=false;
  double todaySales=0; int todayCustomers=0; int todayCashSales=0; int todayCreditSales=0; double profit=0; double loss=0;
  List<SaleSummary> recentSales=const [];
  Future<void> load() async {if(!hasLoadedOnce){isLoading=true;notifyListeners();}await _fetch();isLoading=false;hasLoadedOnce=true;notifyListeners();}
  Future<void> refresh() async {await _fetch();notifyListeners();}
  Future<void> _fetch() async {
    final now = DateTime.now();
    final start = DateTime(now.year, now.month, now.day);
    final end = DateTime(now.year, now.month, now.day, 23, 59, 59, 999);
    todaySales = await _repo.todayTotal();
    todayCustomers = await _repo.todayCustomers();
    todayCashSales = await _repo.todayCashSales();
    todayCreditSales = await _repo.todayCreditSales();
    recentSales = await _repo.recentSales();
    final pl = await ProfitLossService().forRange(start, end);
    profit = pl.profit;
    loss = pl.loss;
  }
  void dispose() {super.dispose();}
}
