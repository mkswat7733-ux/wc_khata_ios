import 'dart:io';
import 'dart:ui' as ui;

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../app/theme/app_theme.dart';
import '../../core/widgets/app_glass_icon_button.dart';
import '../items/item_repository.dart';
import '../purchases/purchases_screen.dart';
import 'bill_context.dart';
import 'bill_paper.dart';
import 'invoice_pdf_builder.dart';
import 'new_sale_screen.dart';
import 'sale_repository.dart';
import 'thermal_receipt.dart';
import 'thermal_receipt_text.dart';
import '../../core/services/thermal_printer_service.dart';
import '../printer/printer_gate.dart';
import '../printer/receipt_designer_screen.dart';
import '../printer/receipt_settings.dart';
import '../../core/widgets/app_message.dart';

/// After a sale (or for a product purchase): three tabs, one per paper size.
///  - 58mm: compact thermal receipt, prints on the connected Bluetooth printer.
///  - 80mm: wide thermal receipt with columns, same printer, wider roll.
///  - A4  : proper mart-style invoice PDF, printed with the system printer.
/// Every tab can also be shared / saved as a PDF in its own exact paper size.
class SaleInvoiceScreen extends StatefulWidget {
  final SavedSale sale;
  final String? customerName;

  /// When set, this screen shows the PURCHASE receipt/invoice of that product.
  final ItemRecord? purchaseItem;

  /// True for a multi-item purchase bill: [sale] is the bill and
  /// [customerName] is the supplier.
  final bool isPurchaseBill;

  const SaleInvoiceScreen({super.key, required this.sale, this.customerName, this.purchaseItem, this.isPurchaseBill = false});

  @override
  State<SaleInvoiceScreen> createState() => _SaleInvoiceScreenState();
}

class _SaleInvoiceScreenState extends State<SaleInvoiceScreen> {
  static const MethodChannel _native = MethodChannel('wc_khata/whatsapp');
  static const String _paperPref = 'bill_paper_tab';

  final GlobalKey _receiptKey = GlobalKey();

  bool get _isPurchase => widget.purchaseItem != null || widget.isPurchaseBill;
  String get _filePrefix => _isPurchase ? 'Purchase' : 'Invoice';

  BillContext? _bill;
  bool _loadFailed = false;
  bool _busy = false;
  String? _busyAction; // only the pressed button shows the spinner
  BillPaper _paper = BillPaper.mm58; // selected tab: 58mm / 80mm / A4
  Future<Uint8List>? _invoiceBytes;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    try {
      await ReceiptSettingsService.instance.load();
    } catch (_) {}
    try {
      final prefs = await SharedPreferences.getInstance();
      final saved = prefs.getString(_paperPref);
      if (saved != null) {
        _paper = BillPaper.fromName(saved);
      } else {
        // First time on the new tabs: start from the paper the printer uses.
        _paper = BillPaper.fromThermalMm(prefs.getInt(ThermalPrinterService.paperPref));
      }
    } catch (_) {}
    try {
      final purchase = widget.purchaseItem;
      final bill = purchase != null
          ? await BillContext.loadPurchase(purchase)
          : widget.isPurchaseBill
              ? await BillContext.loadPurchaseBill(widget.sale, widget.customerName)
              : await BillContext.load(widget.sale, widget.customerName);
      if (!mounted) return;
      setState(() => _bill = bill);
    } catch (_) {
      if (mounted) setState(() => _loadFailed = true);
    }
  }

  Future<void> _setPaper(BillPaper paper) async {
    if (paper == _paper) return;
    setState(() => _paper = paper);
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_paperPref, paper.name);
    } catch (_) {}
    // Thermal tabs also tell the printer which roll is loaded (58 / 80).
    final mm = paper.thermalMm;
    if (mm != null) await ThermalPrinterService.instance.setPaper(mm);
  }

  Future<Uint8List> _invoicePdf() => _invoiceBytes ??= InvoicePdfBuilder.build(_bill!);

  void _snack(String msg) {
    if (!mounted) return;
    AppMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(msg)));
  }

  Future<void> _guard(String key, Future<void> Function() action, String errorMessage, {bool printerErrors = false}) async {
    if (_busy || _bill == null) return;
    setState(() { _busy = true; _busyAction = key; });
    try {
      await action();
    } on PrinterException catch (e) {
      _snack(printerErrors ? e.message : errorMessage);
    } catch (_) {
      _snack(errorMessage);
    } finally {
      if (mounted) setState(() { _busy = false; _busyAction = null; });
    }
  }

  // ---------------------------------------------------------------- receipt

  Future<({Uint8List png, int width, int height})> _captureReceipt() async {
    await Future<void>.delayed(const Duration(milliseconds: 120));
    final boundary = _receiptKey.currentContext?.findRenderObject() as RenderRepaintBoundary?;
    if (boundary == null) throw StateError('Receipt is not ready.');
    final ui.Image image = await boundary.toImage(pixelRatio: 3.5);
    final ByteData? data = await image.toByteData(format: ui.ImageByteFormat.png);
    final w = image.width;
    final h = image.height;
    image.dispose();
    if (data == null) throw StateError('Could not create receipt image.');
    return (png: data.buffer.asUint8List(), width: w, height: h);
  }

  /// The receipt as a PDF whose page is exactly the thermal paper width
  /// (58mm / 80mm), so it prints, shares and saves identically.
  Future<({Uint8List bytes, PdfPageFormat format})> _receiptPdf() async {
    final cap = await _captureReceipt();
    final widthPt = _paper.mm * PdfPageFormat.mm;
    final heightPt = widthPt * cap.height / cap.width;
    final format = PdfPageFormat(widthPt, heightPt, marginAll: 0);
    final doc = pw.Document();
    final image = pw.MemoryImage(cap.png);
    doc.addPage(
      pw.Page(
        pageFormat: format,
        margin: pw.EdgeInsets.zero,
        build: (_) => pw.Image(image, fit: pw.BoxFit.fill),
      ),
    );
    return (bytes: await doc.save(), format: format);
  }

  String get _receiptFileName => '${_isPurchase ? 'PurchaseReceipt' : 'Receipt'}_${widget.sale.id}_${_paper.mm}mm.pdf';

  Future<File> _receiptFile(Uint8List bytes) async {
    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/$_receiptFileName');
    await file.writeAsBytes(bytes, flush: true);
    return file;
  }

  // Printing goes straight to the connected thermal printer (no system
  // print dialog). If no printer is connected the user is asked to connect.
  Future<void> _printReceipt() async {
    if (_busy || _bill == null) return;
    if (!await PrinterGate.ensure(context)) return;
    await _guard('print', () async {
      final svc = ThermalPrinterService.instance;
      // 80 mm: print the bill as printer text (tiny, instant, one continuous
      // run). Falls back to the picture when it has a logo / non-English text.
      if (await svc.canPrintText(_paper.mm)) {
        final design = ReceiptSettingsService.instance.value;
        final text = ThermalTextReceipt.build(
          bill: _bill!,
          design: design,
          columns: svc.dotsFor(_paper.mm) ~/ 12,
          logo: await svc.logoBlock(design, _paper.mm),
        );
        if (text != null) {
          await svc.printEscpos(text);
          _snack('Receipt sent to the printer.');
          return;
        }
      }
      final cap = await _captureReceipt();
      await ThermalPrinterService.instance.printPng(cap.png, paperMm: _paper.mm);
      _snack('Receipt sent to the printer.');
    }, 'Could not print receipt.', printerErrors: true);
  }

  Future<void> _shareReceipt() => _guard('share', () async {
        final pdf = await _receiptPdf();
        final file = await _receiptFile(pdf.bytes);
        await Share.shareXFiles([XFile(file.path, mimeType: 'application/pdf')], text: _isPurchase ? 'Purchase Receipt' : 'Receipt');
      }, 'Could not share receipt PDF.');

  Future<void> _downloadReceipt() => _guard('download', () async {
        final pdf = await _receiptPdf();
        await _savePdf(pdf.bytes, _receiptFileName);
      }, 'Could not save receipt PDF.');

  /// Lets the user choose WHERE to save (system "Save as" dialog: folder +
  /// file name). If that dialog is unavailable, falls back to the Downloads
  /// folder so the PDF is never lost.
  Future<void> _savePdf(Uint8List bytes, String fileName) async {
    try {
      final path = await FilePicker.platform.saveFile(
        dialogTitle: 'Save PDF',
        fileName: fileName,
        type: FileType.custom,
        allowedExtensions: const ['pdf'],
        bytes: bytes,
      );
      if (path == null) {
        _snack('Save cancelled.');
        return;
      }
      _snack('PDF saved successfully.');
      return;
    } catch (_) {
      // fall through to the Downloads folder
    }
    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/$fileName');
    await file.writeAsBytes(bytes, flush: true);
    final savedPath = await _native.invokeMethod<String>('saveInvoicePdf', {'path': file.path, 'fileName': fileName});
    _snack(switch (savedPath) {
      null => 'Could not save PDF. Please try again.',
      'permission_required' => 'Storage permission is required on this Android version. Please allow it and tap Download PDF again.',
      _ => 'PDF saved in Downloads.',
    });
  }

  // ---------------------------------------------------------------- invoice

  Future<File> _invoiceFile() async {
    final bytes = await _invoicePdf();
    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/${_filePrefix}_${widget.sale.id}.pdf');
    await file.writeAsBytes(bytes, flush: true);
    return file;
  }

  // A4 goes to a normal (system) printer - Wi-Fi / USB / PDF printer. It is NOT
  // squeezed onto the thermal roll any more: 58mm / 80mm have their own tabs.
  Future<void> _printInvoice() async {
    if (_busy || _bill == null) return;
    await _guard('print', () async {
      final bytes = await _invoicePdf();
      await Printing.layoutPdf(
        name: '${_filePrefix}_${widget.sale.id}.pdf',
        format: PdfPageFormat.a4,
        onLayout: (_) async => bytes,
      );
    }, 'Could not print invoice.');
  }

  Future<void> _shareInvoice() => _guard('share', () async {
        final file = await _invoiceFile();
        await Share.shareXFiles([XFile(file.path, mimeType: 'application/pdf')], text: 'Invoice');
      }, 'Could not share invoice PDF.');

  Future<void> _downloadInvoice() => _guard('download', () async {
        final bytes = await _invoicePdf();
        await _savePdf(bytes, '${_filePrefix}_${widget.sale.id}.pdf');
      }, 'Could not save PDF.');

  /// Opens Customize Receipt (logo, margins, header / footer); the preview here
  /// refreshes when the user comes back.
  Future<void> _openDesigner() async {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => const ReceiptDesignerScreen()));
    if (mounted) setState(() {});
  }

  Future<void> _editBill() async {
    final item = widget.purchaseItem;
    if (item == null) {
      Navigator.push(context, MaterialPageRoute(builder: (_) => NewSaleScreen(editingSale: widget.sale)));
      return;
    }
    // The purchase id is carried in the item's id (see PurchaseInvoiceScreen.asItem).
    final saved = await Navigator.push<bool>(context, MaterialPageRoute(builder: (_) => PurchasesScreen(editPurchaseId: item.id)));
    // Refresh by closing this stale bill.
    if (saved == true && mounted) Navigator.pop(context, true);
  }

  // ------------------------------------------------------------------ build

  @override
  Widget build(BuildContext context) {
    final double s = (MediaQuery.sizeOf(context).width / 390).clamp(.82, 1.2).toDouble();

    return Scaffold(
      backgroundColor: AppColors.lightBackground,
      body: Column(
        children: [
          SafeArea(
            bottom: false,
            child: Container(
              height: 62 * s,
              padding: EdgeInsets.symmetric(horizontal: 14 * s),
              decoration: const BoxDecoration(
                color: Colors.white,
                border: Border(bottom: BorderSide(color: AppColors.lightDivider)),
              ),
              child: Row(
                children: [
                  AppGlassIconButton(icon: Icons.arrow_back_rounded, onTap: () => Navigator.pop(context)),
                  Expanded(
                    child: Center(
                      child: Text(_isPurchase ? 'Purchase Receipt' : 'Invoice Receipt', style: TextStyle(fontSize: 20 * s, fontWeight: FontWeight.w900)),
                    ),
                  ),
                  if (_paper.isThermal)
                    AppGlassIconButton(icon: Icons.tune_rounded, onTap: _openDesigner)
                  else
                    SizedBox(width: 42 * s),
                ],
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.fromLTRB(14 * s, 12 * s, 14 * s, 0),
            child: _segmented(
              s,
              labels: [for (final p in BillPaper.values) p.label],
              selected: BillPaper.values.indexOf(_paper),
              onChanged: (i) => _setPaper(BillPaper.values[i]),
              height: 44,
            ),
          ),
          Padding(
            padding: EdgeInsets.only(top: 6 * s),
            child: Text(
              _paper.caption,
              style: TextStyle(fontSize: 11.5 * s, fontWeight: FontWeight.w600, color: AppColors.lightTextSecondary),
            ),
          ),
          SizedBox(height: 8 * s),
          Expanded(child: _buildBody(s)),
          _buildBottomBar(s),
        ],
      ),
    );
  }

  Widget _buildBody(double s) {
    if (_loadFailed) {
      return const Center(child: Text('Could not load the bill.'));
    }
    final bill = _bill;
    if (bill == null) return const Center(child: CircularProgressIndicator());

    if (_paper.isThermal) {
      // The receipt keeps its real design width (so what is captured is exactly
      // what prints) and is only SCALED on screen to fit this phone / tablet.
      final designWidth = ThermalReceipt.widthFor(_paper);
      return LayoutBuilder(
        builder: (context, constraints) {
          final available = constraints.maxWidth - 28 * s;
          final scale = (available / designWidth).clamp(0.5, 1.4).toDouble();
          return SingleChildScrollView(
            padding: EdgeInsets.fromLTRB(14 * s, 8 * s, 14 * s, 16 * s),
            child: Center(
              child: SizedBox(
                width: designWidth * scale,
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: .12), blurRadius: 16, offset: const Offset(0, 6))],
                  ),
                  child: FittedBox(
                    fit: BoxFit.contain,
                    child: RepaintBoundary(
                      key: _receiptKey,
                      child: ThermalReceipt(bill: bill, paper: _paper, design: ReceiptSettingsService.instance.value),
                    ),
                  ),
                ),
              ),
            ),
          );
        },
      );
    }

    return PdfPreview(
      key: const ValueKey('invoice_preview'),
      build: (_) => _invoicePdf(),
      useActions: false,
      canChangePageFormat: false,
      canChangeOrientation: false,
      canDebug: false,
      maxPageWidth: 700,
      pdfFileName: '${_filePrefix}_${widget.sale.id}.pdf',
      scrollViewDecoration: const BoxDecoration(color: AppColors.lightBackground),
    );
  }

  Widget _buildBottomBar(double s) {
    final isReceipt = _paper.isThermal;
    return Container(
      padding: EdgeInsets.fromLTRB(14 * s, 10 * s, 14 * s, 10 * s + MediaQuery.paddingOf(context).bottom),
      decoration: const BoxDecoration(color: Colors.white, border: Border(top: BorderSide(color: AppColors.lightDivider))),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(
            width: double.infinity,
            height: 50 * s,
            child: FilledButton.icon(
              onPressed: _busy || _bill == null ? null : (isReceipt ? _printReceipt : _printInvoice),
              icon: _busy && _busyAction == 'print'
                  ? SizedBox(width: 18 * s, height: 18 * s, child: const CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                  : const Icon(Icons.print_rounded),
              label: Text(isReceipt ? 'Print Invoice (${_paper.label})' : 'Print Invoice (A4)'),
              style: FilledButton.styleFrom(
                backgroundColor: AppColors.primary,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16 * s)),
                textStyle: TextStyle(fontSize: 15 * s, fontWeight: FontWeight.w800),
              ),
            ),
          ),
          SizedBox(height: 8 * s),
          Row(
            children: [
              Expanded(
                child: _outlined(
                  s,
                  key: 'share',
                  icon: Icons.share_rounded,
                  label: 'Share PDF',
                  onTap: isReceipt ? _shareReceipt : _shareInvoice,
                ),
              ),
              SizedBox(width: 8 * s),
              Expanded(child: _outlined(s, key: 'download', icon: Icons.download_rounded, label: 'Download PDF', onTap: isReceipt ? _downloadReceipt : _downloadInvoice)),
              SizedBox(width: 8 * s),
              Expanded(
                child: FilledButton.icon(
                  onPressed: () => Navigator.popUntil(context, (route) => route.isFirst),
                  icon: const Icon(Icons.check_rounded),
                  label: const Text('Done'),
                  style: FilledButton.styleFrom(
                    backgroundColor: Colors.black,
                    minimumSize: Size.fromHeight(46 * s),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14 * s)),
                  ),
                ),
              ),
            ],
          ),
          if (!widget.isPurchaseBill)
          TextButton.icon(
            onPressed: _editBill,
            icon: const Icon(Icons.edit_rounded, size: 18),
            label: Text(_isPurchase ? 'Edit Purchase' : 'Edit Invoice'),
            style: TextButton.styleFrom(foregroundColor: AppColors.primary, visualDensity: VisualDensity.compact),
          ),
        ],
      ),
    );
  }

  Widget _outlined(double s, {required String key, required IconData icon, required String label, required VoidCallback onTap}) {
    return OutlinedButton.icon(
      onPressed: _busy || _bill == null ? null : onTap,
      icon: _busy && _busyAction == key
          ? SizedBox(width: 18 * s, height: 18 * s, child: const CircularProgressIndicator(strokeWidth: 2))
          : Icon(icon, size: 19 * s),
      label: FittedBox(fit: BoxFit.scaleDown, child: Text(label)),
      style: OutlinedButton.styleFrom(
        foregroundColor: AppColors.lightTextPrimary,
        minimumSize: Size.fromHeight(46 * s),
        side: const BorderSide(color: AppColors.lightCardBorder),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14 * s)),
      ),
    );
  }

  Widget _segmented(
    double s, {
    required List<String> labels,
    required int selected,
    required ValueChanged<int> onChanged,
    required double height,
    bool small = false,
  }) {
    return Container(
      height: height * s,
      padding: EdgeInsets.all(3 * s),
      decoration: BoxDecoration(color: const Color(0xFFE7EBF3), borderRadius: BorderRadius.circular(16 * s)),
      child: Stack(
        children: [
          AnimatedAlign(
            duration: const Duration(milliseconds: 280),
            curve: Curves.easeOutCubic,
            alignment: Alignment(labels.length == 1 ? 0 : -1 + 2 * selected / (labels.length - 1), 0),
            child: FractionallySizedBox(
              widthFactor: 1 / labels.length,
              heightFactor: 1,
              child: Container(
                decoration: BoxDecoration(
                  gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF4C8DFF), AppColors.primary]),
                  borderRadius: BorderRadius.circular(13 * s),
                  boxShadow: [BoxShadow(color: AppColors.primary.withValues(alpha: 0.35), blurRadius: 8 * s, offset: Offset(0, 3 * s))],
                ),
              ),
            ),
          ),
          Row(
            children: [
              for (var i = 0; i < labels.length; i++)
                Expanded(
                  child: GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onTap: () => onChanged(i),
                    child: Center(
                      child: AnimatedDefaultTextStyle(
                        duration: const Duration(milliseconds: 250),
                        style: TextStyle(
                          color: i == selected ? Colors.white : AppColors.lightTextSecondary,
                          fontSize: (small ? 12.5 : 14) * s,
                          fontWeight: i == selected ? FontWeight.w800 : FontWeight.w600,
                        ),
                        child: Text(labels[i]),
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ],
      ),
    );
  }
}
