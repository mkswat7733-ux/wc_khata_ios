import '../../core/services/item_image_store.dart';
import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:provider/provider.dart';
import '../../app/theme/app_theme.dart';
import '../../core/utils/currency_formatter.dart';
import '../../core/widgets/app_glass_icon_button.dart';
import '../../core/services/scanner_sound_service.dart';
import '../items/product_scan_screen.dart';
import '../../core/services/scanner_settings_service.dart';
import '../../data/models/account_model.dart';
import '../../data/models/transaction_model.dart';
import '../../data/repositories/account_repository.dart';
import '../../data/repositories/transaction_repository.dart';
import '../ledger/both_star_badge.dart';
import '../ledger/ledger_party.dart';
import '../ledger/ledger_repository.dart';
import '../ledger/new_party_screen.dart';
import '../ledger/add_party_screen.dart';
import '../items/item_repository.dart';
import 'sale_repository.dart';
import 'sale_invoice_screen.dart';
import 'sale_price_editor_screen.dart';
import 'sale_calculator.dart';
import 'hidden_cost_box.dart';
import '../../core/widgets/app_message.dart';
import '../../core/services/sale_flow_service.dart';
import 'direct_bill_printer.dart';
import '../../core/utils/amount_limit.dart';

class NewSaleScreen extends StatefulWidget {
  final SavedSale? editingSale;
  const NewSaleScreen({super.key, this.editingSale});
  @override State<NewSaleScreen> createState() => _NewSaleScreenState();
}

class _NewSaleScreenState extends State<NewSaleScreen> with SingleTickerProviderStateMixin {
  final _repo = ItemRepository();
  final _saleRepo = SaleRepository();
  final _search = TextEditingController();
  final _scanner = MobileScannerController(detectionSpeed: DetectionSpeed.unrestricted);
  List<ItemRecord> _items = [];
  List<SaleLine> _cart = [];
  bool _loading = true;
  bool _scanning = false;
  String _query = '';
  String? _lastCode;
  DateTime? _lastScan;
  bool _autoCloseScanner = true;
  String _scanFeedback = 'none';
  bool _scanBusy = false;
  bool _cameraErrorReported = false;
  double? _billTotalOverride;
  late final AnimationController _scanAnimation;

  @override void initState() {
    super.initState();
    if (widget.editingSale != null) {
      _cart = widget.editingSale!.lines.map((e) => e.copy()).toList();
    }
    if (widget.editingSale != null) {
      // Legacy bills may carry old tax; tax is removed, so compare net amounts.
      final sale = widget.editingSale!;
      final expected = SaleCalc.compute(subtotal: _cart.fold<double>(0, (sum, e) => sum + e.total), cogs: 0, discount: sale.discountAmount).total;
      final net = sale.total - sale.taxAmount;
      _billTotalOverride = (net - expected).abs() > 0.01 ? net : null;
    }
    _scanAnimation = AnimationController(vsync: this, duration: const Duration(milliseconds: 1500))..repeat();
    unawaited(ScannerSoundService.instance.warmUp());
    _loadScannerSetting();
    _load();
  }
  Future<void> _loadScannerSetting() async {
    final value = await ScannerSettingsService.instance.getAutoClose();
    if (mounted) setState(() => _autoCloseScanner = value);
  }

  @override void dispose() { _scanAnimation.dispose(); _search.dispose(); _scanner.dispose(); super.dispose(); }
  Future<void> _load() async { final items = await _repo.getItems(); if (mounted) setState(() { _items = items; _loading = false; }); }

  /// Stock the user can really sell right now. When editing a bill, the qty
  /// already sold on that bill is returned to stock before re-saving.
  double _available(ItemRecord item) {
    if (!item.trackStock) return 1e9; // quantity not managed: never out of stock
    var a = item.qty;
    final old = widget.editingSale;
    if (old != null) {
      for (final l in old.lines) { if (l.item.id == item.id) a += l.qty; }
    }
    return a;
  }

  bool _canAdd(ItemRecord item) {
    final avail = _available(item);
    return avail > 0 && _inCart(item) + 1 <= avail + 0.000001;
  }

  double _inCart(ItemRecord item) {
    var q = 0.0;
    for (final l in _cart) { if (l.item.id == item.id) q += l.qty; }
    return q;
  }

  ItemRecord? _findItemByCode(String code){for(final e in _items){if(e.barcode==code)return e;}return null;}

  List<ItemRecord> get _filtered {
    final q = _query.trim().toLowerCase();
    if (q.isEmpty) return _items;
    return _items.where((e) => e.name.toLowerCase().contains(q) || (e.barcode ?? '').contains(q)).toList();
  }

  bool _add(ItemRecord item) {
    final avail = _available(item);
    if (avail <= 0) return false;
    final i = _cart.indexWhere((e) => e.item.id == item.id);
    if (i >= 0) {
      if (_cart[i].qty + 1 > avail + 0.000001) return false;
      _cart[i].qty += 1;
    } else {
      _cart.add(SaleLine(item: item));
    }
    setState(() { _billTotalOverride = null; });
    return true;
  }
  void _change(SaleLine line, double delta) {
    final max = _available(line.item);
    final next = line.qty + delta;
    if (next <= 0) { _cart.remove(line); } else if (next <= max + 0.000001) { line.qty = next; }
    setState(() { _billTotalOverride = null; });
  }

  Future<void> _closeScanner() async {
    if (!_scanning) return;
    try { await _scanner.stop(); } catch (_) {}
    if (mounted) setState(() { _scanning = false; _scanBusy = false; _scanFeedback = 'none'; });
  }

  Future<void> _handleScannerFailure({String message = 'Scanner error. Please try again.'}) async {
    if (_scanBusy || !_scanning || _cameraErrorReported) return;
    _cameraErrorReported = true;
    if (mounted) setState(() => _scanFeedback = 'error');
    unawaited(ScannerSoundService.instance.playBarcodeError());
    if (mounted) AppMessenger.of(context)..hideCurrentSnackBar()..showSnackBar(SnackBar(content: Text(message), duration: const Duration(milliseconds: 700)));
    if (_autoCloseScanner) {
      await Future<void>.delayed(const Duration(milliseconds: 350));
      await _closeScanner();
    } else {
      await Future<void>.delayed(const Duration(milliseconds: 700));
      if (mounted && _scanning) { _cameraErrorReported = false; setState(() => _scanFeedback = 'none'); }
    }
  }

  Future<void> _openScanner() async {
    if (_scanning) return;
    _cameraErrorReported = false;
    _scanBusy = false;
    // MobileScanner auto-starts when the widget enters the tree. Calling
    // start() in the same frame can race with widget attachment on Android.
    if (mounted) setState(() { _scanning = true; _scanFeedback = 'none'; });
  }

  Future<void> _onScan(BarcodeCapture capture) async {
    if (_scanBusy || !_scanning) return;
    String? code;
    for (final b in capture.barcodes) {
      final raw = b.rawValue?.trim();
      if (raw != null && raw.isNotEmpty) { code = raw; break; }
    }
    if (code == null) {
      await _handleScannerFailure(message: 'Could not read this barcode.');
      return;
    }

    final now = DateTime.now();
    if (_lastCode == code && _lastScan != null && now.difference(_lastScan!) < const Duration(milliseconds: 300)) return;
    _lastCode = code;
    _lastScan = now;
    _scanBusy = true;

    final item = _findItemByCode(code);
    if (item == null) {
      if (mounted) setState(() => _scanFeedback = 'error');
      unawaited(ScannerSoundService.instance.playBarcodeError());
      if (mounted) AppMessenger.of(context)..hideCurrentSnackBar()..showSnackBar(const SnackBar(content: Text('No product found for this barcode.'), duration: Duration(milliseconds: 650)));
      if (_autoCloseScanner) {
        await Future<void>.delayed(const Duration(milliseconds: 350));
        await _closeScanner();
      } else {
        await Future<void>.delayed(const Duration(milliseconds: 650));
        if (mounted && _scanning) { _scanBusy = false; setState(() => _scanFeedback = 'none'); }
      }
      return;
    }

    // A barcode can exist in the catalogue while its current stock is zero
    // (or the cart has already consumed the available quantity). That is an
    // inventory error, not a successful scan, so never play the success
    // sound and never add it to the bill.
    final canAdd = _canAdd(item);
    if (canAdd) unawaited(ScannerSoundService.instance.playBarcodeSuccess()); // beep instantly
    if (!_add(item)) {
      if (mounted) setState(() => _scanFeedback = 'error');
      unawaited(ScannerSoundService.instance.playBarcodeError());
      if (mounted) AppMessenger.of(context)..hideCurrentSnackBar()..showSnackBar(SnackBar(content: Text(_available(item) <= 0 ? '${item.name} is out of stock.' : 'No more stock available for ${item.name}.'), duration: const Duration(milliseconds: 700)));
      if (_autoCloseScanner) {
        await Future<void>.delayed(const Duration(milliseconds: 350));
        await _closeScanner();
      } else {
        await Future<void>.delayed(const Duration(milliseconds: 650));
        if (mounted && _scanning) { _scanBusy = false; setState(() => _scanFeedback = 'none'); }
      }
      return;
    }
    if (mounted) setState(() => _scanFeedback = 'success');
    if (_autoCloseScanner) {
      await Future<void>.delayed(const Duration(milliseconds: 280));
      await _closeScanner();
    } else {
      await Future<void>.delayed(const Duration(milliseconds: 550));
      if (mounted && _scanning) { _scanBusy = false; setState(() => _scanFeedback = 'none'); }
    }
    if (mounted) AppMessenger.of(context).showSnackBar(SnackBar(duration: const Duration(milliseconds: 220), content: Text('${item.name} added')));
  }

  /// Scan a product by its picture (like a barcode) and put it on the bill.
  Future<void> _scanByPicture() async {
    if (_scanning) await _closeScanner();
    if (!mounted) return;
    final item = await Navigator.push<ItemRecord>(context, MaterialPageRoute(builder: (_) => ProductScanScreen(items: _items)));
    if (item == null || !mounted) return;
    if (!_add(item)) {
      unawaited(ScannerSoundService.instance.playBarcodeError());
      AppMessenger.of(context)..hideCurrentSnackBar()..showSnackBar(SnackBar(content: Text(_available(item) <= 0 ? '${item.name} is out of stock.' : 'No more stock available for ${item.name}.'), duration: const Duration(milliseconds: 900)));
      return;
    }
    AppMessenger.of(context)..hideCurrentSnackBar()..showSnackBar(SnackBar(duration: const Duration(milliseconds: 600), content: Text('${item.name} added')));
  }

  Future<void> _next() async {
    if (_cart.isEmpty) { AppMessenger.of(context).showSnackBar(const SnackBar(content: Text('Add at least one product.'))); return; }
    await Navigator.push<bool>(context, MaterialPageRoute(builder: (_) => SaleCheckoutScreen(lines: _cart.map((e) => e.copy()).toList(), editingSale: widget.editingSale, totalOverride: _billTotalOverride, initialDiscount: widget.editingSale?.discountAmount ?? 0)));
    if (mounted) { await _load(); setState(() => _cart = []); }
  }

  @override Widget build(BuildContext context) {
    final s = (MediaQuery.sizeOf(context).width / 390).clamp(.82, 1.2).toDouble();
    return Scaffold(backgroundColor: AppColors.lightBackground, body: Column(children: [
      SafeArea(bottom: false, child: _header(s)),
      if (_scanning) _scannerView(s) else _searchBar(s),
      Expanded(child: Padding(padding: EdgeInsets.fromLTRB(14*s, 10*s, 14*s, 0), child: _itemList(s))),
      _cartBar(s),
    ]));
  }

  Widget _header(double s) => Container(height: 58*s, padding: EdgeInsets.symmetric(horizontal: 14*s), decoration: const BoxDecoration(color: Colors.white, border: Border(bottom: BorderSide(color: AppColors.lightDivider))), child: Row(children: [AppGlassIconButton(icon: Icons.arrow_back_rounded, onTap: () => Navigator.pop(context)), Expanded(child: Center(child: Text(widget.editingSale == null ? 'New Sale' : 'Edit Sale', style: TextStyle(fontSize: 19*s, fontWeight: FontWeight.w800, color: AppColors.lightTextPrimary)))), AppGlassIconButton(icon: Icons.image_search_rounded, iconColor: AppColors.primary, onTap: _scanByPicture)]));

  Widget _searchBar(double s) => Padding(
    padding: EdgeInsets.fromLTRB(14*s, 12*s, 14*s, 0),
    child: Container(
      height: 48*s,
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16*s), border: Border.all(color: AppColors.lightCardBorder), boxShadow: [BoxShadow(color: Colors.black.withValues(alpha:.04), blurRadius: 10)]),
      child: Row(children: [
        Expanded(child: TextField(controller: _search, onChanged: (v) => setState(() => _query = v), decoration: InputDecoration(border: InputBorder.none, prefixIcon: Icon(Icons.search_rounded, color: AppColors.primary, size: 21*s), hintText: 'Search product by name or barcode', hintStyle: TextStyle(fontSize: 12*s, color: AppColors.lightTextSecondary)))),
        IconButton(onPressed: _openScanner, icon: Icon(Icons.qr_code_scanner_rounded, color: AppColors.primary, size: 24*s)),
        SizedBox(width: 3*s),
      ]),
    ),
  );

  Widget _scannerView(double s) => Container(
    height: 210*s, margin: EdgeInsets.fromLTRB(14*s, 12*s, 14*s, 0), clipBehavior: Clip.antiAlias,
    decoration: BoxDecoration(color: Colors.black, borderRadius: BorderRadius.circular(22*s)),
    child: Stack(children: [
      Positioned.fill(child: MobileScanner(
        controller: _scanner,
        onDetect: _onScan,
        onDetectError: (error, stack) => unawaited(_handleScannerFailure(message: 'Scanner error. Please try again.')),
        errorBuilder: (context, error) => Container(color: Colors.black, alignment: Alignment.center, child: const Column(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.camera_alt_rounded, color: Colors.white70, size: 34), SizedBox(height: 8), Text('Scanner error', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800))])),
      )),
      Positioned.fill(child: IgnorePointer(child: AnimatedBuilder(animation: _scanAnimation, builder: (_, __) => CustomPaint(painter: _SaleScannerPainter(progress: _scanAnimation.value, feedback: _scanFeedback))))),
      Positioned(top: 10*s, left: 10*s, child: _roundBlack(Icons.close_rounded, _closeScanner)),
      Positioned(top: 10*s, right: 10*s, child: _roundBlack(Icons.flash_on_rounded, () => _scanner.toggleTorch())),
      Positioned(bottom: 10*s, left: 0, right: 0, child: Center(child: Container(padding: EdgeInsets.symmetric(horizontal: 12*s, vertical: 6*s), decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(99)), child: Text('Scan product barcode / QR', style: TextStyle(color: Colors.white, fontSize: 9*s, fontWeight: FontWeight.w700))))),
    ]),
  );
  Widget _roundBlack(IconData icon, VoidCallback onTap) => Material(color: Colors.black54, shape: const CircleBorder(), child: InkWell(onTap: onTap, customBorder: const CircleBorder(), child: Padding(padding: const EdgeInsets.all(9), child: Icon(icon, color: Colors.white))));

  Widget _itemList(double s) => Container(
    decoration: BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(20*s),
      border: Border.all(color: AppColors.lightCardBorder),
      boxShadow: [BoxShadow(color: Colors.black.withValues(alpha:.04), blurRadius: 12)],
    ),
    clipBehavior: Clip.antiAlias,
    child: _loading
        ? const Center(child: CircularProgressIndicator())
        : _filtered.isEmpty
            ? Center(child: Text(_items.isEmpty ? 'No products added yet.' : 'No matching products.', style: TextStyle(color: AppColors.lightTextSecondary, fontWeight: FontWeight.w600)))
            : LayoutBuilder(builder: (context, constraints) {
                final gap = 8*s;
                final width = (constraints.maxWidth - (20*s) - (2*gap)) / 3;
                final cardHeight = width;
                return GridView.builder(
                  padding: EdgeInsets.fromLTRB(10*s, 10*s, 10*s, 12*s),
                  physics: const ClampingScrollPhysics(),
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 3,
                    crossAxisSpacing: gap,
                    mainAxisSpacing: 10*s,
                    mainAxisExtent: cardHeight,
                  ),
                  itemCount: _filtered.length,
                  itemBuilder: (_, i) => _saleItemCard(_filtered[i], s),
                );
              }),
  );

  String _fmtQty(double v) => v.truncateToDouble() == v ? v.toInt().toString() : v.toStringAsFixed(1);

  Widget _saleItemCard(ItemRecord item, double s) {
    final lineIndex = _cart.indexWhere((e) => e.item.id == item.id);
    final line = lineIndex >= 0 ? _cart[lineIndex] : null;
    final qtyText = line == null ? '0' : _fmtQty(line.qty);
    final avail = _available(item);
    // Live stock: shelf stock minus what is already in the cart. It drops on
    // every add and goes back up when the qty is reduced / removed from cart.
    final remaining = (avail - (line?.qty ?? 0)).clamp(0, double.infinity).toDouble();
    final outOfStock = avail <= 0;
    final reachedMax = !outOfStock && remaining <= 0.000001;
    final isLow = !outOfStock && item.lowStock > 0 && remaining <= item.lowStock;
    const red = Color(0xFFDC2626);
    const orange = Color(0xFFF59E0B);
    final borderColor = outOfStock ? red : (line != null ? AppColors.primary.withValues(alpha: .45) : AppColors.lightCardBorder);
    final badgeColor = outOfStock ? red : (reachedMax ? red : (isLow ? orange : const Color(0xFF16A34A)));
    final badgeText = outOfStock ? 'Out of stock' : 'In Stock ${_fmtQty(remaining)}';
    return Opacity(
      opacity: outOfStock ? .6 : 1,
      child: Material(
        color: outOfStock ? const Color(0xFFFEF2F2) : Colors.white,
        borderRadius: BorderRadius.circular(16*s),
        child: InkWell(
          onTap: outOfStock ? null : () => _add(item),
          borderRadius: BorderRadius.circular(16*s),
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16*s),
              border: Border.all(color: borderColor, width: outOfStock ? 1.8 : 1),
              boxShadow: [BoxShadow(color: Colors.black.withValues(alpha:.035), blurRadius: 8*s, offset: Offset(0,3*s))],
            ),
            clipBehavior: Clip.antiAlias,
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Expanded(child: Stack(children: [
                Positioned.fill(child: Container(
                  color: Colors.transparent,
                  alignment: Alignment.center,
                  padding: EdgeInsets.all(4*s),
                  child: ItemImageStore.resolve(item.imagePath) != null
                      ? Image.file(ItemImageStore.resolve(item.imagePath)!, width: double.infinity, height: double.infinity, fit: BoxFit.contain)
                      : Icon(Icons.inventory_2_outlined, color: outOfStock ? red : AppColors.primary, size: 24*s),
                )),
                Positioned(top: 4*s, right: 4*s, child: Container(
                  padding: EdgeInsets.symmetric(horizontal: 5*s, vertical: 2*s),
                  decoration: BoxDecoration(color: badgeColor, borderRadius: BorderRadius.circular(99)),
                  child: Text(badgeText, maxLines: 1, style: TextStyle(fontSize: 7.5*s, height: 1.1, fontWeight: FontWeight.w900, color: Colors.white)),
                )),
              ])),
              Padding(
                padding: EdgeInsets.fromLTRB(5*s, 2*s, 5*s, 4*s),
                child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(item.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 9*s, height: 1.05, fontWeight: FontWeight.w800, color: AppColors.lightTextPrimary)),
                  SizedBox(height: 1*s),
                  Text(CurrencyFormatter.formatCompact(item.price), maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 8*s, height: 1.05, fontWeight: FontWeight.w800, color: outOfStock ? red : AppColors.primary)),
                  SizedBox(height: 2*s),
                  Row(children: [
                    _mini(Icons.remove_rounded, line == null ? () {} : () => _change(line, -1), s, enabled: line != null),
                    Expanded(child: Center(child: Text(qtyText, maxLines: 1, style: TextStyle(fontSize: 9*s, height: 1, fontWeight: FontWeight.w900, color: AppColors.lightTextPrimary)))),
                    _mini(Icons.add_rounded, (outOfStock || reachedMax) ? () {} : () => _add(item), s, enabled: !(outOfStock || reachedMax)),
                  ]),
                ]),
              ),
            ]),
          ),
        ),
      ),
    );
  }

  Widget _thumb(ItemRecord item, double s) => Container(width: 52*s, height: 52*s, clipBehavior: Clip.antiAlias, decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(13*s)), child: ItemImageStore.resolve(item.imagePath) != null ? Image.file(ItemImageStore.resolve(item.imagePath)!, fit: BoxFit.contain) : Icon(Icons.inventory_2_rounded, color: AppColors.primary, size: 24*s));

  Future<void> _editCartLine(SaleLine line, double s) async {
    final value = await Navigator.push<double>(context, MaterialPageRoute(builder: (_) => SalePriceEditorScreen(line: line)));
    if (!mounted || value == null) return;
    setState(() { line.unitPrice = value; _billTotalOverride = null; });
  }

  Future<void> _editBillTotal(double currentTotal, double s) async {
    final value = await Navigator.push<double>(context, MaterialPageRoute(builder: (_) => SaleTotalEditorScreen(currentTotal: currentTotal)));
    if (!mounted || value == null) return;
    setState(() => _billTotalOverride = value);
  }

  Widget _cartBar(double s) {
    final calculatedTotal = _cart.fold<double>(0, (sum, e) => sum + e.total);
    final total = _billTotalOverride ?? calculatedTotal;
    return Container(
      padding: EdgeInsets.fromLTRB(14*s, 7*s, 14*s, 10*s),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border(top: BorderSide(color: AppColors.lightDivider)),
        boxShadow: [BoxShadow(color: Colors.black.withValues(alpha:.06), blurRadius: 12)],
      ),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        if (_cart.isNotEmpty) ...[
          SizedBox(
            height: 64*s,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              physics: const BouncingScrollPhysics(),
              itemCount: _cart.length,
              separatorBuilder: (_, __) => SizedBox(width: 8*s),
              itemBuilder: (_, i) => _cartChip(_cart[i], s),
            ),
          ),
          SizedBox(height: 7*s),
        ],
        Row(children: [
          Expanded(child: InkWell(
            onTap: _cart.isEmpty ? null : () => _editBillTotal(total, s),
            borderRadius: BorderRadius.circular(10*s),
            child: Padding(
              padding: EdgeInsets.symmetric(vertical: 3*s),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
                Text('${_cart.length} products', style: TextStyle(fontSize: 10*s, color: AppColors.lightTextSecondary)),
                Text(CurrencyFormatter.formatCompact(total), style: TextStyle(fontSize: 17*s, fontWeight: FontWeight.w900, color: AppColors.lightTextPrimary)),
                if (_cart.isNotEmpty) Text('Tap total to edit', style: TextStyle(fontSize: 8*s, fontWeight: FontWeight.w700, color: AppColors.primary)),
              ],
            ),
          ))),
          SizedBox(width: 12*s),
          SizedBox(width: 118*s, height: 46*s, child: FilledButton(
            onPressed: _cart.isEmpty ? null : _next,
            style: FilledButton.styleFrom(backgroundColor: AppColors.primary, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14*s))),
            child: Text('Next', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 13*s)),
          )),
        ]),
      ]),
    );
  }

  Widget _cartChip(SaleLine line, double s) => Material(
    color: Colors.transparent,
    borderRadius: BorderRadius.circular(12*s),
    child: InkWell(
      onTap: () => _editCartLine(line, s),
      borderRadius: BorderRadius.circular(12*s),
      child: Container(
    width: 150*s,
    padding: EdgeInsets.symmetric(horizontal: 7*s, vertical: 5*s),
    decoration: BoxDecoration(color: AppColors.lightBackground, borderRadius: BorderRadius.circular(12*s), border: Border.all(color: AppColors.lightCardBorder)),
    child: Row(children: [
      _thumb(line.item, s),
      SizedBox(width: 6*s),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
        Text(line.item.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 9*s, fontWeight: FontWeight.w800)),
        SizedBox(height: 3*s),
        Row(children: [
          _mini(Icons.remove_rounded, () => _change(line,-1), s),
          Expanded(child: Center(child: Text(line.qty.toStringAsFixed(line.qty.truncateToDouble()==line.qty?0:1), style: TextStyle(fontSize: 9*s, fontWeight: FontWeight.w900)))),
          _mini(Icons.add_rounded, () => _change(line,1), s, enabled: line.qty < _available(line.item) - 0.000001),
        ]),
      ])),
    ]),
      ),
    ),
  );
  Widget _mini(IconData icon, VoidCallback onTap, double s, {bool enabled = true}) => InkWell(onTap: enabled ? onTap : null, child: Container(width: 22*s, height: 22*s, decoration: BoxDecoration(color: enabled ? Colors.white : const Color(0xFFE5E7EB), borderRadius: BorderRadius.circular(7*s)), child: Icon(icon, size: 13*s, color: enabled ? AppColors.primary : AppColors.lightTextSecondary.withValues(alpha: .5))));
}

class SaleCheckoutScreen extends StatefulWidget {
  final List<SaleLine> lines;
  final SavedSale? editingSale;
  final double? totalOverride;
  final double initialDiscount;
  const SaleCheckoutScreen({super.key, required this.lines, this.editingSale, this.totalOverride, this.initialDiscount = 0});
  @override State<SaleCheckoutScreen> createState() => _SaleCheckoutScreenState();
}

class _SaleCheckoutScreenState extends State<SaleCheckoutScreen> {
  bool _costVisible = false;
  final _saleRepo = SaleRepository();
  final _ledger = LedgerRepository();
  final _paid = TextEditingController(text: '0');
  final _discount = TextEditingController(text: '0');
  final _discountPct = TextEditingController(text: '0');
  final _net = TextEditingController();
  final _netFocus = FocusNode();
  bool _syncingDiscount = false;
  List<Map<String,Object?>> _customers = [];
  int? _customerId;
  String _payment = 'cash';
  String _customerQuery = '';
  bool _saving = false;
  double? _manualTotalOverride;
  double get _discountInput => double.tryParse(_discount.text.trim()) ?? 0;
  SaleBreakdown get _calc => SaleCalc.compute(
        subtotal: widget.lines.fold<double>(0, (a, b) => a + b.total),
        cogs: widget.lines.fold<double>(0, (a, b) => a + b.totalCost),
        discount: _discountInput,
        totalOverride: _manualTotalOverride,
      );
  double get _calculatedTotal => _calc.subtotal;
  double get _discountAmount => _calc.discount;
  double get _total => _calc.total;
  double get _lineSubtotal => widget.lines.fold<double>(0, (a, b) => a + b.total);
  static String _pctText(double v) => v <= 0 ? '0' : v.toStringAsFixed(2).replaceFirst(RegExp(r'\.?0+$'), '');
  /// Rupee box edited -> show the equivalent percentage.
  void _onRupeeDiscountChanged() {
    if (_syncingDiscount) return;
    _syncingDiscount = true;
    final sub = _lineSubtotal;
    final rs = double.tryParse(_discount.text.trim()) ?? 0;
    final pct = (sub > 0 && rs > 0) ? (rs > sub ? 100.0 : rs / sub * 100) : 0.0;
    _discountPct.text = _pctText(pct);
    _syncingDiscount = false;
  }
  /// Percentage box edited -> work out the rupee discount from the bill subtotal.
  void _onPercentDiscountChanged() {
    if (_syncingDiscount) return;
    _syncingDiscount = true;
    var pct = double.tryParse(_discountPct.text.trim()) ?? 0;
    if (pct > 100) { pct = 100; _discountPct.text = '100'; }
    final rs = SaleCalc.r2(_lineSubtotal * pct / 100);
    _discount.text = pct <= 0 ? '0' : rs.toStringAsFixed(2);
    _syncingDiscount = false;
  }
  void _onAdjustmentChanged() { if (_manualTotalOverride != null) _manualTotalOverride = null; if (mounted) setState(() {}); _syncNet(); }

  /// Keeps the Net Total box in step with the bill (unless it is being typed in).
  void _syncNet() {
    if (_netFocus.hasFocus) return;
    final text = _total.toStringAsFixed(2);
    if (_net.text != text) _net.text = text;
  }

  /// Net Total typed: a lower total becomes the discount, a higher total is
  /// kept as the final bill total.
  void _onNetChanged(String v) {
    final n = double.tryParse(v.replaceAll(',', '').trim());
    if (n == null) return;
    final sub = _lineSubtotal;
    if (n >= sub) {
      _discount.text = '0';
      _manualTotalOverride = n > sub + 0.004 ? n : null;
    } else {
      _manualTotalOverride = null;
      _discount.text = SaleCalc.r2(sub - n).toStringAsFixed(2);
    }
    if (mounted) setState(() {});
  }
  @override void initState(){
    super.initState();
    _payment = widget.editingSale?.paymentType ?? 'cash';
    _customerId = widget.editingSale?.customerId;
    _paid.text = (widget.editingSale?.invoicePaid ?? widget.editingSale?.paid ?? 0).toStringAsFixed(0);
    _discount.text = widget.initialDiscount.toStringAsFixed(2);
    _onRupeeDiscountChanged();
    _manualTotalOverride = widget.totalOverride;
    _discount.addListener(_onRupeeDiscountChanged);
    _discount.addListener(_onAdjustmentChanged);
    _discountPct.addListener(_onPercentDiscountChanged);
    _netFocus.addListener(() { if (!_netFocus.hasFocus) _syncNet(); });
    _syncNet();
    _loadCustomers();
  }
  @override void dispose(){_paid.dispose(); _discount.dispose(); _discountPct.dispose(); _net.dispose(); _netFocus.dispose(); super.dispose();}
  Future<void> _loadCustomers() async { final c=await _saleRepo.getCustomers(); if(mounted)setState(()=>_customers=c); }
  Future<void> _openCustomerManager() async {
    final saved = await Navigator.push<bool>(context, MaterialPageRoute(builder: (_) => const AddPartyScreen(type: LedgerPartyType.customer, returnAfterSelection: true)));
    if (saved == true) await _loadCustomers();
  }

  Future<void> _newCustomer() async => _openCustomerManager();
  Future<void> _submit() async {
    if(_saving) return;
    if(_payment=='credit' && _customerId==null){_msg('Select a customer for credit sale.');return;}
    final paid=double.tryParse(_paid.text.trim())??0;
    if(_total>AmountLimit.max||paid>AmountLimit.max){AmountLimit.showMessage(context);return;}
    if(paid<0||paid>_total){_msg('Enter a valid paid amount.');return;}
    setState(()=>_saving=true);
    try{
      final saved=widget.editingSale == null
          ? await _saleRepo.saveSale(lines: widget.lines, customerId:_customerId, paymentType:_payment, paidAmount:_payment=='cash'?_total:paid, totalOverride: _manualTotalOverride, discountAmount: _discountAmount)
          : await _saleRepo.updateSale(id: widget.editingSale!.id, lines: widget.lines, customerId:_customerId, paymentType:_payment, paidAmount:_payment=='cash'?_total:paid, totalOverride: _manualTotalOverride, discountAmount: _discountAmount);
      var postingFailed=false;
      try{
        final account = await AccountRepository().getDefaultCashAccount();
        final now=DateTime.now();
        final cashPaid=_payment=='cash'?_total:paid;
        if(_customerId==null && account?.id!=null && cashPaid>0){await TransactionRepository().create(TransactionModel(type:TransactionType.income,amount:cashPaid,accountId:account!.id!,date:now,createdAt:now,updatedAt:now,source:'Sale',paymentMethod:_payment,note:saved.invoiceNo));}
        if (_customerId != null) {
          // A sale creates the customer's receivable. Any amount paid now
          // offsets it immediately. For cash this produces a complete ledger
          // record with a zero outstanding balance; for credit the remainder
          // stays receivable.
          if (_total > 0) {
            await _ledger.addTransaction(
              partyId: _customerId!,
              type: 'pay',
              amount: _total,
              note: 'Sale ${saved.invoiceNo}',
              date: now,
              systemPosted: true,
            );
          }
          if (cashPaid > 0) {
            await _ledger.addTransaction(
              partyId: _customerId!,
              type: 'receive',
              amount: cashPaid,
              note: 'Payment for ${saved.invoiceNo}',
              date: now,
              systemPosted: true,
            );
          }
        }
      }catch(_){postingFailed=true;}
      if(!mounted)return;
      if(postingFailed)_msg('Sale saved, but the cash/khata entry could not be posted. Please check the ledger.');
      var shown=saved;
      if(widget.editingSale!=null){try{shown=saved.withPaid(await _saleRepo.settledPaid(saved.id));}catch(_){}}
      if(!mounted)return;
      // Soft Settings: what happens after a NEW sale is submitted.
      final flow=SaleFlowService.instance;
      await flow.load();
      final mode=widget.editingSale==null?flow.mode:SaleFlowMode.normal;
      if(mode==SaleFlowMode.newSaleOnly){Navigator.pop(context,true);return;}
      if(mode==SaleFlowMode.printThenPreview||mode==SaleFlowMode.printThenNewSale){
        final printed=await DirectBillPrinter.print(context,shown,customerName:_customerName);
        if(!mounted)return;
        // If printing failed the bill preview opens instead, so it can be printed again from there.
        if(printed&&mode==SaleFlowMode.printThenNewSale){Navigator.pop(context,true);return;}
      }
      await Navigator.pushReplacement(context,MaterialPageRoute(builder:(_)=>SaleInvoiceScreen(sale:shown,customerName:_customerName)));
    }catch(e){if(mounted)_msg('Could not complete sale. Please try again.');}finally{if(mounted)setState(()=>_saving=false);}
  }
  bool get _customerIsBoth { if(_customerId==null)return false; for(final c in _customers){if(c['id']==_customerId)return c['linked_party_id']!=null;} return false; }
  String? get _customerName { if(_customerId==null)return null; for(final c in _customers){if(c['id']==_customerId)return c['name'] as String;} return null; }
  void _msg(String v)=>AppMessenger.of(context)..hideCurrentSnackBar()..showSnackBar(SnackBar(content:Text(v)));
  @override
  Widget build(BuildContext context) {
    final s = (MediaQuery.sizeOf(context).width / 390).clamp(.82, 1.2).toDouble();
    final filtered = _customers.where((c) {
      final name = (c['name'] as String).toLowerCase();
      final phone = (c['phone'] as String? ?? '').toLowerCase();
      final q = _customerQuery.toLowerCase();
      return name.contains(q) || phone.contains(q);
    }).toList();
    return Scaffold(
      backgroundColor: AppColors.lightBackground,
      body: Column(children: [
        SafeArea(bottom: false, child: _head(s)),
        Expanded(child: ListView(padding: EdgeInsets.all(14*s), children: [
          _lineCard(s), SizedBox(height: 12*s), _grossCard(s),
          SizedBox(height: 12*s), _adjustmentsCard(s),
          SizedBox(height: 12*s), _totalCard(s),
          SizedBox(height: 12*s), _paymentCard(s),
          if (_payment == 'credit') ...[SizedBox(height: 12*s), _paidBox(s)],
          SizedBox(height: 12*s), _customerCard(s, filtered),
          SizedBox(height: 12*s), _profitCard(s), SizedBox(height: 12*s),
          SizedBox(height: 52*s, child: FilledButton(onPressed: _saving ? null : _submit, style: FilledButton.styleFrom(backgroundColor: AppColors.primary, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15*s))), child: _saving ? const CircularProgressIndicator(color: Colors.white) : Text('Submit Sale', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 14*s)))),
        ])),
      ]),
    );
  }

  Widget _head(double s)=>Container(height:58*s,padding:EdgeInsets.symmetric(horizontal:14*s),decoration:const BoxDecoration(color:Colors.white,border:Border(bottom:BorderSide(color:AppColors.lightDivider))),child:Row(children:[AppGlassIconButton(icon:Icons.arrow_back_rounded,onTap:()=>Navigator.pop(context)),Expanded(child:Center(child:Text('Sale Checkout',style:TextStyle(fontSize:19*s,fontWeight:FontWeight.w800))),),SizedBox(width:42*s)]));
  Widget _lineCard(double s)=>_card(s,Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('Sale Products',style:TextStyle(fontSize:14*s,fontWeight:FontWeight.w800)),SizedBox(height:8*s),...widget.lines.map((l)=>Padding(padding:EdgeInsets.symmetric(vertical:5*s),child:Row(children:[Expanded(child:Text('${l.item.name} × ${l.qty}',maxLines:1,overflow:TextOverflow.ellipsis,style:TextStyle(fontSize:12*s,fontWeight:FontWeight.w600))),Text(CurrencyFormatter.formatCompact(l.total),style:TextStyle(fontSize:12*s,fontWeight:FontWeight.w800,color:AppColors.primary))])))]));
  Widget _paymentCard(double s) => _card(s, Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Text('Payment', style: TextStyle(fontSize: 14*s, fontWeight: FontWeight.w800)),
    SizedBox(height: 10*s),
    Row(children: [
      Expanded(child: _choice('Paid', Icons.payments_rounded, 'cash', s)), SizedBox(width: 10*s),
      Expanded(child: _choice('Unpaid', Icons.credit_score_rounded, 'credit', s)),
    ]),
  ]));
  Widget _choice(String title, IconData icon, String value, double s) => InkWell(
    onTap: () => setState(() => _payment = value),
    borderRadius: BorderRadius.circular(15*s),
    child: Container(
      padding: EdgeInsets.symmetric(vertical: 12*s, horizontal: 12*s),
      decoration: BoxDecoration(color: _payment == value ? AppColors.primary.withValues(alpha:.1) : AppColors.lightBackground, borderRadius: BorderRadius.circular(15*s), border: Border.all(color: _payment == value ? AppColors.primary : AppColors.lightCardBorder, width: _payment == value ? 1.5 : 1)),
      child: Row(children: [
        Icon(icon, color: _payment == value ? AppColors.primary : AppColors.lightTextSecondary, size: 20*s), SizedBox(width: 8*s),
        Expanded(child: Text(title, style: TextStyle(fontWeight: FontWeight.w800, fontSize: 12*s))),
        Container(width: 18*s, height: 18*s, decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: _payment == value ? AppColors.primary : AppColors.lightTextSecondary, width: 2), color: _payment == value ? AppColors.primary : Colors.transparent), child: _payment == value ? const Icon(Icons.check, color: Colors.white, size: 12) : null),
      ]),
    ),
  );
  Widget _customerCard(double s,List<Map<String,Object?>> filtered)=>_card(s, Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
    Row(children:[Expanded(child:Text(_payment == 'credit' ? 'Select Customer (Required)' : 'Customer (Optional)',style:TextStyle(fontSize:14*s,fontWeight:FontWeight.w800))),
      IconButton(onPressed:_openCustomerManager,icon:Icon(Icons.person_add_alt_1_rounded,color:AppColors.primary,size:21*s))]),
    Material(color:AppColors.lightBackground,borderRadius:BorderRadius.circular(13*s),child:InkWell(onTap:()=>_showCustomerSheet(s),borderRadius:BorderRadius.circular(13*s),child:Container(height:46*s,padding:EdgeInsets.symmetric(horizontal:12*s),decoration:BoxDecoration(borderRadius:BorderRadius.circular(13*s),border:Border.all(color:AppColors.lightCardBorder)),child:Row(children:[Icon(Icons.person_search_rounded,size:19*s,color:AppColors.primary),SizedBox(width:8*s),Expanded(child:Row(children:[Flexible(child:Text(_customerId==null?'Select customer':_customerName??'Select customer',maxLines:1,overflow:TextOverflow.ellipsis,style:TextStyle(fontSize:12*s,fontWeight:FontWeight.w700,color:_customerId==null?AppColors.lightTextSecondary:AppColors.lightTextPrimary))),if(_customerIsBoth)...[SizedBox(width:6*s),BothStarBadge(size:17*s)]])),Icon(Icons.keyboard_arrow_down_rounded,color:AppColors.lightTextSecondary)])))),
  ]));

  Future<void> _showCustomerSheet(double s) async {
    final customers = List<Map<String, Object?>>.from(_customers);
    final selected = await showModalBottomSheet<int>(context:context,isScrollControlled:true,backgroundColor:Colors.transparent,builder:(ctx){
      String q='';
      return StatefulBuilder(builder:(ctx,setSheet)=>Container(height:MediaQuery.sizeOf(ctx).height*.72,decoration:const BoxDecoration(color:Colors.white,borderRadius:BorderRadius.vertical(top:Radius.circular(26))),child:Column(children:[
        const SizedBox(height:10),Container(width:42,height:4,decoration:BoxDecoration(color:AppColors.lightDivider,borderRadius:BorderRadius.all(Radius.circular(99)))),
        Padding(padding:EdgeInsets.fromLTRB(16*s,14*s,16*s,10*s),child:Row(children:[Expanded(child:Text('Select Customer',style:TextStyle(fontSize:18*s,fontWeight:FontWeight.w800))),TextButton.icon(onPressed:(){Navigator.pop(ctx);_openCustomerManager();},icon:Icon(Icons.person_add_alt_1_rounded,size:17*s),label:Text('Add Customer',style:TextStyle(fontSize:11*s,fontWeight:FontWeight.w800)))])),
        Padding(padding:EdgeInsets.symmetric(horizontal:16*s),child:Container(height:44*s,decoration:BoxDecoration(color:AppColors.lightBackground,borderRadius:BorderRadius.circular(13*s)),child:TextField(onChanged:(v)=>setSheet(()=>q=v),decoration:InputDecoration(border:InputBorder.none,prefixIcon:Icon(Icons.search_rounded,size:19*s),hintText:'Search customers')))),
        SizedBox(height:8*s),Expanded(child:Builder(builder:(_){final list=customers.where((c){final name=(c['name'] as String).toLowerCase();final phone=((c['phone'] as String?)??'').toLowerCase();final query=q.toLowerCase();return name.contains(query)||phone.contains(query);}).toList();return ListView.builder(itemCount:list.length,itemBuilder:(_,i){final c=list[i];return ListTile(onTap:()=>Navigator.pop(ctx,c['id'] as int),leading:CircleAvatar(backgroundColor:AppColors.primary.withValues(alpha:.1),child:Icon(Icons.person_rounded,color:AppColors.primary)),title:Row(children:[Flexible(child:Text(c['name'] as String,maxLines:1,overflow:TextOverflow.ellipsis,style:const TextStyle(fontWeight:FontWeight.w700))),if(c['linked_party_id']!=null)...[const SizedBox(width:6),const BothStarBadge(size:18)]]),subtitle:Text((c['phone'] as String?)??''),trailing:Icon(_customerId==c['id']?Icons.check_circle_rounded:Icons.radio_button_unchecked_rounded,color:_customerId==c['id']?AppColors.primary:AppColors.lightTextSecondary));});}))
      ])));
    });
    if(selected!=null&&mounted)setState(()=>_customerId=selected);
  }

  Widget _paidBox(double s)=>_card(s, Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('Amount Paid Now',style:TextStyle(fontSize:13*s,fontWeight:FontWeight.w800)),SizedBox(height:7*s),TextField(controller:_paid,keyboardType:const TextInputType.numberWithOptions(decimal:true),inputFormatters:const [MaxAmountFormatter()],decoration:InputDecoration(prefixText:'${CurrencyFormatter.label} ',filled:true,fillColor:AppColors.lightBackground,border:OutlineInputBorder(borderRadius:BorderRadius.circular(13*s),borderSide:const BorderSide(color:AppColors.lightCardBorder))))]));
  Widget _adjustmentsCard(double s) => _card(s, Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Text('Discount', style: TextStyle(fontSize: 14*s, fontWeight: FontWeight.w800)),
    SizedBox(height: 10*s),
    Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Expanded(flex: 3, child: TextField(controller: _discount, keyboardType: const TextInputType.numberWithOptions(decimal: true), inputFormatters: const [MaxAmountFormatter()], decoration: InputDecoration(labelText: 'Discount (${CurrencyFormatter.label})', prefixText: '${CurrencyFormatter.label} ', filled: true, fillColor: AppColors.lightBackground, border: OutlineInputBorder(borderRadius: BorderRadius.circular(13*s), borderSide: BorderSide.none)))),
      SizedBox(width: 10*s),
      Expanded(flex: 2, child: TextField(controller: _discountPct, keyboardType: const TextInputType.numberWithOptions(decimal: true), inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'[0-9.]')), LengthLimitingTextInputFormatter(6)], decoration: InputDecoration(labelText: 'Discount (%)', suffixText: '%', filled: true, fillColor: AppColors.lightBackground, border: OutlineInputBorder(borderRadius: BorderRadius.circular(13*s), borderSide: BorderSide.none)))),
    ]),
  ]));

  Widget _profitCard(double s) {
    final c = _calc;
    final color = c.isLoss ? const Color(0xFFDC2626) : const Color(0xFF16A34A);
    return _card(s, Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('Profit & Loss (this bill)', style: TextStyle(fontSize: 14*s, fontWeight: FontWeight.w800)),
      SizedBox(height: 10*s),
      HiddenCostBox(label: 'Purchase Expenses', value: c.cogs, scale: s, onVisibilityChanged: (v) => setState(() => _costVisible = v)),
      SizedBox(height: 10*s),
      _adjustRow('Sale Amount', c.total, s),
      // Profit / loss stays blank (space reserved) until the purchase
      // expenses are revealed with the eye button.
      Visibility(
        visible: _costVisible,
        maintainSize: true,
        maintainAnimation: true,
        maintainState: true,
        child: Container(
          margin: EdgeInsets.only(top: 6*s),
          padding: EdgeInsets.symmetric(horizontal: 12*s, vertical: 10*s),
          decoration: BoxDecoration(color: color.withValues(alpha: .08), borderRadius: BorderRadius.circular(13*s), border: Border.all(color: color.withValues(alpha: .25))),
          child: Row(children: [
            Icon(c.isLoss ? Icons.trending_down_rounded : Icons.trending_up_rounded, color: color, size: 20*s),
            SizedBox(width: 8*s),
            Expanded(child: Text(c.isLoss ? 'Loss' : 'Profit', style: TextStyle(fontSize: 13*s, fontWeight: FontWeight.w800, color: color))),
            Text(CurrencyFormatter.formatCompact(c.profitAbs), style: TextStyle(fontSize: 15*s, fontWeight: FontWeight.w900, color: color)),
          ]),
        ),
      ),
    ]));
  }

  Widget _adjustRow(String label, double value, double s, {Color? color}) => Padding(padding: EdgeInsets.symmetric(vertical: 2*s), child: Row(children: [Expanded(child: Text(label, style: TextStyle(fontSize: 11*s, color: AppColors.lightTextSecondary, fontWeight: FontWeight.w700))), Text(CurrencyFormatter.formatCompact(value), style: TextStyle(fontSize: 11.5*s, fontWeight: FontWeight.w800, color: color ?? AppColors.lightTextPrimary))]));

  Widget _grossCard(double s) => _card(s, Row(children: [
    Expanded(child: Text('Gross Total', style: TextStyle(fontSize: 14*s, fontWeight: FontWeight.w800))),
    Text(CurrencyFormatter.formatCompact(_calculatedTotal), style: TextStyle(fontSize: 17*s, fontWeight: FontWeight.w900, color: AppColors.lightTextPrimary)),
  ]));
  Widget _totalCard(double s) => _card(s, Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Row(children: [
      Expanded(child: Text('Net Total', style: TextStyle(fontSize: 14*s, fontWeight: FontWeight.w800))),
      Text(CurrencyFormatter.formatCompact(_total), style: TextStyle(fontSize: 19*s, fontWeight: FontWeight.w900, color: AppColors.primary)),
    ]),
    SizedBox(height: 10*s),
    TextField(
      controller: _net,
      focusNode: _netFocus,
      onChanged: _onNetChanged,
      keyboardType: const TextInputType.numberWithOptions(decimal: true),
      inputFormatters: const [MaxAmountFormatter()],
      decoration: InputDecoration(labelText: 'Net Total (editable)', prefixText: '${CurrencyFormatter.label} ', filled: true, fillColor: AppColors.lightBackground, border: OutlineInputBorder(borderRadius: BorderRadius.circular(13*s), borderSide: BorderSide.none)),
    ),
  ]));
  Widget _card(double s, Widget child) => Container(width: double.infinity, padding: EdgeInsets.all(15*s), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20*s), border: Border.all(color: AppColors.lightCardBorder), boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: .045), blurRadius: 12)]), child: child);
}

class _SaleScannerPainter extends CustomPainter {
  final double progress;
  final String feedback;
  const _SaleScannerPainter({required this.progress, required this.feedback});

  @override
  void paint(Canvas c, Size s) {
    final box = Rect.fromCenter(
      center: Offset(s.width / 2, s.height / 2),
      width: s.width * .64,
      height: s.width * .64,
    );
    final isSuccess = feedback == 'success';
    final isError = feedback == 'error';
    final baseColor = isSuccess ? Colors.greenAccent : isError ? Colors.redAccent : AppColors.primary;
    final pulse = .5 + .5 * math.sin(progress * math.pi * 2);
    final glow = Paint()
      ..color = baseColor.withValues(alpha: isSuccess || isError ? .28 + .18 * pulse : .18 + .18 * pulse)
      ..style = PaintingStyle.stroke
      ..strokeWidth = isSuccess ? 11 : 8;
    c.drawRRect(RRect.fromRectAndRadius(box, const Radius.circular(22)), glow);

    final border = Paint()
      ..color = baseColor
      ..style = PaintingStyle.stroke
      ..strokeWidth = isSuccess ? 5 : 3;
    c.drawRRect(RRect.fromRectAndRadius(box, const Radius.circular(22)), border);

    final y = box.top + box.height * progress;
    final scanLine = Paint()
      ..color = isError ? Colors.redAccent : isSuccess ? Colors.greenAccent : Colors.white.withValues(alpha: .9)
      ..strokeWidth = isSuccess || isError ? 4 : 2.2
      ..strokeCap = StrokeCap.round;
    c.drawLine(Offset(box.left + 10, y), Offset(box.right - 10, y), scanLine);

    if (isSuccess) {
      final check = Paint()
        ..color = Colors.greenAccent
        ..style = PaintingStyle.stroke
        ..strokeWidth = 6
        ..strokeCap = StrokeCap.round
        ..strokeJoin = StrokeJoin.round;
      final path = Path()
        ..moveTo(box.center.dx - 34, box.center.dy)
        ..lineTo(box.center.dx - 10, box.center.dy + 24)
        ..lineTo(box.center.dx + 38, box.center.dy - 28);
      c.drawPath(path, check);
    }
  }

  @override
  bool shouldRepaint(covariant _SaleScannerPainter oldDelegate) => oldDelegate.progress != progress || oldDelegate.feedback != feedback;
}
