import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/scheduler.dart';

import '../../core/services/thermal_printer_service.dart';
import '../../core/widgets/app_message.dart';
import '../printer/printer_gate.dart';
import '../printer/receipt_settings.dart';
import 'bill_context.dart';
import 'bill_paper.dart';
import 'sale_repository.dart';
import 'thermal_receipt.dart';
import 'thermal_receipt_text.dart';

/// Prints a sale's receipt straight to the thermal printer, without opening
/// the bill screen (Settings > Soft Settings). Uses the same fast text print as
/// the bill screen, and falls back to the receipt picture (logo / non-English
/// text) exactly like it.
class DirectBillPrinter {
  DirectBillPrinter._();

  /// Returns true when the receipt was sent to the printer. On failure the
  /// reason is shown to the user and false is returned.
  static Future<bool> print(BuildContext context, SavedSale sale, {String? customerName}) async {
    final svc = ThermalPrinterService.instance;
    try {
      await svc.load();
      try {
        await ReceiptSettingsService.instance.load();
      } catch (_) {}
      if (!context.mounted) return false;
      if (!await PrinterGate.ensure(context)) return false;

      final bill = await BillContext.load(sale, customerName);
      final mm = svc.paperMm;
      final design = ReceiptSettingsService.instance.value;

      if (await svc.canPrintText(mm)) {
        final text = ThermalTextReceipt.build(
          bill: bill,
          design: design,
          columns: svc.dotsFor(mm) ~/ 12,
          logo: await svc.logoBlock(design, mm),
        );
        if (text != null) {
          await svc.printEscpos(text);
          return true;
        }
      }

      if (!context.mounted) return false;
      final png = await _capture(context, bill, BillPaper.fromThermalMm(mm), design);
      await svc.printPng(png, paperMm: mm);
      return true;
    } on PrinterException catch (e) {
      if (context.mounted) _say(context, e.message);
    } catch (_) {
      if (context.mounted) _say(context, 'Could not print receipt.');
    }
    return false;
  }

  static void _say(BuildContext context, String msg) {
    AppMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(msg)));
  }

  /// Renders the receipt widget off-screen (never visible) and captures it.
  static Future<Uint8List> _capture(BuildContext context, BillContext bill, BillPaper paper, ReceiptSettings design) async {
    final overlay = Overlay.of(context, rootOverlay: true);
    final key = GlobalKey();
    final entry = OverlayEntry(
      builder: (_) => Positioned(
        left: -6000,
        top: 0,
        width: ThermalReceipt.widthFor(paper),
        height: 8000,
        child: Material(
          type: MaterialType.transparency,
          child: OverflowBox(
            alignment: Alignment.topLeft,
            minHeight: 0,
            maxHeight: double.infinity,
            child: RepaintBoundary(key: key, child: ThermalReceipt(bill: bill, paper: paper, design: design)),
          ),
        ),
      ),
    );
    overlay.insert(entry);
    try {
      // Let Flutter lay out and paint the receipt (and load a logo, if any).
      await SchedulerBinding.instance.endOfFrame;
      await Future<void>.delayed(const Duration(milliseconds: 250));
      await SchedulerBinding.instance.endOfFrame;
      final boundary = key.currentContext?.findRenderObject() as RenderRepaintBoundary?;
      if (boundary == null) throw StateError('Receipt is not ready.');
      final ui.Image image = await boundary.toImage(pixelRatio: 3.5);
      final ByteData? data = await image.toByteData(format: ui.ImageByteFormat.png);
      image.dispose();
      if (data == null) throw StateError('Could not create receipt image.');
      return data.buffer.asUint8List();
    } finally {
      entry.remove();
    }
  }
}
