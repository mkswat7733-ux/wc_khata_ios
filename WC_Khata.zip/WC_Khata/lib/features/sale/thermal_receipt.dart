import 'dart:io';

import 'package:flutter/material.dart';

import '../../core/utils/branding.dart';
import '../../core/utils/currency_formatter.dart';
import '../printer/receipt_settings.dart';
import 'bill_context.dart';
import 'bill_paper.dart';

/// The receipt that is previewed, shared as an image and printed (58mm / 80mm).
/// Pure black on white so thermal printers print it sharp; its width comes from
/// [BillPaper.designWidth] (not scaled with the phone) so the captured image is
/// always exactly what the printer receives. Long amounts shrink to fit their
/// column instead of wrapping, so a big total never breaks the layout.
///
/// Logo, margins, visible parts, header / footer text and text size come from
/// [ReceiptSettings] (More > Printer > Receipt Printer > Customize Receipt).
class ThermalReceipt extends StatelessWidget {
  final BillContext bill;
  final BillPaper paper; // mm58 or mm80

  /// Customisation. Falls back to the saved settings when not given.
  final ReceiptSettings? design;

  /// The fixed "Powered by" line. Always printed; only the design screen's
  /// on-screen preview hides it (and turns it on while test printing).
  final bool showBranding;

  const ThermalReceipt({super.key, required this.bill, required this.paper, this.design, this.showBranding = true});

  static double widthFor(BillPaper paper) => paper.isThermal ? paper.designWidth : BillPaper.mm80.designWidth;

  /// Layout pixels per millimetre of paper (same for 58 and 80 mm).
  static double pxPerMm(BillPaper paper) {
    final p = paper.isThermal ? paper : BillPaper.mm80;
    return p.designWidth / p.printMm;
  }

  bool get _columns => paper.usesColumns;

  @override
  Widget build(BuildContext context) {
    final d = design ?? ReceiptSettingsService.instance.value;
    final BillPaper p = paper.isThermal ? paper : BillPaper.mm80;
    final double f = p.fontBase * d.fontScale;
    final double mmPx = pxPerMm(paper);
    final sale = bill.sale;
    final symbol = CurrencyFormatter.defaultSymbol;
    final FontWeight base = d.bold ? FontWeight.w800 : FontWeight.w600;

    final phone = d.showPhone ? bill.phone : null;
    final header = d.headerText.trim();
    final double m = f - 0.5;

    return Container(
      width: widthFor(paper),
      color: Colors.white,
      padding: EdgeInsets.fromLTRB(d.marginLeft * mmPx, d.marginTop * mmPx, d.marginRight * mmPx, d.marginBottom * mmPx),
      child: DefaultTextStyle(
        style: TextStyle(color: Colors.black, fontSize: f, height: 1.3, fontWeight: base),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // ---------------------------------------------------- letterhead
            if (d.hasLogo) _logo(d),
            if (d.showBusinessName)
              Text(
                bill.businessName.toUpperCase(),
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: f + 4, fontWeight: FontWeight.w900, height: 1.2, letterSpacing: .4),
              ),
            if (d.showAddress && bill.address != null)
              Padding(
                padding: const EdgeInsets.only(top: 3),
                child: Text(bill.address!, textAlign: TextAlign.center, style: TextStyle(fontSize: f - 1.5)),
              ),
            if (phone != null)
              Padding(
                padding: const EdgeInsets.only(top: 1),
                child: Text('Tel: $phone', textAlign: TextAlign.center, style: TextStyle(fontSize: f - 1.5, fontWeight: FontWeight.w800)),
              ),
            if (header.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 2),
                child: Text(header, textAlign: TextAlign.center, style: TextStyle(fontSize: f - 1.5, fontWeight: FontWeight.w800)),
              ),
            const SizedBox(height: 7),
            const _Rule(thick: true),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 4),
              child: Text(bill.receiptTitle, textAlign: TextAlign.center, style: TextStyle(fontSize: f + 1, fontWeight: FontWeight.w900, letterSpacing: 2)),
            ),
            const _Rule(thick: true),
            const SizedBox(height: 5),

            // ---------------------------------------------------- bill info
            ..._infoStacked(d, m),
            const SizedBox(height: 5),

            // ---------------------------------------------------- items
            const _Rule(thick: true),
            if (_columns) ..._itemsColumns(f) else ..._itemsStacked(f),
            const _Rule(thick: true),
            const SizedBox(height: 3),

            // ---------------------------------------------------- totals
            if (d.showQtySummary) _kv('Items / Qty', '${sale.lines.length} / ${BillContext.qty(bill.totalQty)}', m, d),
            _kv('Sub Total', '$symbol ${BillContext.moneyShort(sale.subtotal)}', f, d, shrink: true),
            if (d.showDiscount && sale.discountAmount > 0) _kv('Discount', '- $symbol ${BillContext.moneyShort(sale.discountAmount)}', f, d, shrink: true),
            if (d.showTax && sale.taxAmount > 0) _kv('Tax (${sale.taxRate.toStringAsFixed(2)}%)', '$symbol ${BillContext.moneyShort(sale.taxAmount)}', f, d, shrink: true),
            const SizedBox(height: 4),
            Container(
              padding: const EdgeInsets.symmetric(vertical: 5),
              decoration: const BoxDecoration(border: Border.symmetric(horizontal: BorderSide(color: Colors.black, width: 3))),
              child: _kv('NET TOTAL', '$symbol ${BillContext.moneyShort(sale.total)}', f + 2, d, bold: true, shrink: true),
            ),
            if (d.showPaidBalance) ...[
              const SizedBox(height: 4),
              _kv(bill.isPurchase ? 'Paid' : 'Received', '$symbol ${BillContext.moneyShort(sale.paid)}', f, d, shrink: true),
              _kv(bill.isPaid ? 'Balance' : 'Balance Due', '$symbol ${BillContext.moneyShort(bill.balance < 0 ? 0 : bill.balance)}', f, d, bold: !bill.isPaid, shrink: true),
            ],
            const SizedBox(height: 7),
            const _Rule(),
            const SizedBox(height: 6),
            if (d.showPaidStamp && bill.isPaid)
              Padding(
                padding: const EdgeInsets.only(bottom: 5),
                child: Text('*** PAID ***', textAlign: TextAlign.center, style: TextStyle(fontSize: f + 1, fontWeight: FontWeight.w900, letterSpacing: 1.5)),
              ),
            // Fixed footer: always printed, cannot be edited or hidden.
            if (showBranding)
              Text(Branding.poweredBy, textAlign: TextAlign.center, style: TextStyle(fontSize: f - 2.5)),
            const SizedBox(height: 6),
          ],
        ),
      ),
    );
  }

  List<Widget> _infoStacked(ReceiptSettings d, double m) {
    final sale = bill.sale;
    return [
      if (d.showInvoiceNo) _kv('Invoice', bill.invoiceId, m, d),
      if (d.showDate) _kv('Date', BillContext.dateTime(sale.date), m, d),
      if (d.showParty && bill.customerName != null) _kv(bill.partyRole, bill.customerName!, m, d),
      if (d.showPartyPhone && (bill.customerPhone ?? '').isNotEmpty) _kv('Mobile', bill.customerPhone!, m, d),
      if (d.showPartyAddress && (bill.customerAddress ?? '').isNotEmpty) _kv('Address', bill.customerAddress!, m, d),
      if (d.showPayment) _kv('Payment', bill.paymentLabel, m, d),
    ];
  }

  /// The shop logo. Optionally forced to high-contrast black & white so it
  /// prints crisp on thermal paper (colour / grey logos otherwise turn muddy).
  Widget _logo(ReceiptSettings d) {
    // contrast matrix: grey = 0.299R + 0.587G + 0.114B, then stretched around mid-grey.
    const k = 2.4;
    const o = 128 * (1 - k);
    const bw = ColorFilter.matrix(<double>[
      0.299 * k, 0.587 * k, 0.114 * k, 0, o,
      0.299 * k, 0.587 * k, 0.114 * k, 0, o,
      0.299 * k, 0.587 * k, 0.114 * k, 0, o,
      0, 0, 0, 1, 0,
    ]);
    final align = switch (d.logoAlign) {
      0 => Alignment.centerLeft,
      2 => Alignment.centerRight,
      _ => Alignment.center,
    };
    Widget img = Image.file(
      File(d.logoPath!),
      fit: BoxFit.contain,
      gaplessPlayback: true,
      filterQuality: FilterQuality.high,
      errorBuilder: (_, __, ___) => const SizedBox.shrink(),
    );
    if (d.logoHighContrast) img = ColorFiltered(colorFilter: bw, child: img);
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Align(
        alignment: align,
        child: FractionallySizedBox(
          widthFactor: d.logoWidthPct / 100,
          child: ConstrainedBox(constraints: BoxConstraints(maxHeight: widthFor(paper) * .55), child: img),
        ),
      ),
    );
  }

  Widget _kv(String label, String value, double size, ReceiptSettings d, {bool bold = false, bool shrink = false}) {
    final style = TextStyle(fontSize: size, fontWeight: bold ? FontWeight.w900 : (d.bold ? FontWeight.w900 : FontWeight.w700));
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 1.5),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: style),
          const SizedBox(width: 8),
          Expanded(
            child: shrink ? _fit(Text(value, style: style)) : Text(value, textAlign: TextAlign.end, style: style),
          ),
        ],
      ),
    );
  }

  /// Keeps a number on ONE line: it shrinks (never wraps) when the column is
  /// too narrow. Wrapped in Align so FittedBox gets loose constraints.
  Widget _fit(Widget child) => Align(
        alignment: Alignment.centerRight,
        child: FittedBox(fit: BoxFit.scaleDown, alignment: Alignment.centerRight, child: child),
      );

  // Narrow paper (58mm): "1. Item name", then "qty x rate ..... amount".
  List<Widget> _itemsStacked(double f) {
    final lines = bill.sale.lines;
    return [
      for (var i = 0; i < lines.length; i++)
        Padding(
          padding: const EdgeInsets.only(top: 4, bottom: 3),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text('${i + 1}. ${lines[i].item.name}', style: TextStyle(fontSize: f, fontWeight: FontWeight.w900)),
              Padding(
                padding: const EdgeInsets.only(top: 1, left: 14),
                child: Row(
                  children: [
                    Expanded(flex: 5, child: Text('${BillContext.qty(lines[i].qty)} x ${BillContext.moneyShort(lines[i].unitPrice)}', style: TextStyle(fontSize: f - 0.5))),
                    Expanded(flex: 4, child: _fit(Text(BillContext.moneyShort(lines[i].total), style: TextStyle(fontSize: f, fontWeight: FontWeight.w900)))),
                  ],
                ),
              ),
            ],
          ),
        ),
    ];
  }

  // Wide paper (80mm): a proper table, one row per product:
  // ITEM (wraps if long) | QTY | RATE | AMOUNT. Numbers sit on the same line
  // as the product name, so nothing is detached or hard to read.
  List<Widget> _itemsColumns(double f) {
    const int fName = 10, fQty = 3, fRate = 5, fAmt = 6;
    Widget head(String t, {TextAlign align = TextAlign.right}) =>
        Text(t, textAlign: align, style: TextStyle(fontSize: f - 1.5, fontWeight: FontWeight.w900, letterSpacing: .4));
    Widget cell(String t, {bool bold = false}) => Align(
          alignment: Alignment.topRight,
          child: FittedBox(
            fit: BoxFit.scaleDown,
            alignment: Alignment.centerRight,
            child: Text(t, style: TextStyle(fontSize: f, fontWeight: bold ? FontWeight.w900 : FontWeight.w800)),
          ),
        );
    final lines = bill.sale.lines;
    return [
      Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(
          children: [
            Expanded(flex: fName, child: head('ITEM', align: TextAlign.left)),
            Expanded(flex: fQty, child: head('QTY')),
            Expanded(flex: fRate, child: head('RATE')),
            Expanded(flex: fAmt, child: head('AMOUNT')),
          ],
        ),
      ),
      const _Rule(),
      for (var i = 0; i < lines.length; i++) ...[
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 5),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                flex: fName,
                child: Padding(
                  padding: const EdgeInsets.only(right: 4),
                  child: Text('${i + 1}. ${lines[i].item.name}', style: TextStyle(fontSize: f, fontWeight: FontWeight.w900)),
                ),
              ),
              Expanded(flex: fQty, child: cell(BillContext.qty(lines[i].qty))),
              Expanded(flex: fRate, child: cell(BillContext.moneyShort(lines[i].unitPrice))),
              Expanded(flex: fAmt, child: cell(BillContext.moneyShort(lines[i].total), bold: true)),
            ],
          ),
        ),
        if (i != lines.length - 1) const _Dash(),
      ],
      const SizedBox(height: 4),
    ];
  }
}

/// Printed ruler: thin dashed line, or a solid heavy one (thick).
class _Rule extends StatelessWidget {
  final bool thick;
  const _Rule({this.thick = false});

  @override
  Widget build(BuildContext context) {
    if (thick) return Container(height: 3, color: Colors.black);
    return const _Dash();
  }
}

class _Dash extends StatelessWidget {
  const _Dash();

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final count = (constraints.maxWidth / 7).floor();
        return Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: List.generate(count, (_) => Container(width: 3.5, height: 2.2, color: Colors.black)),
        );
      },
    );
  }
}
