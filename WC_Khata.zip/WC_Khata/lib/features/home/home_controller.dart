import '../reports/profit_loss_service.dart';
import 'package:flutter/foundation.dart';
import '../../data/models/bill_model.dart';
import '../../data/models/subscription_model.dart';
import '../../data/models/transaction_model.dart';
import '../../data/repositories/account_repository.dart';
import '../../data/repositories/bill_repository.dart';
import '../../data/repositories/subscription_repository.dart';
import '../ledger/ledger_repository.dart';
import '../ledger/ledger_party.dart';
import '../../data/repositories/transaction_repository.dart';
import '../sale/sale_repository.dart';

class HomeController extends ChangeNotifier {
  final AccountRepository _accountRepo = AccountRepository();
  final TransactionRepository _txRepo = TransactionRepository();
  final BillRepository _billRepo = BillRepository();
  final SubscriptionRepository _subRepo = SubscriptionRepository();
  final LedgerRepository _ledgerRepo = LedgerRepository();
  final SaleRepository _saleRepo = SaleRepository();

  // Only true before the very first successful fetch — this is what
  // shows the big centered spinner. After that, pull-to-refresh must
  // never flip this back to true: the content stays on screen and the
  // RefreshIndicator's own circular spinner is the only loading cue,
  // exactly like a native Facebook/TikTok-style pull-to-refresh.
  bool isLoading = true;
  bool hasLoadedOnce = false;

  double availableBalance = 0;

  /// Current balance of the Cashbook (default cash account). Can be negative.
  double cashbookBalance = 0;
  double get totalBalance => availableBalance;
  double monthIncome = 0;
  double monthExpense = 0;
  double todayIncome = 0;
  double todaySales = 0;
  double todayExpense = 0;
  double todayProfit = 0;
  double todayLoss = 0;

  /// What you'll pay out in total — people you owe + unpaid bills + due
  /// subscriptions + used credit card balances, the same single
  /// "Payable" figure the Financial Position screen shows, so Home and
  /// Financial Position never disagree.
  double payableTotal = 0;

  /// What you're owed in total — people with a positive balance.
  double receivableTotal = 0;

  /// Every unpaid bill, soonest due date first, capped to the handful
  /// shown on Home (the Bills screen itself has the full list).
  List<BillModel> upcomingBills = const [];

  /// Latest transactions for Home (never more than five) and account
  /// names to label them with.
  List<TransactionModel> recentTransactions = const [];
  Map<int, String> accountNames = const {};

  /// Every active subscription, soonest next-payment date first,
  /// capped the same way as [upcomingBills] — the Subscriptions screen
  /// itself has the full list.
  List<SubscriptionModel> upcomingSubscriptions = const [];

  /// Initial load — shows the full-screen spinner the first time only.
  Future<void> load() async {
    if (!hasLoadedOnce) {
      isLoading = true;
      notifyListeners();
    }
    await _fetch();
    isLoading = false;
    hasLoadedOnce = true;
    notifyListeners();
  }

  /// Pull-to-refresh — used by RefreshIndicator.onRefresh. Never
  /// toggles [isLoading], so the screen never "reloads": the numbers
  /// simply update in place once the fetch completes, while
  /// RefreshIndicator shows its own circular loading animation.
  Future<void> refresh() async {
    await _fetch();
    notifyListeners();
  }

  Future<void> _fetch() async {
    final now = DateTime.now();
    final monthStart = DateTime(now.year, now.month, 1);
    final monthEnd = DateTime(now.year, now.month + 1, 0, 23, 59, 59);
    final todayStart = DateTime(now.year, now.month, now.day);
    final todayEnd = DateTime(now.year, now.month, now.day, 23, 59, 59);

    final balanceResults = await Future.wait<double>([
      _accountRepo.getAvailableBalance(),
      _txRepo.sumByTypeInRange(TransactionType.income, monthStart, monthEnd),
      _txRepo.sumOperatingExpenseInRange(monthStart, monthEnd),
      _txRepo.sumByTypeInRange(TransactionType.income, todayStart, todayEnd),
      _txRepo.sumOperatingExpenseInRange(todayStart, todayEnd),
    ]);
    final actualTodaySales = await _saleRepo.sumSalesInRange(todayStart, todayEnd);

    availableBalance = balanceResults[0];
    monthIncome = balanceResults[1];
    monthExpense = balanceResults[2];
    todayIncome = balanceResults[3];
    todaySales = actualTodaySales;
    todayExpense = balanceResults[4];
    // Profit/Loss = product profit (sale - cost price) minus running
    // expenses. Supplier payments / stock purchases are NOT expenses.
    final pl = await ProfitLossService().forRange(todayStart, todayEnd);
    todayProfit = pl.profit;
    todayLoss = pl.loss;

    final cashAccount = await _accountRepo.getDefaultCashAccount();
    cashbookBalance = cashAccount?.currentBalance ?? 0;

    final accounts = await _accountRepo.getAll();
    accountNames = {for (final a in accounts) if (a.id != null) a.id!: a.name};
    recentTransactions = await _txRepo.getAll(limit: 5);
    final bills = await _billRepo.getAll();
    final subscriptions = await _subRepo.getAll();

    final pendingBills = bills.where((b) => b.status != 'paid').toList()
      ..sort((a, b) => a.dueDate.compareTo(b.dueDate));

    // Customer/Supplier balances are sourced from the Ledger module so the
    // Home dashboard always reflects the exact same Pay/Receive ledger.
    final ledgerParties = await _ledgerRepo.getParties();
    final balancePositions = ledgerParties.where((p) => p.linkedPartyId == null || p.type == LedgerPartyType.customer);
    final personsPayable = balancePositions
        .where((p) => p.isPayable)
        .fold<double>(0.0, (sum, p) => sum + p.balance.abs());
    final personsReceivable = balancePositions
        .where((p) => p.isReceivable)
        .fold<double>(0.0, (sum, p) => sum + p.balance.abs());
    final billsPayable = pendingBills.fold<double>(0.0, (sum, b) => sum + b.amount);
    final dueSubscriptions = subscriptions.where((s) => !s.nextPaymentDate.isAfter(todayStart));
    final subscriptionsPayable = dueSubscriptions.fold<double>(0.0, (sum, s) => sum + s.amount);
    payableTotal = personsPayable + billsPayable + subscriptionsPayable;
    receivableTotal = personsReceivable;
    upcomingBills = pendingBills.take(4).toList();
    upcomingSubscriptions = (subscriptions.toList()..sort((a, b) => a.nextPaymentDate.compareTo(b.nextPaymentDate)))
        .take(4)
        .toList();
  }
}