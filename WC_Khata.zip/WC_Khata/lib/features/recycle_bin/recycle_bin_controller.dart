import 'package:flutter/foundation.dart';
import '../../data/models/account_model.dart';
import '../../data/repositories/account_repository.dart';
import '../ledger/ledger_repository.dart';

class RecycleBinController extends ChangeNotifier {
  final AccountRepository _accountRepo = AccountRepository();
  final LedgerRepository _ledgerRepo = LedgerRepository();

  bool isLoading = true;
  List<AccountModel> deletedAccounts = const [];
  List<DeletedLedgerTransaction> deletedTransactions = const [];

  Future<void> load() async {
    isLoading = true;
    notifyListeners();
    deletedAccounts = await _accountRepo.getDeleted();
    deletedTransactions = await _ledgerRepo.getDeletedTransactions();
    isLoading = false;
    notifyListeners();
  }

  Future<void> restoreAccount(int id) async {
    await _accountRepo.restore(id);
    await load();
  }

  Future<void> restoreTransaction(int id) async {
    await _ledgerRepo.restoreTransaction(id);
    await load();
  }
}
