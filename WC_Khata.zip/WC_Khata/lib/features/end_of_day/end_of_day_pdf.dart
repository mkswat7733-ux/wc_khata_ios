import 'dart:typed_data';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import '../../core/utils/currency_formatter.dart';
import '../../data/repositories/profile_repository.dart';
import 'end_of_day_report.dart';

/// Modern "day closing" card. Compact portrait page so it looks right as a
/// phone download AND prints cleanly on a 58 / 80 mm thermal roll.
class EndOfDayPdf {
  EndOfDayPdf._();

  static const _navy = PdfColor.fromInt(0xFF1B3C78);
  static const _blue = PdfColor.fromInt(0xFF2F6FED);
  static const _green = PdfColor.fromInt(0xFF12805C);
  static const _red = PdfColor.fromInt(0xFFD92D20);
  static const _orange = PdfColor.fromInt(0xFFB54708);
  static const _muted = PdfColor.fromInt(0xFF667085);
  static const _line = PdfColor.fromInt(0xFFE4E7EC);
  static const _soft = PdfColor.fromInt(0xFFF5F7FA);

  static String fileName(EndOfDayReport r) =>
      'End_of_Day_${DateFormat('yyyy-MM-dd').format(r.day)}${r.isFullDay ? '' : '_${DateFormat('HHmm').format(r.to)}'}.pdf';

  static Future<Uint8List> build(EndOfDayReport r) async {
    final profile = await ProfileRepository().getOrCreate();
    final business = (profile.name?.trim().isNotEmpty ?? false) ? profile.name!.trim() : 'WC Khata';
    final regular = pw.Font.ttf(await rootBundle.load('assets/fonts/NotoSans-Regular.ttf'));
    final naskh = pw.Font.ttf(await rootBundle.load('assets/fonts/NotoNaskhArabic-Regular.ttf'));
    final doc = pw.Document(
      title: 'End of Day ${DateFormat('dd MMM yyyy').format(r.day)}',
      author: business,
      theme: pw.ThemeData.withFont(base: regular, bold: regular, italic: regular, boldItalic: regular, fontFallback: [naskh]),
    );

    String money(double v) => CurrencyFormatter.format(v);
    final accent = r.isLoss ? _red : _green;
    final dateText = DateFormat('EEEE, dd MMM yyyy').format(r.day);
    final stamp = DateFormat('dd MMM yyyy, hh:mm a').format(r.closedAt ?? r.generatedAt);

    pw.Widget row(String label, String value, PdfColor color, {bool last = false}) => pw.Container(
          padding: const pw.EdgeInsets.symmetric(vertical: 7, horizontal: 10),
          decoration: pw.BoxDecoration(border: last ? null : pw.Border(bottom: pw.BorderSide(color: _line, width: .7))),
          child: pw.Row(children: [
            pw.Container(width: 6, height: 6, decoration: pw.BoxDecoration(color: color, shape: pw.BoxShape.circle)),
            pw.SizedBox(width: 7),
            pw.Expanded(child: pw.Text(label, style: const pw.TextStyle(fontSize: 9.5, color: PdfColors.black))),
            pw.Text(value, style: pw.TextStyle(fontSize: 10.5, fontWeight: pw.FontWeight.bold, color: color)),
          ]),
        );

    pw.Widget chip(String label, String value) => pw.Expanded(
          child: pw.Container(
            padding: const pw.EdgeInsets.symmetric(vertical: 6),
            decoration: pw.BoxDecoration(color: _soft, borderRadius: pw.BorderRadius.circular(8)),
            child: pw.Column(children: [
              pw.Text(value, style: pw.TextStyle(fontSize: 11, fontWeight: pw.FontWeight.bold, color: _navy)),
              pw.SizedBox(height: 2),
              pw.Text(label, style: const pw.TextStyle(fontSize: 7, color: _muted)),
            ]),
          ),
        );

    doc.addPage(pw.Page(
      pageFormat: const PdfPageFormat(100 * PdfPageFormat.mm, 175 * PdfPageFormat.mm, marginAll: 5 * PdfPageFormat.mm),
      build: (_) => pw.Container(
        decoration: pw.BoxDecoration(
          borderRadius: pw.BorderRadius.circular(14),
          border: pw.Border.all(color: _line, width: 1),
        ),
        child: pw.Column(children: [
          // Header
          pw.Container(
            width: double.infinity,
            padding: const pw.EdgeInsets.fromLTRB(14, 14, 14, 14),
            decoration: pw.BoxDecoration(
              color: _navy,
              borderRadius: pw.BorderRadius.vertical(top: pw.Radius.circular(13)),
            ),
            child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
              pw.Text(business, maxLines: 1, style: pw.TextStyle(fontSize: 9, color: PdfColors.white, fontWeight: pw.FontWeight.bold)),
              pw.SizedBox(height: 5),
              pw.Text('END OF DAY', style: pw.TextStyle(fontSize: 19, color: PdfColors.white, fontWeight: pw.FontWeight.bold)),
              pw.SizedBox(height: 3),
              pw.Text(dateText, style: const pw.TextStyle(fontSize: 9, color: PdfColors.white)),
              if (r.periodLabel != null) ...[
                pw.SizedBox(height: 2),
                pw.Text(r.periodLabel!, style: const pw.TextStyle(fontSize: 8, color: PdfColors.white)),
              ],
            ]),
          ),
          pw.Padding(
            padding: const pw.EdgeInsets.all(12),
            child: pw.Column(children: [
              // Net result
              pw.Container(
                width: double.infinity,
                padding: const pw.EdgeInsets.symmetric(vertical: 11, horizontal: 12),
                decoration: pw.BoxDecoration(
                  color: r.isLoss ? const PdfColor.fromInt(0xFFFEF3F2) : const PdfColor.fromInt(0xFFECFDF3),
                  borderRadius: pw.BorderRadius.circular(10),
                  border: pw.Border.all(color: accent, width: .8),
                ),
                child: pw.Column(children: [
                  pw.Text(r.isLoss ? 'NET LOSS' : 'NET PROFIT', style: pw.TextStyle(fontSize: 8, color: accent, fontWeight: pw.FontWeight.bold)),
                  pw.SizedBox(height: 3),
                  pw.Text(money(r.isLoss ? r.loss : r.profit), style: pw.TextStyle(fontSize: 20, color: accent, fontWeight: pw.FontWeight.bold)),
                ]),
              ),
              pw.SizedBox(height: 10),
              // Figures
              pw.Container(
                decoration: pw.BoxDecoration(borderRadius: pw.BorderRadius.circular(10), border: pw.Border.all(color: _line, width: .8)),
                child: pw.Column(children: [
                  row('Today Sale', money(r.sales), _blue),
                  row('Expense', money(r.expense), _red),
                  row('Today Pay', money(r.paid), _orange),
                  row('Today Receive', money(r.received), _green, last: true),
                ]),
              ),
              pw.SizedBox(height: 10),
              pw.Row(children: [
                chip('Invoices', '${r.invoiceCount}'),
                pw.SizedBox(width: 6),
                chip('Cash sales', '${r.cashSales}'),
                pw.SizedBox(width: 6),
                chip('Credit sales', '${r.creditSales}'),
              ]),
              pw.SizedBox(height: 10),
              pw.Container(
                width: double.infinity,
                padding: const pw.EdgeInsets.symmetric(vertical: 8, horizontal: 10),
                decoration: pw.BoxDecoration(color: _soft, borderRadius: pw.BorderRadius.circular(8)),
                child: pw.Row(mainAxisAlignment: pw.MainAxisAlignment.spaceBetween, children: [
                  pw.Text('Available balance', style: const pw.TextStyle(fontSize: 8.5, color: _muted)),
                  pw.Text(money(r.availableBalance), style: pw.TextStyle(fontSize: 10, fontWeight: pw.FontWeight.bold, color: _navy)),
                ]),
              ),
            ]),
          ),
          pw.Spacer(),
          pw.Padding(
            padding: const pw.EdgeInsets.only(bottom: 10),
            child: pw.Column(children: [
              pw.Text(r.closedAt != null ? 'Day closed: $stamp' : 'Generated: $stamp', style: const pw.TextStyle(fontSize: 7.5, color: _muted)),
              pw.SizedBox(height: 2),
              pw.Text('Powered by WebdSoft Company', style: const pw.TextStyle(fontSize: 7, color: _muted)),
            ]),
          ),
        ]),
      ),
    ));
    return Uint8List.fromList(await doc.save());
  }
}
