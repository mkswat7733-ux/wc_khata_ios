import '../../core/services/data_events.dart';
import '../reports/profit_loss_service.dart';
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../../core/database/app_database.dart';
import '../../core/database/database_constants.dart';
import '../../data/models/transaction_model.dart';
import '../../data/repositories/account_repository.dart';
import '../../data/repositories/transaction_repository.dart';
import '../sale/sale_repository.dart';
import 'end_of_day_report.dart';

/// Day closing logic.
///
/// A business day runs 12:00 AM -> 11:59 PM. Closing is stored as a point in
/// time ("everything before this moment is closed"), which gives two ways to
/// close a day:
///  * after 12 AM the finished day is waiting to be closed: the End of Day
///    popup appears on Home and the user taps "End Of Day" to start the new day;
///  * the Home top-bar button only shows today's card (no closing).
///
/// The figures use exactly the same rules as the Home dashboard:
///   net = (profit of sales - loss of sales) - expenses.
class EndOfDayService {
  EndOfDayService._();
  static final EndOfDayService instance = EndOfDayService._();

  static const _boundaryKey = 'eod_closed_until_v2';
  static const _legacyDayKey = 'eod_last_closed_day_v1';
  static const _historyKey = 'eod_history_v1';
  static const _maxHistory = 120;

  final SaleRepository _sales = SaleRepository();
  final TransactionRepository _tx = TransactionRepository();
  final AccountRepository _accounts = AccountRepository();

  static DateTime _dayStart(DateTime d) => DateTime(d.year, d.month, d.day);
  static DateTime _dayEnd(DateTime d) => DateTime(d.year, d.month, d.day, 23, 59, 59, 999);

  /// Everything before this moment is already closed.
  Future<DateTime> _boundary(SharedPreferences p) async {
    final raw = p.getString(_boundaryKey);
    final parsed = raw == null ? null : DateTime.tryParse(raw);
    if (parsed != null) return parsed;

    final todayStart = _dayStart(DateTime.now());
    DateTime start = todayStart; // first ever run: past history is not ours to close
    final legacy = DateTime.tryParse(p.getString(_legacyDayKey) ?? '');
    if (legacy != null) {
      start = DateTime(legacy.year, legacy.month, legacy.day + 1); // day after the last closed one
    }
    await p.setString(_boundaryKey, start.toIso8601String());
    return start;
  }

  Future<void> _setBoundary(SharedPreferences p, DateTime t) => p.setString(_boundaryKey, t.toIso8601String());

  /// The oldest finished period that still needs closing, or `null` when only
  /// today is open.
  Future<({DateTime from, DateTime to})?> pendingPeriod() async {
    final p = await SharedPreferences.getInstance();
    final boundary = await _boundary(p);
    final todayStart = _dayStart(DateTime.now());
    if (!boundary.isBefore(todayStart)) return null;

    final db = await AppDatabase.instance.database;
    final b = boundary.toIso8601String();
    final rows = await db.rawQuery('''
      SELECT MIN(d) AS first_date FROM (
        SELECT MIN(date) AS d FROM ${DBConstants.tableSaleInvoices} WHERE date >= ?
        UNION ALL
        SELECT MIN(date) AS d FROM ${DBConstants.tableTransactions} WHERE date >= ?
        UNION ALL
        SELECT MIN(date) AS d FROM ${DBConstants.tableLedgerTransactions} WHERE date >= ? AND deleted_at IS NULL
      )
    ''', [b, b, b]);

    final first = rows.isEmpty ? null : DateTime.tryParse((rows.first['first_date'] as String?) ?? '');
    if (first == null || !first.isBefore(todayStart)) {
      // Nothing happened on any finished day -> skip them all.
      await _setBoundary(p, todayStart);
      return null;
    }
    final dayStart = _dayStart(first);
    return (from: boundary.isAfter(dayStart) ? boundary : dayStart, to: _dayEnd(first));
  }

  /// The currently open period: from the last closing (or 12 AM) until now.
  /// Used by the manual End of Day button on Home.
  Future<({DateTime from, DateTime to})> currentPeriod() async {
    final p = await SharedPreferences.getInstance();
    final boundary = await _boundary(p);
    final todayStart = _dayStart(DateTime.now());
    return (from: boundary.isAfter(todayStart) ? boundary : todayStart, to: DateTime.now());
  }

  /// Collects every figure for [from] .. [to].
  Future<EndOfDayReport> build({required DateTime from, required DateTime to}) async {
    final db = await AppDatabase.instance.database;

    final totalSales = await _sales.sumSalesInRange(from, to);

    // Expenses = running costs only (stock purchases / supplier payments /
    // customer refunds are not expenses). Profit = product profit - expenses.
    final pl = await ProfitLossService().forRange(from, to);
    final expense = pl.expenses;
    final net = pl.net;

    // Only real cash movements through the ledger:
    //  customer "receive"  -> money collected from a customer
    //  supplier "receive"  -> money paid to a supplier
    final ledgerRows = await db.rawQuery('''
      SELECT p.type AS party_type, COALESCE(SUM(t.amount), 0) AS total
      FROM ${DBConstants.tableLedgerTransactions} t
      JOIN ${DBConstants.tableLedgerParties} p ON p.id = t.party_id
      WHERE t.type = 'receive' AND t.deleted_at IS NULL AND t.date >= ? AND t.date <= ?
      GROUP BY p.type
    ''', [from.toIso8601String(), to.toIso8601String()]);
    double received = 0, paid = 0;
    for (final r in ledgerRows) {
      final v = (r['total'] as num?)?.toDouble() ?? 0;
      if (r['party_type'] == 'supplier') {
        paid += v;
      } else {
        received += v;
      }
    }
    // Money handed back to customers (manual customer "Pay") is cash paid out too.
    final refundRows = await db.rawQuery('''
      SELECT COALESCE(SUM(t.amount), 0) AS total
      FROM ${DBConstants.tableLedgerTransactions} t
      JOIN ${DBConstants.tableLedgerParties} p ON p.id = t.party_id
      WHERE t.type = 'pay' AND p.type = 'customer' AND t.is_system = 0
        AND t.cash_transaction_id IS NOT NULL
        AND t.deleted_at IS NULL AND t.date >= ? AND t.date <= ?
    ''', [from.toIso8601String(), to.toIso8601String()]);
    paid += (refundRows.first['total'] as num?)?.toDouble() ?? 0;

    final countRows = await db.rawQuery('''
      SELECT payment_type, COUNT(*) AS c FROM ${DBConstants.tableSaleInvoices}
      WHERE date >= ? AND date <= ? GROUP BY payment_type
    ''', [from.toIso8601String(), to.toIso8601String()]);
    int cash = 0, credit = 0;
    for (final r in countRows) {
      final c = (r['c'] as num?)?.toInt() ?? 0;
      if (r['payment_type'] == 'credit') {
        credit += c;
      } else {
        cash += c;
      }
    }

    return EndOfDayReport(
      from: from,
      to: to,
      sales: totalSales,
      expense: expense,
      profit: net > 0 ? net : 0,
      loss: net < 0 ? net.abs() : 0,
      paid: paid,
      received: received,
      invoiceCount: cash + credit,
      cashSales: cash,
      creditSales: credit,
      availableBalance: await _accounts.getAvailableBalance(),
      generatedAt: DateTime.now(),
    );
  }

  /// Closes the period: stores its report in history and starts the new day.
  Future<void> closeDay(EndOfDayReport report) async {
    try {
    final p = await SharedPreferences.getInstance();
    final closed = report.copyWith(closedAt: DateTime.now());
    final list = await history();
    list.removeWhere((r) => r.id == closed.id);
    list.insert(0, closed);
    if (list.length > _maxHistory) list.removeRange(_maxHistory, list.length);
    await p.setString(_historyKey, jsonEncode(list.map((e) => e.toJson()).toList()));
    // Anything after this moment belongs to the new day. For a finished day
    // this is the next 12:00 AM; for an early closing it is "now".
    final endsAtDayEnd = report.to.hour == 23 && report.to.minute == 59 && report.to.second == 59;
    await _setBoundary(p, endsAtDayEnd ? _dayStart(report.to).add(const Duration(days: 1)) : report.to);
      } finally {
      DataEvents.changed();
    }
  }

  /// Closed days, newest first.
  Future<List<EndOfDayReport>> history() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString(_historyKey);
    if (raw == null) return [];
    try {
      return (jsonDecode(raw) as List).map((e) => EndOfDayReport.fromJson(Map<String, dynamic>.from(e as Map))).toList();
    } catch (_) {
      return [];
    }
  }
}
