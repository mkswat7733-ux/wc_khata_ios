import 'package:flutter/material.dart';
import '../../app/theme/app_theme.dart';
import '../../core/routing/app_transitions.dart';
import '../../core/utils/currency_formatter.dart';
import '../../core/widgets/app_tab_screen.dart';
import '../../data/models/transaction_model.dart';
import '../../data/repositories/account_repository.dart';
import '../../data/repositories/transaction_repository.dart';
import '../../core/widgets/app_message.dart';
import '../../core/utils/amount_limit.dart';
import 'package:flutter/services.dart';

class CashbookEntryScreen extends StatefulWidget {
  final TransactionType type;
  const CashbookEntryScreen({super.key, required this.type});
  @override State<CashbookEntryScreen> createState() => _CashbookEntryScreenState();
}

class _CashbookEntryScreenState extends State<CashbookEntryScreen> {
  final _amount = TextEditingController();
  final _title = TextEditingController();
  final _note = TextEditingController();
  final _accounts = AccountRepository();
  final _repo = TransactionRepository();
  int? _cashAccountId;
  DateTime _date = DateTime.now();
  bool _saving = false;
  bool get _in => widget.type == TransactionType.income;
  Color get _color => _in ? AppColors.income : AppColors.expense;
  String get _titleText => _in ? 'Cash In' : 'Cash Out';

  @override void initState(){super.initState();_load();}
  Future<void> _load() async { final cash = await _accounts.getDefaultCashAccount(); if(!mounted)return; setState(() => _cashAccountId = cash?.id); }
  @override void dispose(){_amount.dispose();_title.dispose();_note.dispose();super.dispose();}

  Future<void> _pickDate() async { final d=await showDatePicker(context:context,firstDate:DateTime(2000),lastDate:DateTime(2100),initialDate:_date); if(d!=null&&mounted)setState(()=>_date=DateTime(d.year,d.month,d.day,_date.hour,_date.minute)); }
  Future<void> _save() async { final amount=double.tryParse(_amount.text.trim()); if(amount!=null&&amount>AmountLimit.max){AmountLimit.showMessage(context);return;} if(amount==null||amount<=0||_cashAccountId==null){AppMessenger.of(context).showSnackBar(const SnackBar(content:Text('Enter a valid amount.')));return;} setState(()=>_saving=true); try{final now=DateTime.now(); await _repo.create(TransactionModel(type:widget.type,amount:amount,accountId:_cashAccountId!,date:_date,createdAt:now,updatedAt:now,source:_title.text.trim().isEmpty?_titleText:_title.text.trim(),paymentMethod:'Cashbook',note:_note.text.trim().isEmpty?null:_note.text.trim())); if(mounted)Navigator.pop(context,true);}catch(e){if(mounted)AppMessenger.of(context).showSnackBar(const SnackBar(content:Text('Could not save cash transaction.')));}finally{if(mounted)setState(()=>_saving=false);} }

  @override Widget build(BuildContext context){return AppTabScreen(title:_titleText,onBack:()=>Navigator.pop(context),body:ListView(padding:const EdgeInsets.fromLTRB(14,14,14,24),children:[
    Container(padding:const EdgeInsets.all(15),decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(18),border:Border.all(color:_color.withValues(alpha:.22))),child:Row(children:[Container(width:42,height:42,decoration:BoxDecoration(color:_color.withValues(alpha:.10),shape:BoxShape.circle),child:Icon(_in?Icons.arrow_downward_rounded:Icons.arrow_upward_rounded,color:_color)),const SizedBox(width:10),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(_titleText,style:const TextStyle(fontSize:15,fontWeight:FontWeight.w900)),const SizedBox(height:2),Text(_in?'Add money to Cash':'Record money leaving Cash',style:const TextStyle(fontSize:11,color:AppColors.lightTextSecondary))]))]),
    ),const SizedBox(height:14),
    _field('Amount',_amount,keyboard:const TextInputType.numberWithOptions(decimal:true),formatters:const [MaxAmountFormatter()]),const SizedBox(height:10),
    _field('Title',_title),const SizedBox(height:10),
    InkWell(onTap:_pickDate,borderRadius:BorderRadius.circular(14),child:_box(Row(children:[const Icon(Icons.calendar_today_rounded,size:18,color:AppColors.lightTextSecondary),const SizedBox(width:9),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('Date',style:TextStyle(fontSize:10,color:AppColors.lightTextSecondary,fontWeight:FontWeight.w700)),const SizedBox(height:2),Text('${_date.day}/${_date.month}/${_date.year}',style:const TextStyle(fontSize:13,fontWeight:FontWeight.w800))])),const Icon(Icons.chevron_right_rounded,color:AppColors.lightTextSecondary)])),),const SizedBox(height:10),
    _field('Note (Optional)',_note,maxLines:3),const SizedBox(height:18),
    SizedBox(height:50,child:FilledButton(onPressed:_saving?_nullSave:_save,style:FilledButton.styleFrom(backgroundColor:_color,shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(15))),child:_saving?const SizedBox(width:20,height:20,child:CircularProgressIndicator(strokeWidth:2,color:Colors.white)):Text('Save $_titleText',style:const TextStyle(fontWeight:FontWeight.w900))),),
  ]));}
  VoidCallback? get _nullSave=>null;
  Widget _field(String label,TextEditingController c,{TextInputType? keyboard,int maxLines=1,List<TextInputFormatter>? formatters})=>TextField(controller:c,keyboardType:keyboard,inputFormatters:formatters,maxLines:maxLines,decoration:InputDecoration(labelText:label,border:OutlineInputBorder(borderRadius:BorderRadius.circular(14)),filled:true,fillColor:Colors.white));
  Widget _box(Widget child)=>Container(padding:const EdgeInsets.symmetric(horizontal:13,vertical:12),decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(14),border:Border.all(color:AppColors.lightCardBorder)),child:child);
}
