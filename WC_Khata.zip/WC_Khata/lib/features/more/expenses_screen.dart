import 'package:flutter/material.dart';
import '../../app/theme/app_theme.dart';
import '../../core/routing/app_transitions.dart';
import '../../core/utils/currency_formatter.dart';
import '../../core/widgets/app_tab_screen.dart';
import '../../data/models/account_model.dart';
import '../../data/models/transaction_model.dart';
import '../../data/repositories/account_repository.dart';
import '../../data/repositories/finance_category_repository.dart';
import '../../data/repositories/transaction_repository.dart';
import '../../core/services/thermal_printer_service.dart';
import '../../core/widgets/app_message.dart';
import '../printer/printer_gate.dart';
import '../reports/report_pdf_service.dart';
import '../reports/report_repository.dart';
import 'expense_form_screen.dart';

class ExpensesScreen extends StatefulWidget {
  const ExpensesScreen({super.key});
  @override State<ExpensesScreen> createState() => _ExpensesScreenState();
}

class _ExpensesScreenState extends State<ExpensesScreen> with SingleTickerProviderStateMixin {
  final _repo = TransactionRepository();
  final _accounts = AccountRepository();
  final _cats = FinanceCategoryRepository();
  late final AnimationController _animation;
  List<TransactionModel> _items = [];
  Map<int, AccountModel> _accountMap = {};
  Map<int, FinanceCategory> _catMap = {};
  bool _loading = true;
  int? _categoryId; // null = All
  bool _printing = false;
  DateTime? _fromDate;
  DateTime? _toDate;
  DateTimeRange? _range;

  @override void initState() { super.initState(); _animation = AnimationController(vsync: this, duration: const Duration(milliseconds: 700))..forward(); _load(); }
  @override void dispose() { _animation.dispose(); super.dispose(); }

  Future<void> _load() async {
    final rows = await _repo.getAll(type: TransactionType.expense, limit: 500, excludePurchases: true);
    final accounts = await _accounts.getAllForLookup();
    final cats = await _cats.getExpenseCategories();
    if (!mounted) return;
    setState(() { _items = rows; _accountMap = accounts; _catMap = {for (final c in cats) c.id: c}; _loading = false; });
  }

  List<TransactionModel> get _visible {
    return _items.where((tx) {
      final matchesCategory = _categoryId == null || tx.categoryId == _categoryId;
      final matchesRange = _range == null || (!tx.date.isBefore(_range!.start) && !tx.date.isAfter(DateTime(_range!.end.year, _range!.end.month, _range!.end.day, 23, 59, 59)));
      return matchesCategory && matchesRange;
    }).toList();
  }

  double get _total => _visible.fold(0, (s, x) => s + x.amount);

  Future<void> _openForm([TransactionModel? tx]) async {
    final changed = await Navigator.push(context, AppTransitions.seamless(ExpenseFormScreen(existing: tx)));
    if (changed == true) _load();
  }

  Future<void> _pickDate(bool isFrom) async {
    final picked = await showDatePicker(context: context, initialDate: (isFrom ? _fromDate : _toDate) ?? DateTime.now(), firstDate: DateTime(2020), lastDate: DateTime(2100));
    if (picked == null || !mounted) return;
    setState(() { if (isFrom) { _fromDate = picked; } else { _toDate = picked; } });
  }

  void _submitRange() {
    if (_fromDate == null && _toDate == null) { setState(() => _range = null); return; }
    final a = _fromDate ?? _toDate!;
    final b = _toDate ?? _fromDate!;
    final start = a.isBefore(b) ? a : b;
    final end = a.isBefore(b) ? b : a;
    setState(() => _range = DateTimeRange(start: DateTime(start.year, start.month, start.day), end: DateTime(end.year, end.month, end.day)));
  }

  Future<void> _delete(TransactionModel tx) async {
    final ok = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('Delete Expense?', style: TextStyle(fontWeight: FontWeight.w800)),
      content: Text('Delete “${tx.source ?? tx.note ?? 'Expense'}” and reverse its amount from the selected account?'),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')), FilledButton(style: FilledButton.styleFrom(backgroundColor: AppColors.expense), onPressed: () => Navigator.pop(ctx, true), child: const Text('Delete'))],
    ));
    if (ok != true) return;
    await _repo.delete(tx);
    _load();
  }

  Future<void> _print() async {
    if (_printing) return;
    if (!await PrinterGate.ensure(context)) return;
    final vis = _visible;
    final today = DateTime.now();
    DateTime from = DateTime(today.year, today.month, today.day);
    DateTime to = from;
    if (_range != null) {
      from = _range!.start;
      to = _range!.end;
    } else if (vis.isNotEmpty) {
      final dates = vis.map((e) => DateTime(e.date.year, e.date.month, e.date.day)).toList()..sort();
      from = dates.first;
      to = dates.last;
    }
    setState(() => _printing = true);
    try {
      final data = await ReportRepository().load(ReportType.expenses, from, to, categoryId: _categoryId);
      await ReportPdfService.instance.printReport(data);
      if (mounted) {
        AppMessenger.of(context)
          ..hideCurrentSnackBar()
          ..showSnackBar(const SnackBar(content: Text('Expense report sent to the printer.')));
      }
    } on PrinterException catch (e) {
      if (mounted) {
        AppMessenger.of(context)
          ..hideCurrentSnackBar()
          ..showSnackBar(SnackBar(content: Text(e.message)));
      }
    } catch (_) {
      if (mounted) {
        AppMessenger.of(context)
          ..hideCurrentSnackBar()
          ..showSnackBar(const SnackBar(content: Text('Could not print. Please try again.')));
      }
    } finally {
      if (mounted) setState(() => _printing = false);
    }
  }

  @override Widget build(BuildContext context) {
    final s = (MediaQuery.of(context).size.width / 390).clamp(0.86, 1.18);
    final visible = _visible;
    final bottomSafe = MediaQuery.of(context).padding.bottom;
    return AppTabScreen(
      title: 'Expenses',
      onBack: () => Navigator.pop(context),
      body: _loading ? const Center(child: CircularProgressIndicator()) : Column(children: [
        Padding(
          padding: EdgeInsets.fromLTRB(14*s, 12*s, 14*s, 0),
          child: Column(children: [
            _categoryTabs(s),
            SizedBox(height: 10*s),
            _dateRow(s),
            SizedBox(height: 10*s),
            _actionRow(s),
            SizedBox(height: 10*s),
            if (_range != null) _activeRange(s),
            _totalStrip(s, visible),
            SizedBox(height: 8*s),
          ]),
        ),
        Expanded(child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 14*s),
          child: _listBox(s, visible),
        )),
        Container(
          padding: EdgeInsets.fromLTRB(14*s, 10*s, 14*s, 12*s + bottomSafe),
          child: _AddExpenseButton(s: s, onTap: () => _openForm()),
        ),
      ]),
    );
  }

  /// "All" + one tab per category, same look as the Reports tabs.
  Widget _categoryTabs(double s) {
    final tabs = <({int? id, String label})>[(id: null, label: 'All'), for (final c in _catMap.values) (id: c.id, label: c.name)];
    return Container(
      height: 40 * s,
      padding: EdgeInsets.all(3 * s),
      decoration: BoxDecoration(color: const Color(0xFFE7EBF3), borderRadius: BorderRadius.circular(16 * s)),
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: tabs.length,
        separatorBuilder: (_, __) => SizedBox(width: 4 * s),
        itemBuilder: (context, i) {
          final t = tabs[i];
          final selected = t.id == _categoryId;
          return GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTap: () => setState(() => _categoryId = t.id),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 250),
              curve: Curves.easeOutCubic,
              padding: EdgeInsets.symmetric(horizontal: 14 * s),
              alignment: Alignment.center,
              decoration: BoxDecoration(
                gradient: selected ? const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF4C8DFF), AppColors.primary]) : null,
                borderRadius: BorderRadius.circular(13 * s),
                boxShadow: selected ? [BoxShadow(color: AppColors.primary.withValues(alpha: .35), blurRadius: 8 * s, offset: Offset(0, 3 * s))] : null,
              ),
              child: Text(t.label, style: TextStyle(color: selected ? Colors.white : AppColors.lightTextSecondary, fontSize: 12.5 * s, fontWeight: selected ? FontWeight.w800 : FontWeight.w600)),
            ),
          );
        },
      ),
    );
  }

  Widget _dateRow(double s) => Row(children: [
    Expanded(child: _dateBox(s, 'From date', _fromDate, true)), SizedBox(width: 8*s),
    Expanded(child: _dateBox(s, 'To date', _toDate, false)),
  ]);

  /// Print (left) and Submit (right).
  Widget _actionRow(double s) => Row(children: [
    Expanded(child: _actionButton(s, 'Print', Icons.print_rounded, const [Color(0xFFFFB84D), AppColors.warning], _printing ? null : _print, busy: _printing)),
    SizedBox(width: 10*s),
    Expanded(child: _actionButton(s, 'Submit', Icons.check_rounded, const [Color(0xFF4C8DFF), AppColors.primary], _submitRange)),
  ]);

  Widget _actionButton(double s, String label, IconData icon, List<Color> colors, VoidCallback? onTap, {bool busy = false}) => Opacity(
    opacity: onTap == null ? .6 : 1,
    child: GestureDetector(
      onTap: onTap,
      child: Container(
        height: 44*s,
        decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: colors), borderRadius: BorderRadius.circular(14*s), boxShadow: [BoxShadow(color: colors.last.withValues(alpha: .30), blurRadius: 8*s, offset: Offset(0, 3*s))]),
        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          if (busy) SizedBox(width: 16*s, height: 16*s, child: const CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) else Icon(icon, color: Colors.white, size: 18*s),
          SizedBox(width: 6*s),
          Text(label, style: TextStyle(color: Colors.white, fontSize: 13.5*s, fontWeight: FontWeight.w800)),
        ]),
      ),
    ),
  );

  Widget _totalStrip(double s, List<TransactionModel> visible) => Row(children: [
    Expanded(child: Text('${visible.length} expense${visible.length == 1 ? '' : 's'}', style: TextStyle(fontSize: 11.5*s, color: AppColors.lightTextSecondary, fontWeight: FontWeight.w700))),
    Text('Total  ', style: TextStyle(fontSize: 11.5*s, color: AppColors.lightTextSecondary, fontWeight: FontWeight.w700)),
    Text(CurrencyFormatter.formatCompact(_total), style: TextStyle(fontSize: 14*s, color: AppColors.expense, fontWeight: FontWeight.w900)),
  ]);

  Widget _dateBox(double s, String label, DateTime? date, bool from) {
    return InkWell(
      onTap: () => _pickDate(from),
      borderRadius: BorderRadius.circular(12 * s),
      child: Container(
        height: 44 * s,
        padding: EdgeInsets.symmetric(horizontal: 9 * s),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12 * s),
          border: Border.all(color: AppColors.lightCardBorder, width: 1.1),
        ),
        child: Row(
          children: [
            Icon(Icons.calendar_today_rounded, size: 14 * s, color: AppColors.lightTextSecondary),
            SizedBox(width: 6 * s),
            Expanded(
              child: Text(
                date == null ? label : '${date.day}/${date.month}/${date.year}',
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  fontSize: 10.5 * s,
                  fontWeight: FontWeight.w700,
                  color: date == null ? AppColors.lightTextSecondary : AppColors.lightTextPrimary,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _activeRange(double s) {
    return Padding(
      padding: EdgeInsets.only(bottom: 8 * s),
      child: Row(
        children: [
          Icon(Icons.filter_alt_rounded, size: 15 * s, color: AppColors.primary),
          SizedBox(width: 5 * s),
          Expanded(
            child: Text(
              '${_range!.start.day}/${_range!.start.month}/${_range!.start.year} - ${_range!.end.day}/${_range!.end.month}/${_range!.end.year}',
              style: TextStyle(fontSize: 11 * s, fontWeight: FontWeight.w700),
            ),
          ),
          GestureDetector(
            onTap: () => setState(() {
              _range = null;
              _fromDate = null;
              _toDate = null;
            }),
            child: Text('Clear', style: TextStyle(fontSize: 11 * s, color: AppColors.primary, fontWeight: FontWeight.w800)),
          ),
        ],
      ),
    );
  }

  Widget _listBox(double s, List<TransactionModel> visible) {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20 * s),
        border: Border.all(color: AppColors.lightCardBorder, width: 1.2),
        boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: .05), blurRadius: 12 * s, offset: Offset(0, 5 * s))],
      ),
      clipBehavior: Clip.antiAlias,
      child: visible.isEmpty
          ? Center(child: SingleChildScrollView(child: _empty(s)))
          : ListView.builder(
              padding: EdgeInsets.fromLTRB(10 * s, 10 * s, 10 * s, 5 * s),
              itemCount: visible.length,
              itemBuilder: (_, i) => _expenseCard(i, visible[i], s),
            ),
    );
  }

  Widget _expenseCard(int index, TransactionModel tx, double s) {
    final c = _catMap[tx.categoryId];
    final a = _accountMap[tx.accountId];
    final start = (index * .035).clamp(0.0, .7);
    final end = ((index * .035) + .3).clamp(0.0, 1.0);
    final anim = CurvedAnimation(parent: _animation, curve: Interval(start, end, curve: Curves.easeOutCubic));

    return FadeTransition(
      opacity: anim,
      child: SlideTransition(
        position: anim.drive(Tween<Offset>(begin: const Offset(0, .05), end: Offset.zero)),
        child: Container(
          margin: EdgeInsets.only(bottom: 7 * s),
          padding: EdgeInsets.all(11 * s),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16 * s),
            border: Border.all(color: AppColors.lightDivider),
          ),
          child: Row(
            children: [
              Container(
                width: 38 * s,
                height: 38 * s,
                decoration: BoxDecoration(color: AppColors.expense.withValues(alpha: .10), borderRadius: BorderRadius.circular(11 * s)),
                child: Icon(Icons.arrow_upward_rounded, color: AppColors.expense, size: 19 * s),
              ),
              SizedBox(width: 9 * s),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(tx.source?.isNotEmpty == true ? tx.source! : 'Expense', maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 12.5 * s, fontWeight: FontWeight.w800)),
                    SizedBox(height: 3 * s),
                    Text('${tx.date.day}/${tx.date.month}/${tx.date.year}${c == null ? '' : ' • ${c.name}'}${a == null ? '' : ' • ${a.name}'}', maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 9.8 * s, color: AppColors.lightTextSecondary)),
                  ],
                ),
              ),
              Text('-${CurrencyFormatter.formatCompact(tx.amount)}', style: TextStyle(fontSize: 12 * s, color: AppColors.expense, fontWeight: FontWeight.w900)),
              PopupMenuButton<String>(
                onSelected: (v) {
                  if (v == 'edit') _openForm(tx);
                  if (v == 'delete') _delete(tx);
                },
                itemBuilder: (_) => const [
                  PopupMenuItem(value: 'edit', child: Text('Edit')),
                  PopupMenuItem(value: 'delete', child: Text('Delete')),
                ],
                icon: Icon(Icons.more_vert_rounded, size: 19 * s, color: AppColors.lightTextSecondary),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _empty(double s) => Padding(padding: EdgeInsets.symmetric(vertical: 65*s, horizontal: 18*s), child: Column(children: [Container(width: 62*s, height: 62*s, decoration: BoxDecoration(color: AppColors.expense.withValues(alpha:.10), shape: BoxShape.circle), child: Icon(Icons.receipt_long_rounded, size: 28*s, color: AppColors.expense)), SizedBox(height: 12*s), Text('No expenses found', style: TextStyle(fontSize: 16*s, fontWeight: FontWeight.w800)), SizedBox(height: 5*s), Text('Add your first business expense to start tracking costs.', textAlign: TextAlign.center, style: TextStyle(fontSize: 11.5*s, color: AppColors.lightTextSecondary))]));
}

class _AddExpenseButton extends StatefulWidget {
  final double s; final VoidCallback onTap;
  const _AddExpenseButton({required this.s, required this.onTap});
  @override State<_AddExpenseButton> createState() => _AddExpenseButtonState();
}
class _AddExpenseButtonState extends State<_AddExpenseButton> {
  bool _down = false;
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: widget.onTap,
      onTapDown: (_) => setState(() => _down = true),
      onTapUp: (_) => setState(() => _down = false),
      onTapCancel: () => setState(() => _down = false),
      child: AnimatedScale(
        scale: _down ? .96 : 1,
        duration: const Duration(milliseconds: 100),
        child: Container(
          height: 54 * widget.s,
          width: double.infinity,
          padding: EdgeInsets.symmetric(horizontal: 16 * widget.s),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFF4C8DFF), AppColors.primary],
            ),
            borderRadius: BorderRadius.circular(18 * widget.s),
            boxShadow: [
              BoxShadow(
                color: AppColors.primary.withValues(alpha: .30),
                blurRadius: 12,
                offset: const Offset(0, 5),
              ),
            ],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.add_rounded, color: Colors.white, size: 22 * widget.s),
              SizedBox(width: 6 * widget.s),
              Text(
                'Add Expense',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 14.5 * widget.s,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
