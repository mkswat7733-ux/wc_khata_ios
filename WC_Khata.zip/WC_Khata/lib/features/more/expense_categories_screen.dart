import 'package:flutter/material.dart';
import '../../app/theme/app_theme.dart';
import '../../core/routing/app_transitions.dart';
import '../../core/widgets/app_tab_screen.dart';
import '../../data/repositories/finance_category_repository.dart';
import 'add_category_screen.dart';

class ExpenseCategoriesScreen extends StatefulWidget {
  const ExpenseCategoriesScreen({super.key});

  @override
  State<ExpenseCategoriesScreen> createState() => _ExpenseCategoriesScreenState();
}

class _ExpenseCategoriesScreenState extends State<ExpenseCategoriesScreen>
    with SingleTickerProviderStateMixin {
  final _repo = FinanceCategoryRepository();
  final _search = TextEditingController();
  late final AnimationController _animation;
  List<FinanceCategory> _items = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _animation = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 650),
    )..forward();
    _load();
  }

  @override
  void dispose() {
    _animation.dispose();
    _search.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final rows = await _repo.getExpenseCategories();
    if (!mounted) return;
    setState(() {
      _items = rows;
      _loading = false;
    });
  }

  List<FinanceCategory> get _visible {
    final q = _search.text.trim().toLowerCase();
    if (q.isEmpty) return _items;
    return _items.where((x) => x.name.toLowerCase().contains(q)).toList();
  }

  Future<void> _edit([FinanceCategory? existing]) async {
    final saved = await Navigator.push(
      context,
      AppTransitions.seamless(AddCategoryScreen(existing: existing)),
    );
    if (saved == true) await _load();
  }

  Future<void> _delete(FinanceCategory item) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('Delete Category?', style: TextStyle(fontWeight: FontWeight.w900)),
        content: Text('Delete “${item.name}”? Existing expenses will keep their records without a category.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: AppColors.expense),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    if (ok != true) return;
    await _repo.delete(item.id);
    await _load();
  }

  @override
  Widget build(BuildContext context) {
    final s = (MediaQuery.of(context).size.width / 390).clamp(0.86, 1.18);
    final visible = _visible;

    return AppTabScreen(
      title: 'Expense Categories',
      onBack: () => Navigator.pop(context),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : Stack(
              children: [
                ListView(
                  padding: EdgeInsets.fromLTRB(14 * s, 12 * s, 14 * s, 90 * s),
                  children: [
                    _searchBox(s),
                    SizedBox(height: 10 * s),
                    _categoryList(s, visible),
                  ],
                ),
                Positioned(
                  right: 16 * s,
                  bottom: 16 * s,
                  child: _AddButton(
                    scale: s,
                    onTap: () => _edit(),
                  ),
                ),
              ],
            ),
    );
  }

  Widget _searchBox(double s) {
    return Container(
      height: 44 * s,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15 * s),
        border: Border.all(color: AppColors.lightCardBorder, width: 1.1),
      ),
      child: TextField(
        controller: _search,
        onChanged: (_) => setState(() {}),
        style: TextStyle(fontSize: 13 * s),
        decoration: InputDecoration(
          isDense: true,
          border: InputBorder.none,
          hintText: 'Search categories',
          prefixIcon: Icon(Icons.search_rounded, size: 20 * s, color: AppColors.lightTextSecondary),
          suffixIcon: _search.text.isEmpty
              ? null
              : IconButton(
                  onPressed: () {
                    _search.clear();
                    setState(() {});
                  },
                  icon: Icon(Icons.clear_rounded, size: 18 * s),
                ),
        ),
      ),
    );
  }

  Widget _categoryList(double s, List<FinanceCategory> visible) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20 * s),
        border: Border.all(color: AppColors.lightCardBorder, width: 1.1),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: .045),
            blurRadius: 12 * s,
            offset: Offset(0, 5 * s),
          ),
        ],
      ),
      padding: EdgeInsets.all(9 * s),
      child: visible.isEmpty
          ? Padding(
              padding: EdgeInsets.symmetric(vertical: 60 * s),
              child: Center(
                child: Text(
                  'No categories found',
                  style: TextStyle(fontSize: 14 * s, fontWeight: FontWeight.w800),
                ),
              ),
            )
          : Column(
              children: visible.asMap().entries.map((entry) {
                final item = entry.value;
                final start = (entry.key * .05).clamp(0.0, .7);
                final end = (start + .3).clamp(0.0, 1.0);
                final animation = CurvedAnimation(
                  parent: _animation,
                  curve: Interval(start, end, curve: Curves.easeOutCubic),
                );
                return FadeTransition(
                  opacity: animation,
                  child: SlideTransition(
                    position: animation.drive(
                      Tween<Offset>(begin: const Offset(0, .05), end: Offset.zero),
                    ),
                    child: Container(
                      margin: EdgeInsets.only(bottom: 7 * s),
                      padding: EdgeInsets.symmetric(horizontal: 10 * s, vertical: 9 * s),
                      decoration: BoxDecoration(
                        color: AppColors.lightBackground,
                        borderRadius: BorderRadius.circular(15 * s),
                        border: Border.all(color: AppColors.lightDivider),
                      ),
                      child: Row(
                        children: [
                          Container(
                            width: 40 * s,
                            height: 40 * s,
                            decoration: BoxDecoration(
                              color: AppColors.expense.withValues(alpha: .10),
                              shape: BoxShape.circle,
                            ),
                            child: Icon(
                              _iconFor(item.iconKey),
                              color: AppColors.expense,
                              size: 20 * s,
                            ),
                          ),
                          SizedBox(width: 10 * s),
                          Expanded(
                            child: Text(
                              item.name,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(fontSize: 13 * s, fontWeight: FontWeight.w800),
                            ),
                          ),
                          PopupMenuButton<String>(
                            onSelected: (value) {
                              if (value == 'edit') _edit(item);
                              if (value == 'delete') _delete(item);
                            },
                            itemBuilder: (_) => const [
                              PopupMenuItem(value: 'edit', child: Text('Edit')),
                              PopupMenuItem(value: 'delete', child: Text('Delete')),
                            ],
                            icon: Icon(Icons.more_vert_rounded, size: 20 * s),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
    );
  }

  IconData _iconFor(String? key) {
    switch (key) {
      case 'home_rounded':
        return Icons.home_rounded;
      case 'bolt_rounded':
        return Icons.bolt_rounded;
      case 'local_gas_station_rounded':
        return Icons.local_gas_station_rounded;
      case 'water_drop_rounded':
        return Icons.water_drop_rounded;
      case 'wifi_rounded':
        return Icons.wifi_rounded;
      case 'build_rounded':
        return Icons.build_rounded;
      case 'shopping_cart_rounded':
        return Icons.shopping_cart_rounded;
      default:
        return Icons.payments_rounded;
    }
  }
}

class _AddButton extends StatefulWidget {
  final double scale;
  final VoidCallback onTap;
  const _AddButton({required this.scale, required this.onTap});

  @override
  State<_AddButton> createState() => _AddButtonState();
}

class _AddButtonState extends State<_AddButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: widget.onTap,
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) => setState(() => _pressed = false),
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedScale(
        scale: _pressed ? .96 : 1,
        duration: const Duration(milliseconds: 100),
        child: Container(
          height: 46 * widget.scale,
          padding: EdgeInsets.symmetric(horizontal: 16 * widget.scale),
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [Color(0xFF4C8DFF), AppColors.primary]),
            borderRadius: BorderRadius.circular(24 * widget.scale),
            boxShadow: [
              BoxShadow(
                color: AppColors.primary.withValues(alpha: .28),
                blurRadius: 12,
                offset: const Offset(0, 5),
              ),
            ],
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.add_rounded, color: Colors.white, size: 20 * widget.scale),
              SizedBox(width: 6 * widget.scale),
              Text(
                'Add Category',
                style: TextStyle(color: Colors.white, fontSize: 12.5 * widget.scale, fontWeight: FontWeight.w800),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
