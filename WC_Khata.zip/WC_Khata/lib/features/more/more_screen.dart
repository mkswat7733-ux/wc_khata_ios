import 'package:flutter/material.dart';
import '../../app/theme/app_theme.dart';
import '../../core/routing/app_transitions.dart';
import '../../core/widgets/app_glass_icon_button.dart';
import '../../app/theme/app_dimensions.dart';
import 'expenses_screen.dart';
import 'cashbook_screen.dart';
import 'category_units_screen.dart';
import '../reports/reports_screen.dart';
import '../settings/invoice_label_settings_screen.dart';
import '../settings/business_card_settings_screen.dart';
import '../printer/print_settings_screen.dart';

class MoreScreen extends StatefulWidget {
  const MoreScreen({super.key});

  @override
  State<MoreScreen> createState() => _MoreScreenState();
}

class _MoreScreenState extends State<MoreScreen> with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  // Keep the More menu compact and ordered around the user's workflow.
  // Cashbook is intentionally a placeholder for now; its screen will be built later.
  static const _actions = <_MoreAction>[
    _MoreAction('Expenses', Icons.account_balance_wallet_rounded, Color(0xFFE85D75)),
    _MoreAction('Cashbook', Icons.menu_book_rounded, Color(0xFF0EA5E9)),
    _MoreAction('Reports', Icons.analytics_rounded, Color(0xFF4B7BEC)),
    _MoreAction('Category/Units', Icons.category_rounded, Color(0xFF06B6D4)),
    _MoreAction('Invoice/Label Settings', Icons.receipt_long_rounded, Color(0xFFF59E0B)),
    _MoreAction('Business Card', Icons.badge_rounded, Color(0xFF8B5CF6)),
    _MoreAction('Printer', Icons.print_rounded, Color(0xFF10B981)),
  ];

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    )..forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Animation<double> _reveal(int index) {
    final start = (index * 0.08).clamp(0.0, 0.68);
    final end = (start + 0.34).clamp(0.0, 1.0);
    return CurvedAnimation(
      parent: _controller,
      curve: Interval(start, end, curve: Curves.easeOutCubic),
    );
  }

  void _openAction(_MoreAction action) {
    final screen = action.label == 'Expenses'
        ? const ExpensesScreen()
        : action.label == 'Cashbook'
            ? const CashbookScreen()
        : action.label == 'Reports'
            ? const ReportsScreen()
        : action.label == 'Category/Units'
            ? const CategoryUnitsScreen()
        : action.label == 'Invoice/Label Settings'
            ? const InvoiceLabelSettingsScreen()
        : action.label == 'Business Card'
            ? const BusinessCardSettingsScreen()
        : action.label == 'Printer'
            ? const PrintSettingsScreen()
        : MorePlaceholderScreen(title: action.label, icon: action.icon, iconColor: action.color);
    Navigator.push(context, AppTransitions.seamless(screen));
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppColors.lightBackground,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(
          AppDimensions.spaceMd,
          AppDimensions.spaceMd,
          AppDimensions.spaceMd,
          AppDimensions.spaceLg,
        ),
        children: [
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: _actions.length,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
              childAspectRatio: 2.15,
            ),
            itemBuilder: (context, index) {
              final action = _actions[index];
              final reveal = _reveal(index);
              return FadeTransition(
                opacity: reveal,
                child: SlideTransition(
                  position: reveal.drive(
                    Tween(begin: const Offset(0, 0.16), end: Offset.zero),
                  ),
                  child: _MoreActionButton(
                    action: action,
                    onTap: () => _openAction(action),
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}

class _MoreAction {
  final String label;
  final IconData icon;
  final Color color;

  const _MoreAction(this.label, this.icon, this.color);
}

class _MoreActionButton extends StatelessWidget {
  final _MoreAction action;
  final VoidCallback onTap;

  const _MoreActionButton({required this.action, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        splashColor: AppColors.primary.withValues(alpha: 0.08),
        highlightColor: AppColors.primary.withValues(alpha: 0.04),
        child: Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: AppColors.primary.withValues(alpha: 0.72),
              width: 1.25,
            ),
            boxShadow: [
              BoxShadow(
                color: AppColors.primary.withValues(alpha: 0.08),
                blurRadius: 12,
                offset: const Offset(0, 5),
              ),
            ],
          ),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          child: Row(
            children: [
              Container(
                width: 38,
                height: 38,
                decoration: BoxDecoration(
                  color: action.color.withValues(alpha: 0.13),
                  shape: BoxShape.circle,
                ),
                child: Icon(action.icon, color: action.color, size: 21),
              ),
              const SizedBox(width: 9),
              Expanded(
                child: Text(
                  action.label,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: AppColors.lightTextPrimary,
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class MorePlaceholderScreen extends StatelessWidget {
  final String title;
  final IconData icon;
  final Color iconColor;

  const MorePlaceholderScreen({
    super.key,
    required this.title,
    required this.icon,
    required this.iconColor,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.lightBackground,
      body: Column(
        children: [
          Container(
            width: double.infinity,
            decoration: const BoxDecoration(color: Colors.white, border: Border(bottom: BorderSide(color: AppColors.lightDivider))),
            child: SafeArea(
              bottom: false,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: AppDimensions.spaceMd, vertical: AppDimensions.spaceSm),
                child: SizedBox(
                  height: 45,
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      Center(child: Text(title, style: const TextStyle(color: AppColors.lightTextPrimary, fontSize: 19, fontWeight: FontWeight.w700))),
                      Positioned(left: 0, child: AppGlassIconButton(icon: Icons.arrow_back_rounded, onTap: () => Navigator.pop(context))),
                    ],
                  ),
                ),
              ),
            ),
          ),
          const Expanded(child: SizedBox.expand()),
        ],
      ),
    );
  }
}
