import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../app/theme/app_theme.dart';
import '../../core/routing/app_transitions.dart';
import '../../core/utils/currency_formatter.dart';
import '../../core/widgets/app_tab_screen.dart';
import '../../data/models/transaction_model.dart';
import '../../data/repositories/account_repository.dart';
import '../../data/repositories/transaction_repository.dart';
import 'cashbook_entry_screen.dart';

/// Cashbook: total balance on top, daily Cash In / Cash Out summary,
/// the selected day's transactions in a scrolling container and fixed
/// Cash Out (red, left) / Cash In (green, right) buttons at the bottom.
class CashbookScreen extends StatefulWidget {
  const CashbookScreen({super.key});
  @override
  State<CashbookScreen> createState() => _CashbookScreenState();
}

class _CashbookScreenState extends State<CashbookScreen> {
  final _txRepo = TransactionRepository();
  final _accountRepo = AccountRepository();
  bool _loading = true;
  List<TransactionModel> _day = [];
  double _cashBalance = 0;
  DateTime _selected = _dateOnly(DateTime.now());

  static DateTime _dateOnly(DateTime d) => DateTime(d.year, d.month, d.day);
  bool get _isToday => _selected == _dateOnly(DateTime.now());

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final from = _selected;
    final to = DateTime(from.year, from.month, from.day, 23, 59, 59, 999);
    final rows = await _txRepo.getAll(from: from, to: to, limit: 1000);
    final cash = await _accountRepo.getDefaultCashAccount();
    if (!mounted) return;
    setState(() {
      _day = rows.where((t) => t.type == TransactionType.income || t.type == TransactionType.expense).toList();
      _cashBalance = cash?.currentBalance ?? 0;
      _loading = false;
    });
  }

  double get _cashIn => _day.where((t) => t.type == TransactionType.income).fold(0.0, (s, t) => s + t.amount);
  double get _cashOut => _day.where((t) => t.type == TransactionType.expense).fold(0.0, (s, t) => s + t.amount);

  void _changeDay(int delta) {
    final next = _selected.add(Duration(days: delta));
    if (next.isAfter(_dateOnly(DateTime.now()))) return;
    setState(() => _selected = _dateOnly(next));
    _load();
  }

  Future<void> _pickDay() async {
    final d = await showDatePicker(
      context: context,
      initialDate: _selected,
      firstDate: DateTime(2020),
      lastDate: DateTime.now(),
    );
    if (d == null || !mounted) return;
    setState(() => _selected = _dateOnly(d));
    _load();
  }

  Future<void> _openEntry(TransactionType type) async {
    final changed = await Navigator.push(context, AppTransitions.seamless(CashbookEntryScreen(type: type)));
    if (changed == true) _load();
  }

  @override
  Widget build(BuildContext context) {
    final s = (MediaQuery.of(context).size.width / 390).clamp(0.86, 1.18);
    final bottomSafe = MediaQuery.of(context).padding.bottom;

    return AppTabScreen(
      title: 'Cashbook',
      onBack: () => Navigator.pop(context),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                Padding(
                  padding: EdgeInsets.fromLTRB(14 * s, 12 * s, 14 * s, 0),
                  child: Column(
                    children: [
                      _totalCard(s),
                      SizedBox(height: 10 * s),
                      _daySelector(s),
                      SizedBox(height: 10 * s),
                      Row(children: [
                        Expanded(child: _flowCard(s, 'Total Cash In', _cashIn, AppColors.income, Icons.arrow_downward_rounded)),
                        SizedBox(width: 10 * s),
                        Expanded(child: _flowCard(s, 'Total Cash Out', _cashOut, AppColors.expense, Icons.arrow_upward_rounded)),
                      ]),
                      SizedBox(height: 12 * s),
                    ],
                  ),
                ),
                Expanded(
                  child: Padding(
                    padding: EdgeInsets.symmetric(horizontal: 14 * s),
                    child: _listBox(s),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.fromLTRB(14 * s, 10 * s, 14 * s, 12 * s + bottomSafe),
                  child: Row(children: [
                    Expanded(child: _bottomButton(s, 'Cash Out', AppColors.expense, Icons.arrow_upward_rounded, () => _openEntry(TransactionType.expense))),
                    SizedBox(width: 10 * s),
                    Expanded(child: _bottomButton(s, 'Cash In', AppColors.income, Icons.arrow_downward_rounded, () => _openEntry(TransactionType.income))),
                  ]),
                ),
              ],
            ),
    );
  }

  Widget _totalCard(double s) => Container(
        width: double.infinity,
        padding: EdgeInsets.all(16 * s),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18 * s),
          border: Border.all(color: AppColors.primary.withValues(alpha: .22)),
          boxShadow: [BoxShadow(color: AppColors.primary.withValues(alpha: .07), blurRadius: 14, offset: const Offset(0, 5))],
        ),
        child: Row(children: [
          Container(
            width: 44 * s,
            height: 44 * s,
            decoration: BoxDecoration(color: AppColors.primary.withValues(alpha: .10), borderRadius: BorderRadius.circular(14 * s)),
            child: Icon(Icons.account_balance_wallet_rounded, color: AppColors.primary, size: 22 * s),
          ),
          SizedBox(width: 11 * s),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Total Amount', style: TextStyle(fontSize: 13 * s, fontWeight: FontWeight.w700, color: AppColors.lightTextSecondary)),
              SizedBox(height: 3 * s),
              Text(CurrencyFormatter.formatCompact(_cashBalance),
                  style: TextStyle(fontSize: 22 * s, fontWeight: FontWeight.w900, color: AppColors.lightTextPrimary)),
            ]),
          ),
        ]),
      );

  Widget _daySelector(double s) {
    final label = _isToday ? 'Today' : DateFormat('dd MMM yyyy').format(_selected);
    Widget arrow(IconData icon, bool enabled, VoidCallback onTap) => InkWell(
          onTap: enabled ? onTap : null,
          borderRadius: BorderRadius.circular(12 * s),
          child: SizedBox(
            width: 44 * s,
            height: 44 * s,
            child: Icon(icon, size: 24 * s, color: enabled ? AppColors.lightTextPrimary : AppColors.lightTextSecondary.withValues(alpha: .35)),
          ),
        );
    return Container(
      height: 46 * s,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14 * s),
        border: Border.all(color: AppColors.lightCardBorder, width: 1.1),
      ),
      child: Row(children: [
        arrow(Icons.chevron_left_rounded, true, () => _changeDay(-1)),
        Expanded(
          child: InkWell(
            onTap: _pickDay,
            child: Center(
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                Icon(Icons.calendar_today_rounded, size: 15 * s, color: AppColors.primary),
                SizedBox(width: 7 * s),
                Text(label, style: TextStyle(fontSize: 13.5 * s, fontWeight: FontWeight.w800)),
              ]),
            ),
          ),
        ),
        arrow(Icons.chevron_right_rounded, !_isToday, () => _changeDay(1)),
      ]),
    );
  }

  Future<void> _showFullFlowAmount(double s, String title, double amount, Color color, IconData icon) async {
    final dateLabel = _isToday ? 'Today' : DateFormat('dd MMM yyyy').format(_selected);
    await showDialog<void>(
      context: context,
      builder: (dialogContext) => Dialog(
        insetPadding: EdgeInsets.symmetric(horizontal: 28 * s),
        backgroundColor: Colors.transparent,
        child: Container(
          padding: EdgeInsets.fromLTRB(20 * s, 20 * s, 20 * s, 16 * s),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(26 * s),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: .12),
                blurRadius: 28 * s,
                offset: Offset(0, 12 * s),
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 54 * s,
                height: 54 * s,
                decoration: BoxDecoration(
                  color: color.withValues(alpha: .11),
                  shape: BoxShape.circle,
                ),
                child: Icon(icon, color: color, size: 27 * s),
              ),
              SizedBox(height: 12 * s),
              Text(
                title,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 15 * s,
                  fontWeight: FontWeight.w900,
                  color: AppColors.lightTextPrimary,
                ),
              ),
              SizedBox(height: 4 * s),
              Text(
                dateLabel,
                style: TextStyle(
                  fontSize: 11.5 * s,
                  fontWeight: FontWeight.w600,
                  color: AppColors.lightTextSecondary,
                ),
              ),
              SizedBox(height: 16 * s),
              Container(
                width: double.infinity,
                padding: EdgeInsets.symmetric(horizontal: 14 * s, vertical: 16 * s),
                decoration: BoxDecoration(
                  color: color.withValues(alpha: .06),
                  borderRadius: BorderRadius.circular(18 * s),
                  border: Border.all(color: color.withValues(alpha: .16)),
                ),
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Text(
                    CurrencyFormatter.format(amount),
                    maxLines: 1,
                    style: TextStyle(
                      fontSize: 25 * s,
                      fontWeight: FontWeight.w900,
                      color: color,
                    ),
                  ),
                ),
              ),
              SizedBox(height: 16 * s),
              SizedBox(
                width: double.infinity,
                height: 48 * s,
                child: FilledButton(
                  onPressed: () => Navigator.pop(dialogContext),
                  style: FilledButton.styleFrom(
                    backgroundColor: color,
                    foregroundColor: Colors.white,
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15 * s),
                    ),
                  ),
                  child: Text(
                    'OK',
                    style: TextStyle(fontSize: 14 * s, fontWeight: FontWeight.w900),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _flowCard(double s, String title, double amount, Color color, IconData icon) => Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: () => _showFullFlowAmount(s, title, amount, color, icon),
          borderRadius: BorderRadius.circular(16 * s),
          child: Ink(
            padding: EdgeInsets.all(13 * s),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16 * s),
              border: Border.all(color: color.withValues(alpha: .22)),
            ),
            child: Row(children: [
              Container(
                width: 34 * s,
                height: 34 * s,
                decoration: BoxDecoration(color: color.withValues(alpha: .11), shape: BoxShape.circle),
                child: Icon(icon, color: color, size: 18 * s),
              ),
              SizedBox(width: 8 * s),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(
                    title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(fontSize: 11 * s, fontWeight: FontWeight.w700, color: AppColors.lightTextSecondary),
                  ),
                  SizedBox(height: 2 * s),
                  Text(
                    CurrencyFormatter.formatCompact(amount),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(fontSize: 14.5 * s, fontWeight: FontWeight.w900, color: color),
                  ),
                ]),
              ),
            ]),
          ),
        ),
      );

  Widget _listBox(double s) => Container(
        width: double.infinity,
        clipBehavior: Clip.antiAlias,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20 * s),
          border: Border.all(color: AppColors.lightCardBorder, width: 1.2),
          boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: .05), blurRadius: 12 * s, offset: Offset(0, 5 * s))],
        ),
        child: _day.isEmpty
            ? Center(child: SingleChildScrollView(child: _empty(s)))
            : RefreshIndicator(
                color: AppColors.primary,
                onRefresh: _load,
                child: ListView.builder(
                  padding: EdgeInsets.fromLTRB(10 * s, 10 * s, 10 * s, 4 * s),
                  itemCount: _day.length,
                  itemBuilder: (_, i) => _entry(s, _day[i]),
                ),
              ),
      );

  Widget _entry(double s, TransactionModel tx) {
    final incoming = tx.type == TransactionType.income;
    final color = incoming ? AppColors.income : AppColors.expense;
    final title = (tx.source?.isNotEmpty ?? false) ? tx.source! : (incoming ? 'Cash In' : 'Cash Out');
    final note = (tx.note?.isNotEmpty ?? false) ? tx.note! : 'Cash';
    return Container(
      margin: EdgeInsets.only(bottom: 7 * s),
      padding: EdgeInsets.symmetric(horizontal: 11 * s, vertical: 10 * s),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14 * s),
        border: Border.all(color: AppColors.lightDivider),
      ),
      child: Row(children: [
        Container(
          width: 36 * s,
          height: 36 * s,
          decoration: BoxDecoration(color: color.withValues(alpha: .10), shape: BoxShape.circle),
          child: Icon(incoming ? Icons.arrow_downward_rounded : Icons.arrow_upward_rounded, color: color, size: 19 * s),
        ),
        SizedBox(width: 9 * s),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 12.5 * s, fontWeight: FontWeight.w800)),
            SizedBox(height: 2 * s),
            Text('$note • ${DateFormat('hh:mm a').format(tx.date)}',
                maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 10.5 * s, color: AppColors.lightTextSecondary, fontWeight: FontWeight.w600)),
          ]),
        ),
        Text('${incoming ? '+' : '−'} ${CurrencyFormatter.formatCompact(tx.amount)}',
            style: TextStyle(fontSize: 12.5 * s, fontWeight: FontWeight.w900, color: color)),
      ]),
    );
  }

  Widget _empty(double s) => Padding(
        padding: EdgeInsets.symmetric(vertical: 44 * s),
        child: Column(children: [
          Icon(Icons.menu_book_rounded, size: 42 * s, color: AppColors.lightTextSecondary),
          SizedBox(height: 8 * s),
          Text(_isToday ? 'No cash transactions today' : 'No cash transactions on this day',
              style: TextStyle(fontWeight: FontWeight.w800, color: AppColors.lightTextSecondary, fontSize: 13 * s)),
        ]),
      );

  Widget _bottomButton(double s, String label, Color color, IconData icon, VoidCallback onTap) => SizedBox(
        height: 54 * s,
        child: FilledButton.icon(
          onPressed: onTap,
          icon: Icon(icon, size: 20 * s),
          label: Text(label, style: TextStyle(fontSize: 14.5 * s, fontWeight: FontWeight.w900)),
          style: FilledButton.styleFrom(
            backgroundColor: color,
            foregroundColor: Colors.white,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(17 * s)),
          ),
        ),
      );
}
