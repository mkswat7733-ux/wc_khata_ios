import 'package:flutter/material.dart';

import '../../app/theme/app_theme.dart';
import '../../core/services/unit_repository.dart';
import '../../core/widgets/app_button_3d.dart';
import '../../core/widgets/app_tab_screen.dart';
import '../items/item_repository.dart';

/// More > Category/Units.
///
/// Two tabs: Category (product categories) and Units. Each tab is a white
/// container holding the list row by row, with the Add button under it.
/// Tapping a row opens a dialog to rename or delete it.
class CategoryUnitsScreen extends StatefulWidget {
  const CategoryUnitsScreen({super.key});

  @override
  State<CategoryUnitsScreen> createState() => _CategoryUnitsScreenState();
}

class _CategoryUnitsScreenState extends State<CategoryUnitsScreen> {
  final _items = ItemRepository();
  final _units = UnitRepository.instance;

  int _tab = 0; // 0 = Category, 1 = Units
  bool _loading = true;
  List<ItemCategory> _categories = [];
  Map<int, int> _categoryUsage = {};
  List<UnitRecord> _unitList = [];
  Map<String, int> _unitUsage = {};

  bool get _isCategory => _tab == 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final cats = await _items.getCategories();
      final catUse = await _items.categoryUsage();
      final units = await _units.list();
      final unitUse = await _units.usage();
      if (!mounted) return;
      setState(() {
        _categories = cats;
        _categoryUsage = catUse;
        _unitList = units;
        _unitUsage = unitUse;
        _loading = false;
      });
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  // ------------------------------------------------------------------ actions

  Future<void> _add() async {
    final category = _isCategory;
    await showDialog<void>(
      context: context,
      builder: (_) => _NameDialog(
        title: category ? 'Add Category' : 'Add Unit',
        hint: category ? 'Category name' : 'Unit name (e.g. Box)',
        saveLabel: 'Add',
        onSave: (name) async {
          final ok = category ? await _items.addCategoryChecked(name) : await _units.add(name);
          return ok ? null : (name.trim().isEmpty ? 'Please enter a name.' : 'This name already exists.');
        },
      ),
    );
    await _load();
  }

  Future<void> _openRow({required int id, required String name, required int used}) async {
    final category = _isCategory;
    await showDialog<void>(
      context: context,
      builder: (_) => _NameDialog(
        title: category ? 'Category' : 'Unit',
        hint: category ? 'Category name' : 'Unit name',
        initial: name,
        saveLabel: 'Save',
        note: category
            ? (used == 0 ? 'No products use this category.' : 'Used by $used product${used == 1 ? '' : 's'}.')
            : (used == 0 ? 'No products use this unit.' : 'Used by $used product${used == 1 ? '' : 's'}.'),
        onSave: (newName) async {
          final ok = category ? await _items.renameCategory(id, newName) : await _units.rename(id, name, newName);
          return ok ? null : (newName.trim().isEmpty ? 'Please enter a name.' : 'This name already exists.');
        },
        onDelete: () async {
          final sure = await _confirmDelete(name: name, used: used, category: category);
          if (sure != true) return false;
          if (category) {
            await _items.deleteCategory(id);
          } else {
            await _units.delete(id);
          }
          return true;
        },
      ),
    );
    await _load();
  }

  Future<bool?> _confirmDelete({required String name, required int used, required bool category}) {
    final what = category ? 'category' : 'unit';
    final detail = category
        ? (used == 0
            ? 'This category will be removed.'
            : '$used product${used == 1 ? '' : 's'} in it will not be deleted. They will move to General.')
        : (used == 0
            ? 'This unit will be removed from the list.'
            : '$used product${used == 1 ? '' : 's'} already using it will keep it. It just will not be offered in the list any more.');
    return showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('Delete $what?'),
        content: Text('"$name"\n\n$detail'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: TextButton.styleFrom(foregroundColor: AppColors.expense),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }

  // -------------------------------------------------------------------- build

  @override
  Widget build(BuildContext context) {
    final s = (MediaQuery.sizeOf(context).width / 390).clamp(.85, 1.2).toDouble();
    return AppTabScreen(
      title: 'Category/Units',
      onBack: () => Navigator.pop(context),
      body: Padding(
        padding: EdgeInsets.fromLTRB(14 * s, 12 * s, 14 * s, 14 * s),
        child: Column(
          children: [
            _tabs(s),
            SizedBox(height: 10 * s),
            Expanded(child: _container(s)),
            SizedBox(height: 12 * s),
            SafeArea(
              top: false,
              child: AppButton3D(
                label: _isCategory ? 'Add Category' : 'Add Unit',
                icon: Icons.add_rounded,
                expand: true,
                onPressed: _add,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _tabs(double s) {
    return Container(
      height: 38 * s,
      padding: EdgeInsets.all(3 * s),
      decoration: BoxDecoration(color: const Color(0xFFE7EBF3), borderRadius: BorderRadius.circular(16 * s)),
      child: Stack(
        children: [
          AnimatedAlign(
            duration: const Duration(milliseconds: 280),
            curve: Curves.easeOutCubic,
            alignment: Alignment(_tab * 2 - 1.0, 0),
            child: FractionallySizedBox(
              widthFactor: 1 / 2,
              heightFactor: 1,
              child: Container(
                decoration: BoxDecoration(
                  gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF4C8DFF), AppColors.primary]),
                  borderRadius: BorderRadius.circular(13 * s),
                  boxShadow: [BoxShadow(color: AppColors.primary.withValues(alpha: 0.35), blurRadius: 8 * s, offset: Offset(0, 3 * s))],
                ),
              ),
            ),
          ),
          Row(children: [
            Expanded(child: _tabLabel(s, 'Category (${_categories.length})', 0)),
            Expanded(child: _tabLabel(s, 'Units (${_unitList.length})', 1)),
          ]),
        ],
      ),
    );
  }

  Widget _tabLabel(double s, String label, int index) {
    final selected = _tab == index;
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () => setState(() => _tab = index),
      child: Center(
        child: AnimatedDefaultTextStyle(
          duration: const Duration(milliseconds: 250),
          style: TextStyle(
            color: selected ? Colors.white : AppColors.lightTextSecondary,
            fontSize: 12.5 * s,
            fontWeight: selected ? FontWeight.w800 : FontWeight.w600,
          ),
          child: Text(label),
        ),
      ),
    );
  }

  Widget _container(double s) {
    final rows = _isCategory
        ? [for (final c in _categories) _RowData(c.id, c.name, _categoryUsage[c.id] ?? 0)]
        : [for (final u in _unitList) _RowData(u.id, u.name, _unitUsage[u.name.toLowerCase()] ?? 0)];
    final slide = _tab == 0 ? -0.04 : 0.04;
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20 * s),
        border: Border.all(color: AppColors.lightCardBorder, width: 1.2),
        boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.06), blurRadius: 12 * s, offset: Offset(0, 5 * s))],
      ),
      clipBehavior: Clip.antiAlias,
      child: _loading
          ? const Center(child: CircularProgressIndicator())
          : AnimatedSwitcher(
              duration: const Duration(milliseconds: 260),
              switchInCurve: Curves.easeOutCubic,
              transitionBuilder: (child, animation) => FadeTransition(
                opacity: animation,
                child: SlideTransition(position: animation.drive(Tween(begin: Offset(slide, 0), end: Offset.zero)), child: child),
              ),
              child: rows.isEmpty
                  ? _empty(s)
                  : ListView.separated(
                      key: ValueKey(_tab),
                      padding: EdgeInsets.symmetric(vertical: 6 * s),
                      itemCount: rows.length,
                      separatorBuilder: (_, __) => Divider(height: 1, color: AppColors.lightDivider, indent: 64 * s, endIndent: 12 * s),
                      itemBuilder: (_, i) => _tile(s, rows[i]),
                    ),
            ),
    );
  }

  Widget _tile(double s, _RowData r) {
    const noun = 'product';
    return InkWell(
      onTap: () => _openRow(id: r.id, name: r.name, used: r.used),
      child: Padding(
        padding: EdgeInsets.symmetric(horizontal: 14 * s, vertical: 11 * s),
        child: Row(
          children: [
            Container(
              width: 38 * s,
              height: 38 * s,
              decoration: BoxDecoration(color: AppColors.primary.withValues(alpha: .12), shape: BoxShape.circle),
              child: Icon(_isCategory ? Icons.category_rounded : Icons.straighten_rounded, color: AppColors.primary, size: 19 * s),
            ),
            SizedBox(width: 12 * s),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(r.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 14.5 * s, fontWeight: FontWeight.w800, color: AppColors.lightTextPrimary)),
                  SizedBox(height: 2 * s),
                  Text(
                    r.used == 0 ? 'Not used yet' : '${r.used} $noun${r.used == 1 ? '' : 's'}',
                    style: TextStyle(fontSize: 11.5 * s, fontWeight: FontWeight.w600, color: AppColors.lightTextSecondary),
                  ),
                ],
              ),
            ),
            Icon(Icons.chevron_right_rounded, color: AppColors.lightTextSecondary, size: 22 * s),
          ],
        ),
      ),
    );
  }

  Widget _empty(double s) {
    return Center(
      key: ValueKey('empty$_tab'),
      child: Padding(
        padding: EdgeInsets.all(24 * s),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(_isCategory ? Icons.category_rounded : Icons.straighten_rounded, size: 46 * s, color: AppColors.lightTextSecondary.withValues(alpha: .5)),
            SizedBox(height: 10 * s),
            Text(
              _isCategory ? 'No categories yet' : 'No units yet',
              style: TextStyle(fontSize: 15 * s, fontWeight: FontWeight.w800, color: AppColors.lightTextPrimary),
            ),
            SizedBox(height: 4 * s),
            Text(
              _isCategory ? 'Tap "Add Category" below to create one.' : 'Tap "Add Unit" below to create one.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 12.5 * s, fontWeight: FontWeight.w600, color: AppColors.lightTextSecondary),
            ),
          ],
        ),
      ),
    );
  }
}

class _RowData {
  final int id;
  final String name;
  final int used;
  const _RowData(this.id, this.name, this.used);
}

/// Add / edit dialog. With [onDelete] it is the row dialog (rename + delete).
/// [onSave] returns an error text to show under the field, or null on success.
/// [onDelete] returns true when the item was deleted (the dialog then closes).
class _NameDialog extends StatefulWidget {
  final String title;
  final String hint;
  final String initial;
  final String saveLabel;
  final String? note;
  final Future<String?> Function(String name) onSave;
  final Future<bool> Function()? onDelete;

  const _NameDialog({
    required this.title,
    required this.hint,
    required this.saveLabel,
    required this.onSave,
    this.initial = '',
    this.note,
    this.onDelete,
  });

  @override
  State<_NameDialog> createState() => _NameDialogState();
}

class _NameDialogState extends State<_NameDialog> {
  late final TextEditingController _c = TextEditingController(text: widget.initial);
  String? _error;
  bool _busy = false;

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (_busy) return;
    setState(() {
      _busy = true;
      _error = null;
    });
    String? err;
    try {
      err = await widget.onSave(_c.text);
    } catch (_) {
      err = 'Could not save. Please try again.';
    }
    if (!mounted) return;
    if (err == null) {
      Navigator.pop(context);
    } else {
      setState(() {
        _busy = false;
        _error = err;
      });
    }
  }

  Future<void> _delete() async {
    if (_busy) return;
    setState(() => _busy = true);
    bool done = false;
    try {
      done = await widget.onDelete!();
    } catch (_) {
      done = false;
    }
    if (!mounted) return;
    if (done) {
      Navigator.pop(context);
    } else {
      setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(widget.title),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          TextField(
            controller: _c,
            autofocus: true,
            textCapitalization: TextCapitalization.words,
            textInputAction: TextInputAction.done,
            onSubmitted: (_) => _save(),
            decoration: InputDecoration(hintText: widget.hint, errorText: _error),
          ),
          if (widget.note != null) ...[
            const SizedBox(height: 10),
            Text(widget.note!, style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: AppColors.lightTextSecondary)),
          ],
        ],
      ),
      actions: [
        if (widget.onDelete != null)
          TextButton(
            onPressed: _busy ? null : _delete,
            style: TextButton.styleFrom(foregroundColor: AppColors.expense),
            child: const Text('Delete'),
          ),
        TextButton(onPressed: _busy ? null : () => Navigator.pop(context), child: const Text('Cancel')),
        FilledButton(onPressed: _busy ? null : _save, child: Text(widget.saveLabel)),
      ],
    );
  }
}
