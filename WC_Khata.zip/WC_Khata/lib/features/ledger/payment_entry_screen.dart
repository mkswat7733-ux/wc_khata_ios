import 'dart:async';
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:record/record.dart';

import '../../app/theme/app_colors.dart';
import '../../core/utils/currency_formatter.dart';
import '../../core/widgets/app_glass_icon_button.dart';
import 'ledger_party.dart';
import 'ledger_repository.dart';
import 'payment_receipt_screen.dart';
import '../../core/widgets/app_message.dart';
import '../../core/services/ledger_media_store.dart';

/// Pay / Receive entry screen.
///
/// The screen intentionally keeps the calculator and Save action in a fixed
/// bottom area. Only the form content scrolls. Amount entry never opens the
/// Android keyboard; the comment field uses the normal keyboard.
class PaymentEntryScreen extends StatefulWidget {
  final LedgerParty party;
  final bool isReceive;
  final LedgerTransaction? transaction;

  const PaymentEntryScreen({
    super.key,
    required this.party,
    required this.isReceive,
    this.transaction,
  });

  @override
  State<PaymentEntryScreen> createState() => _PaymentEntryScreenState();
}

class _PaymentEntryScreenState extends State<PaymentEntryScreen> {
  static const double _maxAmount = 10000000.0; // 1 crore (10,000,000)
  final LedgerRepository _repository = LedgerRepository();
  final TextEditingController _commentController = TextEditingController();
  final FocusNode _commentFocusNode = FocusNode();

  DateTime _selectedDate = DateTime.now();
  String _expression = '';
  bool _calculatorVisible = false;
  bool _saving = false;
  int _animationSeed = 0;

  // ---- Voice note + photo attachment ----
  static const int _maxVoiceSeconds = 180;
  final AudioRecorder _recorder = AudioRecorder();
  final AudioPlayer _player = AudioPlayer();
  StreamSubscription<void>? _playerDone;
  Timer? _recordTimer;
  bool _recording = false;
  bool _playing = false;
  int _recordSeconds = 0;
  String? _voicePath;
  String? _photoPath;
  String? _originalVoice;
  String? _originalPhoto;
  bool _mediaSaved = false;

  bool get _isReceive => widget.isReceive;
  String get _type => widget.party.storedType(_isReceive);
  Color get _accent => _isReceive ? AppColors.income : AppColors.expense;

  double? get _amount {
    final value = _expression.replaceAll(',', '').trim();
    if (value.isEmpty) return null;
    return double.tryParse(value);
  }

  String get _displayAmount => _amount == null
      ? '0'
      : CurrencyFormatter.formatCompact(_amount!);

  @override
  void initState() {
    super.initState();
    _commentFocusNode.addListener(_handleCommentFocus);
    final existing = widget.transaction;
    if (existing != null) {
      _expression = _formatNumber(existing.amount);
      _selectedDate = existing.date;
      _commentController.text = existing.note ?? '';
      _voicePath = _originalVoice = existing.voicePath;
      _photoPath = _originalPhoto = existing.attachmentPath;
    }
    _playerDone = _player.onPlayerComplete.listen((_) {
      if (mounted) setState(() => _playing = false);
    });
  }

  @override
  void dispose() {
    _commentFocusNode.removeListener(_handleCommentFocus);
    _commentFocusNode.dispose();
    _commentController.dispose();
    _recordTimer?.cancel();
    _playerDone?.cancel();
    _player.dispose();
    _recorder.dispose();
    if (!_mediaSaved) {
      // Leaving without saving: drop files created during this session.
      if (_voicePath != _originalVoice) LedgerMediaStore.delete(_voicePath);
      if (_photoPath != _originalPhoto) LedgerMediaStore.delete(_photoPath);
    }
    super.dispose();
  }

  void _handleCommentFocus() {
    if (_commentFocusNode.hasFocus && _calculatorVisible && mounted) {
      setState(() => _calculatorVisible = false);
    }
  }

  void _openCalculator() {
    _commentFocusNode.unfocus();
    FocusScope.of(context).unfocus();
    setState(() => _calculatorVisible = true);
  }

  // ------------------------------------------------------ voice note

  Future<void> _toggleRecording() async {
    if (_recording) {
      await _stopRecording();
      return;
    }
    _commentFocusNode.unfocus();
    try {
      if (!await _recorder.hasPermission()) {
        _showMessage('Microphone permission is required to record a voice note.');
        return;
      }
      await _player.stop();
      final path = await LedgerMediaStore.newVoicePath();
      await _recorder.start(
        const RecordConfig(encoder: AudioEncoder.aacLc, bitRate: 64000, sampleRate: 22050),
        path: path,
      );
      _recordSeconds = 0;
      _recordTimer?.cancel();
      _recordTimer = Timer.periodic(const Duration(seconds: 1), (_) {
        if (!mounted) return;
        setState(() => _recordSeconds++);
        if (_recordSeconds >= _maxVoiceSeconds) _stopRecording();
      });
      if (mounted) setState(() { _recording = true; _playing = false; });
    } catch (_) {
      _showMessage('Could not start recording. Please try again.');
    }
  }

  Future<void> _stopRecording() async {
    _recordTimer?.cancel();
    String? path;
    try {
      path = await _recorder.stop();
    } catch (_) {}
    if (!mounted) return;
    final tooShort = _recordSeconds < 1;
    setState(() => _recording = false);
    if (path == null || tooShort) {
      await LedgerMediaStore.delete(path);
      if (path != null) _showMessage('Recording is too short. Please try again.');
      return;
    }
    // Replace any voice recorded earlier in this session.
    if (_voicePath != null && _voicePath != _originalVoice) await LedgerMediaStore.delete(_voicePath);
    setState(() => _voicePath = path);
  }

  Future<void> _togglePlay() async {
    final file = LedgerMediaStore.resolve(_voicePath);
    if (file == null) {
      _showMessage('This voice note could not be found.');
      return;
    }
    try {
      if (_playing) {
        await _player.pause();
        setState(() => _playing = false);
      } else {
        await _player.play(DeviceFileSource(file.path));
        setState(() => _playing = true);
      }
    } catch (_) {
      _showMessage('Could not play this voice note.');
    }
  }

  Future<void> _removeVoice() async {
    await _player.stop();
    if (_voicePath != _originalVoice) await LedgerMediaStore.delete(_voicePath);
    if (mounted) setState(() { _voicePath = null; _playing = false; });
  }

  // ------------------------------------------------------ photo attachment

  void _openAttachmentSheet() {
    _commentFocusNode.unfocus();
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(22))),
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 14, 18, 14),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40, height: 4,
                  decoration: BoxDecoration(color: const Color(0xFFD0D5DD), borderRadius: BorderRadius.circular(4)),
                ),
              ),
              const SizedBox(height: 14),
              Text(
                widget.party.type == LedgerPartyType.supplier ? 'Supplier photo' : 'Customer photo',
                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: AppColors.lightTextPrimary),
              ),
              const SizedBox(height: 4),
              const Text(
                'This photo will be shown on the receipt like an ID card.',
                style: TextStyle(fontSize: 12, color: AppColors.lightTextSecondary),
              ),
              const SizedBox(height: 10),
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.photo_camera_rounded, color: AppColors.primary),
                title: const Text('Take photo'),
                onTap: () { Navigator.pop(ctx); _pickPhoto(ImageSource.camera); },
              ),
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.photo_library_rounded, color: AppColors.primary),
                title: const Text('Choose from gallery'),
                onTap: () { Navigator.pop(ctx); _pickPhoto(ImageSource.gallery); },
              ),
              if (_photoPath != null)
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: const Icon(Icons.delete_outline_rounded, color: AppColors.expense),
                  title: const Text('Remove photo', style: TextStyle(color: AppColors.expense)),
                  onTap: () { Navigator.pop(ctx); _removePhoto(); },
                ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _pickPhoto(ImageSource source) async {
    try {
      final picked = await ImagePicker().pickImage(source: source, imageQuality: 80, maxWidth: 1280, maxHeight: 1280);
      if (picked == null) return;
      final saved = await LedgerMediaStore.savePhoto(picked.path);
      if (!mounted) {
        await LedgerMediaStore.delete(saved);
        return;
      }
      if (_photoPath != null && _photoPath != _originalPhoto) await LedgerMediaStore.delete(_photoPath);
      setState(() => _photoPath = saved);
    } catch (_) {
      _showMessage('Could not add the photo. Please try again.');
    }
  }

  Future<void> _removePhoto() async {
    if (_photoPath != _originalPhoto) await LedgerMediaStore.delete(_photoPath);
    if (mounted) setState(() => _photoPath = null);
  }

  String _mmss(int seconds) =>
      '${(seconds ~/ 60).toString().padLeft(2, '0')}:${(seconds % 60).toString().padLeft(2, '0')}';

  /// Recording bar / voice chip / photo thumbnail shown under the note.
  Widget _mediaStrip(double s) {
    final photo = LedgerMediaStore.resolve(_photoPath);
    final hasVoice = _voicePath != null;
    if (!_recording && !hasVoice && photo == null) return const SizedBox.shrink();
    return Padding(
      padding: EdgeInsets.only(top: 12 * s),
      child: _card(
        s,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Expanded(
              child: _recording
                  ? Row(
                      children: [
                        Container(width: 10 * s, height: 10 * s, decoration: const BoxDecoration(color: AppColors.expense, shape: BoxShape.circle)),
                        SizedBox(width: 8 * s),
                        Expanded(
                          child: Text(
                            'Recording  ${_mmss(_recordSeconds)}',
                            style: TextStyle(fontSize: 13 * s, fontWeight: FontWeight.w800, color: AppColors.expense),
                          ),
                        ),
                        GestureDetector(
                          onTap: _toggleRecording,
                          child: Container(
                            padding: EdgeInsets.symmetric(horizontal: 14 * s, vertical: 8 * s),
                            decoration: BoxDecoration(color: AppColors.expense, borderRadius: BorderRadius.circular(12 * s)),
                            child: Row(mainAxisSize: MainAxisSize.min, children: [
                              Icon(Icons.stop_rounded, color: Colors.white, size: 16 * s),
                              SizedBox(width: 4 * s),
                              Text('Stop', style: TextStyle(color: Colors.white, fontSize: 12 * s, fontWeight: FontWeight.w800)),
                            ]),
                          ),
                        ),
                      ],
                    )
                  : hasVoice
                      ? Row(
                          children: [
                            GestureDetector(
                              onTap: _togglePlay,
                              child: Container(
                                width: 40 * s, height: 40 * s,
                                decoration: BoxDecoration(color: AppColors.primary, shape: BoxShape.circle),
                                child: Icon(_playing ? Icons.pause_rounded : Icons.play_arrow_rounded, color: Colors.white, size: 24 * s),
                              ),
                            ),
                            SizedBox(width: 10 * s),
                            Expanded(
                              child: Text(
                                _playing ? 'Playing voice note...' : 'Voice note',
                                style: TextStyle(fontSize: 13 * s, fontWeight: FontWeight.w800, color: AppColors.lightTextPrimary),
                              ),
                            ),
                            IconButton(
                              onPressed: _removeVoice,
                              tooltip: 'Remove voice note',
                              icon: Icon(Icons.close_rounded, color: AppColors.lightTextSecondary, size: 20 * s),
                            ),
                          ],
                        )
                      : Text('No voice note', style: TextStyle(fontSize: 12 * s, color: AppColors.lightTextSecondary)),
            ),
            if (photo != null) ...[
              SizedBox(width: 10 * s),
              Stack(
                clipBehavior: Clip.none,
                children: [
                  GestureDetector(
                    onTap: _openAttachmentSheet,
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(10 * s),
                      child: Image.file(photo, width: 54 * s, height: 64 * s, fit: BoxFit.cover),
                    ),
                  ),
                  Positioned(
                    right: -6 * s, top: -6 * s,
                    child: GestureDetector(
                      onTap: _removePhoto,
                      child: Container(
                        width: 20 * s, height: 20 * s,
                        decoration: BoxDecoration(color: AppColors.expense, shape: BoxShape.circle, border: Border.all(color: Colors.white, width: 1.5)),
                        child: Icon(Icons.close_rounded, color: Colors.white, size: 12 * s),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }

  void _closeCalculator() {
    setState(() => _calculatorVisible = false);
  }

  void _calculatorKey(String key) {
    setState(() {
      switch (key) {
        case 'C':
          _expression = '';
          return;
        case '⌫':
          if (_expression.isNotEmpty) {
            _expression = _expression.substring(0, _expression.length - 1);
          }
          return;
        case '=':
          final result = _evaluateExpression(_expression);
          if (result != null) {
            if (result > _maxAmount) {
              _showLimitMessage();
              return;
            }
            _expression = _formatNumber(result);
          }
          return;
        case '.':
          _appendDecimal();
          return;
        case '+':
        case '−':
        case '×':
        case '÷':
          _appendOperator(key);
          return;
        default:
          _appendNumber(key);
      }
    });
  }

  void _appendNumber(String key) {
    if (key == '00' && _expression.isEmpty) return;
    if (key == '000' && _expression.isEmpty) return;

    final lastOperator = _lastOperatorIndex(_expression);
    final currentNumber = lastOperator == -1
        ? _expression
        : _expression.substring(lastOperator + 1);

    final nextNumber = currentNumber == '0'
        ? key
        : currentNumber + key;
    final candidate = currentNumber == '0'
        ? _expression.substring(0, lastOperator + 1) + key
        : _expression + key;
    final parsed = double.tryParse(nextNumber);
    final calculated = _evaluateExpression(candidate);

    // Enforce the 1 crore ceiling while typing. A new digit is rejected only
    // when the resulting number is actually above 10,000,000.
    if ((parsed != null && parsed > _maxAmount) ||
        (calculated != null && calculated > _maxAmount)) {
      // '00' / '000' jump 2-3 digits at once. If the full key overshoots the
      // 1 crore limit but a single '0' still fits (e.g. 10 lakh -> 1 crore),
      // add just one zero instead of showing the error.
      if (key.length > 1 && key.split('').every((c) => c == '0')) {
        final oneZero = _expression + '0';
        final p1 = double.tryParse(
            oneZero.substring(_lastOperatorIndex(oneZero) + 1));
        final c1 = _evaluateExpression(oneZero);
        final fits = (p1 == null || p1 <= _maxAmount) &&
            (c1 == null || c1 <= _maxAmount);
        if (fits && currentNumber != '0' && currentNumber.isNotEmpty) {
          _expression = oneZero;
          return;
        }
      }
      // Say exactly what the key would have produced, so it is clear WHY it
      // was rejected (e.g. 1,000,000 + '5' would become 1,00,00,005).
      _showMessage('$_limitText This key would make it ${_prettyExpression(candidate)}.');
      return;
    }

    _expression = candidate;
  }

  void _appendDecimal() {
    final lastOperator = _lastOperatorIndex(_expression);
    final currentNumber = lastOperator == -1
        ? _expression
        : _expression.substring(lastOperator + 1);
    if (currentNumber.contains('.')) return;
    if (currentNumber.isEmpty) {
      _expression += '0.';
    } else {
      _expression += '.';
    }
  }

  void _appendOperator(String operator) {
    if (_expression.isEmpty) return;
    final last = _expression.substring(_expression.length - 1);
    if ('+−×÷'.contains(last)) {
      _expression = _expression.substring(0, _expression.length - 1) + operator;
      return;
    }
    _expression += operator;
  }

  int _lastOperatorIndex(String value) {
    for (var i = value.length - 1; i >= 0; i--) {
      if ('+−×÷'.contains(value[i])) return i;
    }
    return -1;
  }

  /// Shows every number of the expression with thousands separators
  /// (1000000+250 -> 1,000,000+250). Display only; the raw expression is kept.
  String _prettyExpression(String raw) {
    return raw.replaceAllMapped(RegExp(r'\d+'), (m) {
      final digits = m[0]!;
      // Digits after a decimal point stay as typed.
      final start = m.start;
      if (start > 0 && raw[start - 1] == '.') return digits;
      return _groupLakhCrore(digits);
    });
  }

  /// South-Asian grouping: 10000000 -> 1,00,00,000 (1 crore),
  /// 5000000 -> 50,00,000 (50 lakh), 1000000 -> 10,00,000 (10 lakh).
  String _groupLakhCrore(String digits) {
    if (digits.length <= 3) return digits;
    final last3 = digits.substring(digits.length - 3);
    var rest = digits.substring(0, digits.length - 3);
    final parts = <String>[];
    while (rest.length > 2) {
      parts.insert(0, rest.substring(rest.length - 2));
      rest = rest.substring(0, rest.length - 2);
    }
    if (rest.isNotEmpty) parts.insert(0, rest);
    return '${parts.join(',')},$last3';
  }

  String _formatNumber(double value) {
    if (value.isNaN || value.isInfinite) return '';
    if (value == value.roundToDouble()) return value.toInt().toString();
    return value.toStringAsFixed(10).replaceFirst(RegExp(r'0+$'), '').replaceFirst(RegExp(r'\.$'), '');
  }

  double? _evaluateExpression(String input) {
    if (input.isEmpty) return null;
    var expression = input;
    final last = expression.substring(expression.length - 1);
    if ('+−×÷'.contains(last)) {
      expression = expression.substring(0, expression.length - 1);
    }
    if (expression.isEmpty) return null;

    final tokens = <String>[];
    var number = StringBuffer();
    for (final char in expression.split('')) {
      if ('+−×÷'.contains(char)) {
        if (number.isEmpty) return null;
        tokens.add(number.toString());
        tokens.add(char);
        number = StringBuffer();
      } else {
        number.write(char);
      }
    }
    if (number.isNotEmpty) tokens.add(number.toString());
    if (tokens.isEmpty) return null;

    final values = <double>[];
    final operators = <String>[];
    for (var i = 0; i < tokens.length; i++) {
      final token = tokens[i];
      final parsed = double.tryParse(token);
      if (parsed != null) {
        values.add(parsed);
      } else {
        while (operators.isNotEmpty && _precedence(operators.last) >= _precedence(token)) {
          if (values.length < 2) return null;
          final right = values.removeLast();
          final left = values.removeLast();
          final op = operators.removeLast();
          final result = _apply(left, right, op);
          if (result == null) return null;
          values.add(result);
        }
        operators.add(token);
      }
    }

    while (operators.isNotEmpty) {
      if (values.length < 2) return null;
      final right = values.removeLast();
      final left = values.removeLast();
      final op = operators.removeLast();
      final result = _apply(left, right, op);
      if (result == null) return null;
      values.add(result);
    }

    return values.length == 1 ? values.single : null;
  }

  int _precedence(String operator) => (operator == '×' || operator == '÷') ? 2 : 1;

  double? _apply(double left, double right, String operator) {
    switch (operator) {
      case '+':
        return left + right;
      case '−':
        return left - right;
      case '×':
        return left * right;
      case '÷':
        return right == 0 ? null : left / right;
      default:
        return null;
    }
  }

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
      initialDate: _selectedDate,
      builder: (context, child) => Theme(
        data: Theme.of(context).copyWith(
          colorScheme: Theme.of(context).colorScheme.copyWith(
                primary: AppColors.primary,
              ),
        ),
        child: child!,
      ),
    );
    if (picked != null && mounted) {
      setState(() => _selectedDate = DateTime(picked.year, picked.month, picked.day, _selectedDate.hour, _selectedDate.minute, _selectedDate.second));
    }
  }

  Future<void> _save() async {
    final amount = _amount;
    if (amount == null || !amount.isFinite || amount <= 0 || amount > _maxAmount) {
      _showMessage(amount != null && amount > _maxAmount
          ? _limitText
          : 'Enter a valid amount first.');
      _openCalculator();
      return;
    }
    if (_saving || widget.party.id == null) return;
    if (_recording) await _stopRecording();
    await _player.stop();

    FocusScope.of(context).unfocus();
    setState(() => _saving = true);
    try {
      final existing = widget.transaction;
      if (existing == null) {
        await _repository.addTransaction(
          partyId: widget.party.id!,
          type: _type,
          amount: amount,
          note: _commentController.text.trim(),
          date: _selectedDate,
          voicePath: _voicePath,
          attachmentPath: _photoPath,
        );
      } else {
        await _repository.updateTransaction(
          id: existing.id,
          type: _type,
          amount: amount,
          note: _commentController.text.trim(),
          date: _selectedDate,
          voicePath: _voicePath,
          attachmentPath: _photoPath,
        );
      }
      // Saved: keep new files, and drop files replaced / removed while editing.
      _mediaSaved = true;
      if (_originalVoice != null && _originalVoice != _voicePath) await LedgerMediaStore.delete(_originalVoice);
      if (_originalPhoto != null && _originalPhoto != _photoPath) await LedgerMediaStore.delete(_originalPhoto);
      if (!mounted) return;
      LedgerTransaction? transaction;
      if (existing == null) {
        final list = await _repository.getTransactions(widget.party.id!);
        if (list.isNotEmpty) transaction = list.first;
      } else {
        transaction = await _repository.getTransactionById(existing.id);
      }
      if (!mounted) return;
      if (transaction == null) {
        _showMessage('Payment saved, but receipt could not be opened.');
        Navigator.of(context).pop(true);
        return;
      }
      if (existing != null) {
        Navigator.of(context).pop(true);
        return;
      }
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(
          builder: (_) => PaymentReceiptScreen(
            party: widget.party,
            transaction: transaction!,
          ),
        ),
      );
    } catch (_) {
      if (mounted) {
        _showMessage('Could not save payment. Please try again.');
      }
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  static const String _limitText = 'Maximum amount is 1 Crore (1,00,00,000).';

  void _showLimitMessage() {
    _showMessage(_limitText);
  }

  void _showMessage(String message) {
    if (!mounted) return;
    AppMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.sizeOf(context);
    final scale = (size.width / 390).clamp(0.82, 1.14).toDouble();

    return Scaffold(
      backgroundColor: AppColors.lightBackground,
      resizeToAvoidBottomInset: true,
      body: SafeArea(
        child: Column(
          children: [
            _header(scale),
            Expanded(child: _formArea(scale)),
          ],
        ),
      ),
    );
  }

  Widget _formArea(double s) {
    return Column(
      children: [
        Expanded(
          child: SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            padding: EdgeInsets.fromLTRB(16 * s, 12 * s, 16 * s, 12 * s),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                _staggeredCard(s, 0, _amountCard(s)),
                SizedBox(height: 12 * s),
                _staggeredCard(s, 1, _commentCard(s)),
                _mediaStrip(s),
                SizedBox(height: 12 * s),
                _staggeredCard(s, 2, _dateCard(s)),
                _cashbookHint(s),
              ],
            ),
          ),
        ),
        _bottomActions(s),
      ],
    );
  }

  Widget _staggeredCard(double s, int index, Widget child) {
    return TweenAnimationBuilder<double>(
      key: ValueKey('payment-card-${_animationSeed}-$index'),
      tween: Tween(begin: 0, end: 1),
      duration: Duration(milliseconds: 280 + (index * 70)),
      curve: Curves.easeOutCubic,
      builder: (context, value, child) {
        final dy = (1 - value) * 14 * s;
        return Opacity(
          opacity: value.clamp(0.0, 1.0),
          child: Transform.translate(
            offset: Offset(0, dy),
            child: child,
          ),
        );
      },
      child: child,
    );
  }

  Widget _bottomActions(double s) {
    return Material(
      color: Colors.white,
      elevation: 8,
      shadowColor: Colors.black.withValues(alpha: .08),
      child: SafeArea(
        top: false,
        child: AnimatedSize(
          duration: const Duration(milliseconds: 220),
          curve: Curves.easeOutCubic,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              AnimatedSwitcher(
                duration: const Duration(milliseconds: 240),
                switchInCurve: Curves.easeOutCubic,
                switchOutCurve: Curves.easeInCubic,
                transitionBuilder: (child, animation) => SizeTransition(
                  sizeFactor: animation,
                  axisAlignment: -1,
                  child: FadeTransition(opacity: animation, child: child),
                ),
                child: _calculatorVisible
                    ? KeyedSubtree(key: const ValueKey('calculator'), child: _calculator(s))
                    : const SizedBox.shrink(key: ValueKey('no-calculator')),
              ),
              Padding(
                padding: EdgeInsets.fromLTRB(16 * s, 9 * s, 16 * s, 9 * s),
                child: _saveButton(s),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _header(double s) {
    return Container(
      height: 62 * s,
      padding: EdgeInsets.symmetric(horizontal: 14 * s),
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(bottom: BorderSide(color: AppColors.lightDivider)),
      ),
      child: Row(
        children: [
          AppGlassIconButton(
            icon: Icons.arrow_back_rounded,
            onTap: () => Navigator.of(context).pop(),
          ),
          SizedBox(width: 8 * s),
          Text(
            _isReceive ? 'Receive' : 'Pay',
            style: TextStyle(
              fontSize: 19 * s,
              fontWeight: FontWeight.w900,
              color: AppColors.lightTextPrimary,
            ),
          ),
          SizedBox(width: 12 * s),
          Expanded(
            child: Text(
              widget.party.name,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                fontSize: 17 * s,
                fontWeight: FontWeight.w800,
                color: AppColors.lightTextSecondary,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _amountCard(double s) {
    return _card(
      s,
      padding: EdgeInsets.fromLTRB(14 * s, 12 * s, 14 * s, 14 * s),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Enter amount',
            textAlign: TextAlign.left,
            style: TextStyle(
              fontSize: 13 * s,
              fontWeight: FontWeight.w800,
              color: AppColors.lightTextPrimary,
            ),
          ),
          SizedBox(height: 8 * s),
          GestureDetector(
            onTap: _openCalculator,
            child: Container(
              height: 76 * s,
              padding: EdgeInsets.symmetric(horizontal: 15 * s),
              decoration: BoxDecoration(
                color: AppColors.lightBackground,
                borderRadius: BorderRadius.circular(17 * s),
                border: Border.all(
                  color: _calculatorVisible
                      ? _accent
                      : AppColors.lightCardBorder,
                  width: _calculatorVisible ? 1.5 : 1,
                ),
              ),
              child: Row(
                children: [
                  Text(
                    CurrencyFormatter.label,
                    style: TextStyle(
                      fontSize: 16 * s,
                      fontWeight: FontWeight.w900,
                      color: AppColors.lightTextSecondary,
                    ),
                  ),
                  SizedBox(width: 9 * s),
                  Expanded(
                    // FittedBox shrinks the text instead of cutting it off, so
                    // the whole amount (up to 1 crore, or a longer calculation)
                    // is always visible inside the box.
                    child: FittedBox(
                      fit: BoxFit.scaleDown,
                      alignment: Alignment.centerLeft,
                      child: Text(
                      _expression.isEmpty ? '0' : _prettyExpression(_expression),
                      textAlign: TextAlign.left,
                      maxLines: 1,
                      softWrap: false,
                      style: TextStyle(
                        fontSize: 27 * s,
                        fontWeight: FontWeight.w900,
                        color: _expression.isEmpty
                            ? AppColors.lightTextSecondary
                            : AppColors.lightTextPrimary,
                      ),
                    ),
                    ),
                  ),
                  Icon(
                    _calculatorVisible
                        ? Icons.keyboard_arrow_down_rounded
                        : Icons.calculate_outlined,
                    color: _accent,
                    size: 23 * s,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _commentCard(double s) {
    return _card(
      s,
      padding: EdgeInsets.fromLTRB(12 * s, 10 * s, 9 * s, 10 * s),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Expanded(
            child: TextField(
              controller: _commentController,
              focusNode: _commentFocusNode,
              minLines: 2,
              maxLines: 3,
              textCapitalization: TextCapitalization.sentences,
              decoration: InputDecoration(
                isDense: true,
                labelText: 'Comment (optional)',
                hintText: 'Add a note',
                border: InputBorder.none,
                contentPadding: EdgeInsets.symmetric(vertical: 8 * s),
                labelStyle: TextStyle(
                  fontSize: 12 * s,
                  color: AppColors.lightTextSecondary,
                ),
                hintStyle: TextStyle(
                  fontSize: 11 * s,
                  color: AppColors.lightTextSecondary,
                ),
              ),
            ),
          ),
          SizedBox(width: 5 * s),
          _smallTool(
            s,
            Icons.attach_file_rounded,
            'Attachment',
            _openAttachmentSheet,
          ),
          SizedBox(width: 4 * s),
          _smallTool(
            s,
            _recording ? Icons.stop_rounded : Icons.mic_none_rounded,
            'Voice',
            _toggleRecording,
          ),
        ],
      ),
    );
  }

  /// Tells the user what this entry does to the Cashbook.
  Widget _cashbookHint(double s) {
    final isCustomer = widget.party.type == LedgerPartyType.customer;
    final String? text;
    if (isCustomer) {
      text = _isReceive
          ? 'This amount will be added to your Cashbook (Cash In).'
          : 'This amount will be deducted from your Cashbook (Cash Out). It is not counted as an expense.';
    } else {
      text = _isReceive
          ? null
          : 'This payment will be deducted from your Cashbook. It is not counted as an expense.';
    }
    if (text == null) return const SizedBox.shrink();
    return Padding(
      padding: EdgeInsets.only(top: 12 * s),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(Icons.info_outline_rounded, size: 15 * s, color: _accent),
          SizedBox(width: 6 * s),
          Expanded(
            child: Text(
              text,
              style: TextStyle(fontSize: 11.5 * s, height: 1.35, fontWeight: FontWeight.w600, color: AppColors.lightTextSecondary),
            ),
          ),
        ],
      ),
    );
  }

  Widget _dateCard(double s) {
    return _card(
      s,
      child: InkWell(
        borderRadius: BorderRadius.circular(18 * s),
        onTap: _pickDate,
        child: Row(
          children: [
            Container(
              width: 38 * s,
              height: 38 * s,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: AppColors.primary.withValues(alpha: .10),
                borderRadius: BorderRadius.circular(12 * s),
              ),
              child: Icon(
                Icons.calendar_month_rounded,
                color: AppColors.primary,
                size: 19 * s,
              ),
            ),
            SizedBox(width: 10 * s),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Date',
                    style: TextStyle(
                      fontSize: 10.5 * s,
                      color: AppColors.lightTextSecondary,
                    ),
                  ),
                  Text(
                    DateFormat('dd MMM yyyy').format(_selectedDate),
                    style: TextStyle(
                      fontSize: 13 * s,
                      fontWeight: FontWeight.w800,
                      color: AppColors.lightTextPrimary,
                    ),
                  ),
                ],
              ),
            ),
            Text(
              _isSameDay(_selectedDate, DateTime.now()) ? 'Today' : 'Change',
              style: TextStyle(
                fontSize: 11 * s,
                color: AppColors.primary,
                fontWeight: FontWeight.w800,
              ),
            ),
            SizedBox(width: 3 * s),
            Icon(
              Icons.chevron_right_rounded,
              color: AppColors.lightTextSecondary,
              size: 20 * s,
            ),
          ],
        ),
      ),
    );
  }

  Widget _saveButton(double s) {
    return GestureDetector(
      onTap: _saving ? null : _save,
      child: AnimatedOpacity(
        duration: const Duration(milliseconds: 150),
        opacity: _saving ? .65 : 1,
        child: Container(
          height: 52 * s,
          decoration: BoxDecoration(
            color: _accent,
            borderRadius: BorderRadius.circular(17 * s),
            boxShadow: [
              BoxShadow(
                color: _accent.withValues(alpha: .25),
                blurRadius: 12 * s,
                offset: Offset(0, 5 * s),
              ),
            ],
          ),
          child: Center(
            child: _saving
                ? SizedBox(
                    width: 21 * s,
                    height: 21 * s,
                    child: const CircularProgressIndicator(
                      strokeWidth: 2.2,
                      color: Colors.white,
                    ),
                  )
                : Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.check_circle_outline_rounded,
                        color: Colors.white,
                        size: 20 * s,
                      ),
                      SizedBox(width: 7 * s),
                      Text(
                        widget.transaction != null ? 'Save Changes' : (_isReceive ? 'Save Receive' : 'Save Payment'),
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 14 * s,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ],
                  ),
          ),
        ),
      ),
    );
  }

  Widget _calculator(double s) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.fromLTRB(11 * s, 8 * s, 11 * s, 9 * s),
      decoration: BoxDecoration(
        color: AppColors.lightBackground,
        border: const Border(top: BorderSide(color: AppColors.lightDivider)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          _calculatorRow(s, ['C', '÷', '×', '⌫']),
          SizedBox(height: 7 * s),
          _calculatorRow(s, ['7', '8', '9', '−']),
          SizedBox(height: 7 * s),
          _calculatorRow(s, ['4', '5', '6', '+']),
          SizedBox(height: 7 * s),
          _calculatorRow(s, ['1', '2', '3', '=']),
          SizedBox(height: 7 * s),
          _calculatorRow(s, ['0', '00', '.', 'Done']),
        ],
      ),
    );
  }

  Widget _calculatorRow(double s, List<String> keys) {
    return Row(
      children: keys
          .map(
            (key) => Expanded(
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 3.5 * s),
                child: _calcButton(s, key),
              ),
            ),
          )
          .toList(),
    );
  }

  Widget _calcButton(double s, String key) {
    final isOperator = '÷×−+'.contains(key);
    final isEquals = key == '=' || key == 'Done';
    final isClear = key == 'C';

    return _AnimatedCalcButton(
      scale: s,
      label: key,
      onTap: () {
        if (key == 'Done') {
          _closeCalculator();
          return;
        }
        _calculatorKey(key);
      },
      background: Colors.black,
      foreground: Colors.white,
      borderColor: Colors.black,
      fontSize: key == 'Done' ? 12 * s : 19 * s,
    );
  }


  Widget _smallTool(
    double s,
    IconData icon,
    String tooltip,
    VoidCallback onTap,
  ) {
    return Tooltip(
      message: tooltip,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(10 * s),
        child: Container(
          width: 38 * s,
          height: 38 * s,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: AppColors.lightBackground,
            borderRadius: BorderRadius.circular(10 * s),
          ),
          child: Icon(icon, color: AppColors.primary, size: 19 * s),
        ),
      ),
    );
  }

  Widget _card(
    double s, {
    required Widget child,
    EdgeInsets? padding,
  }) {
    return Container(
      padding: padding ?? EdgeInsets.all(12 * s),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(19 * s),
        border: Border.all(color: AppColors.lightCardBorder),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: .045),
            blurRadius: 12 * s,
            offset: Offset(0, 4 * s),
          ),
        ],
      ),
      child: child,
    );
  }

  bool _isSameDay(DateTime a, DateTime b) =>
      a.year == b.year && a.month == b.month && a.day == b.day;
}


class _AnimatedCalcButton extends StatefulWidget {
  final double scale;
  final String label;
  final VoidCallback onTap;
  final Color background;
  final Color foreground;
  final Color borderColor;
  final double fontSize;

  const _AnimatedCalcButton({
    required this.scale,
    required this.label,
    required this.onTap,
    required this.background,
    required this.foreground,
    required this.borderColor,
    required this.fontSize,
  });

  @override
  State<_AnimatedCalcButton> createState() => _AnimatedCalcButtonState();
}

class _AnimatedCalcButtonState extends State<_AnimatedCalcButton> {
  bool _pressed = false;

  void _setPressed(bool value) {
    if (mounted) setState(() => _pressed = value);
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.scale;
    return Semantics(
      button: true,
      label: widget.label,
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTapDown: (_) => _setPressed(true),
        onTapCancel: () => _setPressed(false),
        onTapUp: (_) {
          _setPressed(false);
          widget.onTap();
        },
        child: AnimatedScale(
          scale: _pressed ? .93 : 1,
          duration: const Duration(milliseconds: 90),
          curve: Curves.easeOutCubic,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 90),
            curve: Curves.easeOutCubic,
            height: 50 * s,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: widget.background,
              borderRadius: BorderRadius.circular(14 * s),
              border: Border.all(color: widget.borderColor),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: _pressed ? .04 : .10),
                  blurRadius: _pressed ? 2 : 7,
                  offset: Offset(0, _pressed ? 1 : 3),
                ),
              ],
            ),
            child: Text(
              widget.label,
              style: TextStyle(
                color: widget.foreground,
                fontSize: widget.fontSize,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
        ),
      ),
    );
  }
}
