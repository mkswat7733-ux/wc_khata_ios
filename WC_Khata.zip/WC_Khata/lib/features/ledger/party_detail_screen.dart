import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:flutter/services.dart';

import '../../app/theme/app_theme.dart';
import '../../core/utils/currency_formatter.dart';
import '../../core/services/notification_service.dart';
import '../../core/widgets/app_glass_icon_button.dart';
import '../reports/report_repository.dart';
import 'both_star_badge.dart';
import 'ledger_party.dart';
import 'new_party_screen.dart';
import 'ledger_repository.dart';
import '../reports/reports_screen.dart';
import 'payment_entry_screen.dart';
import 'payment_receipt_screen.dart';
import '../../core/widgets/app_message.dart';
import '../../core/utils/amount_limit.dart';

/// Customer/Supplier ledger detail screen.
///
/// A party has a balance, optional reminder, communication actions and a
/// chronological transaction history. Pay and Receive are persisted locally.
class PartyDetailScreen extends StatefulWidget {
  final LedgerParty party;

  const PartyDetailScreen({super.key, required this.party});

  @override
  State<PartyDetailScreen> createState() => _PartyDetailScreenState();
}

class _PartyDetailScreenState extends State<PartyDetailScreen> {
  final LedgerRepository _repository = LedgerRepository();

  late LedgerParty _party;
  List<LedgerTransaction> _transactions = <LedgerTransaction>[];
  bool _loading = true;
  bool _savingTransaction = false;

  @override
  void initState() {
    super.initState();
    _party = widget.party;
    _load();
  }

  Future<void> _load() async {
    final int? partyId = _party.id;
    if (partyId == null) {
      if (mounted) setState(() => _loading = false);
      return;
    }

    try {
      final List<LedgerParty> parties = await _repository.getParties();
      LedgerParty? freshParty;
      for (final LedgerParty party in parties) {
        if (party.id == partyId) {
          freshParty = party;
          break;
        }
      }

      // "Both" = one khata: customer and supplier entries together.
      final int? linkedId = (freshParty ?? _party).linkedPartyId;
      final List<LedgerTransaction> transactions = linkedId == null
          ? await _repository.getTransactions(partyId)
          : await _repository.getTransactionsWithLinked(partyId, linkedId);

      if (!mounted) return;
      setState(() {
        if (freshParty != null) {
          _party = freshParty;
        }
        _transactions = transactions;
        _loading = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() => _loading = false);
      _showMessage('Could not load this ledger. Please try again.');
    }
  }

  /// Edit name, phone and type (Customer / Supplier / Both).
  Future<void> _editParty() async {
    if (_party.id == null) return;
    final int? keepId = await Navigator.of(context).push<int>(
      MaterialPageRoute(
        builder: (_) => NewPartyScreen(type: _party.type, editing: _party),
      ),
    );
    if (keepId == null || !mounted) return;
    final LedgerParty? updated = await _repository.getPartyById(keepId);
    if (updated != null && mounted) {
      setState(() => _party = updated);
    }
    await _load();
    if (mounted) _showMessage('Details updated.');
  }

  Future<void> _addTransaction(String type) async {
    if (_savingTransaction || _party.id == null) return;

    final bool? saved = await Navigator.of(context).push<bool>(
      MaterialPageRoute(
        builder: (_) => PaymentEntryScreen(
          party: _party,
          isReceive: type == 'receive',
        ),
      ),
    );

    if (saved == true && mounted) {
      await _load();
    }
  }

  Future<void> _setReminder() async {
    final int? partyId = _party.id;
    if (partyId == null || !_remindersEnabled) return;

    final Map<String, Object?>? values = await showModalBottomSheet<Map<String, Object?>>(
      context: context,
      isScrollControlled: true,
      enableDrag: false,
      backgroundColor: Colors.transparent,
      barrierColor: Colors.black54,
      useSafeArea: true,
      builder: (_) => _PaymentReminderSheet(
        partyName: _party.name,
        initialAmount: _party.reminderAmount ?? _party.balance.abs(),
        initialDate: _party.reminderDate ?? DateTime.now().add(const Duration(days: 7)),
      ),
    );

    if (values == null || !mounted) return;

    try {
      final double amount = values['amount']! as double;
      final DateTime date = values['date']! as DateTime;
      await _repository.setReminder(
        partyId: partyId,
        date: date,
        amount: amount,
      );

      final LedgerParty? updated = await _repository.getPartyById(partyId);
      if (updated != null) {
        await NotificationService.instance.scheduleLedgerReminder(updated);
      }

      await _load();
      if (mounted) {
        _showMessage(
          'Reminder set for ${DateFormat('dd MMM yyyy').format(date)} at 9:00 AM.',
        );
      }
    } catch (_) {
      if (mounted) {
        _showMessage('Could not save the reminder. Please try again.');
      }
    }
  }

  bool get _remindersEnabled => _party.isReceivable;

  String _reminderSmsText() {
    final amount = CurrencyFormatter.formatCompact(_party.balance.abs());
    return 'Hello ${_party.name},\n\nA payment of $amount is pending on your account. Please pay at your earliest convenience.\n\nThank you.\nPowered by WebdSoft Company';
  }

  Future<void> _sendReminderSms() async {
    if (!_remindersEnabled) return;
    final phone = _party.phone?.trim();
    if (phone == null || phone.isEmpty) return;
    try {
      final result = await const MethodChannel('wc_khata/whatsapp')
          .invokeMethod<String>('sendReminderSms', <String, dynamic>{
        'phone': phone,
        'smsText': _reminderSmsText(),
      });
      if (!mounted) return;
      if (result == 'sms') {
        _showMessage('Opening SMS for ${_party.name}.');
      } else {
        _showMessage('No SMS app is available on this device.');
      }
    } on PlatformException {
      if (mounted) _showMessage('Could not open the SMS app.');
    }
  }

  Future<void> _sendReminderWhatsApp() async {
    if (!_remindersEnabled) return;
    final phone = _party.phone?.trim();
    if (phone == null || phone.isEmpty) return;
    try {
      final result = await const MethodChannel('wc_khata/whatsapp')
          .invokeMethod<String>('sendReminderWhatsApp', <String, dynamic>{
        'phone': phone,
        'message': _reminderSmsText(),
      });
      if (!mounted) return;
      if (result == 'whatsapp') {
        _showMessage('Opening WhatsApp for ${_party.name}.');
      } else {
        _showMessage('WhatsApp could not open for this number.');
      }
    } on PlatformException {
      if (mounted) _showMessage('Could not open WhatsApp.');
    }
  }

  void _showMessage(String message) {
    if (!mounted) return;
    AppMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  void _openCustomerReport() {
    final customerId = _party.type == LedgerPartyType.customer
        ? _party.id
        : _party.linkedPartyId;
    if (customerId == null) {
      _showMessage('Customer ledger is not available for this party.');
      return;
    }
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => ReportsScreen(
          initialType: ReportType.customerLedger,
          customerId: customerId,
          customerName: _party.name,
        ),
      ),
    );
  }

  void _openSupplierReport() {
    final supplierId = _party.type == LedgerPartyType.supplier
        ? _party.id
        : _party.linkedPartyId;
    if (supplierId == null) {
      _showMessage('Supplier ledger is not available for this party.');
      return;
    }
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => ReportsScreen(
          initialType: ReportType.supplierLedger,
          supplierId: supplierId,
          supplierName: _party.name,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final double scale =
        (MediaQuery.sizeOf(context).width / 390).clamp(0.74, 1.12).toDouble();

    return Scaffold(
      backgroundColor: AppColors.lightBackground,
      resizeToAvoidBottomInset: true,
      body: SafeArea(
        bottom: false,
        child: Column(
          children: <Widget>[
            _buildHeader(scale),
            Expanded(
              child: Padding(
                padding: EdgeInsets.fromLTRB(
                  14 * scale,
                  10 * scale,
                  14 * scale,
                  8 * scale,
                ),
                child: Column(
                  children: <Widget>[
                    _buildBalanceSummary(scale),
                    if (_party.phone?.isNotEmpty == true) ...<Widget>[
                      SizedBox(height: 8 * scale),
                      _infoRow(scale, Icons.phone_rounded, _party.phone!),
                    ],
                    SizedBox(height: 8 * scale),
                    _buildReminderBar(scale),
                    SizedBox(height: 9 * scale),
                    Expanded(child: _buildTransactionsCard(scale)),
                    SizedBox(height: 9 * scale),
                    _buildFixedActionBar(scale),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFixedActionBar(double scale) {
    return SafeArea(
      top: false,
      child: Row(
        children: <Widget>[
          Expanded(
            child: _actionButton(
              scale,
              'Pay',
              Icons.arrow_upward_rounded,
              AppColors.expense,
              () => _addTransaction('pay'),
            ),
          ),
          SizedBox(width: 10 * scale),
          Expanded(
            child: _actionButton(
              scale,
              'Receive',
              Icons.arrow_downward_rounded,
              AppColors.income,
              () => _addTransaction('receive'),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader(double scale) {
    return SafeArea(
      bottom: false,
      child: Container(
        height: 58 * scale,
        padding: EdgeInsets.symmetric(horizontal: 14 * scale),
        decoration: const BoxDecoration(
          color: Colors.white,
          border: Border(
            bottom: BorderSide(color: AppColors.lightDivider),
          ),
        ),
        child: Row(
          children: <Widget>[
            AppGlassIconButton(
              icon: Icons.arrow_back_rounded,
              onTap: () => Navigator.of(context).pop(),
            ),
            if (_party.type == LedgerPartyType.supplier || _party.isBoth) ...<Widget>[
              SizedBox(width: 8 * scale),
              AppGlassIconButton(
                icon: Icons.assessment_rounded,
                onTap: _openSupplierReport,
              ),
            ],
            if (_party.type == LedgerPartyType.customer && !_party.isBoth) ...<Widget>[
              SizedBox(width: 8 * scale),
              AppGlassIconButton(
                icon: Icons.assessment_rounded,
                onTap: _openCustomerReport,
              ),
            ],
            Expanded(
              child: Center(
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    Flexible(
                      child: Text(
                        _party.name,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: AppColors.lightTextPrimary,
                          fontSize: 19 * scale,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                    if (_party.isBoth) ...<Widget>[
                      SizedBox(width: 6 * scale),
                      BothStarBadge(size: 20 * scale),
                    ],
                  ],
                ),
              ),
            ),
            AppGlassIconButton(
              icon: Icons.edit_rounded,
              onTap: _editParty,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBalanceSummary(double scale) {
    final bool receivable = _party.isReceivable;
    final bool payable = _party.isPayable;
    final bool settled = !receivable && !payable;
    final String label = receivable
        ? 'Receivable'
        : payable
            ? 'Payable'
            : 'No Balance';
    final double amount = (receivable || payable) ? _party.balance.abs() : 0;
    final Color color = settled
        ? AppColors.lightTextSecondary
        : receivable
            ? AppColors.income
            : AppColors.expense;
    final IconData icon = receivable
        ? Icons.arrow_downward_rounded
        : payable
            ? Icons.arrow_upward_rounded
            : Icons.remove_circle_outline_rounded;

    return _balanceCard(scale, label, amount, color, icon, enabled: !settled);
  }

  Widget _balanceCard(
    double scale,
    String label,
    double amount,
    Color color,
    IconData icon, {
    bool enabled = true,
  }) {
    final Color effectiveColor = enabled
        ? color
        : Color.lerp(color, Colors.black, 0.58)!;
    return Container(
      padding: EdgeInsets.fromLTRB(
        12 * scale,
        10 * scale,
        12 * scale,
        11 * scale,
      ),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18 * scale),
        border: Border.all(color: AppColors.lightCardBorder, width: 1.2),
        boxShadow: <BoxShadow>[
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 10 * scale,
            offset: Offset(0, 4 * scale),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              Container(
                width: 28 * scale,
                height: 28 * scale,
                decoration: BoxDecoration(
                  color: effectiveColor.withValues(alpha: 0.10),
                  borderRadius: BorderRadius.circular(9 * scale),
                ),
                child: Icon(icon, color: effectiveColor, size: 16 * scale),
              ),
              SizedBox(width: 8 * scale),
              Expanded(
                child: Text(
                  label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 12 * scale,
                    fontWeight: FontWeight.w800,
                    color: AppColors.lightTextPrimary,
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 7 * scale),
          Text(
            CurrencyFormatter.formatCompact(amount),
            style: TextStyle(
              fontSize: 17 * scale,
              fontWeight: FontWeight.w800,
              color: effectiveColor,
            ),
          ),
        ],
      ),
    );
  }

  Widget _infoRow(double scale, IconData icon, String text) {
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: 12 * scale,
        vertical: 10 * scale,
      ),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15 * scale),
        border: Border.all(color: AppColors.lightCardBorder, width: 1.2),
      ),
      child: Row(
        children: <Widget>[
          Icon(icon, color: AppColors.lightTextSecondary, size: 18 * scale),
          SizedBox(width: 8 * scale),
          Expanded(
            child: Text(
              text,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                fontSize: 12.5 * scale,
                color: AppColors.lightTextPrimary,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildReminderBar(double scale) {
    final String subtitle = _party.reminderDate == null
        ? 'Set next payment reminder'
        : 'Due ${DateFormat('dd MMM').format(_party.reminderDate!)}';

    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: 11 * scale,
        vertical: 9 * scale,
      ),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18 * scale),
        border: Border.all(color: AppColors.lightCardBorder, width: 1.2),
        boxShadow: <BoxShadow>[
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 10 * scale,
            offset: Offset(0, 4 * scale),
          ),
        ],
      ),
      child: Row(
        children: <Widget>[
          Container(
            width: 31 * scale,
            height: 31 * scale,
            decoration: BoxDecoration(
              color: AppColors.warning.withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(10 * scale),
            ),
            child: Icon(
              Icons.notifications_active_rounded,
              color: AppColors.warning,
              size: 17 * scale,
            ),
          ),
          SizedBox(width: 8 * scale),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  'Reminder',
                  style: TextStyle(
                    fontSize: 12.5 * scale,
                    fontWeight: FontWeight.w800,
                    color: AppColors.lightTextPrimary,
                  ),
                ),
                Text(
                  subtitle,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 10 * scale,
                    color: AppColors.lightTextSecondary,
                  ),
                ),
              ],
            ),
          ),
          _chip(
            scale,
            'Set',
            Icons.event_available_rounded,
            AppColors.warning,
            _remindersEnabled ? _setReminder : null,
          ),
          SizedBox(width: 6 * scale),
          _chip(
            scale,
            'SMS',
            Icons.sms_rounded,
            const Color(0xFF2563EB),
            _remindersEnabled ? _sendReminderSms : null,
          ),
          SizedBox(width: 6 * scale),
          _chip(
            scale,
            'WhatsApp',
            Icons.chat_rounded,
            const Color(0xFF16A34A),
            _remindersEnabled ? _sendReminderWhatsApp : null,
          ),
        ],
      ),
    );
  }

  Widget _chip(
    double scale,
    String label,
    IconData icon,
    Color color,
    VoidCallback? onTap,
  ) {
    final bool enabled = onTap != null;
    final Color effectiveColor = enabled
        ? color
        : Color.lerp(color, Colors.black, 0.58)!;
    return GestureDetector(
      onTap: onTap,

      child: Container(
        padding: EdgeInsets.symmetric(
          horizontal: 8 * scale,
          vertical: 7 * scale,
        ),
        decoration: BoxDecoration(
          color: effectiveColor,
          borderRadius: BorderRadius.circular(12 * scale),
          boxShadow: <BoxShadow>[
            BoxShadow(
              color: effectiveColor.withValues(alpha: enabled ? 0.25 : 0.08),
              blurRadius: 7 * scale,
              offset: Offset(0, 3 * scale),
            ),
          ],
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Icon(icon, color: Colors.white, size: 13 * scale),
            SizedBox(width: 3 * scale),
            Text(
              label,
              style: TextStyle(
                color: Colors.white,
                fontSize: 10.5 * scale,
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTransactionsCard(double scale) {
    return Container(
      width: double.infinity,
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20 * scale),
        border: Border.all(color: AppColors.lightCardBorder, width: 1.2),
        boxShadow: <BoxShadow>[
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 12 * scale,
            offset: Offset(0, 5 * scale),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Padding(
            padding: EdgeInsets.fromLTRB(
              14 * scale,
              11 * scale,
              14 * scale,
              8 * scale,
            ),
            child: Row(
              children: <Widget>[
                Icon(
                  Icons.receipt_long_rounded,
                  color: AppColors.primary,
                  size: 19 * scale,
                ),
                SizedBox(width: 8 * scale),
                Expanded(
                  child: Text(
                    'Transactions',
                    style: TextStyle(
                      fontSize: 14 * scale,
                      fontWeight: FontWeight.w800,
                      color: AppColors.lightTextPrimary,
                    ),
                  ),
                ),
                if (_transactions.isNotEmpty)
                  Text(
                    '${_transactions.length}',
                    style: TextStyle(
                      fontSize: 11 * scale,
                      fontWeight: FontWeight.w700,
                      color: AppColors.lightTextSecondary,
                    ),
                  ),
              ],
            ),
          ),
          const Divider(height: 1, color: AppColors.lightDivider),
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : _transactions.isEmpty
                    ? Center(
                        child: Padding(
                          padding: EdgeInsets.all(18 * scale),
                          child: Text(
                            'No transactions yet.\nUse Pay or Receive below to start this khata.',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 11.5 * scale,
                              color: AppColors.lightTextSecondary,
                              height: 1.35,
                            ),
                          ),
                        ),
                      )
                    : Scrollbar(
                        child: ListView.builder(
                          physics: const BouncingScrollPhysics(),
                          padding: EdgeInsets.zero,
                          itemCount: _transactions.length,
                          itemBuilder: (BuildContext context, int index) =>
                              _transactionTile(scale, _transactions[index]),
                        ),
                      ),
          ),
        ],
      ),
    );
  }

  /// The party row an entry belongs to (for a "Both" khata the supplier-side
  /// entries belong to the linked supplier row).
  LedgerParty _partyFor(LedgerTransaction transaction) {
    if (!transaction.fromSupplier || _party.linkedPartyId == null) return _party;
    return LedgerParty(
      id: _party.linkedPartyId,
      name: _party.name,
      phone: _party.phone,
      address: _party.address,
      type: LedgerPartyType.supplier,
      linkedPartyId: _party.id,
      balance: 0,
    );
  }

  Widget _transactionTile(double scale, LedgerTransaction transaction) {
    final LedgerParty txParty = _partyFor(transaction);
    final bool isReceive = txParty.uiIsReceive(transaction.type);
    final Color color = isReceive ? AppColors.income : AppColors.expense;
    final String note = transaction.note?.trim() ?? '';
    final String subtitle = note.isNotEmpty
        ? note
        : DateFormat('dd MMM yyyy').format(transaction.date);

    return InkWell(
      onTap: () async {
        final deleted = await Navigator.of(context).push<bool>(
          MaterialPageRoute(
            builder: (_) => PaymentReceiptScreen(
              party: txParty,
              transaction: transaction,
            ),
          ),
        );
        if (deleted == true && mounted) {
          await _load();
        }
      },
      child: Container(
        padding: EdgeInsets.symmetric(
          horizontal: 14 * scale,
          vertical: 10 * scale,
        ),
        decoration: const BoxDecoration(
          border: Border(top: BorderSide(color: AppColors.lightDivider)),
        ),
        child: Row(
        children: <Widget>[
          Container(
            width: 34 * scale,
            height: 34 * scale,
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.10),
              borderRadius: BorderRadius.circular(10 * scale),
            ),
            child: Icon(
              isReceive
                  ? Icons.arrow_downward_rounded
                  : Icons.arrow_upward_rounded,
              color: color,
              size: 17 * scale,
            ),
          ),
          SizedBox(width: 9 * scale),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  isReceive ? 'Receive' : 'Pay',
                  style: TextStyle(
                    fontSize: 12.5 * scale,
                    fontWeight: FontWeight.w800,
                    color: AppColors.lightTextPrimary,
                  ),
                ),
                Text(
                  subtitle,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 10.5 * scale,
                    color: AppColors.lightTextSecondary,
                  ),
                ),
              ],
            ),
          ),
          Text(
            '${isReceive ? '+' : '-'}${CurrencyFormatter.formatCompact(transaction.amount)}',
            style: TextStyle(
              fontSize: 13 * scale,
              fontWeight: FontWeight.w800,
              color: color,
            ),
          ),
        ],
      ),
    ),
    );
  }

  Widget _actionButton(
    double scale,
    String label,
    IconData icon,
    Color color,
    VoidCallback onTap,
  ) {
    return GestureDetector(
      onTap: _savingTransaction ? null : onTap,
      child: AnimatedOpacity(
        duration: const Duration(milliseconds: 120),
        opacity: _savingTransaction ? 0.65 : 1,
        child: Container(
          height: 48 * scale,
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(16 * scale),
            boxShadow: <BoxShadow>[
              BoxShadow(
                color: color.withValues(alpha: 0.25),
                blurRadius: 10 * scale,
                offset: Offset(0, 4 * scale),
              ),
            ],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Icon(icon, color: Colors.white, size: 19 * scale),
              SizedBox(width: 6 * scale),
              Text(
                label,
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 13.5 * scale,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}


class _PaymentReminderSheet extends StatefulWidget {
  final String partyName;
  final double initialAmount;
  final DateTime initialDate;

  const _PaymentReminderSheet({
    required this.partyName,
    required this.initialAmount,
    required this.initialDate,
  });

  @override
  State<_PaymentReminderSheet> createState() => _PaymentReminderSheetState();
}

class _PaymentReminderSheetState extends State<_PaymentReminderSheet> {
  late final TextEditingController _amountController;
  late DateTime _selectedDate;

  @override
  void initState() {
    super.initState();
    _amountController = TextEditingController(
      text: widget.initialAmount.toStringAsFixed(0),
    );
    final DateTime now = DateTime.now();
    final DateTime today = DateTime(now.year, now.month, now.day);
    final DateTime candidate = DateTime(
      widget.initialDate.year,
      widget.initialDate.month,
      widget.initialDate.day,
    );
    _selectedDate = candidate.isBefore(today) ? today : candidate;
  }

  @override
  void dispose() {
    _amountController.dispose();
    super.dispose();
  }

  Future<void> _pickDate() async {
    final DateTime now = DateTime.now();
    final DateTime firstDate = DateTime(now.year, now.month, now.day);
    final DateTime? picked = await showDatePicker(
      context: context,
      firstDate: firstDate,
      lastDate: firstDate.add(const Duration(days: 3650)),
      initialDate: _selectedDate.isBefore(firstDate) ? firstDate : _selectedDate,
    );
    if (!mounted || picked == null) return;
    setState(() => _selectedDate = picked);
  }

  void _save() {
    final double? amount = double.tryParse(_amountController.text.trim());
    if (amount == null || !amount.isFinite || amount <= 0 || amount > 10000000) {
      AppMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Enter a valid amount up to 1 Crore (1,00,00,000).')),
      );
      return;
    }

    Navigator.of(context).pop(<String, Object?>{
      'amount': amount,
      'date': _selectedDate,
    });
  }

  @override
  Widget build(BuildContext context) {
    final double bottomInset = MediaQuery.viewInsetsOf(context).bottom;

    return DraggableScrollableSheet(
      initialChildSize: 0.62,
      minChildSize: 0.38,
      maxChildSize: 0.90,
      snap: true,
      snapSizes: const <double>[0.38, 0.62, 0.90],
      shouldCloseOnMinExtent: true,
      expand: false,
      builder: (BuildContext context, ScrollController scrollController) {
        return Material(
          color: Colors.transparent,
          child: Container(
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
            ),
            child: SafeArea(
              top: false,
              child: ListView(
                controller: scrollController,
                physics: const ClampingScrollPhysics(),
                padding: EdgeInsets.fromLTRB(18, 10, 18, 18 + bottomInset),
                children: <Widget>[
                  Center(
                    child: Container(
                      width: 42,
                      height: 4,
                      decoration: BoxDecoration(
                        color: AppColors.lightDivider,
                        borderRadius: BorderRadius.circular(99),
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: <Widget>[
                      Container(
                        width: 44,
                        height: 44,
                        decoration: BoxDecoration(
                          color: AppColors.warning.withValues(alpha: 0.12),
                          borderRadius: BorderRadius.circular(14),
                        ),
                        child: const Icon(
                          Icons.notifications_active_rounded,
                          color: AppColors.warning,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Text('Payment Reminder', style: AppTextStyles.h3),
                            const SizedBox(height: 2),
                            Text(
                              'Set a reminder for ${widget.partyName}. It will notify you at 9:00 AM on the selected date.',
                              maxLines: 3,
                              overflow: TextOverflow.ellipsis,
                              style: AppTextStyles.caption,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 18),
                  TextField(
                    controller: _amountController,
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    inputFormatters: const [MaxAmountFormatter()],
                    decoration: InputDecoration(
                      labelText: 'Expected amount',
                      prefixText: '${CurrencyFormatter.defaultSymbol} ',
                      prefixIcon: const Icon(Icons.payments_outlined),
                      filled: true,
                      fillColor: AppColors.lightBackground,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(16),
                        borderSide: BorderSide.none,
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Material(
                    color: AppColors.lightBackground,
                    borderRadius: BorderRadius.circular(16),
                    child: InkWell(
                      borderRadius: BorderRadius.circular(16),
                      onTap: _pickDate,
                      child: Padding(
                        padding: const EdgeInsets.all(15),
                        child: Row(
                          children: <Widget>[
                            const Icon(Icons.event_rounded, color: AppColors.primary),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[
                                  Text('Reminder date', style: AppTextStyles.caption),
                                  const SizedBox(height: 3),
                                  Text(
                                    DateFormat('EEEE, dd MMM yyyy').format(_selectedDate),
                                    style: AppTextStyles.bodyMedium,
                                  ),
                                ],
                              ),
                            ),
                            const Icon(Icons.chevron_right_rounded),
                          ],
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 18),
                  SizedBox(
                    width: double.infinity,
                    height: 52,
                    child: FilledButton.icon(
                      onPressed: _save,
                      icon: const Icon(Icons.notifications_active_rounded),
                      label: const Text('Set Reminder'),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

