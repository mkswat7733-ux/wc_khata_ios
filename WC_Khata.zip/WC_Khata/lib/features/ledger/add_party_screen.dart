import 'package:flutter/material.dart';
import 'package:flutter_contacts/flutter_contacts.dart';

import '../../app/theme/app_theme.dart';
import '../../core/widgets/app_glass_icon_button.dart';
import 'ledger_party.dart';
import 'ledger_repository.dart';
import 'new_party_screen.dart';
import 'party_detail_screen.dart';
import '../../core/widgets/app_message.dart';

class AddPartyScreen extends StatefulWidget {
  final LedgerPartyType type;
  final bool returnAfterSelection;
  final PartyRole? initialRole;
  const AddPartyScreen({super.key, required this.type, this.returnAfterSelection = false, this.initialRole});

  @override
  State<AddPartyScreen> createState() => _AddPartyScreenState();
}

class _AddPartyScreenState extends State<AddPartyScreen> {
  final _repository = LedgerRepository();
  final _searchController = TextEditingController();
  List<Contact> _contacts = const [];
  final Map<String, LedgerParty> _addedByPhone = {};
  final Map<String, LedgerParty> _oppositeByPhone = {};
  final Set<String> _adding = {};
  bool _loading = true;
  bool _permissionDenied = false;

  String get _label => widget.initialRole == PartyRole.both ? 'Both' : (widget.type == LedgerPartyType.customer ? 'Customer' : 'Supplier');

  @override
  void initState() {
    super.initState();
    _refreshAll();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  String _normalize(String? value) => (value ?? '').replaceAll(RegExp(r'[^0-9+]'), '');
  String _name(Contact c) => (c.displayName ?? '').trim().isEmpty ? 'Unnamed contact' : (c.displayName ?? '').trim();
  String _phone(Contact c) => c.phones.isEmpty ? '' : (c.phones.first.number ?? '').trim();

  Future<void> _loadAdded() async {
    final parties = await _repository.getParties();
    final opposite = widget.type == LedgerPartyType.customer
        ? LedgerPartyType.supplier
        : LedgerPartyType.customer;
    _addedByPhone
      ..clear()
      ..addEntries(parties.where((p) => p.type == widget.type && _normalize(p.phone).isNotEmpty).map((p) => MapEntry(_normalize(p.phone), p)));
    _oppositeByPhone
      ..clear()
      ..addEntries(parties.where((p) => p.type == opposite && _normalize(p.phone).isNotEmpty).map((p) => MapEntry(_normalize(p.phone), p)));
  }

  Future<void> _refreshAll() async {
    if (mounted) setState(() { _loading = true; _permissionDenied = false; });
    try {
      await _loadAdded();
      final permission = await FlutterContacts.permissions.request(PermissionType.read);
      if (permission != PermissionStatus.granted && permission != PermissionStatus.limited) {
        if (!mounted) return;
        setState(() => _permissionDenied = true);
        return;
      }
      final contacts = await FlutterContacts.getAll(properties: {ContactProperty.name, ContactProperty.phone});
      if (!mounted) return;
      setState(() => _contacts = contacts.where((c) => _phone(c).isNotEmpty).toList(growable: false));
    } catch (_) {
      if (mounted) _message("Couldn't load contacts. Please try again.");
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  List<Contact> get _filtered {
    final q = _searchController.text.trim().toLowerCase();
    if (q.isEmpty) return _contacts;
    return _contacts.where((c) => _name(c).toLowerCase().contains(q) || _phone(c).toLowerCase().contains(q)).toList(growable: false);
  }

  Future<void> _add(Contact contact) async {
    final phone = _phone(contact);
    final key = _normalize(phone);
    if (key.isEmpty || _adding.contains(key)) return;
    final existing = _addedByPhone[key];
    if (existing != null) { if (widget.returnAfterSelection) { if (mounted) Navigator.pop(context, true); } else { await _openParty(existing); } return; }

    // Open the same form as "New" so the user can choose Customer / Supplier / Both.
    final saved = await Navigator.push<bool>(context, MaterialPageRoute(builder: (_) => NewPartyScreen(type: widget.type, initialRole: widget.initialRole, initialName: _name(contact), initialPhone: phone)));
    if (saved != true) return;
    if (widget.returnAfterSelection) {
      if (mounted) Navigator.pop(context, true);
      return;
    }
    await _loadAdded();
    if (mounted) setState(() {});
  }

  Future<void> _openParty(LedgerParty party) async {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => PartyDetailScreen(party: party)));
    await _loadAdded();
    if (mounted) setState(() {});
  }

  Future<void> _newParty() async {
    final saved = await Navigator.push<bool>(context, MaterialPageRoute(builder: (_) => NewPartyScreen(type: widget.type, initialRole: widget.initialRole)));
    if (saved == true) {
      if (widget.returnAfterSelection) {
        if (mounted) Navigator.pop(context, true);
        return;
      }
      await _loadAdded();
      if (mounted) setState(() {});
    }
  }

  void _message(String value) {
    AppMessenger.of(context)..hideCurrentSnackBar()..showSnackBar(SnackBar(content: Text(value)));
  }

  @override
  Widget build(BuildContext context) {
    final s = (MediaQuery.sizeOf(context).width / 390).clamp(.82, 1.2).toDouble();
    return Scaffold(
      backgroundColor: AppColors.lightBackground,
      body: Column(children: [
        _header(s),
        Padding(padding: EdgeInsets.fromLTRB(14*s, 14*s, 14*s, 0), child: _search(s)),
        Padding(padding: EdgeInsets.fromLTRB(14*s, 10*s, 14*s, 0), child: _newButton(s)),
        SizedBox(height: 12*s),
        Expanded(child: Padding(padding: EdgeInsets.fromLTRB(14*s, 0, 14*s, 14*s), child: _contactsCard(s))),
      ]),
    );
  }

  Widget _header(double s) => SafeArea(bottom: false, child: Container(
    height: 58*s, padding: EdgeInsets.symmetric(horizontal: 14*s),
    decoration: const BoxDecoration(color: Colors.white, border: Border(bottom: BorderSide(color: AppColors.lightDivider))),
    child: Row(children: [
      AppGlassIconButton(icon: Icons.arrow_back_rounded, onTap: () => Navigator.pop(context)),
      Expanded(child: Center(child: Text('Select $_label', style: TextStyle(color: AppColors.lightTextPrimary, fontSize: 19*s, fontWeight: FontWeight.w700)))),
      SizedBox(width: 42*s),
    ]),
  ));

  Widget _search(double s) => Container(
    height: 44*s,
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(15*s), border: Border.all(color: AppColors.lightCardBorder, width: 1.2)),
    child: TextField(
      controller: _searchController, onChanged: (_) => setState(() {}), textInputAction: TextInputAction.search,
      style: TextStyle(fontSize: 13*s, color: AppColors.lightTextPrimary),
      decoration: InputDecoration(border: InputBorder.none, prefixIcon: Icon(Icons.search_rounded, size: 19*s, color: AppColors.lightTextSecondary), hintText: 'Search phone contacts', hintStyle: TextStyle(fontSize: 12.5*s, color: AppColors.lightTextSecondary), suffixIcon: _searchController.text.isEmpty ? null : IconButton(icon: const Icon(Icons.close_rounded), onPressed: () { _searchController.clear(); setState(() {}); })),
    ),
  );

  Widget _newButton(double s) => Material(
    color: AppColors.primary.withValues(alpha: .08), borderRadius: BorderRadius.circular(16*s),
    child: InkWell(onTap: _newParty, borderRadius: BorderRadius.circular(16*s), child: Container(
      padding: EdgeInsets.symmetric(horizontal: 14*s, vertical: 13*s),
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(16*s), border: Border.all(color: AppColors.primary.withValues(alpha: .18))),
      child: Row(children: [
        Container(width: 38*s, height: 38*s, decoration: BoxDecoration(color: AppColors.primary, borderRadius: BorderRadius.circular(12*s)), child: Icon(Icons.person_add_alt_1_rounded, color: Colors.white, size: 20*s)),
        SizedBox(width: 11*s),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('New $_label', style: TextStyle(color: AppColors.lightTextPrimary, fontSize: 13.5*s, fontWeight: FontWeight.w800)), SizedBox(height: 2*s), Text('Add with name and phone number', style: TextStyle(color: AppColors.lightTextSecondary, fontSize: 10.5*s))])),
        Icon(Icons.chevron_right_rounded, color: AppColors.lightTextSecondary, size: 22*s),
      ]),
    )),
  );

  Widget _contactsCard(double s) => Container(
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20*s), border: Border.all(color: AppColors.lightCardBorder, width: 1.2), boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: .05), blurRadius: 12*s, offset: Offset(0,5*s))]),
    clipBehavior: Clip.antiAlias,
    child: Column(children: [
      Padding(padding: EdgeInsets.fromLTRB(14*s, 13*s, 14*s, 10*s), child: Row(children: [
        Container(width: 34*s, height: 34*s, decoration: BoxDecoration(color: AppColors.primary.withValues(alpha: .10), borderRadius: BorderRadius.circular(11*s)), child: Icon(Icons.contacts_rounded, color: AppColors.primary, size: 18*s)),
        SizedBox(width: 10*s), Expanded(child: Text('Phone Contacts', style: TextStyle(fontSize: 14*s, fontWeight: FontWeight.w800, color: AppColors.lightTextPrimary))),
        if (_loading) SizedBox(width: 18*s, height: 18*s, child: const CircularProgressIndicator(strokeWidth: 2)),
      ])),
      const Divider(height: 1, color: AppColors.lightDivider),
      Expanded(child: _contactsBody(s)),
    ]),
  );

  Widget _contactsBody(double s) {
    if (_loading) return Center(child: Text('Loading contacts...', style: TextStyle(color: AppColors.lightTextSecondary, fontSize: 12*s)));
    if (_permissionDenied) return _empty(s, Icons.lock_outline_rounded, 'Contacts permission needed', 'Allow contacts permission to show your real phone contacts.', action: TextButton(onPressed: _refreshAll, child: const Text('Allow Permission')));
    final contacts = _filtered;
    if (contacts.isEmpty) return _empty(s, Icons.search_off_rounded, 'No contacts found', 'No phone contacts match your search.');
    return Scrollbar(child: ListView.separated(
      padding: EdgeInsets.zero,
      itemCount: contacts.length,
      separatorBuilder: (_, __) => Divider(height: 1, color: AppColors.lightDivider, indent: 64*s, endIndent: 12*s),
      itemBuilder: (_, i) => _contactTile(s, contacts[i]),
    ));
  }

  Widget _empty(double s, IconData icon, String title, String subtitle, {Widget? action}) => Center(child: Padding(padding: EdgeInsets.all(20*s), child: Column(mainAxisSize: MainAxisSize.min, children: [Icon(icon, color: AppColors.primary, size: 28*s), SizedBox(height: 8*s), Text(title, textAlign: TextAlign.center, style: TextStyle(color: AppColors.lightTextPrimary, fontSize: 13*s, fontWeight: FontWeight.w800)), SizedBox(height: 3*s), Text(subtitle, textAlign: TextAlign.center, style: TextStyle(color: AppColors.lightTextSecondary, fontSize: 11*s)), if (action != null) ...[SizedBox(height: 8*s), action]])));

  Widget _contactTile(double s, Contact c) {
    final name = _name(c), phone = _phone(c), key = _normalize(phone);
    final party = _addedByPhone[key], added = party != null, adding = _adding.contains(key);
    final oppositeParty = _oppositeByPhone[key];
    final initial = name.isEmpty ? '?' : name[0].toUpperCase();
    return InkWell(
      onTap: added ? () => _openParty(party) : null,
      child: Padding(padding: EdgeInsets.symmetric(horizontal: 12*s, vertical: 8*s), child: Row(children: [
        CircleAvatar(radius: 21*s, backgroundColor: AppColors.primary.withValues(alpha: .10), child: Text(initial, style: TextStyle(color: AppColors.primary, fontSize: 15*s, fontWeight: FontWeight.w800))),
        SizedBox(width: 11*s),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(name, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 13*s, fontWeight: FontWeight.w700, color: AppColors.lightTextPrimary)),
          SizedBox(height: 2*s),
          Text(phone, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 10.5*s, color: AppColors.lightTextSecondary)),
          if (oppositeParty != null && !added) ...[
            SizedBox(height: 3*s),
            Row(children: [Icon(Icons.swap_horiz_rounded, size: 12*s, color: AppColors.primary), SizedBox(width: 3*s), Expanded(child: Text('Already ${oppositeParty.type == LedgerPartyType.customer ? 'Customer' : 'Supplier'} • can also be $_label', maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 9.5*s, color: AppColors.primary, fontWeight: FontWeight.w700)))])
          ],
        ])),
        SizedBox(width: 8*s),
        _stateButton(s, added: added, loading: adding, onTap: added ? () => _openParty(party) : () => _add(c)),
      ])),
    );
  }

  Widget _stateButton(double s, {required bool added, required bool loading, required VoidCallback onTap}) => Material(
    color: added ? AppColors.income.withValues(alpha: .10) : AppColors.primary, borderRadius: BorderRadius.circular(11*s),
    child: InkWell(onTap: loading ? null : onTap, borderRadius: BorderRadius.circular(11*s), child: Container(
      constraints: BoxConstraints(minWidth: 70*s), padding: EdgeInsets.symmetric(horizontal: 10*s, vertical: 8*s), alignment: Alignment.center,
      child: loading ? SizedBox(width: 15*s, height: 15*s, child: const CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : Row(mainAxisSize: MainAxisSize.min, children: [Icon(added ? Icons.check_circle_rounded : Icons.add_rounded, size: 15*s, color: added ? AppColors.income : Colors.white), SizedBox(width: 4*s), Text(added ? 'Added' : 'Add', style: TextStyle(color: added ? AppColors.income : Colors.white, fontSize: 11*s, fontWeight: FontWeight.w800))]),
    )),
  );
}
