import 'dart:io';

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../../core/services/ledger_media_store.dart';
import '../../core/utils/currency_formatter.dart';
import '../../core/utils/currency_symbols.dart';
import '../../core/utils/number_to_words.dart';
import '../../data/models/profile_model.dart';
import 'ledger_party.dart';
import 'ledger_repository.dart';

/// The printed-style "Money Receipt" card (business header, green ribbon,
/// dotted fields, signature lines, green footer bar).
///
/// It is laid out at a fixed [designWidth] so the text always keeps the same
/// proportions; wrap it in a `FittedBox(fit: BoxFit.fitWidth)` to scale it to
/// any screen, and in a `RepaintBoundary` to capture it as an image.
class MoneyReceiptCard extends StatelessWidget {
  static const double designWidth = 400;
  static const Color green = Color(0xFF0B9A4C);
  static const Color greenDark = Color(0xFF087A3B);
  static const Color red = Color(0xFFD92D20);
  static const Color redDark = Color(0xFFB42318);

  /// Receipt colour: green for Receive, red for Pay.
  static Color accentFor(bool isReceive) => isReceive ? green : red;
  static Color accentDarkFor(bool isReceive) => isReceive ? greenDark : redDark;
  static const Color ink = Color(0xFF1B1F23);
  static const Color muted = Color(0xFF4A5057);

  final ProfileModel? profile;
  final LedgerParty party;
  final LedgerTransaction transaction;
  final bool isReceive;
  final String currencyCode;

  const MoneyReceiptCard({
    super.key,
    required this.profile,
    required this.party,
    required this.transaction,
    required this.isReceive,
    required this.currencyCode,
  });

  Color get _accent => accentFor(isReceive);
  Color get _accentDark => accentDarkFor(isReceive);

  static String? _clean(String? v) {
    final t = v?.trim();
    return (t == null || t.isEmpty) ? null : t;
  }

  static String _initials(String name) {
    final words = name.trim().split(RegExp(r'\s+')).where((w) => w.isNotEmpty).toList();
    if (words.isEmpty) return 'WC';
    if (words.length == 1) {
      final w = words.first;
      return w.length >= 2 ? w.substring(0, 2).toUpperCase() : w.toUpperCase();
    }
    return (words[0][0] + words[1][0]).toUpperCase();
  }

  /// "MR-00012" for money received, "PV-00012" for payment vouchers.
  String get receiptNumber =>
      '${isReceive ? 'MR' : 'PV'}-${transaction.id.toString().padLeft(5, '0')}';

  @override
  Widget build(BuildContext context) {
    final business = _clean(profile?.name) ?? 'WC Khata';
    final date = DateFormat('dd MMM yyyy').format(transaction.date);
    final shortDate = DateFormat('dd / MM / yyyy').format(transaction.date);
    final note = _clean(transaction.note);
    final phone = _clean(party.phone);
    final currencyName = currencyNameFor(currencyCode);
    final isSupplier = party.type == LedgerPartyType.supplier;
    // Customer/supplier photo: only when this entry has an attachment.
    final photo = LedgerMediaStore.resolve(transaction.attachmentPath);

    return SizedBox(
      width: designWidth,
      child: DecoratedBox(
        decoration: const BoxDecoration(color: Colors.white),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(18, 14, 18, 0),
              child: _header(business),
            ),
            const SizedBox(height: 10),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 18),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Expanded(child: _line('MR No. :', receiptNumber)),
                  const SizedBox(width: 8),
                  _Ribbon(text: isReceive ? 'Money Receipt' : 'Payment Voucher', isReceive: isReceive),
                  const SizedBox(width: 8),
                  Expanded(child: _line('Date :', date)),
                ],
              ),
            ),
            const SizedBox(height: 4),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 18),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  _line(isSupplier ? 'Supplier Name :' : 'Customer Name :', party.name),
                  const SizedBox(height: 7),
                  _line(
                    isReceive
                        ? 'Receive with thanks a sum of $currencyName :'
                        : 'Pay with thanks a sum of $currencyName :',
                    CurrencyFormatter.formatCompact(transaction.amount),
                  ),
                  const SizedBox(height: 7),
                  _line('In Words :', NumberToWords.amountInWords(transaction.amount, currencyCode)),
                  const SizedBox(height: 7),
                  _line(
                    'On account of :',
                    note ?? (isReceive ? 'Payment received against khata' : 'Payment made against khata'),
                    maxLines: 2,
                  ),
                  const SizedBox(height: 7),
                  _line(isReceive ? 'From :' : 'To :', phone ?? ''),
                  const SizedBox(height: 7),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text('By Cash/Cheque No.:', style: _labelStyle),
                      const SizedBox(width: 4),
                      Expanded(flex: 3, child: _Dotted(child: _value('Cash'))),
                      const SizedBox(width: 6),
                      Text('Date :', style: _labelStyle),
                      const SizedBox(width: 4),
                      Expanded(flex: 4, child: _Dotted(child: _value(shortDate))),
                      const SizedBox(width: 6),
                      Text('Bank :', style: _labelStyle),
                      const SizedBox(width: 4),
                      Expanded(flex: 3, child: _Dotted(child: _value(''))),
                    ],
                  ),
                ],
              ),
                  ),
                  if (photo != null) ...[
                    const SizedBox(width: 10),
                    _PhotoIdCard(
                      photo: photo,
                      label: isSupplier ? 'SUPPLIER' : 'CUSTOMER',
                      name: party.name,
                      color: _accent,
                    ),
                  ],
                ],
              ),
            ),
            SizedBox(
              height: 78,
              child: Stack(
                children: [
                  Positioned(
                    left: 18,
                    right: 18,
                    bottom: 0,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        _signature(Text('For Customer', style: _sigStyle)),
                        _signature(
                          ConstrainedBox(
                            constraints: const BoxConstraints(maxWidth: 170),
                            child: Text.rich(
                              TextSpan(children: [
                                TextSpan(text: 'For ', style: _sigStyle),
                                TextSpan(text: business, style: _sigStyle.copyWith(color: _accent)),
                              ]),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Positioned(
                    left: 0,
                    right: 0,
                    top: 4,
                    child: Center(
                      child: _Stamp(
                        text: isReceive ? 'RECEIVE' : 'PAY',
                        date: DateFormat('dd/MM/yy').format(transaction.date),
                        color: _accent,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            Container(
              height: 17,
              color: _accent,
              alignment: Alignment.center,
              child: const Text(
                'Powered by WebdSoft Company',
                style: TextStyle(
                  color: Color(0xCCFFFFFF),
                  fontSize: 7,
                  fontWeight: FontWeight.w600,
                  letterSpacing: 0.6,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  static const TextStyle _labelStyle = TextStyle(
    fontSize: 9.5,
    color: ink,
    fontWeight: FontWeight.w600,
    height: 1.1,
  );

  static const TextStyle _sigStyle = TextStyle(
    fontSize: 9,
    color: ink,
    fontWeight: FontWeight.w800,
  );

  static Widget _value(String text, {int maxLines = 1}) {
    const style = TextStyle(fontSize: 10.5, color: ink, fontWeight: FontWeight.w800, height: 1.15);
    if (maxLines > 1) {
      return Text(text, maxLines: maxLines, overflow: TextOverflow.ellipsis, style: style);
    }
    return FittedBox(
      fit: BoxFit.scaleDown,
      alignment: Alignment.centerLeft,
      child: Text(text, maxLines: 1, style: style),
    );
  }

  static Widget _line(String label, String value, {int maxLines = 1}) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        Text(label, style: _labelStyle),
        const SizedBox(width: 4),
        Expanded(child: _Dotted(child: _value(value, maxLines: maxLines))),
      ],
    );
  }

  static Widget _signature(Widget child) {
    return Container(
      padding: const EdgeInsets.fromLTRB(4, 3, 14, 0),
      decoration: const BoxDecoration(
        border: Border(top: BorderSide(color: ink, width: 0.9)),
      ),
      child: child,
    );
  }

  Widget _logo(String business) {
    final path = _clean(profile?.photoPath);
    if (path != null && File(path).existsSync()) {
      return ClipRRect(
        borderRadius: BorderRadius.circular(7),
        child: Image.file(File(path), width: 46, height: 46, fit: BoxFit.cover),
      );
    }
    return Container(
      width: 60,
      height: 40,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(7),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [isReceive ? const Color(0xFF16B35F) : const Color(0xFFEF4A3F), _accentDark],
        ),
      ),
      child: Text(
        _initials(business),
        style: const TextStyle(
          color: Colors.white,
          fontSize: 20,
          fontWeight: FontWeight.w900,
          letterSpacing: 1,
        ),
      ),
    );
  }

  Widget _header(String business) {
    final tagline = _clean(profile?.tagline);
    final address = _clean(profile?.address);
    final email = _clean(profile?.email);
    final phone = _clean(profile?.phone);
    const small = TextStyle(fontSize: 7.5, color: muted, height: 1.35, fontWeight: FontWeight.w500);
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          width: 118,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _logo(business),
              if (tagline != null)
                Padding(
                  padding: const EdgeInsets.only(top: 3),
                  child: Text(
                    tagline,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 7.5, color: muted, fontWeight: FontWeight.w600),
                  ),
                ),
            ],
          ),
        ),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                business,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.right,
                style: const TextStyle(fontSize: 15, color: ink, fontWeight: FontWeight.w900, height: 1.15),
              ),
              const SizedBox(height: 3),
              if (address != null)
                Text(address, maxLines: 3, overflow: TextOverflow.ellipsis, textAlign: TextAlign.right, style: small),
              if (email != null)
                Text('Email: $email', maxLines: 1, overflow: TextOverflow.ellipsis, textAlign: TextAlign.right, style: small),
              if (phone != null)
                Text('HOTLINE: $phone', maxLines: 1, overflow: TextOverflow.ellipsis, textAlign: TextAlign.right, style: small),
            ],
          ),
        ),
      ],
    );
  }
}

/// Draws a dotted baseline under [child] (the "......" fill-in lines on a
/// printed receipt).
class _Dotted extends StatelessWidget {
  const _Dotted({required this.child});
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      painter: _DotPainter(),
      child: Padding(
        padding: const EdgeInsets.only(left: 2, bottom: 2.5),
        child: ConstrainedBox(
          constraints: const BoxConstraints(minHeight: 13),
          child: Align(alignment: Alignment.bottomLeft, child: child),
        ),
      ),
    );
  }
}

class _DotPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = const Color(0xFF6B7178);
    final y = size.height - 0.8;
    for (double x = 0.5; x < size.width; x += 3) {
      canvas.drawCircle(Offset(x, y), 0.6, paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

/// The green folded ribbon holding the title.
class _Ribbon extends StatelessWidget {
  const _Ribbon({required this.text, required this.isReceive});
  final String text;
  final bool isReceive;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 132,
      height: 31,
      child: CustomPaint(
        painter: _RibbonPainter(isReceive: isReceive),
        child: Padding(
          padding: const EdgeInsets.only(bottom: 4),
          child: Center(
            child: SizedBox(
              width: 80,
              child: FittedBox(
                fit: BoxFit.scaleDown,
                child: Text(
                  text,
                  maxLines: 1,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 8.5,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 0.2,
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _RibbonPainter extends CustomPainter {
  const _RibbonPainter({required this.isReceive});
  final bool isReceive;

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    const tail = 34.0;
    const inset = 24.0;

    // Back tails with a swallow-tail notch.
    final tailPaint = Paint()..color = isReceive ? const Color(0xFF087A3B) : const Color(0xFFB42318);
    canvas.drawPath(
      Path()
        ..moveTo(0, 6)
        ..lineTo(tail, 6)
        ..lineTo(tail, 29)
        ..lineTo(0, 29)
        ..lineTo(9, 17.5)
        ..close(),
      tailPaint,
    );
    canvas.drawPath(
      Path()
        ..moveTo(w, 6)
        ..lineTo(w - tail, 6)
        ..lineTo(w - tail, 29)
        ..lineTo(w, 29)
        ..lineTo(w - 9, 17.5)
        ..close(),
      tailPaint,
    );

    // Dark fold triangles where the ribbon wraps behind.
    final fold = Paint()..color = isReceive ? const Color(0xFF05562B) : const Color(0xFF7A271A);
    canvas.drawPath(
      Path()
        ..moveTo(inset, 24)
        ..lineTo(tail, 24)
        ..lineTo(tail, 29)
        ..close(),
      fold,
    );
    canvas.drawPath(
      Path()
        ..moveTo(w - inset, 24)
        ..lineTo(w - tail, 24)
        ..lineTo(w - tail, 29)
        ..close(),
      fold,
    );

    // Front band with gently curved top and bottom edges.
    final band = Path()
      ..moveTo(inset, 3)
      ..quadraticBezierTo(w / 2, -1, w - inset, 3)
      ..lineTo(w - inset, 25)
      ..quadraticBezierTo(w / 2, 29, inset, 25)
      ..close();
    final rect = Rect.fromLTWH(0, 0, w, 28);
    canvas.drawPath(
      band,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: isReceive
              ? const [Color(0xFF18B862), Color(0xFF0B9A4C)]
              : const [Color(0xFFF2574B), Color(0xFFD92D20)],
        ).createShader(rect),
    );
  }

  @override
  bool shouldRepaint(covariant _RibbonPainter oldDelegate) => oldDelegate.isReceive != isReceive;
}


/// Small ID-card style photo (like a student ID): green header strip with a
/// lanyard slot, the customer/supplier photo, and the name underneath.
class _PhotoIdCard extends StatelessWidget {
  const _PhotoIdCard({required this.photo, required this.label, required this.name, required this.color});

  final File photo;
  final String label;
  final String name;
  final Color color;

  @override
  Widget build(BuildContext context) {
    final green = color;
    return Container(
      width: 84,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: green, width: 1.2),
        boxShadow: const [BoxShadow(color: Color(0x22000000), blurRadius: 4, offset: Offset(0, 2))],
      ),
      clipBehavior: Clip.antiAlias,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            height: 17,
            color: green,
            alignment: Alignment.center,
            child: Text(
              label,
              style: const TextStyle(color: Colors.white, fontSize: 6.5, fontWeight: FontWeight.w900, letterSpacing: 0.8),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(6, 6, 6, 0),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(4),
              child: Container(
                height: 76,
                decoration: BoxDecoration(border: Border.all(color: const Color(0xFFD0D5DD), width: 0.8)),
                child: Image.file(photo, fit: BoxFit.cover, width: double.infinity, height: double.infinity),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(4, 4, 4, 3),
            child: Text(
              name,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 7.5, fontWeight: FontWeight.w800, color: MoneyReceiptCard.ink),
            ),
          ),
          Container(height: 5, color: green),
        ],
      ),
    );
  }
}


/// Small square rubber-stamp: green "RECEIVE" or red "PAY", tilted a little
/// like a real office stamp.
class _Stamp extends StatelessWidget {
  const _Stamp({required this.text, required this.date, required this.color});

  final String text;
  final String date;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Transform.rotate(
      angle: -0.16,
      child: Opacity(
        opacity: 0.92,
        child: Container(
          width: 62,
          height: 62,
          padding: const EdgeInsets.all(2.2),
          decoration: BoxDecoration(
            border: Border.all(color: color, width: 1.8),
            borderRadius: BorderRadius.circular(5),
          ),
          child: Container(
            decoration: BoxDecoration(
              border: Border.all(color: color, width: 0.8),
              borderRadius: BorderRadius.circular(3),
            ),
            padding: const EdgeInsets.symmetric(horizontal: 3, vertical: 4),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                SizedBox(
                  width: double.infinity,
                  child: FittedBox(
                    fit: BoxFit.scaleDown,
                    child: Text(
                      text,
                      maxLines: 1,
                      style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.w900, letterSpacing: 0.5, height: 1.1),
                    ),
                  ),
                ),
                Container(height: 0.9, margin: const EdgeInsets.symmetric(vertical: 3), color: color),
                Text(
                  date,
                  maxLines: 1,
                  style: TextStyle(color: color, fontSize: 7.5, fontWeight: FontWeight.w800, letterSpacing: 0.2),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
