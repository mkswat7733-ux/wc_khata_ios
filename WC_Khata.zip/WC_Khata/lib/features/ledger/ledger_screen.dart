import '../../core/services/data_events.dart';
import 'package:flutter/material.dart';
import '../../app/theme/app_theme.dart';
import '../../core/utils/currency_formatter.dart';
import '../../core/widgets/app_tab_screen.dart';
import '../../core/widgets/responsive.dart';
import 'ledger_controller.dart';
import 'both_star_badge.dart';
import 'ledger_party.dart';
import 'add_party_screen.dart';
import 'party_detail_screen.dart';

/// Ledger tab: Payable / Receivable totals (customers + suppliers),
/// a small search bar, Customer / Supplier tabs and the party list container.
class LedgerScreen extends StatefulWidget {
  final VoidCallback onBack;

  const LedgerScreen({super.key, required this.onBack});

  @override
  State<LedgerScreen> createState() => LedgerScreenState();
}

class LedgerScreenState extends State<LedgerScreen> {
  final _c = LedgerController();
  final _searchCtrl = TextEditingController();


  @override
  void initState() {
    super.initState();
    _c.load();
    _unlistenData = DataEvents.listen(() { if (mounted) _c.load(); });
  }

  VoidCallback? _unlistenData;

  /// Called by the root shell whenever the Ledger tab is opened, so balances
  /// always reflect purchases / sales / edits made on other tabs.
  void reload() => _c.load();

  @override
  void dispose() {
    _unlistenData?.call();
    _searchCtrl.dispose();
    _c.dispose();
    super.dispose();
  }

  double get _s => (MediaQuery.of(context).size.width / 390).clamp(0.82, 1.2);

  @override
  Widget build(BuildContext context) {
    final s = _s;
    return AppTabScreen(
      title: 'Ledger',
      onBack: widget.onBack,
      body: ListenableBuilder(
        listenable: _c,
        builder: (context, _) {
          return Padding(
            padding: EdgeInsets.fromLTRB(14 * s, 12 * s, 14 * s, 12 * s),
            child: Column(
              children: [
                _buildTotals(s),
                SizedBox(height: 10 * s),
                _buildSearch(s),
                SizedBox(height: 10 * s),
                _buildTabs(s),
                SizedBox(height: 8 * s),
                Expanded(child: _buildListWithAddButton(s)),
              ],
            ),
          );
        },
      ),
    );
  }

  // ------------------------------------------------------------------ totals

  Widget _buildTotals(double s) {
    return Row(
      children: [
        Expanded(
          child: _totalCard(
            s: s,
            label: 'Payable',
            hint: "You'll give",
            amount: _c.payableTotal,
            icon: Icons.arrow_upward_rounded,
            color: AppColors.expense,
          ),
        ),
        SizedBox(width: 10 * s),
        Expanded(
          child: _totalCard(
            s: s,
            label: 'Receivable',
            hint: "You'll get",
            amount: _c.receivableTotal,
            icon: Icons.arrow_downward_rounded,
            color: AppColors.income,
          ),
        ),
      ],
    );
  }

  Widget _totalCard({
    required double s,
    required String label,
    required String hint,
    required double amount,
    required IconData icon,
    required Color color,
  }) {
    return Container(
      padding: EdgeInsets.fromLTRB(12 * s, 10 * s, 12 * s, 10 * s),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18 * s),
        border: Border.all(color: AppColors.lightCardBorder, width: 1.2),
        boxShadow: [
          BoxShadow(color: Colors.black.withValues(alpha: 0.06), blurRadius: 10 * s, offset: Offset(0, 4 * s)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 28 * s,
                height: 28 * s,
                decoration: BoxDecoration(color: color.withValues(alpha: 0.10), borderRadius: BorderRadius.circular(9 * s)),
                child: Icon(icon, color: color, size: 16 * s),
              ),
              SizedBox(width: 8 * s),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      label,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(color: AppColors.lightTextPrimary, fontSize: 12.5 * s, fontWeight: FontWeight.w800),
                    ),
                    Text(
                      hint,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(color: AppColors.lightTextSecondary, fontSize: 10 * s),
                    ),
                  ],
                ),
              ),
            ],
          ),
          SizedBox(height: 8 * s),
          SizedBox(
            width: double.infinity,
            child: AutoSizeText(
              CurrencyFormatter.formatCompact(amount),
              style: TextStyle(color: color, fontSize: 17 * s, fontWeight: FontWeight.w800),
            ),
          ),
        ],
      ),
    );
  }

  // ------------------------------------------------------------------ search

  Widget _buildSearch(double s) {
    return Container(
      height: 38 * s,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14 * s),
        border: Border.all(color: AppColors.lightCardBorder, width: 1.2),
      ),
      child: TextField(
        controller: _searchCtrl,
        onChanged: _c.setQuery,
        textInputAction: TextInputAction.search,
        style: TextStyle(fontSize: 13 * s, color: AppColors.lightTextPrimary),
        decoration: InputDecoration(
          isDense: true,
          border: InputBorder.none,
          hintText: 'Search customer or supplier',
          hintStyle: TextStyle(fontSize: 12.5 * s, color: AppColors.lightTextSecondary),
          prefixIcon: Icon(Icons.search_rounded, size: 18 * s, color: AppColors.lightTextSecondary),
          prefixIconConstraints: BoxConstraints(minWidth: 38 * s, minHeight: 38 * s),
          suffixIcon: _c.query.isEmpty
              ? null
              : GestureDetector(
                  onTap: () {
                    _searchCtrl.clear();
                    _c.setQuery('');
                  },
                  child: Icon(Icons.close_rounded, size: 17 * s, color: AppColors.lightTextSecondary),
                ),
          suffixIconConstraints: BoxConstraints(minWidth: 34 * s, minHeight: 38 * s),
          contentPadding: EdgeInsets.symmetric(vertical: 10 * s),
        ),
      ),
    );
  }

  // -------------------------------------------------------------------- tabs

  Widget _buildTabs(double s) {
    final index = _c.tab.index;
    return Container(
      height: 38 * s,
      padding: EdgeInsets.all(3 * s),
      decoration: BoxDecoration(
        color: const Color(0xFFE7EBF3),
        borderRadius: BorderRadius.circular(16 * s),
      ),
      child: Stack(
        children: [
          AnimatedAlign(
            duration: const Duration(milliseconds: 280),
            curve: Curves.easeOutCubic,
            alignment: Alignment(index - 1.0, 0),
            child: FractionallySizedBox(
              widthFactor: 1 / 3,
              heightFactor: 1,
              child: Container(
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [Color(0xFF4C8DFF), AppColors.primary],
                  ),
                  borderRadius: BorderRadius.circular(13 * s),
                  boxShadow: [
                    BoxShadow(color: AppColors.primary.withValues(alpha: 0.35), blurRadius: 8 * s, offset: Offset(0, 3 * s)),
                  ],
                ),
              ),
            ),
          ),
          Row(
            children: [
              Expanded(child: _tabLabel(s, 'Customer', _c.customerCount, _c.tab == LedgerTab.customer, LedgerTab.customer)),
              Expanded(child: _tabLabel(s, 'Supplier', _c.supplierCount, _c.tab == LedgerTab.supplier, LedgerTab.supplier)),
              Expanded(child: _tabLabel(s, 'Both', _c.bothCount, _c.tab == LedgerTab.both, LedgerTab.both)),
            ],
          ),
        ],
      ),
    );
  }

  Widget _tabLabel(double s, String label, int count, bool selected, LedgerTab tab) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () => _c.setTab(tab),
      child: Center(
        child: AnimatedDefaultTextStyle(
          duration: const Duration(milliseconds: 250),
          style: TextStyle(
            color: selected ? Colors.white : AppColors.lightTextSecondary,
            fontSize: 12.5 * s,
            fontWeight: selected ? FontWeight.w800 : FontWeight.w600,
          ),
          child: Text('$label ($count)'),
        ),
      ),
    );
  }

  Widget _buildListWithAddButton(double s) {
    final icon = _c.tab == LedgerTab.customer
        ? Icons.person_add_alt_1_rounded
        : (_c.tab == LedgerTab.supplier ? Icons.local_shipping_rounded : Icons.star_rounded);
    return Stack(
      children: [
        Positioned.fill(child: _buildListContainer(s)),
        Positioned(
          right: 12 * s,
          bottom: 12 * s,
          child: _PressableChip(
            onTap: () async {
              await Navigator.push<void>(
                context,
                MaterialPageRoute(builder: (_) => AddPartyScreen(
                  type: _c.tab == LedgerTab.supplier ? LedgerPartyType.supplier : LedgerPartyType.customer,
                  initialRole: _c.tab == LedgerTab.both ? PartyRole.both : null,
                )),
              );
              if (mounted) await _c.load();
            },
            child: Container(
              width: 50 * s,
              height: 50 * s,
              decoration: BoxDecoration(
                gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF4C8DFF), AppColors.primary]),
                shape: BoxShape.circle,
                boxShadow: [BoxShadow(color: AppColors.primary.withValues(alpha: .35), blurRadius: 12 * s, offset: Offset(0, 5 * s))],
              ),
              child: Icon(icon, color: Colors.white, size: 22 * s),
            ),
          ),
        ),
      ],
    );
  }

  // --------------------------------------------------------------- container

  Widget _buildListContainer(double s) {
    final parties = _c.visibleParties;
    final slide = _c.tab.index == 0 ? -0.04 : 0.04;
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20 * s),
        border: Border.all(color: AppColors.lightCardBorder, width: 1.2),
        boxShadow: [
          BoxShadow(color: Colors.black.withValues(alpha: 0.06), blurRadius: 12 * s, offset: Offset(0, 5 * s)),
        ],
      ),
      clipBehavior: Clip.antiAlias,
      child: AnimatedSwitcher(
        duration: const Duration(milliseconds: 260),
        switchInCurve: Curves.easeOutCubic,
        transitionBuilder: (child, animation) => FadeTransition(
          opacity: animation,
          child: SlideTransition(
            position: animation.drive(Tween(begin: Offset(slide, 0), end: Offset.zero)),
            child: child,
          ),
        ),
        child: parties.isEmpty
            ? _buildEmpty(s)
            : ListView.separated(
                key: ValueKey(_c.tab),
                padding: EdgeInsets.symmetric(vertical: 6 * s),
                itemCount: parties.length,
                separatorBuilder: (_, __) => Divider(height: 1, color: AppColors.lightDivider, indent: 64 * s, endIndent: 12 * s),
                itemBuilder: (_, i) => _partyTile(s, parties[i]),
              ),
      ),
    );
  }

  Widget _buildEmpty(double s) {
    final searching = _c.query.trim().isNotEmpty;
    final noun = _c.tab == LedgerTab.customer ? 'customers' : (_c.tab == LedgerTab.supplier ? 'suppliers' : 'both parties');
    return Center(
      key: ValueKey('empty_${_c.tab}'),
      child: Padding(
        padding: EdgeInsets.all(20 * s),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 54 * s,
              height: 54 * s,
              decoration: BoxDecoration(color: AppColors.primary.withValues(alpha: 0.08), shape: BoxShape.circle),
              child: Icon(
                searching ? Icons.search_off_rounded : (_c.tab == LedgerTab.customer ? Icons.people_alt_rounded : (_c.tab == LedgerTab.supplier ? Icons.local_shipping_rounded : Icons.star_rounded)),
                color: AppColors.primary,
                size: 26 * s,
              ),
            ),
            SizedBox(height: 10 * s),
            Text(
              searching ? 'No $noun found' : 'No $noun yet',
              style: TextStyle(color: AppColors.lightTextPrimary, fontSize: 14 * s, fontWeight: FontWeight.w800),
            ),
            SizedBox(height: 3 * s),
            Text(
              searching ? 'Try a different name or number' : 'Their khata will show up here',
              textAlign: TextAlign.center,
              style: TextStyle(color: AppColors.lightTextSecondary, fontSize: 11.5 * s),
            ),
          ],
        ),
      ),
    );
  }

  Widget _partyTile(double s, LedgerParty p) {
    final color = p.isReceivable ? AppColors.income : (p.isPayable ? AppColors.expense : AppColors.lightTextSecondary);
    final status = p.isReceivable ? "You'll get" : (p.isPayable ? "You'll give" : 'Settled');
    final initial = p.name.trim().isEmpty ? '?' : p.name.trim()[0].toUpperCase();
    return InkWell(
      onTap: () async {
        if (p.id == null) return;
        await Navigator.push(context, MaterialPageRoute(builder: (_) => PartyDetailScreen(party: p)));
        await _c.load();
      },
      child: Padding(
        padding: EdgeInsets.symmetric(horizontal: 12 * s, vertical: 9 * s),
        child: Row(
          children: [
            Container(
              width: 40 * s,
              height: 40 * s,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: AppColors.primary.withValues(alpha: 0.10),
                shape: BoxShape.circle,
                border: p.isBoth ? Border.all(color: const Color(0xFFFFC107), width: 2) : null,
              ),
              child: Text(
                initial,
                style: TextStyle(color: AppColors.primary, fontSize: 16 * s, fontWeight: FontWeight.w800),
              ),
            ),
            SizedBox(width: 12 * s),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(children: [
                    Flexible(child: Text(
                      p.name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(color: AppColors.lightTextPrimary, fontSize: 14 * s, fontWeight: FontWeight.w700),
                    )),
                    if (p.isBoth) ...[SizedBox(width: 5 * s), BothStarBadge(size: 17 * s)],
                  ]),
                  if (p.phone != null && p.phone!.isNotEmpty)
                    Text(
                      p.phone!,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(color: AppColors.lightTextSecondary, fontSize: 11 * s),
                    ),
                ],
              ),
            ),
            SizedBox(width: 8 * s),
            ConstrainedBox(
              constraints: BoxConstraints(maxWidth: 110 * s),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  AutoSizeText(
                    CurrencyFormatter.formatCompact(p.balance.abs()),
                    textAlign: TextAlign.right,
                    style: TextStyle(color: color, fontSize: 14.5 * s, fontWeight: FontWeight.w800),
                  ),
                  Text(status, style: TextStyle(color: AppColors.lightTextSecondary, fontSize: 10 * s)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Small press-scale wrapper so the SMS / WhatsApp buttons react to touch.
class _PressableChip extends StatefulWidget {
  final Widget child;
  final VoidCallback onTap;

  const _PressableChip({required this.child, required this.onTap});

  @override
  State<_PressableChip> createState() => _PressableChipState();
}

class _PressableChipState extends State<_PressableChip> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTapDown: (_) => setState(() => _down = true),
      onTapCancel: () => setState(() => _down = false),
      onTapUp: (_) => setState(() => _down = false),
      onTap: widget.onTap,
      child: AnimatedScale(
        scale: _down ? 0.93 : 1.0,
        duration: const Duration(milliseconds: 100),
        child: widget.child,
      ),
    );
  }
}
