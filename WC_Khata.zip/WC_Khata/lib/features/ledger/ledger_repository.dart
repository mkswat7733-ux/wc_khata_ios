import '../../core/services/data_events.dart';
import 'package:sqflite/sqflite.dart';

import '../../core/database/app_database.dart';
import '../../core/database/database_constants.dart';
import '../../data/finance_rules.dart';
import '../../data/models/transaction_model.dart';
import '../../data/repositories/account_repository.dart';
import '../../data/repositories/transaction_repository.dart';
import 'ledger_party.dart';

class LedgerTransaction {
  final int id;
  final String type; // pay | receive
  final double amount;
  final String? note;
  final DateTime date;
  final DateTime? deletedAt;
  final int? cashTransactionId;

  /// Optional voice note (m4a) and customer/supplier photo for this entry.
  final String? voicePath;
  final String? attachmentPath;

  /// True for entries the app posted itself (sale bill, stock purchase).
  final bool isSystem;

  /// True when this entry belongs to the supplier side of a "Both" party.
  final bool fromSupplier;

  const LedgerTransaction({
    required this.id,
    required this.type,
    required this.amount,
    this.note,
    required this.date,
    this.deletedAt,
    this.cashTransactionId,
    this.voicePath,
    this.attachmentPath,
    this.isSystem = false,
    this.fromSupplier = false,
  });
}


class DeletedLedgerTransaction {
  final LedgerTransaction transaction;
  final int partyId;
  final String partyName;
  final LedgerPartyType partyType;

  const DeletedLedgerTransaction({
    required this.transaction,
    required this.partyId,
    required this.partyName,
    required this.partyType,
  });
}

class LedgerRepository {
  Future<List<LedgerParty>> getParties() async {
    await purgeExpiredDeletedTransactions();
    final db = await AppDatabase.instance.database;
    final rows = await db.rawQuery('''
      SELECT p.id, p.name, p.phone, p.address, p.type, p.linked_party_id, p.reminder_date, p.reminder_amount,
             COALESCE(SUM(CASE
               WHEN p.type = 'customer' AND t.type = 'pay' THEN t.amount
               WHEN p.type = 'customer' AND t.type = 'receive' THEN -t.amount
               WHEN p.type = 'supplier' AND t.type = 'receive' THEN -t.amount
               WHEN p.type = 'supplier' AND t.type = 'pay' THEN t.amount
               ELSE 0
             END), 0) AS balance,
             MAX(t.date) AS last_activity
      FROM ${DBConstants.tableLedgerParties} p
      LEFT JOIN ${DBConstants.tableLedgerTransactions} t
        ON t.party_id = p.id AND t.deleted_at IS NULL
      GROUP BY p.id
      ORDER BY p.name COLLATE NOCASE ASC
    ''');

    final own = rows.map((r) => LedgerParty(
      id: r['id'] as int,
      name: (r['name'] as String?) ?? '',
      phone: r['phone'] as String?,
      address: r['address'] as String?,
      type: (r['type'] as String) == 'supplier' ? LedgerPartyType.supplier : LedgerPartyType.customer,
      linkedPartyId: r['linked_party_id'] as int?,
      balance: (r['balance'] as num?)?.toDouble() ?? 0,
      lastActivity: r['last_activity'] == null ? null : DateTime.tryParse(r['last_activity'] as String),
      reminderDate: r['reminder_date'] == null ? null : DateTime.tryParse(r['reminder_date'] as String),
      reminderAmount: (r['reminder_amount'] as num?)?.toDouble(),
    )).toList();

    final byId = <int, LedgerParty>{for (final p in own) if (p.id != null) p.id!: p};
    return own.map((party) {
      final linked = party.linkedPartyId == null ? null : byId[party.linkedPartyId];
      final balance = linked == null ? party.balance : party.balance - linked.balance;
      return LedgerParty(
        id: party.id,
        name: party.name,
        phone: party.phone,
        address: party.address,
        type: party.type,
        linkedPartyId: party.linkedPartyId,
        balance: balance,
        lastActivity: party.lastActivity,
        reminderDate: party.reminderDate,
        reminderAmount: party.reminderAmount,
      );
    }).toList();
  }

  Future<LedgerParty?> getPartyById(int id) async {
    final parties = await getParties();
    for (final party in parties) {
      if (party.id == id) return party;
    }
    return null;
  }

  Future<LedgerParty?> findPartyByPhone({
    required String phone,
    required LedgerPartyType type,
  }) async {
    final normalized = _normalizePhone(phone);
    if (normalized.isEmpty) return null;
    final parties = await getParties();
    for (final party in parties) {
      if (party.type == type && _normalizePhone(party.phone) == normalized) {
        return party;
      }
    }
    return null;
  }

  Future<bool> isPartyAdded({
    required String phone,
    required LedgerPartyType type,
  }) async {
    final normalized = _normalizePhone(phone);
    if (normalized.isEmpty) return false;
    final db = await AppDatabase.instance.database;
    final rows = await db.rawQuery(
      'SELECT phone FROM ${DBConstants.tableLedgerParties} WHERE type = ? AND phone IS NOT NULL',
      [type.name],
    );
    return rows.any((row) => _normalizePhone(row['phone'] as String?) == normalized);
  }

  String _normalizePhone(String? phone) {
    if (phone == null) return '';
    return phone.replaceAll(RegExp(r'[^0-9+]'), '');
  }

  /// Adds a party. [role] = both creates a Customer row and a Supplier row
  /// linked together. Returns the id of the row matching [type] (for
  /// [PartyRole.both] the row of the tab the user started from).
  Future<int> addParty({
    required String name,
    required LedgerPartyType type,
    String? phone,
    String? address,
    PartyRole? role,
  }) async {
    try {
    final db = await AppDatabase.instance.database;
    final r = role ?? (type == LedgerPartyType.customer ? PartyRole.customer : PartyRole.supplier);
    return db.transaction((txn) async {
      final now = DateTime.now().toIso8601String();
      final normalized = _normalizePhone(phone);

      Future<int> insertRow(String t, int? linkedId) => txn.insert(DBConstants.tableLedgerParties, {
            'name': name.trim(),
            'phone': phone?.trim(),
            'address': (address ?? '').trim().isEmpty ? null : address!.trim(),
            'type': t,
            'linked_party_id': linkedId,
            'created_at': now,
            'updated_at': now,
          });

      Future<void> link(int a, int b) async {
        await txn.update(DBConstants.tableLedgerParties, {'linked_party_id': b, 'updated_at': now}, where: 'id = ?', whereArgs: [a]);
        await txn.update(DBConstants.tableLedgerParties, {'linked_party_id': a, 'updated_at': now}, where: 'id = ?', whereArgs: [b]);
      }

      if (r == PartyRole.both) {
        final c = await insertRow('customer', null);
        final s = await insertRow('supplier', c);
        await link(c, s);
        return type == LedgerPartyType.customer ? c : s;
      }

      // Single role. If the same phone already exists in the other role the
      // two rows are linked (same real person) - existing behaviour.
      int? linkedId;
      if (normalized.isNotEmpty) {
        final opposite = r == PartyRole.customer ? 'supplier' : 'customer';
        final rows = await txn.query(
          DBConstants.tableLedgerParties,
          columns: ['id', 'phone', 'linked_party_id'],
          where: 'type = ? AND phone IS NOT NULL AND linked_party_id IS NULL',
          whereArgs: [opposite],
        );
        for (final row in rows) {
          if (_normalizePhone(row['phone'] as String?) == normalized) {
            linkedId = row['id'] as int;
            break;
          }
        }
      }
      final id = await insertRow(r == PartyRole.customer ? 'customer' : 'supplier', linkedId);
      if (linkedId != null) await link(id, linkedId);
      return id;
    });
      } finally {
      DataEvents.changed();
    }
  }

  /// True when this party row already has records that depend on it.
  Future<bool> _roleInUse(DatabaseExecutor db, int partyId, String type) async {
    final tx = await db.rawQuery('SELECT COUNT(*) c FROM ${DBConstants.tableLedgerTransactions} WHERE party_id = ?', [partyId]);
    if (((tx.first['c'] as num?) ?? 0) > 0) return true;
    if (type == 'customer') {
      final r = await db.rawQuery('SELECT COUNT(*) c FROM ${DBConstants.tableSaleInvoices} WHERE customer_id = ?', [partyId]);
      return ((r.first['c'] as num?) ?? 0) > 0;
    }
    final r = await db.rawQuery('SELECT COUNT(*) c FROM ${DBConstants.tableItems} WHERE supplier_id = ?', [partyId]);
    return ((r.first['c'] as num?) ?? 0) > 0;
  }

  /// Edits name, phone and type (Customer / Supplier / Both).
  ///
  /// Adding a role creates the missing row; removing a role deletes that row
  /// but only if it has no ledger entries, sales or stock purchases.
  /// Returns the id of the row the detail screen should keep showing.
  /// Throws [StateError] with a user-readable message when not allowed.
  Future<int> updateParty({
    required int partyId,
    required String name,
    String? phone,
    String? address,
    required PartyRole role,
  }) async {
    try {
    final db = await AppDatabase.instance.database;
    return db.transaction((txn) async {
      final now = DateTime.now().toIso8601String();
      final cleanName = name.trim();
      final cleanPhone = (phone ?? '').trim().isEmpty ? null : phone!.trim();
      final cleanAddress = (address ?? '').trim().isEmpty ? null : address!.trim();

      final self = await txn.query(DBConstants.tableLedgerParties, where: 'id = ?', whereArgs: [partyId], limit: 1);
      if (self.isEmpty) throw StateError('This party no longer exists.');
      final selfRow = self.first;
      final selfType = selfRow['type'] as String;
      final linkedId = selfRow['linked_party_id'] as int?;
      Map<String, Object?>? otherRow;
      if (linkedId != null) {
        final o = await txn.query(DBConstants.tableLedgerParties, where: 'id = ?', whereArgs: [linkedId], limit: 1);
        if (o.isNotEmpty) otherRow = o.first;
      }
      final selfIsCustomer = selfType == 'customer';
      final customerRow = selfIsCustomer ? selfRow : otherRow;
      final supplierRow = selfIsCustomer ? otherRow : selfRow;

      final wantCustomer = role != PartyRole.supplier;
      final wantSupplier = role != PartyRole.customer;

      // Duplicate phone check against every other party of the wanted role.
      final normalized = _normalizePhone(cleanPhone);
      if (normalized.isNotEmpty) {
        final ownIds = {partyId, if (otherRow != null) otherRow['id'] as int};
        final rows = await txn.query(DBConstants.tableLedgerParties, columns: ['id', 'type', 'phone'], where: 'phone IS NOT NULL');
        for (final r in rows) {
          if (ownIds.contains(r['id'])) continue;
          final t = r['type'] as String;
          if (_normalizePhone(r['phone'] as String?) != normalized) continue;
          if ((t == 'customer' && wantCustomer) || (t == 'supplier' && wantSupplier)) {
            throw StateError('Another ${t == 'customer' ? 'customer' : 'supplier'} already uses this phone number.');
          }
        }
      }

      // Removing a role is only allowed when nothing depends on it.
      if (!wantCustomer && customerRow != null && await _roleInUse(txn, customerRow['id'] as int, 'customer')) {
        throw StateError('This party has customer records (sales / ledger). Customer role cannot be removed.');
      }
      if (!wantSupplier && supplierRow != null && await _roleInUse(txn, supplierRow['id'] as int, 'supplier')) {
        throw StateError('This party has supplier records (purchases / ledger). Supplier role cannot be removed.');
      }

      Future<void> rename(Map<String, Object?> row) => txn.update(
            DBConstants.tableLedgerParties,
            {'name': cleanName, 'phone': cleanPhone, 'address': cleanAddress, 'updated_at': now},
            where: 'id = ?',
            whereArgs: [row['id']],
          );

      int? customerId = customerRow?['id'] as int?;
      int? supplierId = supplierRow?['id'] as int?;

      if (customerRow != null && wantCustomer) await rename(customerRow);
      if (supplierRow != null && wantSupplier) await rename(supplierRow);

      if (customerRow != null && !wantCustomer) {
        await txn.delete(DBConstants.tableLedgerParties, where: 'id = ?', whereArgs: [customerId]);
        customerId = null;
      }
      if (supplierRow != null && !wantSupplier) {
        await txn.delete(DBConstants.tableLedgerParties, where: 'id = ?', whereArgs: [supplierId]);
        supplierId = null;
      }

      Future<int> insertRow(String t) => txn.insert(DBConstants.tableLedgerParties, {
            'name': cleanName,
            'phone': cleanPhone,
            'address': cleanAddress,
            'type': t,
            'linked_party_id': null,
            'created_at': now,
            'updated_at': now,
          });
      if (wantCustomer && customerId == null) customerId = await insertRow('customer');
      if (wantSupplier && supplierId == null) supplierId = await insertRow('supplier');

      // Re-link (or unlink) the surviving rows.
      if (customerId != null && supplierId != null) {
        await txn.update(DBConstants.tableLedgerParties, {'linked_party_id': supplierId}, where: 'id = ?', whereArgs: [customerId]);
        await txn.update(DBConstants.tableLedgerParties, {'linked_party_id': customerId}, where: 'id = ?', whereArgs: [supplierId]);
      } else {
        final only = customerId ?? supplierId!;
        await txn.update(DBConstants.tableLedgerParties, {'linked_party_id': null}, where: 'id = ?', whereArgs: [only]);
      }

      // Keep showing the same row if it survived, otherwise the remaining one.
      final keep = selfIsCustomer ? (customerId ?? supplierId) : (supplierId ?? customerId);
      return keep!;
    });
      } finally {
      DataEvents.changed();
    }
  }

  Future<void> setReminder({
    required int partyId,
    required DateTime date,
    required double amount,
  }) async {
    try {
    final db = await AppDatabase.instance.database;
    await db.update(
      DBConstants.tableLedgerParties,
      {
        'reminder_date': date.toIso8601String(),
        'reminder_amount': amount,
        'updated_at': DateTime.now().toIso8601String(),
      },
      where: 'id = ?',
      whereArgs: [partyId],
    );
      } finally {
      DataEvents.changed();
    }
  }

  /// Which way real cash moves for a ledger entry ('in' / 'out' / null).
  ///
  ///  * Customer Receive  -> cash IN  (customer paid us)
  ///  * Supplier Receive  -> cash OUT (stored type; we paid the supplier)
  ///  * Customer Pay      -> cash OUT (we gave money back to the customer),
  ///                         but only for manual entries. A sale bill posts
  ///                         its own 'pay' (the receivable) and moves no cash.
  ///  * Supplier credit purchase (stored 'pay') -> no cash.
  static String? cashDirection({
    required String partyType,
    required String type,
    required bool isSystem,
  }) {
    if (type == 'receive') return partyType == 'customer' ? 'in' : 'out';
    if (type == 'pay' && partyType == 'customer' && !isSystem) return 'out';
    return null;
  }

  /// Posts the cash row + account balance change for a ledger entry and
  /// returns the cash transaction id (or null when no cash account exists /
  /// this entry does not move cash).
  Future<int?> _postCash(
    DatabaseExecutor txn, {
    required String? direction,
    required String partyType,
    required double amount,
    required int ledgerId,
    required String? note,
    required DateTime when,
    required DateTime now,
    int? cashAccountId,
  }) async {
    if (direction == null) return null;
    final accountRows = cashAccountId != null
        ? await txn.query(DBConstants.tableAccounts, where: 'id = ? AND is_active = 1 AND deleted_at IS NULL', whereArgs: [cashAccountId], limit: 1)
        : await txn.query(DBConstants.tableAccounts, where: "is_active = 1 AND deleted_at IS NULL AND type != 'person' AND type != 'credit_card'", orderBy: "CASE WHEN type = 'cash' THEN 0 ELSE 1 END, created_at ASC", limit: 1);
    var accountRowsSafe = accountRows;
    if (accountRowsSafe.isEmpty && cashAccountId == null) {
      // No cash account yet: create the default one so the payment is never
      // lost from the Cashbook.
      final stamp = now.toIso8601String();
      final newId = await txn.insert(DBConstants.tableAccounts, {
        'name': 'Cash', 'type': 'cash', 'opening_balance': 0.0, 'current_balance': 0.0,
        'currency': 'PKR', 'notes': 'WC Khata default cash balance', 'is_active': 1,
        'deleted_at': null, 'created_at': stamp, 'updated_at': stamp,
      });
      accountRowsSafe = await txn.query(DBConstants.tableAccounts, where: 'id = ?', whereArgs: [newId], limit: 1);
    }
    if (accountRowsSafe.isEmpty) return null;
    final accountId = accountRowsSafe.first['id'] as int;
    final accountType = accountRowsSafe.first['type'] as String;
    if (accountType == 'person' || accountType == 'credit_card') return null;

    final isIn = direction == 'in';
    final source = isIn
        ? FinanceRules.ledgerReceive
        : (partyType == 'supplier' ? FinanceRules.supplierPayment : FinanceRules.customerRefund);
    final cleanNote = note?.trim();
    final cashTxId = await txn.insert(DBConstants.tableTransactions, {
      'type': isIn ? TransactionType.income.value : TransactionType.expense.value,
      'amount': amount,
      'account_id': accountId,
      'to_account_id': null,
      'category_id': null,
      'source': source,
      'payment_method': 'Cashbook',
      'frequency': null,
      'date': when.toIso8601String(),
      'note': (cleanNote == null || cleanNote.isEmpty) ? 'Ledger #$ledgerId' : cleanNote,
      'created_at': now.toIso8601String(),
      'updated_at': now.toIso8601String(),
    });
    await txn.rawUpdate(
      'UPDATE ${DBConstants.tableAccounts} SET current_balance = current_balance + ?, updated_at = ? WHERE id = ?',
      [isIn ? amount : -amount, now.toIso8601String(), accountId],
    );
    return cashTxId;
  }

  /// Reverses a previously posted cash row (balance + row).
  Future<void> _reverseCash(DatabaseExecutor txn, int cashId, DateTime now) async {
    final cash = await txn.query(DBConstants.tableTransactions, where: 'id = ?', whereArgs: [cashId], limit: 1);
    if (cash.isEmpty) return;
    final amount = (cash.first['amount'] as num).toDouble();
    final accountId = cash.first['account_id'] as int;
    final isIncome = cash.first['type'] == 'income';
    await txn.rawUpdate(
      'UPDATE ${DBConstants.tableAccounts} SET current_balance = current_balance + ?, updated_at = ? WHERE id = ?',
      [isIncome ? -amount : amount, now.toIso8601String(), accountId],
    );
    await txn.delete(DBConstants.tableTransactions, where: 'id = ?', whereArgs: [cashId]);
  }

  /// [systemPosted] = true for entries the app creates by itself (sale bill,
  /// stock purchase). Those never turn a customer "Pay" into a cash refund.
  Future<void> addTransaction({
    required int partyId,
    required String type,
    required double amount,
    String? note,
    DateTime? date,
    int? cashAccountId,
    String? voicePath,
    String? attachmentPath,
    bool systemPosted = false,
  }) async {
    try {
    if (type != 'pay' && type != 'receive') {
      throw ArgumentError.value(type, 'type', 'Expected pay or receive.');
    }
    if (!amount.isFinite || amount <= 0 || amount > 10000000) {
      throw ArgumentError.value(amount, 'amount', 'Amount must be between 0 and 10,000,000 (1 crore).');
    }
    final db = await AppDatabase.instance.database;
    final now = DateTime.now();
    final when = date ?? now;
    await db.transaction((txn) async {
      final cleanNote = (note?.trim().isEmpty ?? true) ? null : note!.trim();
      final ledgerId = await txn.insert(DBConstants.tableLedgerTransactions, {
        'party_id': partyId,
        'type': type,
        'amount': amount,
        'note': cleanNote,
        'date': when.toIso8601String(),
        'created_at': now.toIso8601String(),
        'deleted_at': null,
        'voice_path': voicePath,
        'attachment_path': attachmentPath,
        'is_system': systemPosted ? 1 : 0,
      });
      final partyRows = await txn.query(DBConstants.tableLedgerParties, columns: ['type'], where: 'id = ?', whereArgs: [partyId], limit: 1);
      final partyType = partyRows.isEmpty ? 'customer' : partyRows.first['type'] as String;
      final cashTxId = await _postCash(
        txn,
        direction: cashDirection(partyType: partyType, type: type, isSystem: systemPosted),
        partyType: partyType,
        amount: amount,
        ledgerId: ledgerId,
        note: cleanNote,
        when: when,
        now: now,
        cashAccountId: cashAccountId,
      );
      if (cashTxId != null) {
        await txn.update(DBConstants.tableLedgerTransactions, {'cash_transaction_id': cashTxId}, where: 'id = ?', whereArgs: [ledgerId]);
      }
      await txn.update(DBConstants.tableLedgerParties, {'updated_at': now.toIso8601String()}, where: 'id = ?', whereArgs: [partyId]);
    });
      } finally {
      DataEvents.changed();
    }
  }

  /// Posts / updates / removes everything ONE purchase record leaves in the
  /// books. Must be called inside the purchase's own transaction [txn].
  ///
  /// Supplier purchase -> two linked system rows tagged with [purchaseId]:
  ///  * a bill    - stored 'pay'     = total owed to the supplier
  ///  * a payment - stored 'receive' = amount paid now (cash out of the Cashbook)
  /// Editing the purchase UPDATES those rows (amounts, date, note and the cash
  /// movement) instead of posting new ones, moves them when the supplier is
  /// changed and removes them when the purchase is removed. Paying more than
  /// the total simply makes the supplier balance negative = receivable.
  ///
  /// Purchase WITHOUT a supplier -> one plain 'Purchase' cash-out in the
  /// Cashbook when [cashPurchase] is true. Returns that cash row's id (store it
  /// on the purchase so the next edit can replace it), otherwise null.
  Future<int?> syncPurchaseEntries(
    Transaction txn, {
    required int purchaseId,
    required int itemId,
    required int? supplierId,
    required String itemName,
    required double total,
    required double settled,
    required String purchaseType,
    required DateTime date,
    int? oldCashTxId,
    bool cashPurchase = false,
    bool remove = false,
  }) async {
    final now = DateTime.now();
    final wantsRows = !remove && supplierId != null && total > 0;
    final wantsCash = !remove && supplierId == null && cashPurchase && total > 0;

    final existing = await txn.query(DBConstants.tableLedgerTransactions, where: 'purchase_id = ? AND is_system = 1', whereArgs: [purchaseId], orderBy: 'id DESC');
    Map<String, Object?>? bill;
    Map<String, Object?>? payment;
    final stale = <Map<String, Object?>>[];
    for (final r in existing) {
      final sameParty = wantsRows && r['party_id'] == supplierId;
      final isBill = r['type'] == 'pay';
      if (sameParty && r['deleted_at'] == null && isBill && bill == null) {
        bill = r;
      } else if (sameParty && r['deleted_at'] == null && !isBill && payment == null) {
        payment = r;
      } else {
        stale.add(r);
      }
    }
    // Rows that no longer belong (supplier changed / purchase removed / duplicates).
    final touchedParties = <int>{};
    for (final r in stale) {
      final cashId = r['cash_transaction_id'] as int?;
      if (cashId != null && r['deleted_at'] == null) await _reverseCash(txn, cashId, now);
      touchedParties.add(r['party_id'] as int);
      await txn.delete(DBConstants.tableLedgerTransactions, where: 'id = ?', whereArgs: [r['id']]);
    }

    if (wantsRows) {
      final label = purchaseType == 'cash' ? 'Cash' : 'Credit';
      final billNote = 'Stock purchase • $itemName • $label';
      final payNote = 'Supplier payment • $itemName • ${purchaseType == 'cash' ? 'Cash' : 'Paid now'}';

      if (bill == null) {
        await txn.insert(DBConstants.tableLedgerTransactions, {
          'party_id': supplierId, 'type': 'pay', 'amount': total, 'note': billNote,
          'date': date.toIso8601String(), 'created_at': now.toIso8601String(),
          'deleted_at': null, 'is_system': 1, 'item_id': itemId, 'purchase_id': purchaseId,
        });
      } else {
        await txn.update(DBConstants.tableLedgerTransactions,
            {'amount': total, 'note': billNote, 'date': date.toIso8601String(), 'item_id': itemId},
            where: 'id = ?', whereArgs: [bill['id']]);
      }

      if (payment != null) {
        final oldCash = payment['cash_transaction_id'] as int?;
        if (oldCash != null) await _reverseCash(txn, oldCash, now);
      }
      if (settled > 0) {
        final ledgerId = payment == null
            ? await txn.insert(DBConstants.tableLedgerTransactions, {
                'party_id': supplierId, 'type': 'receive', 'amount': settled, 'note': payNote,
                'date': date.toIso8601String(), 'created_at': now.toIso8601String(),
                'deleted_at': null, 'is_system': 1, 'item_id': itemId, 'purchase_id': purchaseId,
              })
            : payment['id'] as int;
        final cashId = await _postCash(
          txn,
          direction: 'out',
          partyType: 'supplier',
          amount: settled,
          ledgerId: ledgerId,
          note: payNote,
          when: date,
          now: now,
        );
        await txn.update(DBConstants.tableLedgerTransactions,
            {'amount': settled, 'note': payNote, 'date': date.toIso8601String(), 'cash_transaction_id': cashId, 'item_id': itemId},
            where: 'id = ?', whereArgs: [ledgerId]);
      } else if (payment != null) {
        await txn.delete(DBConstants.tableLedgerTransactions, where: 'id = ?', whereArgs: [payment['id']]);
      }
      touchedParties.add(supplierId);
    }
    for (final partyId in touchedParties) {
      await txn.update(DBConstants.tableLedgerParties, {'updated_at': now.toIso8601String()}, where: 'id = ?', whereArgs: [partyId]);
    }

    // ---- plain cash purchase (no supplier) -------------------------------
    if (oldCashTxId != null) await _reverseCash(txn, oldCashTxId, now);
    int? newCashTx;
    if (wantsCash) {
      final accountRows = await txn.query(DBConstants.tableAccounts,
          where: "is_active = 1 AND deleted_at IS NULL AND type != 'person' AND type != 'credit_card'",
          orderBy: "CASE WHEN type = 'cash' THEN 0 ELSE 1 END, created_at ASC",
          limit: 1);
      if (accountRows.isNotEmpty) {
        final accountId = accountRows.first['id'] as int;
        newCashTx = await txn.insert(DBConstants.tableTransactions, {
          'type': TransactionType.expense.value,
          'amount': total,
          'account_id': accountId,
          'to_account_id': null,
          'category_id': null,
          'source': FinanceRules.purchase,
          'payment_method': 'Cash',
          'frequency': null,
          'date': date.toIso8601String(),
          'note': 'Stock purchase • $itemName',
          'created_at': now.toIso8601String(),
          'updated_at': now.toIso8601String(),
        });
        await txn.rawUpdate(
          'UPDATE ${DBConstants.tableAccounts} SET current_balance = current_balance - ?, updated_at = ? WHERE id = ?',
          [total, now.toIso8601String(), accountId],
        );
      }
    }
    return newCashTx;
  }

  /// Posts what ONE multi-item purchase bill leaves in the books, inside the
  /// bill's own transaction [txn]:
  ///  * a bill    - stored 'pay'     = [total] owed to the supplier
  ///  * a payment - stored 'receive' = [paid] handed over now (cash out of the
  ///    Cashbook), only when [paid] > 0
  /// Both are system rows, so the supplier khata shows the bill and the
  /// payment and the balance is exactly total - paid.
  Future<void> postPurchaseBillEntries(
    Transaction txn, {
    required int supplierId,
    required String invoiceNo,
    required double total,
    required double paid,
    required DateTime date,
  }) async {
    final now = DateTime.now();
    if (total > 0) {
      await txn.insert(DBConstants.tableLedgerTransactions, {
        'party_id': supplierId,
        'type': 'pay',
        'amount': total,
        'note': 'Purchase $invoiceNo',
        'date': date.toIso8601String(),
        'created_at': now.toIso8601String(),
        'deleted_at': null,
        'is_system': 1,
      });
    }
    if (paid > 0) {
      final payNote = 'Payment for $invoiceNo';
      final ledgerId = await txn.insert(DBConstants.tableLedgerTransactions, {
        'party_id': supplierId,
        'type': 'receive',
        'amount': paid,
        'note': payNote,
        'date': date.toIso8601String(),
        'created_at': now.toIso8601String(),
        'deleted_at': null,
        'is_system': 1,
      });
      final cashId = await _postCash(
        txn,
        direction: 'out',
        partyType: 'supplier',
        amount: paid,
        ledgerId: ledgerId,
        note: payNote,
        when: date,
        now: now,
      );
      if (cashId != null) {
        await txn.update(DBConstants.tableLedgerTransactions, {'cash_transaction_id': cashId}, where: 'id = ?', whereArgs: [ledgerId]);
      }
    }
    await txn.update(DBConstants.tableLedgerParties, {'updated_at': now.toIso8601String()}, where: 'id = ?', whereArgs: [supplierId]);
  }

  Future<List<LedgerTransaction>> getTransactions(int partyId) async {
    await purgeExpiredDeletedTransactions();
    final db = await AppDatabase.instance.database;
    final rows = await db.query(
      DBConstants.tableLedgerTransactions,
      where: 'party_id = ? AND deleted_at IS NULL',
      whereArgs: [partyId],
      orderBy: 'date DESC, id DESC',
    );
    return rows.map(_fromRow).toList();
  }

  /// One khata for a "Both" party: entries of the customer row and of its
  /// linked supplier row, newest first.
  Future<List<LedgerTransaction>> getTransactionsWithLinked(int partyId, int linkedId) async {
    await purgeExpiredDeletedTransactions();
    final db = await AppDatabase.instance.database;
    final rows = await db.query(
      DBConstants.tableLedgerTransactions,
      where: '(party_id = ? OR party_id = ?) AND deleted_at IS NULL',
      whereArgs: [partyId, linkedId],
      orderBy: 'date DESC, id DESC',
    );
    return rows.map((r) => _fromRow(r, fromSupplier: (r['party_id'] as int) == linkedId)).toList();
  }

  /// Khata balance of [party] just BEFORE and just AFTER entry [txId], i.e. the
  /// "previous balance" and the "due" a receipt of that entry must show.
  /// Entries are counted in khata order (date, id); later entries and deleted
  /// ones are ignored, so an old receipt always reprints with its own figures.
  /// For a "Both" party the linked row is netted off, exactly like the khata
  /// balance. Same sign rule as [getParties]: a 'pay' entry adds, a 'receive'
  /// entry subtracts. Returns null when the entry cannot be found.
  Future<({double before, double after})?> getBalanceAround(LedgerParty party, int txId) async {
    final id = party.id;
    if (id == null) return null;
    final ids = <int>[id, if (party.linkedPartyId != null) party.linkedPartyId!];
    final db = await AppDatabase.instance.database;
    final rows = await db.query(
      DBConstants.tableLedgerTransactions,
      columns: ['id', 'party_id', 'type', 'amount'],
      where: 'party_id IN (${List.filled(ids.length, '?').join(',')}) AND deleted_at IS NULL',
      whereArgs: ids,
      orderBy: 'date ASC, id ASC',
    );
    double running = 0;
    for (final r in rows) {
      final amount = (r['amount'] as num).toDouble();
      final delta = (r['type'] as String) == 'pay' ? amount : -amount;
      final own = (r['party_id'] as int) == id;
      final signed = own ? delta : -delta;
      if ((r['id'] as int) == txId) {
        return (before: running, after: running + signed);
      }
      running += signed;
    }
    return null;
  }

  Future<LedgerTransaction?> getTransactionById(int id) async {
    await purgeExpiredDeletedTransactions();
    final db = await AppDatabase.instance.database;
    final rows = await db.query(
      DBConstants.tableLedgerTransactions,
      where: 'id = ?',
      whereArgs: [id],
      limit: 1,
    );
    return rows.isEmpty ? null : _fromRow(rows.first);
  }

  LedgerTransaction _fromRow(Map<String, Object?> r, {bool fromSupplier = false}) => LedgerTransaction(
        fromSupplier: fromSupplier,
        id: r['id'] as int,
        type: r['type'] as String,
        amount: (r['amount'] as num).toDouble(),
        note: r['note'] as String?,
        date: DateTime.parse(r['date'] as String),
        deletedAt: r['deleted_at'] == null
            ? null
            : DateTime.tryParse(r['deleted_at'] as String),
        cashTransactionId: r['cash_transaction_id'] as int?,
        voicePath: r['voice_path'] as String?,
        attachmentPath: r['attachment_path'] as String?,
        isSystem: (r['is_system'] as num?)?.toInt() == 1,
      );

  Future<void> updateTransaction({
    required int id,
    required String type,
    required double amount,
    String? note,
    required DateTime date,
    int? cashAccountId,
    String? voicePath,
    String? attachmentPath,
  }) async {
    try {
    if (type != 'pay' && type != 'receive') throw ArgumentError.value(type, 'type', 'Expected pay or receive.');
    if (!amount.isFinite || amount <= 0 || amount > 10000000) throw ArgumentError.value(amount, 'amount', 'Amount must be between 0 and 10,000,000 (1 crore).');
    final db = await AppDatabase.instance.database;
    final now = DateTime.now();
    await db.transaction((txn) async {
      final rows = await txn.query(DBConstants.tableLedgerTransactions, where: 'id = ? AND deleted_at IS NULL', whereArgs: [id], limit: 1);
      if (rows.isEmpty) throw StateError('Transaction not found.');
      final isSystem = ((rows.first['is_system'] as num?)?.toInt() ?? 0) == 1;
      final oldCashId = rows.first['cash_transaction_id'] as int?;
      if (oldCashId != null) await _reverseCash(txn, oldCashId, now);
      final partyRows = await txn.query(DBConstants.tableLedgerParties, columns: ['type'], where: 'id = ?', whereArgs: [rows.first['party_id']], limit: 1);
      final partyType = partyRows.isEmpty ? 'customer' : partyRows.first['type'] as String;
      final cleanNote = (note?.trim().isEmpty ?? true) ? null : note!.trim();
      final newCashId = await _postCash(
        txn,
        direction: cashDirection(partyType: partyType, type: type, isSystem: isSystem),
        partyType: partyType,
        amount: amount,
        ledgerId: id,
        note: cleanNote,
        when: date,
        now: now,
        cashAccountId: cashAccountId,
      );
      await txn.update(DBConstants.tableLedgerTransactions, {'type': type, 'amount': amount, 'note': cleanNote, 'date': date.toIso8601String(), 'cash_transaction_id': newCashId, 'voice_path': voicePath, 'attachment_path': attachmentPath}, where: 'id = ?', whereArgs: [id]);
    });
      } finally {
      DataEvents.changed();
    }
  }

  Future<void> deleteTransaction(int id) async {
    try {
    final db = await AppDatabase.instance.database;
    await db.transaction((txn) async {
      final rows = await txn.query(DBConstants.tableLedgerTransactions, where: 'id = ? AND deleted_at IS NULL', whereArgs: [id], limit: 1);
      if (rows.isEmpty) return;
      final now = DateTime.now();
      final cashId = rows.first['cash_transaction_id'] as int?;
      if (cashId != null) await _reverseCash(txn, cashId, now);
      await txn.update(DBConstants.tableLedgerTransactions, {'deleted_at': now.toIso8601String()}, where: 'id = ?', whereArgs: [id]);
    });
      } finally {
      DataEvents.changed();
    }
  }

  Future<void> restoreTransaction(int id) async {
    try {
    final db = await AppDatabase.instance.database;
    final now = DateTime.now();
    await db.transaction((txn) async {
      final rows = await txn.rawQuery('''
        SELECT t.*, p.type AS party_type
        FROM ${DBConstants.tableLedgerTransactions} t
        JOIN ${DBConstants.tableLedgerParties} p ON p.id = t.party_id
        WHERE t.id = ?
        LIMIT 1
      ''', [id]);
      if (rows.isEmpty) return;
      final row = rows.first;
      final type = row['type'] as String;
      final partyType = row['party_type'] as String;
      final isSystem = ((row['is_system'] as num?)?.toInt() ?? 0) == 1;
      var direction = cashDirection(partyType: partyType, type: type, isSystem: isSystem);
      // An old customer "Pay" that never moved cash must not start doing so
      // just because it was restored from the Recycle Bin.
      if (direction != null && type == 'pay' && row['cash_transaction_id'] == null) direction = null;
      final cashId = await _postCash(
        txn,
        direction: direction,
        partyType: partyType,
        amount: (row['amount'] as num).toDouble(),
        ledgerId: id,
        note: row['note'] as String?,
        when: DateTime.tryParse(row['date'] as String) ?? now,
        now: now,
      );
      await txn.update(DBConstants.tableLedgerTransactions, {'deleted_at': null, 'cash_transaction_id': cashId}, where: 'id = ?', whereArgs: [id]);
    });
      } finally {
      DataEvents.changed();
    }
  }

  Future<void> purgeExpiredDeletedTransactions() async {
    try {
    final db = await AppDatabase.instance.database;
    final cutoff = DateTime.now().subtract(const Duration(days: 60)).toIso8601String();
    await db.delete(
      DBConstants.tableLedgerTransactions,
      where: 'deleted_at IS NOT NULL AND deleted_at < ?',
      whereArgs: [cutoff],
    );
      } finally {
      DataEvents.changed();
    }
  }

  Future<List<DeletedLedgerTransaction>> getDeletedTransactions() async {
    await purgeExpiredDeletedTransactions();
    final db = await AppDatabase.instance.database;
    final rows = await db.rawQuery('''
      SELECT t.*, p.name AS party_name, p.type AS party_type
      FROM ${DBConstants.tableLedgerTransactions} t
      INNER JOIN ${DBConstants.tableLedgerParties} p ON p.id = t.party_id
      WHERE t.deleted_at IS NOT NULL
      ORDER BY t.deleted_at DESC, t.id DESC
    ''');
    return rows.map((r) {
      return DeletedLedgerTransaction(
        transaction: _fromRow(r),
        partyId: r['party_id'] as int,
        partyName: (r['party_name'] as String?) ?? '',
        partyType: (r['party_type'] as String) == 'supplier'
            ? LedgerPartyType.supplier
            : LedgerPartyType.customer,
      );
    }).toList();
  }
}
