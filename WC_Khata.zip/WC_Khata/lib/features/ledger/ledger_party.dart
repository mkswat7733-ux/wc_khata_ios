enum LedgerPartyType { customer, supplier }

/// What the user picks on the party form. [both] creates a Customer row AND
/// a Supplier row (linked), so the person appears in every customer and
/// supplier list/picker and the two balances are netted together.
enum PartyRole { customer, supplier, both }

/// One customer or supplier in the ledger.
/// [balance] > 0 means the party owes us; [balance] < 0 means we owe them.
class LedgerParty {
  final int? id;
  final String name;
  final String? phone;
  final String? address;
  final LedgerPartyType type;
  final int? linkedPartyId;
  final double balance;
  final DateTime? lastActivity;
  final DateTime? reminderDate;
  final double? reminderAmount;

  const LedgerParty({
    this.id,
    required this.name,
    this.phone,
    this.address,
    required this.type,
    this.linkedPartyId,
    required this.balance,
    this.lastActivity,
    this.reminderDate,
    this.reminderAmount,
  });

  /// Balance direction depends on whether this is a customer or supplier.
  /// Customer: positive = they owe us (receivable), negative = we owe them.
  /// Supplier: positive = we owe them (payable), negative = they owe us.
  bool get isReceivable => type == LedgerPartyType.customer ? balance > 0 : balance < 0;
  bool get isPayable => type == LedgerPartyType.customer ? balance < 0 : balance > 0;
  bool get isSettled => balance == 0;

  /// True when the same person is both a customer and a supplier.
  bool get isBoth => linkedPartyId != null;

  PartyRole get role => isBoth
      ? PartyRole.both
      : (type == LedgerPartyType.customer ? PartyRole.customer : PartyRole.supplier);

  /// Pay / Receive buttons mean the same thing for customers and suppliers:
  /// Pay = money we give, Receive = money/credit we get.
  /// Stored ledger types for suppliers are the mirror of the buttons
  /// (stored 'receive' = payment made to the supplier, stored 'pay' = credit
  /// purchase), so every screen converts through these two helpers.
  bool get _isSupplier => type == LedgerPartyType.supplier;

  /// Stored ledger type for the button the user pressed.
  String storedType(bool uiReceive) => (_isSupplier ? !uiReceive : uiReceive) ? 'receive' : 'pay';

  /// True when a stored ledger type should be shown as "Receive".
  bool uiIsReceive(String stored) => _isSupplier ? stored != 'receive' : stored == 'receive';
}
