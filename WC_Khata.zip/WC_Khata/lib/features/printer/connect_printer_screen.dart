import 'dart:async';

import 'package:flutter/material.dart';

import '../../app/theme/app_theme.dart';
import '../../core/routing/app_transitions.dart';
import '../../core/services/thermal_printer_service.dart';
import '../../core/widgets/app_button_3d.dart';
import '../../core/widgets/app_tab_screen.dart';
import 'label_printer_screen.dart';

enum _Phase { intro, choose, working, tested, ready }

enum _Step { pending, active, done, failed }

/// More > Printer. Centre button "Connect Printer" runs the whole flow:
/// Bluetooth ON -> choose printer -> pair -> connect -> test print -> Continue.
class ConnectPrinterScreen extends StatefulWidget {
  /// When opened from a Print button: pop(true) after Continue so the
  /// original print can go ahead.
  final bool returnOnReady;

  const ConnectPrinterScreen({super.key, this.returnOnReady = false});

  @override
  State<ConnectPrinterScreen> createState() => _ConnectPrinterScreenState();
}

class _ConnectPrinterScreenState extends State<ConnectPrinterScreen> {
  final svc = ThermalPrinterService.instance;

  _Phase _phase = _Phase.intro;
  bool _starting = false;
  bool _scanning = false;
  bool _loading = true;
  bool _reconnecting = false;
  bool _testing = false;
  String? _error;

  final List<PrinterDevice> _devices = [];
  PrinterDevice? _selected;
  final List<_Step> _steps = List.filled(4, _Step.pending);
  static const _stepLabels = ['Bluetooth ON', 'Printer pair', 'Printer connect', 'Test print'];

  StreamSubscription<PrinterDevice>? _foundSub;
  StreamSubscription<void>? _doneSub;

  @override
  void initState() {
    super.initState();
    _foundSub = svc.onDeviceFound.listen(_onFound);
    _doneSub = svc.onScanFinished.listen((_) {
      if (mounted) setState(() => _scanning = false);
    });
    svc.addListener(_refresh);
    _init();
  }

  @override
  void dispose() {
    svc.removeListener(_refresh);
    _foundSub?.cancel();
    _doneSub?.cancel();
    svc.stopScan();
    super.dispose();
  }

  void _refresh() {
    if (mounted) setState(() {});
  }

  Future<void> _init() async {
    await svc.load();
    if (!mounted) return;
    setState(() {
      _loading = false;
      _phase = svc.hasSavedPrinter ? _Phase.ready : _Phase.intro;
    });
    if (svc.hasSavedPrinter && !svc.connected) {
      setState(() => _reconnecting = true);
      await svc.silentReconnect();
      if (mounted) setState(() => _reconnecting = false);
    }
  }

  // ----------------------------------------------------------------- flow

  void _resetSteps() {
    for (var i = 0; i < _steps.length; i++) {
      _steps[i] = _Step.pending;
    }
  }

  Future<void> _start() async {
    if (_starting) return;
    setState(() {
      _starting = true;
      _error = null;
    });
    try {
      if (!await svc.isSupported()) {
        _fail('This phone does not support Bluetooth.');
        return;
      }
      if (!await svc.hasPermissions() && !await svc.requestPermissions()) {
        _fail('Please allow the Bluetooth permission, then tap Connect Printer again.');
        return;
      }
      if (!await svc.isBluetoothOn()) {
        if (!await svc.enableBluetooth()) {
          _fail('Bluetooth was not turned on. Please turn it on and try again.');
          return;
        }
      }
      if (!mounted) return;
      setState(() {
        _phase = _Phase.choose;
        _devices.clear();
      });
      await _loadDevices();
    } finally {
      if (mounted) setState(() => _starting = false);
    }
  }

  void _fail(String msg) {
    if (mounted) setState(() => _error = msg);
  }

  Future<void> _loadDevices() async {
    final paired = await svc.pairedDevices();
    if (!mounted) return;
    setState(() {
      _devices
        ..clear()
        ..addAll(paired);
      _scanning = true;
    });
    final started = await svc.startScan();
    if (mounted && !started) setState(() => _scanning = false);
  }

  void _onFound(PrinterDevice d) {
    if (!mounted || _phase != _Phase.choose) return;
    final i = _devices.indexWhere((e) => e.address == d.address);
    setState(() {
      if (i >= 0) {
        // Keep a known name if the new report has none.
        _devices[i] = PrinterDevice(
          name: d.name.isNotEmpty ? d.name : _devices[i].name,
          address: d.address,
          paired: d.paired || _devices[i].paired,
        );
      } else {
        _devices.add(d);
      }
    });
  }

  Future<void> _pick(PrinterDevice device) async {
    await svc.stopScan();
    if (!mounted) return;
    setState(() {
      _selected = device;
      _phase = _Phase.working;
      _error = null;
      _scanning = false;
      _resetSteps();
      _steps[0] = _Step.done;
      _steps[1] = _Step.active;
    });

    if (!device.paired) {
      final paired = await svc.pair(device);
      if (!mounted) return;
      if (!paired) {
        setState(() {
          _steps[1] = _Step.failed;
          _error = 'Pairing failed. Turn the printer on and accept the pairing request (PIN is usually 0000 or 1234).';
        });
        return;
      }
    }
    setState(() {
      _steps[1] = _Step.done;
      _steps[2] = _Step.active;
    });

    final connected = await svc.connect(device);
    if (!mounted) return;
    if (!connected) {
      setState(() {
        _steps[2] = _Step.failed;
        _error = 'Could not connect. Make sure the printer is on and not connected to another phone.';
      });
      return;
    }
    setState(() {
      _steps[2] = _Step.done;
      _steps[3] = _Step.active;
    });
    await _runTest(fromFlow: true);
  }

  Future<void> _runTest({bool fromFlow = false}) async {
    setState(() {
      _testing = true;
      if (fromFlow) _steps[3] = _Step.active;
    });
    try {
      await svc.printTest();
      if (!mounted) return;
      setState(() {
        _steps[3] = _Step.done;
        _testing = false;
        _phase = _Phase.tested;
        _error = null;
      });
    } on PrinterException catch (e) {
      _testFailed(e.message);
    } catch (_) {
      _testFailed('Test print failed. Please try again.');
    }
  }

  void _testFailed(String msg) {
    if (!mounted) return;
    setState(() {
      _testing = false;
      _steps[3] = _Step.failed;
      _error = msg;
      if (_phase != _Phase.ready) _phase = _Phase.working;
    });
  }

  void _continue() {
    if (widget.returnOnReady) {
      Navigator.pop(context, true);
    } else {
      setState(() => _phase = _Phase.ready);
    }
  }

  Future<void> _changePrinter() async {
    await svc.disconnect();
    if (!mounted) return;
    setState(() {
      _error = null;
      _phase = _Phase.intro;
    });
    await _start();
  }

  void _openLabelPrinter() {
    Navigator.push(context, AppTransitions.seamless(const LabelPrinterScreen()));
  }

  Future<void> _forget() async {
    await svc.forget();
    if (mounted) setState(() => _phase = _Phase.intro);
  }

  Future<void> _reconnect() async {
    setState(() => _reconnecting = true);
    final ok = await svc.silentReconnect();
    if (!mounted) return;
    setState(() {
      _reconnecting = false;
      if (!ok) _error = 'Could not connect. Turn on the printer and Bluetooth, then try again.';
    });
  }

  // ------------------------------------------------------------------- ui

  @override
  Widget build(BuildContext context) {
    return AppTabScreen(
      title: 'Printer',
      onBack: () => Navigator.pop(context, false),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : AnimatedSwitcher(
              duration: const Duration(milliseconds: 260),
              child: KeyedSubtree(key: ValueKey(_phase), child: _body()),
            ),
    );
  }

  Widget _body() {
    switch (_phase) {
      case _Phase.intro:
        return _intro();
      case _Phase.choose:
        return _choose();
      case _Phase.working:
        return _working();
      case _Phase.tested:
        return _tested();
      case _Phase.ready:
        return _ready();
    }
  }

  Widget _iconBadge(IconData icon, Color color, {double size = 96}) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.12),
        shape: BoxShape.circle,
        border: Border.all(color: color.withValues(alpha: 0.35), width: 1.4),
      ),
      child: Icon(icon, color: color, size: size * 0.5),
    );
  }

  Widget _errorBox() {
    if (_error == null) return const SizedBox.shrink();
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(top: 14),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.expenseLight,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.expense.withValues(alpha: 0.3)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Icon(Icons.error_outline_rounded, color: AppColors.expense, size: 20),
          const SizedBox(width: 8),
          Expanded(child: Text(_error!, style: const TextStyle(color: AppColors.expense, fontWeight: FontWeight.w600, height: 1.35))),
        ],
      ),
    );
  }

  // Centre screen: only the Connect Printer button.
  Widget _intro() {
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _iconBadge(Icons.print_rounded, AppColors.primary, size: 112),
            const SizedBox(height: 20),
            const Text('Thermal Printer', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w800, color: AppColors.lightTextPrimary)),
            const SizedBox(height: 8),
            const Text(
              'Connect your Bluetooth thermal printer.\nEvery Print button in the app will then print directly on it (58mm / 80mm).',
              textAlign: TextAlign.center,
              style: TextStyle(color: AppColors.lightTextSecondary, height: 1.45),
            ),
            const SizedBox(height: 26),
            AppButton3D(
              label: _starting ? 'Please wait...' : 'Connect Printer',
              icon: Icons.bluetooth_searching_rounded,
              expand: true,
              onPressed: _starting ? null : _start,
            ),
            const SizedBox(height: 12),
            AppButton3D(label: 'Label Printer', icon: Icons.label_rounded, outlined: true, expand: true, onPressed: _openLabelPrinter),
            _errorBox(),
          ],
        ),
      ),
    );
  }

  Widget _choose() {
    final paired = _devices.where((d) => d.paired).toList();
    final nearby = _devices.where((d) => !d.paired).toList();
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
      children: [
        _stepsCard(),
        const SizedBox(height: 16),
        Row(
          children: [
            const Expanded(child: Text('Select a printer', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: AppColors.lightTextPrimary))),
            if (_scanning)
              const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2.2))
            else
              InkWell(
                onTap: _loadDevices,
                borderRadius: BorderRadius.circular(20),
                child: const Padding(
                  padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  child: Row(children: [
                    Icon(Icons.refresh_rounded, size: 18, color: AppColors.primary),
                    SizedBox(width: 4),
                    Text('Rescan', style: TextStyle(color: AppColors.primary, fontWeight: FontWeight.w700)),
                  ]),
                ),
              ),
          ],
        ),
        const SizedBox(height: 4),
        const Text('Keep the printer turned on. Paired printers are listed first, new nearby devices below.', style: TextStyle(color: AppColors.lightTextSecondary, fontSize: 12.5)),
        const SizedBox(height: 12),
        if (paired.isNotEmpty) _sectionLabel('Paired printers'),
        for (final d in paired) _deviceTile(d),
        if (nearby.isNotEmpty) _sectionLabel('Nearby devices'),
        for (final d in nearby) _deviceTile(d),
        if (_devices.isEmpty)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 28),
            child: Center(
              child: Text(
                _scanning ? 'Searching for printers...' : 'No devices found. Turn the printer on and tap Rescan.',
                textAlign: TextAlign.center,
                style: const TextStyle(color: AppColors.lightTextSecondary),
              ),
            ),
          ),
        _errorBox(),
      ],
    );
  }

  Widget _sectionLabel(String t) => Padding(
        padding: const EdgeInsets.only(top: 6, bottom: 8),
        child: Text(t, style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w800, color: AppColors.lightTextSecondary, letterSpacing: .4)),
      );

  Widget _deviceTile(PrinterDevice d) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Material(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: () => _pick(d),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: AppColors.primary.withValues(alpha: 0.5), width: 1.1),
              boxShadow: [BoxShadow(color: AppColors.primary.withValues(alpha: 0.07), blurRadius: 10, offset: const Offset(0, 4))],
            ),
            child: Row(
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(color: AppColors.primary.withValues(alpha: 0.12), shape: BoxShape.circle),
                  child: Icon(d.paired ? Icons.print_rounded : Icons.bluetooth_rounded, color: AppColors.primary, size: 21),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(d.displayName, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15, color: AppColors.lightTextPrimary)),
                      const SizedBox(height: 2),
                      Text(d.address, style: const TextStyle(fontSize: 12, color: AppColors.lightTextSecondary)),
                    ],
                  ),
                ),
                if (d.paired)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(color: AppColors.incomeLight, borderRadius: BorderRadius.circular(20)),
                    child: const Text('Paired', style: TextStyle(color: AppColors.income, fontWeight: FontWeight.w800, fontSize: 11.5)),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _stepsCard() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: AppColors.lightCardBorder),
      ),
      child: Column(
        children: [
          for (var i = 0; i < _stepLabels.length; i++) _stepRow(i),
        ],
      ),
    );
  }

  Widget _stepRow(int i) {
    final st = i == 0 && _phase == _Phase.choose ? _Step.done : _steps[i];
    late final Color color;
    late final Widget leading;
    switch (st) {
      case _Step.done:
        color = AppColors.income;
        leading = const Icon(Icons.check_circle_rounded, color: AppColors.income, size: 24);
        break;
      case _Step.failed:
        color = AppColors.expense;
        leading = const Icon(Icons.cancel_rounded, color: AppColors.expense, size: 24);
        break;
      case _Step.active:
        color = AppColors.primary;
        leading = const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2.4));
        break;
      case _Step.pending:
        color = AppColors.lightTextSecondary;
        leading = Icon(Icons.radio_button_unchecked_rounded, color: AppColors.lightTextSecondary.withValues(alpha: 0.6), size: 24);
        break;
    }
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 7),
      child: Row(
        children: [
          SizedBox(width: 26, child: Center(child: leading)),
          const SizedBox(width: 12),
          Text(_stepLabels[i], style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15, color: st == _Step.pending ? AppColors.lightTextSecondary : color)),
        ],
      ),
    );
  }

  Widget _working() {
    final failed = _steps.contains(_Step.failed);
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 20, 16, 24),
      children: [
        Center(child: _iconBadge(failed ? Icons.print_disabled_rounded : Icons.print_rounded, failed ? AppColors.expense : AppColors.primary)),
        const SizedBox(height: 14),
        Center(
          child: Text(
            _selected?.displayName ?? 'Printer',
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.lightTextPrimary),
          ),
        ),
        const SizedBox(height: 16),
        _stepsCard(),
        _errorBox(),
        if (failed) ...[
          const SizedBox(height: 18),
          if (_steps[3] == _Step.failed && _steps[2] == _Step.done)
            AppButton3D(label: 'Test Print Again', icon: Icons.refresh_rounded, expand: true, onPressed: _testing ? null : () => _runTest(fromFlow: true))
          else if (_selected != null)
            AppButton3D(label: 'Try Again', icon: Icons.refresh_rounded, expand: true, onPressed: () => _pick(_selected!)),
          const SizedBox(height: 10),
          AppButton3D(label: 'Choose Another Printer', icon: Icons.bluetooth_searching_rounded, outlined: true, expand: true, onPressed: _start),
        ],
      ],
    );
  }

  Widget _tested() {
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _iconBadge(Icons.check_rounded, AppColors.income, size: 104),
            const SizedBox(height: 18),
            const Text('Printer Connected', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: AppColors.lightTextPrimary)),
            const SizedBox(height: 8),
            Text(
              'A test print was sent to ${svc.printerName ?? 'the printer'}. Once it prints, tap Continue.',
              textAlign: TextAlign.center,
              style: const TextStyle(color: AppColors.lightTextSecondary, height: 1.45),
            ),
            const SizedBox(height: 22),
            _stepsCard(),
            const SizedBox(height: 22),
            AppButton3D(label: 'Continue', icon: Icons.arrow_forward_rounded, expand: true, onPressed: _continue),
            const SizedBox(height: 10),
            AppButton3D(
              label: _testing ? 'Printing...' : 'Test Print Again',
              icon: Icons.print_rounded,
              outlined: true,
              expand: true,
              onPressed: _testing ? null : () => _runTest(),
            ),
            _errorBox(),
          ],
        ),
      ),
    );
  }

  // Normal state after setup: connected printer + paper size + actions.
  Widget _ready() {
    final connected = svc.connected;
    final statusColor = connected ? AppColors.income : AppColors.expense;
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 18, 16, 24),
      children: [
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: AppColors.primary.withValues(alpha: 0.5), width: 1.2),
            boxShadow: [BoxShadow(color: AppColors.primary.withValues(alpha: 0.08), blurRadius: 14, offset: const Offset(0, 6))],
          ),
          child: Row(
            children: [
              _iconBadge(Icons.print_rounded, AppColors.primary, size: 56),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(svc.printerName ?? 'Thermal Printer', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: AppColors.lightTextPrimary)),
                    const SizedBox(height: 3),
                    Text(svc.printerAddress ?? '', style: const TextStyle(fontSize: 12, color: AppColors.lightTextSecondary)),
                    const SizedBox(height: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                      decoration: BoxDecoration(color: statusColor.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(20)),
                      child: Text(
                        _reconnecting ? 'Connecting...' : (connected ? 'Connected' : 'Not connected'),
                        style: TextStyle(color: statusColor, fontWeight: FontWeight.w800, fontSize: 12),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 18),
        const Text('Paper size', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: AppColors.lightTextPrimary)),
        const SizedBox(height: 4),
        const Text('All prints will use this paper size.', style: TextStyle(color: AppColors.lightTextSecondary, fontSize: 12.5)),
        const SizedBox(height: 10),
        Row(
          children: [
            Expanded(child: _paperChip(58)),
            const SizedBox(width: 10),
            Expanded(child: _paperChip(80)),
          ],
        ),
        const SizedBox(height: 18),
        _widthControl(),
        const SizedBox(height: 14),
        _compatControl(),
        _errorBox(),
        const SizedBox(height: 22),
        if (!connected)
          AppButton3D(label: _reconnecting ? 'Connecting...' : 'Reconnect', icon: Icons.bluetooth_connected_rounded, expand: true, onPressed: _reconnecting ? null : _reconnect)
        else
          AppButton3D(label: _testing ? 'Printing...' : 'Test Print', icon: Icons.print_rounded, expand: true, onPressed: _testing ? null : _testFromReady),
        const SizedBox(height: 10),
        AppButton3D(label: 'Label Printer', icon: Icons.label_rounded, outlined: true, expand: true, onPressed: _openLabelPrinter),
        const SizedBox(height: 10),
        AppButton3D(label: 'Change Printer', icon: Icons.swap_horiz_rounded, outlined: true, expand: true, onPressed: _changePrinter),
        const SizedBox(height: 10),
        AppButton3D(label: 'Disconnect', icon: Icons.bluetooth_disabled_rounded, outlined: true, color: AppColors.expense, expand: true, onPressed: _forget),
        if (widget.returnOnReady && connected) ...[
          const SizedBox(height: 10),
          AppButton3D(label: 'Continue', icon: Icons.arrow_forward_rounded, expand: true, onPressed: () => Navigator.pop(context, true)),
        ],
      ],
    );
  }

  Widget _optionChips(List<String> labels, int selected, ValueChanged<int> onTap) {
    return Row(
      children: [
        for (var i = 0; i < labels.length; i++) ...[
          if (i > 0) const SizedBox(width: 8),
          Expanded(
            child: GestureDetector(
              onTap: () => onTap(i),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 160),
                padding: const EdgeInsets.symmetric(vertical: 10),
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: selected == i ? AppColors.primary : Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: selected == i ? AppColors.primary : AppColors.lightDivider, width: 1.2),
                ),
                child: Text(labels[i], style: TextStyle(fontWeight: FontWeight.w800, fontSize: 13.5, color: selected == i ? Colors.white : AppColors.lightTextPrimary)),
              ),
            ),
          ),
        ],
      ],
    );
  }

  // For printers (mostly 80mm) that print garbage, blanks or stop halfway.
  Widget _compatControl() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.lightCardBorder),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Printer compatibility', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: AppColors.lightTextPrimary)),
          const SizedBox(height: 2),
          const Text(
            'If the printer prints garbage, blank paper or stops halfway (common on 80mm), try Compatible mode and/or Safe speed, then tap Test Print.',
            style: TextStyle(color: AppColors.lightTextSecondary, fontSize: 12.5, height: 1.35),
          ),
          const SizedBox(height: 12),
          const Text('Print mode', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
          const SizedBox(height: 6),
          _optionChips(const ['Standard', 'Compatible'], svc.printMode, svc.setPrintMode),
          const SizedBox(height: 12),
          const Text('Speed', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
          const SizedBox(height: 6),
          _optionChips(const ['Fast', 'Normal', 'Safe'], svc.printSpeed, svc.setPrintSpeed),
          const SizedBox(height: 4),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Battery protection', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
            subtitle: const Text('Stops the printer switching off on dark receipts.', style: TextStyle(fontSize: 11.5)),
            value: svc.powerSafe,
            onChanged: svc.setPowerSafe,
          ),
        ],
      ),
    );
  }

  Widget _widthControl() {
    final mm = svc.paperMm;
    final min = ThermalPrinterService.minDots(mm).toDouble();
    final max = ThermalPrinterService.maxDots(mm).toDouble();
    final value = svc.printDots.toDouble().clamp(min, max).toDouble();
    return Container(
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 8),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.lightCardBorder),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Expanded(child: Text('Print width', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: AppColors.lightTextPrimary))),
              Text('${value.round()} dots', style: const TextStyle(fontWeight: FontWeight.w800, color: AppColors.primary)),
              const SizedBox(width: 6),
              InkWell(
                onTap: () => svc.setPrintDots(mm, ThermalPrinterService.defaultDots(mm)),
                child: const Padding(padding: EdgeInsets.all(4), child: Text('Reset', style: TextStyle(color: AppColors.primary, fontWeight: FontWeight.w700))),
              ),
            ],
          ),
          const SizedBox(height: 2),
          const Text(
            'Receipt looks narrow? Increase it. Right side cut off? Decrease it. Then tap Test Print to check the border.',
            style: TextStyle(color: AppColors.lightTextSecondary, fontSize: 12.5, height: 1.35),
          ),
          Slider(
            value: value,
            min: min,
            max: max,
            divisions: ((max - min) / 8).round(),
            onChanged: (v) => svc.setPrintDots(mm, v.round()),
          ),
        ],
      ),
    );
  }

  Future<void> _testFromReady() async {
    setState(() {
      _testing = true;
      _error = null;
    });
    try {
      await svc.printTest();
      if (mounted) setState(() => _testing = false);
    } on PrinterException catch (e) {
      if (mounted) setState(() { _testing = false; _error = e.message; });
    } catch (_) {
      if (mounted) setState(() { _testing = false; _error = 'Test print failed.'; });
    }
  }

  Widget _paperChip(int mm) {
    final selected = svc.paperMm == mm;
    return GestureDetector(
      onTap: () => svc.setPaper(mm),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          color: selected ? AppColors.primary : Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: selected ? AppColors.primary : AppColors.lightDivider, width: 1.3),
          boxShadow: selected ? [BoxShadow(color: AppColors.primary.withValues(alpha: 0.3), blurRadius: 10, offset: const Offset(0, 4))] : null,
        ),
        child: Column(
          children: [
            Icon(Icons.receipt_long_rounded, color: selected ? Colors.white : AppColors.lightTextSecondary, size: 22),
            const SizedBox(height: 4),
            Text('${mm}mm', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16, color: selected ? Colors.white : AppColors.lightTextPrimary)),
          ],
        ),
      ),
    );
  }
}
