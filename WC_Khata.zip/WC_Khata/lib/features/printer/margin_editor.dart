import 'package:flutter/material.dart';

import '../../app/theme/app_theme.dart';

/// Four margin steppers (left / right / top / bottom) in millimetres, shared by
/// the receipt designer, the Printer Settings screen and the label designer.
class MarginEditor extends StatelessWidget {
  final double left, right, top, bottom;
  final double maxSide, maxVertical;
  final double step;

  /// Called with the new (left, right, top, bottom).
  final void Function(double l, double r, double t, double b) onChanged;

  /// Label of the reset button and what it does (null = no reset button).
  final String? resetLabel;
  final VoidCallback? onReset;

  /// Small caption under the values, e.g. "Automatic".
  final String? caption;

  const MarginEditor({
    super.key,
    required this.left,
    required this.right,
    required this.top,
    required this.bottom,
    required this.onChanged,
    this.maxSide = 12,
    this.maxVertical = 25,
    this.step = .5,
    this.resetLabel,
    this.onReset,
    this.caption,
  });

  String _n(double v) => v == v.roundToDouble() ? v.toInt().toString() : v.toStringAsFixed(1);

  double _c(double v, double max) => ((v.clamp(0.0, max)) / step).round() * step;

  Widget _stepButton(IconData icon, VoidCallback? onTap) => InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(10),
        child: Container(
          width: 34,
          height: 34,
          decoration: BoxDecoration(
            color: AppColors.primary.withValues(alpha: onTap == null ? .04 : .10),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Icon(icon, color: onTap == null ? AppColors.lightDivider : AppColors.primary, size: 20),
        ),
      );

  Widget _row(String label, IconData icon, double value, double max, ValueChanged<double> set) => Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: Row(children: [
          Icon(icon, size: 17, color: AppColors.lightTextSecondary),
          const SizedBox(width: 8),
          Expanded(child: Text(label, style: const TextStyle(fontWeight: FontWeight.w700, color: AppColors.lightTextPrimary))),
          _stepButton(Icons.remove_rounded, value <= 0 ? null : () => set(_c(value - step, max))),
          SizedBox(width: 64, child: Center(child: Text('${_n(value)} mm', style: const TextStyle(fontWeight: FontWeight.w800)))),
          _stepButton(Icons.add_rounded, value >= max ? null : () => set(_c(value + step, max))),
        ]),
      );

  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      _row('Left', Icons.align_horizontal_left_rounded, left, maxSide, (v) => onChanged(v, right, top, bottom)),
      _row('Right', Icons.align_horizontal_right_rounded, right, maxSide, (v) => onChanged(left, v, top, bottom)),
      _row('Top', Icons.align_vertical_top_rounded, top, maxVertical, (v) => onChanged(left, right, v, bottom)),
      _row('Bottom', Icons.align_vertical_bottom_rounded, bottom, maxVertical, (v) => onChanged(left, right, top, v)),
      Row(children: [
        Expanded(
          child: Wrap(spacing: 6, runSpacing: 6, children: [
            _quick('Left + Right', () {
              final v = _c((left + right) / 2, maxSide);
              onChanged(v, v, top, bottom);
            }),
            _quick('All equal', () {
              final v = _c((left + right + top + bottom) / 4, maxSide);
              onChanged(v, v, v, v);
            }),
          ]),
        ),
        if (onReset != null)
          TextButton(
            onPressed: onReset,
            child: Text(resetLabel ?? 'Reset', style: const TextStyle(fontWeight: FontWeight.w800)),
          ),
      ]),
      if (caption != null)
        Padding(
          padding: const EdgeInsets.only(top: 2),
          child: Text(caption!, style: const TextStyle(fontSize: 11.5, color: AppColors.lightTextSecondary, height: 1.3)),
        ),
    ]);
  }

  Widget _quick(String text, VoidCallback onTap) => GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
          decoration: BoxDecoration(
            color: AppColors.lightBackground,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: AppColors.lightDivider),
          ),
          child: Text(text, style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w800, color: AppColors.lightTextPrimary)),
        ),
      );
}
