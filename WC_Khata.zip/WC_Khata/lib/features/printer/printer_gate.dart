import 'package:flutter/material.dart';

import '../../app/theme/app_theme.dart';
import '../../core/routing/app_transitions.dart';
import '../../core/services/print_mode_service.dart';
import '../../core/services/thermal_printer_service.dart';
import '../../core/widgets/app_button_3d.dart';
import 'connect_printer_screen.dart';
import 'label_printer_screen.dart';
import '../../core/widgets/app_message.dart';

/// Every Print button in the app goes through here: if no thermal printer is
/// connected it asks the user to connect one (inside this app only), then
/// the job is sent straight to the thermal printer - no system print dialog.
class PrinterGate {
  PrinterGate._();

  /// Returns true when a printer is connected and ready.
  static Future<bool> ensure(BuildContext context) async {
    // External print service ON: the app's own printer is not used at all,
    // so there is nothing to connect. The job goes to the Android print dialog.
    await PrintModeService.instance.load();
    if (PrintModeService.instance.external) return true;
    final svc = ThermalPrinterService.instance;
    await svc.load();
    if (svc.connected) return true;
    if (svc.hasSavedPrinter && await svc.silentReconnect()) return true;
    if (!context.mounted) return false;

    final connect = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('Printer not connected', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18)),
        content: const Text(
          'Please connect a thermal printer before printing.',
          style: TextStyle(color: AppColors.lightTextSecondary, height: 1.4),
        ),
        actionsPadding: const EdgeInsets.fromLTRB(16, 0, 16, 14),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          AppButton3D(label: 'Connect Printer', icon: Icons.bluetooth_rounded, compact: true, onPressed: () => Navigator.pop(ctx, true)),
        ],
      ),
    );
    if (connect != true || !context.mounted) return false;

    final ok = await Navigator.push<bool>(
      context,
      AppTransitions.seamless<bool>(const ConnectPrinterScreen(returnOnReady: true)),
    );
    return ok == true;
  }

  /// Label Print buttons: a label printer (or the dual printer) must be set up.
  /// If not, the Label Printer screen opens; the print continues after Continue.
  static Future<bool> ensureLabel(BuildContext context) async {
    await PrintModeService.instance.load();
    if (PrintModeService.instance.external) return true;
    final svc = ThermalPrinterService.instance;
    await svc.load();
    if (svc.hasLabelPrinter) return true;
    if (!context.mounted) return false;

    final setup = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('Label printer not set up', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18)),
        content: const Text(
          'Please connect a label printer, or choose your dual printer, before printing labels.',
          style: TextStyle(color: AppColors.lightTextSecondary, height: 1.4),
        ),
        actionsPadding: const EdgeInsets.fromLTRB(16, 0, 16, 14),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          AppButton3D(label: 'Set up Label Printer', icon: Icons.label_rounded, compact: true, onPressed: () => Navigator.pop(ctx, true)),
        ],
      ),
    );
    if (setup != true || !context.mounted) return false;

    final ok = await Navigator.push<bool>(
      context,
      AppTransitions.seamless<bool>(const LabelPrinterScreen(returnOnReady: true)),
    );
    return ok == true;
  }

  /// Checks the printer, runs [job], and shows a friendly message either way.
  static Future<bool> run(BuildContext context, Future<void> Function() job, {String success = 'Sent to the printer.'}) async {
    if (!await ensure(context)) return false;
    try {
      await job();
      if (context.mounted) _snack(context, success);
      return true;
    } on PrinterException catch (e) {
      if (context.mounted) _snack(context, e.message);
    } catch (_) {
      if (context.mounted) _snack(context, 'Printing failed. Please try again.');
    }
    return false;
  }

  static void _snack(BuildContext context, String msg) {
    AppMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(msg)));
  }
}
