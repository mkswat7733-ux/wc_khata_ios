import 'package:flutter/material.dart';
import '../../app/theme/app_theme.dart';
import '../../core/routing/app_transitions.dart';
import '../../core/widgets/modern_header.dart';
import '../profile/profile_screen.dart';
import '../security/security_screen.dart';
import '../backup/backup_screen.dart';
import '../backup/restore_screen.dart';
import '../home/currency_settings_screen.dart';
import '../about/about_screen.dart';
import '../../core/services/print_mode_service.dart';
import '../../core/services/scanner_settings_service.dart';
import 'barcode_settings_screen.dart';
import 'unit_system_screen.dart';
import 'soft_settings_screen.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  bool _autoCloseScanner = true;
  bool _externalPrint = false;

  @override
  void initState() {
    super.initState();
    _loadScannerSetting();
    _loadPrintMode();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    )..forward();
  }

  Future<void> _loadScannerSetting() async {
    final value = await ScannerSettingsService.instance.getAutoClose();
    if (mounted) setState(() => _autoCloseScanner = value);
  }

  Future<void> _loadPrintMode() async {
    await PrintModeService.instance.load();
    if (mounted) setState(() => _externalPrint = PrintModeService.instance.external);
  }

  Future<void> _setExternalPrint(bool value) async {
    setState(() => _externalPrint = value);
    await PrintModeService.instance.setExternal(value);
  }

  Future<void> _setAutoCloseScanner(bool value) async {
    setState(() => _autoCloseScanner = value);
    await ScannerSettingsService.instance.setAutoClose(value);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Animation<double> _reveal(int index) {
    final begin = (0.06 + index * 0.10).clamp(0.0, 0.72);
    final end = (begin + 0.34).clamp(0.0, 1.0);
    return CurvedAnimation(
      parent: _controller,
      curve: Interval(begin, end, curve: Curves.easeOutCubic),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.lightBackground,
      body: Column(
        children: [
          ModernHeader(title: 'Settings', onBack: () => Navigator.pop(context)),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(AppDimensions.spaceMd),
              children: [
                _sectionLabel('Preferences'),
                _navTile(0, Icons.person_rounded, AppColors.primary, 'Profile',
                    () => Navigator.push(context, AppTransitions.seamless(ProfileScreen(onBack: () => Navigator.pop(context))))),
                _navTile(2, Icons.currency_exchange_rounded, AppColors.income, 'Currency',
                    () => Navigator.push(context, AppTransitions.seamless(const CurrencySettingsScreen()))),
                _scannerToggleTile(),
                _externalPrintTile(),
                _navTile(3, Icons.tune_rounded, AppColors.primary, 'Soft Settings',
                    () => Navigator.push(context, AppTransitions.seamless(const SoftSettingsScreen()))),
                _navTile(3, Icons.qr_code_2_rounded, AppColors.primary, 'Barcode System',
                    () => Navigator.push(context, AppTransitions.seamless(const BarcodeSettingsScreen()))),
                _navTile(4, Icons.layers_rounded, AppColors.primary, 'Inner / Outer Unit System',
                    () => Navigator.push(context, AppTransitions.seamless(const UnitSystemScreen()))),
                const SizedBox(height: AppDimensions.spaceLg),
                _sectionLabel('Security'),
                _navTile(4, Icons.verified_user_rounded, AppColors.warning, 'Security',
                    () => Navigator.push(context, AppTransitions.seamless(const SecurityScreen()))),
                const SizedBox(height: AppDimensions.spaceLg),
                _sectionLabel('Backup & Restore'),
                _navTile(5, Icons.cloud_upload_rounded, AppColors.catHealth, 'Create Backup',
                    () => Navigator.push(context, AppTransitions.seamless(const BackupScreen()))),
                _navTile(6, Icons.cloud_download_rounded, AppColors.catEntertainment, 'Restore Backup',
                    () => Navigator.push(context, AppTransitions.seamless(const RestoreScreen()))),
                const SizedBox(height: AppDimensions.spaceLg),
                _sectionLabel('About'),
                _aboutTile(7),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _sectionLabel(String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: AppDimensions.spaceSm, left: 4),
      child: Text(
        text,
        style: AppTextStyles.caption.copyWith(
          color: AppColors.lightTextSecondary,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }

  Widget _scannerToggleTile() {
    final reveal = _reveal(2);
    return FadeTransition(
      opacity: reveal,
      child: SlideTransition(
        position: reveal.drive(Tween(begin: const Offset(-0.25, 0), end: Offset.zero)),
        child: Container(
          margin: const EdgeInsets.only(bottom: AppDimensions.spaceSm),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
          decoration: BoxDecoration(
            color: AppColors.lightSurface,
            borderRadius: BorderRadius.circular(AppDimensions.radiusMd),
            boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: .10), blurRadius: 10, offset: const Offset(0, 4))],
          ),
          child: Row(children: [
            Container(width: 40, height: 40, decoration: BoxDecoration(color: AppColors.primary.withValues(alpha: .12), shape: BoxShape.circle), child: const Icon(Icons.qr_code_scanner_rounded, color: AppColors.primary, size: 19)),
            const SizedBox(width: AppDimensions.spaceMd),
            const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Auto Close Scanner', style: AppTextStyles.bodyMedium),
              SizedBox(height: 2),
              Text('Close scanner after success or error', style: AppTextStyles.caption),
            ])),
            Switch.adaptive(value: _autoCloseScanner, onChanged: _setAutoCloseScanner, activeColor: AppColors.primary),
          ]),
        ),
      ),
    );
  }

  Widget _externalPrintTile() {
    final reveal = _reveal(2);
    return FadeTransition(
      opacity: reveal,
      child: SlideTransition(
        position: reveal.drive(Tween(begin: const Offset(-0.25, 0), end: Offset.zero)),
        child: Container(
          margin: const EdgeInsets.only(bottom: AppDimensions.spaceSm),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
          decoration: BoxDecoration(
            color: AppColors.lightSurface,
            borderRadius: BorderRadius.circular(AppDimensions.radiusMd),
            boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: .10), blurRadius: 10, offset: const Offset(0, 4))],
          ),
          child: Row(children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(color: AppColors.primary.withValues(alpha: .12), shape: BoxShape.circle),
              child: const Icon(Icons.print_rounded, color: AppColors.primary, size: 19),
            ),
            const SizedBox(width: AppDimensions.spaceMd),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('External Print Service', style: AppTextStyles.bodyMedium),
                const SizedBox(height: 2),
                Text(
                  _externalPrint
                      ? 'ON: printing goes through your print service app. App printer is disabled'
                      : 'OFF: the app prints with its own printer system',
                  style: AppTextStyles.caption,
                ),
              ]),
            ),
            Switch.adaptive(value: _externalPrint, onChanged: _setExternalPrint, activeColor: AppColors.primary),
          ]),
        ),
      ),
    );
  }

  Widget _navTile(int index, IconData icon, Color color, String label, VoidCallback onTap) {
    final reveal = _reveal(index);
    return FadeTransition(
      opacity: reveal,
      child: SlideTransition(
        position: reveal.drive(Tween(begin: const Offset(-0.25, 0), end: Offset.zero)),
        child: Padding(
          padding: const EdgeInsets.only(bottom: AppDimensions.spaceSm),
          child: Material(
            color: AppColors.lightSurface,
            borderRadius: BorderRadius.circular(AppDimensions.radiusMd),
            child: InkWell(
              onTap: onTap,
              borderRadius: BorderRadius.circular(AppDimensions.radiusMd),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(AppDimensions.radiusMd),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.10),
                      blurRadius: 10,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: Row(
                  children: [
                    Container(
                      width: 40,
                      height: 40,
                      decoration: BoxDecoration(
                        color: color.withValues(alpha: 0.12),
                        shape: BoxShape.circle,
                      ),
                      child: Icon(icon, color: color, size: 19),
                    ),
                    const SizedBox(width: AppDimensions.spaceMd),
                    Expanded(child: Text(label, style: AppTextStyles.bodyMedium)),
                    const Icon(Icons.chevron_right_rounded, size: 19, color: AppColors.lightTextSecondary),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _aboutTile(int index) {
    final reveal = _reveal(index);
    return FadeTransition(
      opacity: reveal,
      child: SlideTransition(
        position: reveal.drive(Tween(begin: const Offset(-0.25, 0), end: Offset.zero)),
        child: Material(
          color: AppColors.lightSurface,
          borderRadius: BorderRadius.circular(AppDimensions.radiusMd),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(AppDimensions.radiusMd),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.10),
                  blurRadius: 10,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: InkWell(
              onTap: () => Navigator.push(context, AppTransitions.slideFromRight(const AboutScreen())),
              borderRadius: BorderRadius.circular(AppDimensions.radiusMd),
              child: const Padding(
                padding: EdgeInsets.all(2),
                child: Row(
                  children: [
                    Icon(Icons.info_outline_rounded, color: AppColors.primary),
                    SizedBox(width: AppDimensions.spaceMd),
                    Expanded(child: Text('About WC Khata', style: AppTextStyles.bodyMedium)),
                    Icon(Icons.chevron_right_rounded, size: 19, color: AppColors.lightTextSecondary),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
