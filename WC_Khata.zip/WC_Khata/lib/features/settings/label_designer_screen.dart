import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:pdf/widgets.dart' as pw;

import '../../app/theme/app_theme.dart';
import '../../core/services/thermal_printer_service.dart';
import '../../core/widgets/app_glass_icon_button.dart';
import '../../core/widgets/app_message.dart';
import '../../data/repositories/profile_repository.dart';
import '../printer/margin_editor.dart';
import '../printer/printer_gate.dart';
import 'label_sizes.dart';
import 'template_service.dart';

/// Label designer: live preview that never scrolls away, then size, what to
/// show, the text size of every element, barcode height and colour.
/// Pops the saved [DocumentTemplate] (or null when cancelled).
class LabelDesignerScreen extends StatefulWidget {
  final DocumentTemplate template;
  const LabelDesignerScreen({super.key, required this.template});

  @override
  State<LabelDesignerScreen> createState() => _LabelDesignerScreenState();
}

class _LabelDesignerScreenState extends State<LabelDesignerScreen> {
  late DocumentTemplate _t;
  late final TextEditingController _name;
  String _business = 'Business Name';
  bool _busy = false;

  static const _accents = <int>[
    0xFF111827, 0xFF2563EB, 0xFF059669, 0xFFEA580C, 0xFF7C3AED, 0xFFBE123C, 0xFF0F766E, 0xFFB45309,
  ];

  @override
  void initState() {
    super.initState();
    _t = widget.template;
    _name = TextEditingController(text: _t.name);
    ProfileRepository().getOrCreate().then((p) {
      if (!mounted) return;
      final n = p.name?.trim() ?? '';
      if (n.isNotEmpty) setState(() => _business = n);
    });
  }

  @override
  void dispose() {
    _name.dispose();
    super.dispose();
  }

  void _set(DocumentTemplate t) => setState(() => _t = t);

  void _toast(String m) {
    if (!mounted) return;
    AppMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(m)));
  }

  DocumentTemplate _final() => _t.copyWith(name: _name.text.trim().isEmpty ? 'My Label' : _name.text.trim());

  Future<void> _save(bool active) async {
    final t = _final();
    await TemplateService.instance.save(t);
    if (active) await TemplateService.instance.setActive(t);
    if (mounted) Navigator.pop(context, t);
  }

  Future<void> _testPrint() async {
    if (_busy) return;
    if (!await PrinterGate.ensureLabel(context)) return;
    setState(() => _busy = true);
    try {
      final t = _final();
      final doc = pw.Document();
      doc.addPage(LabelPdf.page(template: t, business: _business, product: 'SAMPLE PRODUCT', code: '1234567890', price: 250));
      final bytes = Uint8List.fromList(await doc.save());
      await ThermalPrinterService.instance.printLabelPdf(bytes, widthMm: t.labelWidthMm, heightMm: t.labelHeightMm);
      _toast('Test label sent to the printer.');
    } on PrinterException catch (e) {
      _toast(e.message);
    } catch (_) {
      _toast('Could not print the test label.');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  // ------------------------------------------------------------------- ui

  @override
  Widget build(BuildContext context) {
    final s = (MediaQuery.sizeOf(context).width / 390).clamp(.82, 1.2).toDouble();
    return Scaffold(
      backgroundColor: AppColors.lightBackground,
      body: Column(children: [
        _header(s),
        _previewCard(s),
        Expanded(
          child: ListView(
            padding: EdgeInsets.fromLTRB(12 * s, 4 * s, 12 * s, 14 * s),
            children: [
              _section(s, Icons.straighten_rounded, 'Label size', 'Pick the size of your label roll.', LabelSizePicker(
                widthMm: _t.labelWidthMm,
                heightMm: _t.labelHeightMm,
                onChanged: (w, h) => _set(_t.copyWith(labelWidthMm: w, labelHeightMm: h)),
              )),
              _section(s, Icons.visibility_rounded, 'Show on label', 'Turn each part on or off.', _showSwitches(s)),
              _section(s, Icons.format_size_rounded, 'Text size', 'Set the size of every text. Auto fits the label size.', _textSizes(s)),
              _section(s, Icons.view_week_rounded, 'Barcode', 'Height of the barcode lines.', BarcodeHeightSlider(
                value: _t.barcodeHeightPct,
                onChanged: (v) => _set(_t.copyWith(barcodeHeightPct: v)),
              )),
              _section(s, Icons.crop_free_rounded, 'Margins', 'Empty space between the label edge and the content.', _margins()),
              _section(s, Icons.palette_rounded, 'Name & colour', 'Name of this template and the colour of business name and price.', _nameColour(s)),
            ],
          ),
        ),
        _bottomBar(s),
      ]),
    );
  }

  Widget _header(double s) => SafeArea(
        bottom: false,
        child: Container(
          height: 60 * s,
          padding: EdgeInsets.symmetric(horizontal: 12 * s),
          decoration: const BoxDecoration(color: Colors.white, border: Border(bottom: BorderSide(color: AppColors.lightDivider))),
          child: Row(children: [
            AppGlassIconButton(icon: Icons.arrow_back_rounded, onTap: () => Navigator.pop(context)),
            Expanded(
              child: Column(mainAxisSize: MainAxisSize.min, mainAxisAlignment: MainAxisAlignment.center, children: [
                Text('Label Designer', style: TextStyle(fontSize: 17 * s, fontWeight: FontWeight.w900)),
                Text(_t.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 10.5 * s, color: AppColors.lightTextSecondary, fontWeight: FontWeight.w600)),
              ]),
            ),
            SizedBox(width: 42 * s),
          ]),
        ),
      );

  Widget _previewCard(double s) {
    String n(double v) => v == v.roundToDouble() ? v.toInt().toString() : v.toStringAsFixed(1);
    return Container(
      margin: EdgeInsets.fromLTRB(12 * s, 10 * s, 12 * s, 6 * s),
      padding: EdgeInsets.all(10 * s),
      decoration: BoxDecoration(
        color: const Color(0xFFE9EDF2),
        borderRadius: BorderRadius.circular(18 * s),
        border: Border.all(color: AppColors.lightCardBorder),
      ),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Row(children: [
          Icon(Icons.preview_rounded, size: 16 * s, color: AppColors.primary),
          SizedBox(width: 5 * s),
          Text('Live preview', style: TextStyle(fontSize: 12 * s, fontWeight: FontWeight.w900)),
          const Spacer(),
          Container(
            padding: EdgeInsets.symmetric(horizontal: 9 * s, vertical: 4 * s),
            decoration: BoxDecoration(color: AppColors.primary.withValues(alpha: .10), borderRadius: BorderRadius.circular(99)),
            child: Text('${n(_t.labelWidthMm)} × ${n(_t.labelHeightMm)} mm', style: TextStyle(fontSize: 9.5 * s, fontWeight: FontWeight.w800, color: AppColors.primary)),
          ),
        ]),
        SizedBox(height: 8 * s),
        ConstrainedBox(
          constraints: BoxConstraints(maxHeight: 170 * s),
          child: FittedBox(
            fit: BoxFit.contain,
            child: Container(
              decoration: const BoxDecoration(boxShadow: [BoxShadow(color: Color(0x33000000), blurRadius: 12, offset: Offset(0, 5))]),
              child: LabelPreview(template: _t, business: _business, product: 'SAMPLE PRODUCT', code: '1234567890', price: 250),
            ),
          ),
        ),
      ]),
    );
  }

  Widget _section(double s, IconData icon, String title, String sub, Widget child) => Container(
        margin: EdgeInsets.only(top: 10 * s),
        padding: EdgeInsets.all(13 * s),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18 * s),
          border: Border.all(color: AppColors.lightCardBorder),
          boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: .04), blurRadius: 10 * s, offset: Offset(0, 4 * s))],
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Container(
              width: 32 * s,
              height: 32 * s,
              decoration: BoxDecoration(color: AppColors.primary.withValues(alpha: .10), shape: BoxShape.circle),
              child: Icon(icon, color: AppColors.primary, size: 17 * s),
            ),
            SizedBox(width: 9 * s),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(title, style: TextStyle(fontSize: 14 * s, fontWeight: FontWeight.w900)),
                Text(sub, style: TextStyle(fontSize: 10.5 * s, color: AppColors.lightTextSecondary)),
              ]),
            ),
          ]),
          SizedBox(height: 11 * s),
          child,
        ]),
      );

  Widget _switchRow(double s, String label, bool value, ValueChanged<bool> onChanged) => Container(
        margin: EdgeInsets.only(bottom: 6 * s),
        padding: EdgeInsets.symmetric(horizontal: 12 * s),
        decoration: BoxDecoration(color: AppColors.lightBackground, borderRadius: BorderRadius.circular(13 * s)),
        child: Row(children: [
          Expanded(child: Text(label, style: TextStyle(fontSize: 12.5 * s, fontWeight: FontWeight.w800))),
          Switch.adaptive(value: value, activeColor: AppColors.primary, onChanged: onChanged),
        ]),
      );

  Widget _showSwitches(double s) => Column(children: [
        _switchRow(s, 'Business name', _t.showLabelBusiness, (v) => _set(_t.copyWith(showLabelBusiness: v))),
        _switchRow(s, 'Product name', _t.showLabelProduct, (v) => _set(_t.copyWith(showLabelProduct: v))),
        _switchRow(s, 'Barcode', _t.showLabelBarcode, (v) => _set(_t.copyWith(showLabelBarcode: v))),
        _switchRow(s, 'Barcode number', _t.showLabelBarcode && _t.showLabelCode, _t.showLabelBarcode ? (v) => _set(_t.copyWith(showLabelCode: v)) : (_) {}),
        _switchRow(s, 'Price', _t.showLabelPrice, (v) => _set(_t.copyWith(showLabelPrice: v))),
      ]);

  Widget _margins() {
    final m = LabelMargins.of(_t);
    return MarginEditor(
      left: m.left,
      right: m.right,
      top: m.top,
      bottom: m.bottom,
      maxSide: LabelMargins.maxSide(_t.labelWidthMm),
      maxVertical: LabelMargins.maxVertical(_t.labelHeightMm),
      onChanged: (l, r, t, b) => _set(_t.copyWith(labelMarginL: l, labelMarginR: r, labelMarginT: t, labelMarginB: b)),
      resetLabel: 'Auto',
      onReset: m.isAuto ? null : () => _set(_t.copyWith(labelMarginL: -1, labelMarginR: -1, labelMarginT: -1, labelMarginB: -1)),
      caption: m.isAuto
          ? 'Automatic: margins fit the label size. Change any value to set your own.'
          : 'Custom margins. Tap Auto to go back to automatic.',
    );
  }

  Widget _textSizes(double s) {
    final w = _t.labelWidthMm, h = _t.labelHeightMm;
    final f = LabelFonts.of(_t);
    return Column(children: [
      _sizeRow(s, 'Business name', Icons.storefront_rounded, _t.showLabelBusiness, _t.labelBusinessFs, f.business, LabelFonts.autoBusiness(w, h), (v) => _set(_t.copyWith(labelBusinessFs: v))),
      _sizeRow(s, 'Product name', Icons.inventory_2_rounded, _t.showLabelProduct, _t.labelProductFs, f.product, LabelFonts.autoProduct(w, h), (v) => _set(_t.copyWith(labelProductFs: v))),
      _sizeRow(s, 'Barcode number', Icons.pin_rounded, _t.showLabelBarcode && _t.showLabelCode, _t.labelCodeFs, f.code, LabelFonts.autoCode(w, h), (v) => _set(_t.copyWith(labelCodeFs: v))),
      _sizeRow(s, 'Price', Icons.sell_rounded, _t.showLabelPrice, _t.labelPriceFs, f.price, LabelFonts.autoPrice(w, h), (v) => _set(_t.copyWith(labelPriceFs: v))),
    ]);
  }

  /// [stored] 0 = auto. [shown] is the size currently used. Minus / plus move
  /// in 0.5 pt steps from the shown size.
  Widget _sizeRow(double s, String label, IconData icon, bool enabled, double stored, double shown, double auto, ValueChanged<double> onChanged) {
    final isAuto = stored <= 0;
    final value = shown.clamp(LabelFonts.minPt, LabelFonts.maxPt).toDouble();
    String pt(double v) => v == v.roundToDouble() ? v.toInt().toString() : v.toStringAsFixed(1);
    return Opacity(
      opacity: enabled ? 1 : .4,
      child: IgnorePointer(
        ignoring: !enabled,
        child: Container(
          margin: EdgeInsets.only(bottom: 8 * s),
          padding: EdgeInsets.fromLTRB(12 * s, 8 * s, 8 * s, 2 * s),
          decoration: BoxDecoration(color: AppColors.lightBackground, borderRadius: BorderRadius.circular(14 * s)),
          child: Column(children: [
            Row(children: [
              Icon(icon, size: 16 * s, color: AppColors.primary),
              SizedBox(width: 7 * s),
              Expanded(child: Text(label, style: TextStyle(fontSize: 12.5 * s, fontWeight: FontWeight.w800))),
              _stepper(s, Icons.remove_rounded, () => onChanged((value - .5).clamp(LabelFonts.minPt, LabelFonts.maxPt).toDouble())),
              Container(
                width: 62 * s,
                alignment: Alignment.center,
                child: Text(isAuto ? 'Auto ${pt(value)}' : '${pt(value)} pt', style: TextStyle(fontSize: 11.5 * s, fontWeight: FontWeight.w900, color: AppColors.primary)),
              ),
              _stepper(s, Icons.add_rounded, () => onChanged((value + .5).clamp(LabelFonts.minPt, LabelFonts.maxPt).toDouble())),
            ]),
            SliderTheme(
              data: SliderTheme.of(context).copyWith(trackHeight: 4, thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 9)),
              child: Slider(
                value: value,
                min: LabelFonts.minPt,
                max: LabelFonts.maxPt,
                divisions: ((LabelFonts.maxPt - LabelFonts.minPt) * 2).round(),
                activeColor: AppColors.primary,
                onChanged: (v) => onChanged((v * 2).round() / 2),
              ),
            ),
            Align(
              alignment: Alignment.centerRight,
              child: TextButton(
                onPressed: isAuto ? null : () => onChanged(0),
                style: TextButton.styleFrom(padding: EdgeInsets.symmetric(horizontal: 8 * s), minimumSize: Size(0, 26 * s), tapTargetSize: MaterialTapTargetSize.shrinkWrap),
                child: Text('Reset to Auto (${pt(auto)} pt)', style: TextStyle(fontSize: 10.5 * s, fontWeight: FontWeight.w800)),
              ),
            ),
          ]),
        ),
      ),
    );
  }

  Widget _stepper(double s, IconData icon, VoidCallback onTap) => InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(9 * s),
        child: Container(
          width: 30 * s,
          height: 30 * s,
          decoration: BoxDecoration(color: AppColors.primary.withValues(alpha: .10), borderRadius: BorderRadius.circular(9 * s)),
          child: Icon(icon, size: 18 * s, color: AppColors.primary),
        ),
      );

  Widget _nameColour(double s) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        TextField(
          controller: _name,
          textCapitalization: TextCapitalization.words,
          style: TextStyle(fontSize: 13 * s, fontWeight: FontWeight.w800),
          decoration: InputDecoration(
            labelText: 'Template name',
            filled: true,
            fillColor: AppColors.lightBackground,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(13 * s), borderSide: BorderSide.none),
          ),
        ),
        SizedBox(height: 12 * s),
        Wrap(spacing: 9 * s, runSpacing: 9 * s, children: [
          for (final c in _accents)
            GestureDetector(
              onTap: () => _set(_t.copyWith(accent: c)),
              child: Container(
                width: 34 * s,
                height: 34 * s,
                decoration: BoxDecoration(
                  color: Color(c),
                  shape: BoxShape.circle,
                  border: Border.all(color: _t.accent == c ? AppColors.primary : Colors.transparent, width: 3),
                ),
                child: _t.accent == c ? Icon(Icons.check_rounded, color: Colors.white, size: 17 * s) : null,
              ),
            ),
        ]),
      ]);

  Widget _bottomBar(double s) => Container(
        padding: EdgeInsets.fromLTRB(12 * s, 8 * s, 12 * s, 10 * s),
        decoration: const BoxDecoration(color: Colors.white, border: Border(top: BorderSide(color: AppColors.lightDivider))),
        child: SafeArea(
          top: false,
          child: Row(children: [
            SizedBox(
              height: 46 * s,
              child: OutlinedButton.icon(
                onPressed: _busy ? null : _testPrint,
                icon: Icon(Icons.print_rounded, size: 18 * s),
                label: Text(_busy ? 'Printing...' : 'Test', style: TextStyle(fontSize: 11.5 * s, fontWeight: FontWeight.w900)),
                style: OutlinedButton.styleFrom(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(13 * s))),
              ),
            ),
            SizedBox(width: 8 * s),
            Expanded(
              child: SizedBox(
                height: 46 * s,
                child: FilledButton(
                  onPressed: () => _save(false),
                  style: FilledButton.styleFrom(backgroundColor: Colors.black, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(13 * s))),
                  child: Text('Save', style: TextStyle(fontSize: 12 * s, fontWeight: FontWeight.w900)),
                ),
              ),
            ),
            SizedBox(width: 8 * s),
            Expanded(
              flex: 2,
              child: SizedBox(
                height: 46 * s,
                child: FilledButton(
                  onPressed: () => _save(true),
                  style: FilledButton.styleFrom(backgroundColor: const Color(0xFF15803D), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(13 * s))),
                  child: Text('Save & Use This Label', style: TextStyle(fontSize: 12 * s, fontWeight: FontWeight.w900)),
                ),
              ),
            ),
          ]),
        ),
      );
}
