import 'package:flutter/material.dart';

import '../../app/theme/app_theme.dart';
import '../../core/services/sale_flow_service.dart';
import '../../core/widgets/modern_header.dart';

/// Settings > Soft Settings: what happens right after a sale is submitted.
///
/// Three toggles, only one can be on. All off = the normal behaviour (the bill
/// preview opens and nothing is printed by itself).
class SoftSettingsScreen extends StatefulWidget {
  const SoftSettingsScreen({super.key});

  @override
  State<SoftSettingsScreen> createState() => _SoftSettingsScreenState();
}

class _SoftSettingsScreenState extends State<SoftSettingsScreen> {
  final _flow = SaleFlowService.instance;

  @override
  void initState() {
    super.initState();
    _flow.addListener(_changed);
    _flow.load();
  }

  @override
  void dispose() {
    _flow.removeListener(_changed);
    super.dispose();
  }

  void _changed() {
    if (mounted) setState(() {});
  }

  Widget _tile(SaleFlowMode mode, IconData icon, String title, String sub) {
    final on = _flow.mode == mode;
    return Container(
      margin: const EdgeInsets.only(bottom: AppDimensions.spaceSm),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: AppColors.lightSurface,
        borderRadius: BorderRadius.circular(AppDimensions.radiusMd),
        border: Border.all(color: on ? AppColors.primary : Colors.transparent, width: 1.4),
        boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: .10), blurRadius: 10, offset: const Offset(0, 4))],
      ),
      child: Row(children: [
        Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(color: AppColors.primary.withValues(alpha: .12), shape: BoxShape.circle),
          child: Icon(icon, color: AppColors.primary, size: 19),
        ),
        const SizedBox(width: AppDimensions.spaceMd),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: AppTextStyles.bodyMedium),
            const SizedBox(height: 2),
            Text(sub, style: AppTextStyles.caption),
          ]),
        ),
        Switch.adaptive(
          value: on,
          activeColor: AppColors.primary,
          // Turning one on turns the others off; turning it off = all off.
          onChanged: (v) => _flow.setMode(v ? mode : SaleFlowMode.normal),
        ),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.lightBackground,
      body: Column(children: [
        ModernHeader(title: 'Soft Settings', onBack: () => Navigator.pop(context)),
        Expanded(
          child: ListView(
            padding: const EdgeInsets.all(AppDimensions.spaceMd),
            children: [
              const Padding(
                padding: EdgeInsets.fromLTRB(4, 0, 4, 10),
                child: Text(
                  'What should happen when a sale is submitted? Only one option can be on. '
                  'With all of them off, the bill preview opens and nothing is printed automatically.',
                  style: AppTextStyles.caption,
                ),
              ),
              _tile(
                SaleFlowMode.printThenPreview,
                Icons.print_rounded,
                'Print, then open bill',
                'Prints the receipt directly, then shows the bill preview.',
              ),
              _tile(
                SaleFlowMode.printThenNewSale,
                Icons.point_of_sale_rounded,
                'Print, then new sale',
                'Prints the receipt directly, then returns to a fresh New Sale screen.',
              ),
              _tile(
                SaleFlowMode.newSaleOnly,
                Icons.add_shopping_cart_rounded,
                'New sale only (no print)',
                'Returns to a fresh New Sale screen. No bill is opened and nothing is printed.',
              ),
            ],
          ),
        ),
      ]),
    );
  }
}
