import 'dart:typed_data';
import 'package:flutter/material.dart';
import '../../app/theme/app_theme.dart';
import '../../core/widgets/app_bottom_sheet.dart';
import '../../core/widgets/modern_header.dart';
import '../../data/models/profile_model.dart';
import '../../data/repositories/profile_repository.dart';
import '../profile/profile_screen.dart';
import 'business_card/card_export.dart';
import 'business_card/card_models.dart';
import 'business_card/card_renderer.dart';
import '../printer/printer_gate.dart';
import '../../core/services/thermal_printer_service.dart';
import '../../core/widgets/app_message.dart';

/// Business card templates (gallery). Tap a card to preview, customise and
/// download it.
class BusinessCardSettingsScreen extends StatefulWidget {
  const BusinessCardSettingsScreen({super.key});

  @override
  State<BusinessCardSettingsScreen> createState() => _BusinessCardSettingsScreenState();
}

Future<void> _openProfile(BuildContext context) {
  return Navigator.push(
    context,
    MaterialPageRoute(builder: (ctx) => ProfileScreen(onBack: () => Navigator.pop(ctx))),
  );
}

bool _profileIncomplete(ProfileModel p) {
  bool empty(String? v) => v == null || v.trim().isEmpty;
  return empty(p.name) || empty(p.ownerName) || empty(p.phone);
}

class _BusinessCardSettingsScreenState extends State<BusinessCardSettingsScreen> {
  final _repo = ProfileRepository();
  final _search = TextEditingController();
  ProfileModel? _profile;
  BcOptions _options = BcOptions();
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final profile = await _repo.getOrCreate();
    final options = await BcOptions.load();
    await bcEvictLogo(profile);
    if (!mounted) return;
    setState(() {
      _profile = profile;
      _options = options;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final query = _search.text.trim().toLowerCase();
    final items = kBcTemplates
        .where((t) => t.name.toLowerCase().contains(query) || t.subtitle.toLowerCase().contains(query))
        .toList();

    return Scaffold(
      backgroundColor: AppColors.lightBackground,
      body: Column(
        children: [
          ModernHeader(title: 'Business Card', onBack: () => Navigator.maybePop(context)),
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 12, 14, 8),
            child: TextField(
              controller: _search,
              onChanged: (_) => setState(() {}),
              decoration: InputDecoration(
                hintText: 'Search business card designs...',
                prefixIcon: const Icon(Icons.search_rounded),
                filled: true,
                fillColor: Colors.white,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: BorderSide(color: AppColors.lightCardBorder),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: BorderSide(color: AppColors.lightCardBorder),
                ),
              ),
            ),
          ),
          if (!_loading && _profile != null && _profileIncomplete(_profile!))
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 0, 14, 8),
              child: _ProfileHint(
                onTap: () async {
                  await _openProfile(context);
                  if (mounted) _load();
                },
              ),
            ),
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : items.isEmpty
                    ? const Center(child: Text('No designs found'))
                    : ListView.separated(
                        padding: const EdgeInsets.fromLTRB(14, 6, 14, 24),
                        itemCount: items.length,
                        separatorBuilder: (_, __) => const SizedBox(height: 22),
                        itemBuilder: (_, i) => _tile(items[i]),
                      ),
          ),
        ],
      ),
    );
  }

  Widget _tile(BcTemplate t) {
    final data = BcData.from(_profile!, _options);
    final accent = data.accent ?? t.accent;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        GestureDetector(
          onTap: () => _openPreview(t),
          child: BcPreview(template: t, data: data),
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(t.name, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 2),
                  Text(t.subtitle, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11.5, color: Colors.grey)),
                ],
              ),
            ),
            const SizedBox(width: 10),
            ElevatedButton(
              onPressed: () => _openPreview(t),
              style: ElevatedButton.styleFrom(
                backgroundColor: accent,
                foregroundColor: accent.computeLuminance() > .55 ? Colors.black : Colors.white,
                elevation: 0,
                padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 11),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              child: const Text('Use Design', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w900)),
            ),
          ],
        ),
      ],
    );
  }

  Future<void> _openPreview(BcTemplate t) async {
    await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => BusinessCardPreviewScreen(template: t)),
    );
    if (mounted) _load();
  }
}

class _ProfileHint extends StatelessWidget {
  final VoidCallback onTap;
  const _ProfileHint({required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppColors.primary.withValues(alpha: .08),
      borderRadius: BorderRadius.circular(14),
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          child: Row(
            children: [
              const Icon(Icons.info_outline_rounded, color: AppColors.primary, size: 20),
              const SizedBox(width: 10),
              const Expanded(
                child: Text(
                  'Add your business name, owner name and mobile number in Profile for a complete card.',
                  style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600),
                ),
              ),
              const SizedBox(width: 6),
              Text('Edit Profile', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w900, color: AppColors.primaryDark)),
            ],
          ),
        ),
      ),
    );
  }
}

// ===========================================================================
// Preview: front + back, download / print / share
// ===========================================================================

class BusinessCardPreviewScreen extends StatefulWidget {
  final BcTemplate template;
  const BusinessCardPreviewScreen({super.key, required this.template});

  @override
  State<BusinessCardPreviewScreen> createState() => _BusinessCardPreviewScreenState();
}

class _BusinessCardPreviewScreenState extends State<BusinessCardPreviewScreen> {
  final _repo = ProfileRepository();
  final _frontKey = GlobalKey();
  final _backKey = GlobalKey();
  ProfileModel? _profile;
  BcOptions _options = BcOptions();
  bool _loading = true;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final profile = await _repo.getOrCreate();
    final options = await BcOptions.load();
    await bcEvictLogo(profile);
    if (!mounted) return;
    setState(() {
      _profile = profile;
      _options = options;
      _loading = false;
    });
  }

  Future<void> _customize() async {
    final result = await Navigator.push<BcOptions>(
      context,
      MaterialPageRoute(
        builder: (_) => BusinessCardCustomizeScreen(template: widget.template, options: _options.copy()),
      ),
    );
    // Profile may have been edited from the customise screen too.
    await _load();
    if (result == null || !mounted) return;
    setState(() => _options = result);
  }

  Future<T?> _guard<T>(Future<T> Function() job, String error) async {
    if (_busy) return null;
    setState(() => _busy = true);
    try {
      return await job();
    } on PrinterException catch (e) {
      _message(e.message);
      return null;
    } catch (_) {
      _message(error);
      return null;
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  String get _safeName => widget.template.name.replaceAll(RegExp(r'[^a-zA-Z0-9_-]+'), '_');

  Future<void> _download() async {
    await showAppBottomSheet(
      context: context,
      builder: (ctx) => Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          ListTile(
            leading: const Icon(Icons.picture_as_pdf_rounded, color: AppColors.expense),
            title: const Text('PDF  (Front + Back)', style: TextStyle(fontWeight: FontWeight.w800)),
            subtitle: const Text('Print-ready, 3.5 x 2 in'),
            onTap: () {
              Navigator.pop(ctx);
              _savePdf();
            },
          ),
          ListTile(
            leading: const Icon(Icons.image_rounded, color: AppColors.primary),
            title: const Text('Image  (Front, PNG)', style: TextStyle(fontWeight: FontWeight.w800)),
            subtitle: const Text('High quality image'),
            onTap: () {
              Navigator.pop(ctx);
              _savePng(front: true);
            },
          ),
          ListTile(
            leading: const Icon(Icons.flip_rounded, color: AppColors.primary),
            title: const Text('Image  (Back, PNG)', style: TextStyle(fontWeight: FontWeight.w800)),
            subtitle: const Text('Contact details and QR code'),
            onTap: () {
              Navigator.pop(ctx);
              _savePng(front: false);
            },
          ),
        ],
      ),
    );
  }

  Future<void> _savePdf() async {
    final saved = await _guard<bool>(() async {
      final front = await BcExport.capturePng(_frontKey);
      final back = await BcExport.capturePng(_backKey);
      final pdf = await BcExport.buildPdf(front, back);
      return BcExport.save(bytes: pdf, fileName: 'WCKhata_${_safeName}_BusinessCard', extension: 'pdf');
    }, 'Unable to save business card.');
    if (saved == null) return;
    _message(saved ? 'Business card saved successfully.' : 'Save cancelled.');
  }

  Future<void> _savePng({required bool front}) async {
    final saved = await _guard<bool>(() async {
      final bytes = await BcExport.capturePng(front ? _frontKey : _backKey);
      return BcExport.save(
        bytes: bytes,
        fileName: 'WCKhata_${_safeName}_${front ? 'Front' : 'Back'}',
        extension: 'png',
      );
    }, 'Unable to save business card.');
    if (saved == null) return;
    _message(saved ? 'Business card saved successfully.' : 'Save cancelled.');
  }

  Future<void> _print() async {
    if (!await PrinterGate.ensure(context)) return;
    await _guard<void>(() async {
      final front = await BcExport.capturePng(_frontKey);
      final back = await BcExport.capturePng(_backKey);
      final Uint8List pdf = await BcExport.buildPdf(front, back);
      await BcExport.printPdf(pdf);
      _message('Business card sent to the printer.');
    }, 'Unable to print business card.');
  }

  Future<void> _share() async {
    await _guard<void>(() async {
      final front = await BcExport.capturePng(_frontKey);
      final back = await BcExport.capturePng(_backKey);
      await BcExport.shareImages(front, back);
    }, 'Unable to share business card.');
  }

  void _message(String message) {
    if (!mounted) return;
    AppMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    final t = widget.template;
    return Scaffold(
      backgroundColor: AppColors.lightBackground,
      body: Column(
        children: [
          ModernHeader(title: 'Card Preview', onBack: () => Navigator.maybePop(context)),
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : _body(t),
          ),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(14, 6, 14, 12),
              child: Column(
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: _busy ? null : _customize,
                          icon: const Icon(Icons.tune_rounded),
                          label: const Text('Customize'),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: _busy ? null : _download,
                          icon: _busy
                              ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                              : const Icon(Icons.download_rounded),
                          label: Text(_busy ? 'Please wait...' : 'Download'),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: _busy ? null : _print,
                          icon: const Icon(Icons.print_rounded),
                          label: const Text('Print'),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: _busy ? null : _share,
                          icon: const Icon(Icons.share_rounded),
                          label: const Text('Share'),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _body(BcTemplate t) {
    final data = BcData.from(_profile!, _options);
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 12),
      children: [
        _sideLabel('FRONT'),
        BcPreview(template: t, data: data, captureKey: _frontKey),
        const SizedBox(height: 20),
        _sideLabel('BACK'),
        BcPreview(template: t, data: data, back: true, captureKey: _backKey),
        const SizedBox(height: 16),
        Center(child: Text(t.name, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900))),
        const SizedBox(height: 3),
        Center(child: Text(t.subtitle, style: const TextStyle(color: Colors.grey, fontSize: 12))),
        if (_profileIncomplete(_profile!)) ...[
          const SizedBox(height: 14),
          _ProfileHint(
            onTap: () async {
              await _openProfile(context);
              if (mounted) _load();
            },
          ),
        ],
      ],
    );
  }

  Widget _sideLabel(String text) => Padding(
        padding: const EdgeInsets.only(left: 4, bottom: 8),
        child: Text(text, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w900, letterSpacing: 1.6, color: Colors.grey)),
      );
}

// ===========================================================================
// Customize: what to show + accent colour, with live preview
// ===========================================================================

class BusinessCardCustomizeScreen extends StatefulWidget {
  final BcTemplate template;
  final BcOptions options;
  const BusinessCardCustomizeScreen({super.key, required this.template, required this.options});

  @override
  State<BusinessCardCustomizeScreen> createState() => _BusinessCardCustomizeScreenState();
}

class _BusinessCardCustomizeScreenState extends State<BusinessCardCustomizeScreen> {
  final _repo = ProfileRepository();
  late BcOptions _o;
  ProfileModel? _profile;
  bool _showBack = false;

  @override
  void initState() {
    super.initState();
    _o = widget.options;
    _loadProfile();
  }

  Future<void> _loadProfile() async {
    final p = await _repo.getOrCreate();
    if (!mounted) return;
    setState(() => _profile = p);
  }

  Future<void> _save() async {
    await _o.save();
    if (mounted) Navigator.pop(context, _o);
  }

  String? _valueFor(String key) {
    final p = _profile;
    if (p == null) return null;
    switch (key) {
      case 'business':
        return p.name;
      case 'owner':
        return p.ownerName;
      case 'title':
        return p.designation;
      case 'tagline':
        return p.tagline;
      case 'phone':
        return p.phone;
      case 'whatsapp':
        return p.whatsapp;
      case 'email':
        return p.email;
      case 'website':
        return p.website;
      case 'address':
        return p.address;
      default:
        return null;
    }
  }

  @override
  Widget build(BuildContext context) {
    final t = widget.template;
    final profile = _profile;
    final data = profile == null ? null : BcData.from(profile, _o);
    final accent = _o.accent > 0 ? kBcAccents[_o.accent - 1] : t.accent;

    return Scaffold(
      backgroundColor: AppColors.lightBackground,
      body: Column(
        children: [
          ModernHeader(title: 'Customize Card', onBack: () => Navigator.maybePop(context)),
          if (data != null)
            Container(
              color: AppColors.lightBackground,
              padding: const EdgeInsets.fromLTRB(40, 14, 40, 8),
              child: Column(
                children: [
                  BcPreview(template: t, data: data, back: _showBack),
                  const SizedBox(height: 10),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      ChoiceChip(label: const Text('Front'), selected: !_showBack, onSelected: (_) => setState(() => _showBack = false)),
                      const SizedBox(width: 8),
                      ChoiceChip(label: const Text('Back'), selected: _showBack, onSelected: (_) => setState(() => _showBack = true)),
                    ],
                  ),
                ],
              ),
            ),
          Expanded(
            child: profile == null
                ? const Center(child: CircularProgressIndicator())
                : ListView(
                    padding: const EdgeInsets.fromLTRB(14, 6, 14, 14),
                    children: [
                      _heading('Accent colour'),
                      _accentPicker(t),
                      const SizedBox(height: 14),
                      _heading('Front'),
                      _option('logo', 'Logo / Photo', Icons.image_rounded, accent, always: true, hint: 'Uses your Profile photo'),
                      _option('business', 'Business Name', Icons.business_rounded, accent),
                      _option('owner', 'Administrator / Owner Name', Icons.person_rounded, accent),
                      _option('title', 'Designation', Icons.badge_rounded, accent),
                      _option('tagline', 'Tagline', Icons.auto_awesome_rounded, accent),
                      const SizedBox(height: 10),
                      _heading('Contact details'),
                      _option('phone', 'Mobile Number', Icons.phone_rounded, accent),
                      _option('whatsapp', 'WhatsApp Number', Icons.chat_rounded, accent),
                      _option('email', 'Email', Icons.email_rounded, accent),
                      _option('website', 'Website', Icons.language_rounded, accent),
                      _option('address', 'Address', Icons.location_on_rounded, accent),
                      const SizedBox(height: 10),
                      _heading('Back'),
                      _option('qr', 'QR Code (scan to save contact)', Icons.qr_code_2_rounded, accent, always: true, hint: 'Saves your visible details as a contact'),
                      const SizedBox(height: 6),
                      OutlinedButton.icon(
                        onPressed: () async {
                          await _openProfile(context);
                          if (mounted) _loadProfile();
                        },
                        icon: const Icon(Icons.edit_rounded),
                        label: const Text('Edit details in Profile'),
                      ),
                    ],
                  ),
          ),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(14, 6, 14, 12),
              child: Row(
                children: [
                  Expanded(child: OutlinedButton(onPressed: () => Navigator.maybePop(context), child: const Text('Cancel'))),
                  const SizedBox(width: 8),
                  Expanded(child: ElevatedButton(onPressed: _save, child: const Text('Save'))),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _heading(String text) => Padding(
        padding: const EdgeInsets.fromLTRB(4, 6, 4, 8),
        child: Text(text, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w900)),
      );

  Widget _accentPicker(BcTemplate t) {
    Widget swatch({required int index, required Color color, Widget? child}) {
      final selected = _o.accent == index;
      return GestureDetector(
        onTap: () => setState(() => _o.accent = index),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 150),
          width: 38,
          height: 38,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: color,
            border: Border.all(color: selected ? AppColors.lightTextPrimary : Colors.white, width: selected ? 2.5 : 2),
            boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: .12), blurRadius: 6, offset: const Offset(0, 2))],
          ),
          child: selected ? const Icon(Icons.check_rounded, color: Colors.white, size: 20) : child,
        ),
      );
    }

    return Wrap(
      spacing: 10,
      runSpacing: 10,
      children: [
        swatch(
          index: 0,
          color: t.accent,
          child: const Icon(Icons.auto_fix_high_rounded, color: Colors.white, size: 17),
        ),
        for (var i = 0; i < kBcAccents.length; i++) swatch(index: i + 1, color: kBcAccents[i]),
      ],
    );
  }

  Widget _option(String key, String title, IconData icon, Color accent, {bool always = false, String? hint}) {
    final value = _valueFor(key);
    final hasValue = always || (value != null && value.trim().isNotEmpty);
    // Business and owner always have a placeholder so they stay switchable.
    final switchable = hasValue || key == 'business' || key == 'owner';
    final subtitle = hint ?? ((value != null && value.trim().isNotEmpty) ? value.trim() : 'Not added yet - add it in Profile');
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14), side: BorderSide(color: AppColors.lightCardBorder)),
      child: SwitchListTile(
        value: _o.on(key) && switchable,
        onChanged: switchable ? (v) => setState(() => _o.show[key] = v) : null,
        secondary: Icon(icon, color: switchable ? accent : Colors.grey),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
        subtitle: Text(subtitle, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11.5)),
      ),
    );
  }
}
