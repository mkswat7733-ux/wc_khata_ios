import 'dart:io';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../../data/models/profile_model.dart';

/// Logical card size (3.5 x 2 inch ratio). The card is always laid out at
/// this exact size and then scaled, so the preview, PNG and PDF are
/// pixel-identical.
const double kCardW = 350;
const double kCardH = 200;

enum BcArt { aurora, gold, ivory, corner, wave, glass, neon, pastel, mono, navy, design }

enum BcLayout { left, center, split, minimal, glass, banner, salford, rimberio, seagull, liceria, arowwai, borcelle }

class BcTemplate {
  final String id;
  final String name;
  final String subtitle;
  final List<Color> gradient;
  final Color fg;
  final Color accent;
  final bool dark;
  final BcArt art;
  final BcLayout layout;

  const BcTemplate({
    required this.id,
    required this.name,
    required this.subtitle,
    required this.gradient,
    required this.fg,
    required this.accent,
    required this.dark,
    required this.art,
    required this.layout,
  });
}

const kBcTemplates = <BcTemplate>[
  BcTemplate(
    id: 'bc_aurora',
    name: 'Aurora',
    subtitle: 'Deep night glow with soft light orbs',
    gradient: [Color(0xFF0A0E2A), Color(0xFF1B1B5E)],
    fg: Colors.white,
    accent: Color(0xFF5EEAD4),
    dark: true,
    art: BcArt.aurora,
    layout: BcLayout.left,
  ),
  BcTemplate(
    id: 'bc_obsidian',
    name: 'Obsidian Gold',
    subtitle: 'Black and gold luxury frame',
    gradient: [Color(0xFF0B0B0D), Color(0xFF1E1B14)],
    fg: Colors.white,
    accent: Color(0xFFD4AF37),
    dark: true,
    art: BcArt.gold,
    layout: BcLayout.center,
  ),
  BcTemplate(
    id: 'bc_ivory',
    name: 'Ivory Minimal',
    subtitle: 'Clean, airy and elegant',
    gradient: [Color(0xFFFFFDF8), Color(0xFFF5F0E6)],
    fg: Color(0xFF1B2433),
    accent: Color(0xFF0F766E),
    dark: false,
    art: BcArt.ivory,
    layout: BcLayout.minimal,
  ),
  BcTemplate(
    id: 'bc_split',
    name: 'Split Modern',
    subtitle: 'Bold colour panel with crisp details',
    gradient: [Color(0xFFFFFFFF), Color(0xFFF1F5FF)],
    fg: Color(0xFF111827),
    accent: Color(0xFF2F6FED),
    dark: false,
    art: BcArt.corner,
    layout: BcLayout.split,
  ),
  BcTemplate(
    id: 'bc_emerald',
    name: 'Emerald Wave',
    subtitle: 'Fresh gradient with flowing waves',
    gradient: [Color(0xFF064E3B), Color(0xFF0F9D75)],
    fg: Colors.white,
    accent: Color(0xFFFDE68A),
    dark: true,
    art: BcArt.wave,
    layout: BcLayout.left,
  ),
  BcTemplate(
    id: 'bc_sunset',
    name: 'Sunset Glass',
    subtitle: 'Vibrant gradient with frosted glass',
    gradient: [Color(0xFFFF7A59), Color(0xFFE11D74), Color(0xFF5B21B6)],
    fg: Colors.white,
    accent: Color(0xFFFFE08A),
    dark: true,
    art: BcArt.glass,
    layout: BcLayout.glass,
  ),
  BcTemplate(
    id: 'bc_navy',
    name: 'Royal Navy',
    subtitle: 'Corporate navy with a gold header',
    gradient: [Color(0xFF0A2540), Color(0xFF123A6B)],
    fg: Colors.white,
    accent: Color(0xFFF5B83D),
    dark: true,
    art: BcArt.navy,
    layout: BcLayout.banner,
  ),
  BcTemplate(
    id: 'bc_neon',
    name: 'Neon Night',
    subtitle: 'Glowing neon outline on black',
    gradient: [Color(0xFF05050A), Color(0xFF0D0B1F)],
    fg: Colors.white,
    accent: Color(0xFFFF2E93),
    dark: true,
    art: BcArt.neon,
    layout: BcLayout.left,
  ),
  BcTemplate(
    id: 'bc_rose',
    name: 'Rose Studio',
    subtitle: 'Soft pastel with graceful circles',
    gradient: [Color(0xFFFFF3F6), Color(0xFFFFDCE6)],
    fg: Color(0xFF3B0A1D),
    accent: Color(0xFFE11D48),
    dark: false,
    art: BcArt.pastel,
    layout: BcLayout.center,
  ),
  BcTemplate(
    id: 'bc_mono',
    name: 'Mono Bold',
    subtitle: 'High-contrast with a bold orange header',
    gradient: [Color(0xFFFFFFFF), Color(0xFFF4F4F5)],
    fg: Color(0xFF0A0A0A),
    accent: Color(0xFFFF5A1F),
    dark: false,
    art: BcArt.mono,
    layout: BcLayout.banner,
  ),
  // -------------------------------------------------------------------------
  // Designed templates (front + back drawn like the supplied artwork).
  // Your logo replaces the sample logo on both sides.
  // -------------------------------------------------------------------------
  BcTemplate(
    id: 'bc_salford',
    name: 'Salford Navy',
    subtitle: 'Navy panel with golden waves',
    gradient: [Color(0xFFFFFFFF), Color(0xFFFFFFFF)],
    fg: Color(0xFF0B3050),
    accent: Color(0xFFF7941D),
    dark: false,
    art: BcArt.design,
    layout: BcLayout.salford,
  ),
  BcTemplate(
    id: 'bc_rimberio',
    name: 'Rimberio Black Gold',
    subtitle: 'Black diamond layers with gold swirl',
    gradient: [Color(0xFF0B0D10), Color(0xFF0B0D10)],
    fg: Colors.white,
    accent: Color(0xFFFFC700),
    dark: true,
    art: BcArt.design,
    layout: BcLayout.rimberio,
  ),
  BcTemplate(
    id: 'bc_seagull',
    name: 'Seagull Gold',
    subtitle: 'White card with blue and gold corners',
    gradient: [Color(0xFFFFFFFF), Color(0xFFFFFFFF)],
    fg: Color(0xFF111111),
    accent: Color(0xFFD4A82A),
    dark: false,
    art: BcArt.design,
    layout: BcLayout.seagull,
  ),
  BcTemplate(
    id: 'bc_liceria',
    name: 'Liceria Builder',
    subtitle: 'Navy bars with a bold yellow roof',
    gradient: [Color(0xFFFFFFFF), Color(0xFFFFFFFF)],
    fg: Color(0xFF0B1445),
    accent: Color(0xFFF5B800),
    dark: false,
    art: BcArt.design,
    layout: BcLayout.liceria,
  ),
  BcTemplate(
    id: 'bc_arowwai',
    name: 'Arowwai Amber',
    subtitle: 'Dark brown geometric with amber corners',
    gradient: [Color(0xFF2B1804), Color(0xFF2B1804)],
    fg: Color(0xFFFFC21A),
    accent: Color(0xFFFFB800),
    dark: true,
    art: BcArt.design,
    layout: BcLayout.arowwai,
  ),
  BcTemplate(
    id: 'bc_borcelle',
    name: 'Borcelle Maroon',
    subtitle: 'Maroon and gold ribbons with a ring',
    gradient: [Color(0xFFFFFFFF), Color(0xFFFFFFFF)],
    fg: Color(0xFF4A0E0A),
    accent: Color(0xFFC9A24B),
    dark: false,
    art: BcArt.design,
    layout: BcLayout.borcelle,
  ),
];

/// Accent colour choices. Index 0 in [BcOptions.accent] means "template
/// default"; 1..n map to this list.
const kBcAccents = <Color>[
  Color(0xFF2F6FED),
  Color(0xFF10B981),
  Color(0xFFF59E0B),
  Color(0xFFEF4444),
  Color(0xFFEC4899),
  Color(0xFF8B5CF6),
  Color(0xFF06B6D4),
  Color(0xFFF97316),
];

/// What the user chose to show on the card, saved on this device.
class BcOptions {
  static const keys = <String>[
    'logo',
    'business',
    'owner',
    'title',
    'tagline',
    'phone',
    'whatsapp',
    'email',
    'website',
    'address',
    'qr',
  ];

  final Map<String, bool> show;
  int accent;

  BcOptions({Map<String, bool>? show, this.accent = 0}) : show = show ?? {for (final k in keys) k: true};

  bool on(String key) => show[key] ?? true;

  BcOptions copy() => BcOptions(show: Map<String, bool>.of(show), accent: accent);

  static Future<BcOptions> load() async {
    final prefs = await SharedPreferences.getInstance();
    return BcOptions(
      show: {for (final k in keys) k: prefs.getBool('business_card_$k') ?? true},
      accent: prefs.getInt('business_card_accent') ?? 0,
    );
  }

  Future<void> save() async {
    final prefs = await SharedPreferences.getInstance();
    for (final k in keys) {
      await prefs.setBool('business_card_$k', on(k));
    }
    await prefs.setInt('business_card_accent', accent);
  }
}

/// The profile photo keeps the same file name when replaced, so drop any
/// cached copy before drawing it on a card.
Future<void> bcEvictLogo(ProfileModel p) async {
  final path = p.photoPath;
  if (path == null || path.isEmpty) return;
  await FileImage(File(path)).evict();
}

String? _clean(String? v) {
  final t = v?.trim();
  return (t == null || t.isEmpty) ? null : t;
}

/// Resolved, ready-to-draw values for one card.
class BcData {
  final String? business;
  final String? owner;
  final String? title;
  final String? tagline;
  final String? phone;
  final String? whatsapp;
  final String? email;
  final String? website;
  final String? address;
  final File? logo;
  final bool showLogo;
  final bool showQr;
  final String initials;
  final Color? accent;
  final String vcard;

  const BcData({
    this.business,
    this.owner,
    this.title,
    this.tagline,
    this.phone,
    this.whatsapp,
    this.email,
    this.website,
    this.address,
    this.logo,
    required this.showLogo,
    required this.showQr,
    required this.initials,
    this.accent,
    required this.vcard,
  });

  bool get hasContacts => phone != null || whatsapp != null || email != null || website != null || address != null;

  factory BcData.from(ProfileModel p, BcOptions o) {
    final businessRaw = _clean(p.name);
    final ownerRaw = _clean(p.ownerName);

    // Business name and owner fall back to a neutral placeholder so a brand
    // new profile still previews nicely.
    final business = o.on('business') ? (businessRaw ?? 'Your Business') : null;
    final owner = o.on('owner') ? (ownerRaw ?? 'Owner Name') : null;
    final title = o.on('title') ? _clean(p.designation) : null;
    final tagline = o.on('tagline') ? _clean(p.tagline) : null;
    final phone = o.on('phone') ? _clean(p.phone) : null;
    final whatsapp = o.on('whatsapp') ? _clean(p.whatsapp) : null;
    final email = o.on('email') ? _clean(p.email) : null;
    final website = o.on('website') ? _clean(p.website) : null;
    final address = o.on('address') ? _clean(p.address) : null;

    File? logo;
    final path = p.photoPath;
    if (o.on('logo') && path != null && path.isNotEmpty) {
      final f = File(path);
      if (f.existsSync()) logo = f;
    }

    final initialSource = businessRaw ?? ownerRaw ?? 'B';
    final words = initialSource.split(RegExp(r'\s+')).where((w) => w.isNotEmpty).toList();
    var initials = words.take(2).map((w) => String.fromCharCode(w.runes.first)).join().toUpperCase();
    if (initials.isEmpty) initials = 'B';

    String esc(String s) => s
        .replaceAll('\\', '\\\\')
        .replaceAll(',', '\\,')
        .replaceAll(';', '\\;')
        .replaceAll('\n', ' ');
    final lines = <String>[
      'BEGIN:VCARD',
      'VERSION:3.0',
      'FN:${esc(ownerRaw ?? businessRaw ?? 'Contact')}',
      if (businessRaw != null) 'ORG:${esc(businessRaw)}',
      if (title != null) 'TITLE:${esc(title)}',
      if (phone != null) 'TEL;TYPE=WORK,VOICE:${esc(phone)}',
      if (whatsapp != null) 'TEL;TYPE=CELL:${esc(whatsapp)}',
      if (email != null) 'EMAIL:${esc(email)}',
      if (website != null) 'URL:${esc(website)}',
      if (address != null) 'ADR;TYPE=WORK:;;${esc(address)};;;;',
      'END:VCARD',
    ];

    return BcData(
      business: business,
      owner: owner,
      title: title,
      tagline: tagline,
      phone: phone,
      whatsapp: whatsapp,
      email: email,
      website: website,
      address: address,
      logo: logo,
      showLogo: o.on('logo'),
      showQr: o.on('qr'),
      initials: initials,
      accent: o.accent > 0 && o.accent <= kBcAccents.length ? kBcAccents[o.accent - 1] : null,
      vcard: lines.join('\n'),
    );
  }
}
