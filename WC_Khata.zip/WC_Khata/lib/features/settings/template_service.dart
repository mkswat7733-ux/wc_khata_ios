import 'dart:convert';
import 'dart:io';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

enum TemplateKind { invoice, label }

enum TemplateElementType { business, logo, title, invoiceNumber, date, customer, items, totals, paymentStatus, notes, thankYou, signature, footer, barcode, productName, price }

class TemplateElement {
  final String id;
  final TemplateElementType type;
  final String label;
  final double x, y, width, height, fontSize;
  final bool visible;
  const TemplateElement({required this.id,required this.type,required this.label,this.x=0,this.y=0,this.width=160,this.height=45,this.fontSize=12,this.visible=true});
  TemplateElement copyWith({String? id,TemplateElementType? type,String? label,double? x,double? y,double? width,double? height,double? fontSize,bool? visible})=>TemplateElement(id:id??this.id,type:type??this.type,label:label??this.label,x:x??this.x,y:y??this.y,width:width??this.width,height:height??this.height,fontSize:fontSize??this.fontSize,visible:visible??this.visible);
  Map<String,dynamic> toJson()=>{'id':id,'type':type.name,'label':label,'x':x,'y':y,'width':width,'height':height,'fontSize':fontSize,'visible':visible};
  factory TemplateElement.fromJson(Map<String,dynamic> j)=>TemplateElement(id:j['id']?.toString()??DateTime.now().microsecondsSinceEpoch.toString(),type:TemplateElementType.values.firstWhere((e)=>e.name==j['type'],orElse:()=>TemplateElementType.notes),label:j['label']?.toString()??'Element',x:(j['x'] as num?)?.toDouble()??0,y:(j['y'] as num?)?.toDouble()??0,width:(j['width'] as num?)?.toDouble()??160,height:(j['height'] as num?)?.toDouble()??45,fontSize:(j['fontSize'] as num?)?.toDouble()??12,visible:j['visible']!=false);
}

class DocumentTemplate {
  final String id,name; final TemplateKind kind; final bool builtIn; final String layout; final int accent; final String? logoPath; final String title;
  final bool showLogo,showBusiness,showCustomer,showItems,showTotals,showNotes,showInvoiceNumber,showDate,showPaymentStatus,showSignature,showFooterMessage,showDiscount,showTax,showPaid,showBalance,showProductImages;
  final bool showLabelProduct,showLabelPrice,showLabelBarcode,showLabelBusiness,showLabelSku;
  final String thankYouMessage;
  final double labelWidthMm,labelHeightMm;
  final double barcodeHeightPct;
  // Label text sizes in pt (0 = automatic, scaled to the label size).
  final double labelBusinessFs,labelProductFs,labelCodeFs,labelPriceFs;
  final bool showLabelCode;
  // Label margins in mm (-1 = automatic, fitted to the label size).
  final double labelMarginL,labelMarginR,labelMarginT,labelMarginB;
  final List<TemplateElement> elements;
  const DocumentTemplate({required this.id,required this.name,required this.kind,required this.builtIn,required this.layout,required this.accent,this.logoPath,this.showLogo=true,this.showBusiness=true,this.showCustomer=true,this.showItems=true,this.showTotals=true,this.showNotes=true,this.showInvoiceNumber=true,this.showDate=true,this.showPaymentStatus=true,this.showSignature=true,this.showFooterMessage=true,this.showDiscount=true,this.showTax=true,this.showPaid=true,this.showBalance=true,this.showProductImages=false,this.showLabelProduct=true,this.showLabelPrice=true,this.showLabelBarcode=true,this.showLabelBusiness=false,this.showLabelSku=false,this.thankYouMessage='Thank you for your business!',this.labelWidthMm=50,this.labelHeightMm=30,this.barcodeHeightPct=100,this.labelBusinessFs=0,this.labelProductFs=0,this.labelCodeFs=0,this.labelPriceFs=0,this.showLabelCode=true,this.labelMarginL=-1,this.labelMarginR=-1,this.labelMarginT=-1,this.labelMarginB=-1,this.elements=const [],this.title='INVOICE'});
  List<TemplateElement> get normalizedElements=>elements.isEmpty?_defaultElements(kind):elements;
  DocumentTemplate copyWith({String? id,String? name,TemplateKind? kind,bool? builtIn,String? layout,int? accent,String? logoPath,bool? showLogo,String? title,bool? showBusiness,bool? showCustomer,bool? showItems,bool? showTotals,bool? showNotes,bool? showInvoiceNumber,bool? showDate,bool? showPaymentStatus,bool? showSignature,bool? showFooterMessage,bool? showDiscount,bool? showTax,bool? showPaid,bool? showBalance,bool? showProductImages,bool? showLabelProduct,bool? showLabelPrice,bool? showLabelBarcode,bool? showLabelBusiness,bool? showLabelSku,String? thankYouMessage,double? labelWidthMm,double? labelHeightMm,double? barcodeHeightPct,double? labelBusinessFs,double? labelProductFs,double? labelCodeFs,double? labelPriceFs,bool? showLabelCode,double? labelMarginL,double? labelMarginR,double? labelMarginT,double? labelMarginB,List<TemplateElement>? elements})=>DocumentTemplate(id:id??this.id,name:name??this.name,kind:kind??this.kind,builtIn:builtIn??this.builtIn,layout:layout??this.layout,accent:accent??this.accent,logoPath:logoPath??this.logoPath,showLogo:showLogo??this.showLogo,title:title??this.title,showBusiness:showBusiness??this.showBusiness,showCustomer:showCustomer??this.showCustomer,showItems:showItems??this.showItems,showTotals:showTotals??this.showTotals,showNotes:showNotes??this.showNotes,showInvoiceNumber:showInvoiceNumber??this.showInvoiceNumber,showDate:showDate??this.showDate,showPaymentStatus:showPaymentStatus??this.showPaymentStatus,showSignature:showSignature??this.showSignature,showFooterMessage:showFooterMessage??this.showFooterMessage,showDiscount:showDiscount??this.showDiscount,showTax:showTax??this.showTax,showPaid:showPaid??this.showPaid,showBalance:showBalance??this.showBalance,showProductImages:showProductImages??this.showProductImages,showLabelProduct:showLabelProduct??this.showLabelProduct,showLabelPrice:showLabelPrice??this.showLabelPrice,showLabelBarcode:showLabelBarcode??this.showLabelBarcode,showLabelBusiness:showLabelBusiness??this.showLabelBusiness,showLabelSku:showLabelSku??this.showLabelSku,thankYouMessage:thankYouMessage??this.thankYouMessage,labelWidthMm:labelWidthMm??this.labelWidthMm,labelHeightMm:labelHeightMm??this.labelHeightMm,barcodeHeightPct:barcodeHeightPct??this.barcodeHeightPct,labelBusinessFs:labelBusinessFs??this.labelBusinessFs,labelProductFs:labelProductFs??this.labelProductFs,labelCodeFs:labelCodeFs??this.labelCodeFs,labelPriceFs:labelPriceFs??this.labelPriceFs,showLabelCode:showLabelCode??this.showLabelCode,labelMarginL:labelMarginL??this.labelMarginL,labelMarginR:labelMarginR??this.labelMarginR,labelMarginT:labelMarginT??this.labelMarginT,labelMarginB:labelMarginB??this.labelMarginB,elements:elements??this.elements);
  Map<String,dynamic> toJson()=>{'id':id,'name':name,'kind':kind.name,'builtIn':builtIn,'layout':layout,'accent':accent,'logoPath':logoPath,'showLogo':showLogo,'title':title,'showBusiness':showBusiness,'showCustomer':showCustomer,'showItems':showItems,'showTotals':showTotals,'showNotes':showNotes,'showInvoiceNumber':showInvoiceNumber,'showDate':showDate,'showPaymentStatus':showPaymentStatus,'showSignature':showSignature,'showFooterMessage':showFooterMessage,'showDiscount':showDiscount,'showTax':showTax,'showPaid':showPaid,'showBalance':showBalance,'showProductImages':showProductImages,'showLabelProduct':showLabelProduct,'showLabelPrice':showLabelPrice,'showLabelBarcode':showLabelBarcode,'showLabelBusiness':showLabelBusiness,'showLabelSku':showLabelSku,'thankYouMessage':thankYouMessage,'labelWidthMm':labelWidthMm,'labelHeightMm':labelHeightMm,'barcodeHeightPct':barcodeHeightPct,'labelBusinessFs':labelBusinessFs,'labelProductFs':labelProductFs,'labelCodeFs':labelCodeFs,'labelPriceFs':labelPriceFs,'showLabelCode':showLabelCode,'labelMarginL':labelMarginL,'labelMarginR':labelMarginR,'labelMarginT':labelMarginT,'labelMarginB':labelMarginB,'elements':elements.map((e)=>e.toJson()).toList()};
  factory DocumentTemplate.fromJson(Map<String,dynamic> j)=>DocumentTemplate(id:j['id']?.toString()??'template_${DateTime.now().millisecondsSinceEpoch}',name:j['name']?.toString()??'Template',kind:TemplateKind.values.firstWhere((e)=>e.name==(j['kind']??'invoice'),orElse:()=>TemplateKind.invoice),builtIn:j['builtIn']==true,layout:j['layout']?.toString()??'classic',accent:(j['accent'] as num?)?.toInt()??0xFF2563EB,logoPath:j['logoPath'] as String?,showLogo:j['showLogo']!=false,title:j['title']?.toString()??'INVOICE',showBusiness:j['showBusiness']!=false,showCustomer:j['showCustomer']!=false,showItems:j['showItems']!=false,showTotals:j['showTotals']!=false,showNotes:j['showNotes']!=false,showInvoiceNumber:j['showInvoiceNumber']!=false,showDate:j['showDate']!=false,showPaymentStatus:j['showPaymentStatus']!=false,showSignature:j['showSignature']!=false,showFooterMessage:j['showFooterMessage']!=false,showDiscount:j['showDiscount']!=false,showTax:j['showTax']!=false,showPaid:j['showPaid']!=false,showBalance:j['showBalance']!=false,showProductImages:j['showProductImages']==true,showLabelProduct:j['showLabelProduct']!=false,showLabelPrice:j['showLabelPrice']!=false,showLabelBarcode:j['showLabelBarcode']!=false,showLabelBusiness:j['showLabelBusiness']==true,showLabelSku:j['showLabelSku']==true,thankYouMessage:j['thankYouMessage']?.toString()??'Thank you for your business!',labelWidthMm:((j['labelWidthMm'] as num?)?.toDouble()??50).clamp(15.0,210.0).toDouble(),labelHeightMm:((j['labelHeightMm'] as num?)?.toDouble()??30).clamp(10.0,300.0).toDouble(),barcodeHeightPct:((j['barcodeHeightPct'] as num?)?.toDouble()??100).clamp(20.0,100.0).toDouble(),labelBusinessFs:_fs(j['labelBusinessFs']),labelProductFs:_fs(j['labelProductFs']),labelCodeFs:_fs(j['labelCodeFs']),labelPriceFs:_fs(j['labelPriceFs']),showLabelCode:j['showLabelCode']!=false,labelMarginL:_mg(j['labelMarginL']),labelMarginR:_mg(j['labelMarginR']),labelMarginT:_mg(j['labelMarginT']),labelMarginB:_mg(j['labelMarginB']),elements:(j['elements'] is List)?(j['elements'] as List).map((e)=>TemplateElement.fromJson(Map<String,dynamic>.from(e))).toList():const []);
}

double _mg(Object? v){final n=(v as num?)?.toDouble()??-1;return n<0?-1:n.clamp(0.0,20.0).toDouble();}

double _fs(Object? v)=>((v as num?)?.toDouble()??0).clamp(0.0,40.0).toDouble();

List<TemplateElement> _defaultElements(TemplateKind kind,{int variant=0}){
 if(kind==TemplateKind.label){
   final compact=variant%3==0;
   return [
     if(!compact) TemplateElement(id:'label_business',type:TemplateElementType.business,label:'Business',x:8,y:4,width:150,height:18,fontSize:8),
     TemplateElement(id:'product',type:TemplateElementType.productName,label:'Product Name',x:8,y:compact?4:24,width:170,height:22,fontSize:variant%4==0?12:10),
     TemplateElement(id:'barcode',type:TemplateElementType.barcode,label:'Barcode',x:12,y:compact?30:50,width:155,height:58,fontSize:8),
     if(variant%3!=1) TemplateElement(id:'price',type:TemplateElementType.price,label:'Price',x:8,y:compact?92:112,width:165,height:22,fontSize:variant%2==0?13:11),
   ];
 }
 final elements=<TemplateElement>[
   TemplateElement(id:'logo',type:TemplateElementType.logo,label:'Logo',x:8,y:8,width:55,height:45),
   TemplateElement(id:'business',type:TemplateElementType.business,label:'Business Details',x:68,y:8,width:190,height:45,fontSize:variant%3==0?16:14),
   TemplateElement(id:'title',type:TemplateElementType.title,label:'Invoice Title',x:280,y:8,width:100,height:38,fontSize:variant%2==0?13:15),
   if(variant%4!=3) TemplateElement(id:'customer',type:TemplateElementType.customer,label:'Customer',x:8,y:65,width:180,height:55),
   TemplateElement(id:'invoiceNumber',type:TemplateElementType.invoiceNumber,label:'Invoice Details',x:198,y:65,width:182,height:55),
   TemplateElement(id:'items',type:TemplateElementType.items,label:'Items Table',x:8,y:128,width:372,height:220),
   TemplateElement(id:'totals',type:TemplateElementType.totals,label:'Totals',x:215,y:358,width:165,height:100),
   if(variant%5!=2) TemplateElement(id:'thankYou',type:TemplateElementType.thankYou,label:'Thank You Message',x:8,y:365,width:190,height:35,fontSize:10),
   if(variant%3==0) TemplateElement(id:'signature',type:TemplateElementType.signature,label:'Signature',x:8,y:465,width:372,height:45,fontSize:9),
 ];
 return elements;
}

class TemplateService {
 TemplateService._(); static final instance=TemplateService._(); static const _key='document_templates_v2'; static const _legacyKey='document_templates_v1'; static const _invoiceActive='invoice_active_v2'; static const _labelActive='label_active_v2';
 Future<SharedPreferences> get _prefs=>SharedPreferences.getInstance();
 Future<List<DocumentTemplate>> all() async {
   final p=await _prefs;
   final raw=p.getString(_key)??p.getString(_legacyKey);
   if(raw==null){
     final list=[..._defaults(TemplateKind.invoice),..._defaults(TemplateKind.label)];
     await _save(list); return list;
   }
   try{
     final list=(jsonDecode(raw) as List).map((e)=>DocumentTemplate.fromJson(Map<String,dynamic>.from(e))).toList();
     final existingIds=list.map((e)=>e.id).toSet();
     final missing=[..._defaults(TemplateKind.invoice),..._defaults(TemplateKind.label)].where((e)=>!existingIds.contains(e.id));
     if(missing.isNotEmpty) list.addAll(missing);
     if(p.getString(_key)==null || missing.isNotEmpty) await _save(list);
     return list;
   }catch(_){
     final list=[..._defaults(TemplateKind.invoice),..._defaults(TemplateKind.label)];
     await _save(list); return list;
   }
 }
 Future<void> _save(List<DocumentTemplate> list) async{final p=await _prefs;await p.setString(_key,jsonEncode(list.map((e)=>e.toJson()).toList()));}
 Future<void> save(DocumentTemplate t) async{final list=await all();final i=list.indexWhere((x)=>x.id==t.id);if(i>=0)list[i]=t;else list.add(t);await _save(list);}
 Future<void> setActive(DocumentTemplate t) async{final p=await _prefs;await p.setString(t.kind==TemplateKind.invoice?_invoiceActive:_labelActive,t.id);await save(t);}
 Future<DocumentTemplate> active(TemplateKind kind) async{final list=await all();final p=await _prefs;final id=p.getString(kind==TemplateKind.invoice?_invoiceActive:_labelActive);final found=list.where((t)=>t.kind==kind&&t.id==id).toList();if(found.isNotEmpty)return found.first;final fallback=list.firstWhere((t)=>t.kind==kind);await p.setString(kind==TemplateKind.invoice?_invoiceActive:_labelActive,fallback.id);return fallback;}
 Future<void> deleteCreated(String id) async{final list=await all();list.removeWhere((t)=>t.id==id&&!t.builtIn);await _save(list);}
 Future<String?> pickLogo() async{final picked=await ImagePicker().pickImage(source:ImageSource.gallery,imageQuality:90);if(picked==null)return null;final dir=await getApplicationDocumentsDirectory();final logos=Directory('${dir.path}/template_logos');await logos.create(recursive:true);final target=File('${logos.path}/logo_${DateTime.now().millisecondsSinceEpoch}${_ext(picked.path)}');await File(picked.path).copy(target.path);return target.path;}
 String _ext(String p){final i=p.lastIndexOf('.');return i<0?'.jpg':p.substring(i);}
 List<DocumentTemplate> _defaults(TemplateKind kind){
 const inv=[
  'Aurora','Royal Blue','Midnight Pro','Emerald Business','Sunset Invoice','Crystal Clean','Executive Black','Modern Retail','Luxury Gold','Smart Minimal',
  'Ocean Pro','Violet Studio','Carbon Elite','Rose Gold','Teal Commerce','Slate Ledger','Copper Classic','Indigo Prime','Pearl White','Graphite Pro'
 ];
 const lab=[
  'Classic Barcode','Retail Price','Compact Code','Product Tag','Bold Price','Clean Label','Shelf Tag','Premium Label','Small Code','Simple Label',
  'Market Tag','Pro Barcode','Gold Shelf','Dark Retail','Fresh Green','Ocean Tag','Minimal Code','Price Focus','Wide Barcode','Business Label'
 ];
 const colors=[
  0xFF2563EB,0xFF1D4ED8,0xFF111827,0xFF059669,0xFFEA580C,0xFF0891B2,0xFF0F172A,0xFF7C3AED,0xFFB45309,0xFF475569,
  0xFF0369A1,0xFF9333EA,0xFF334155,0xFFB45309,0xFF0F766E,0xFF0E7490,0xFF4F46E5,0xFFBE123C,0xFF64748B,0xFF18181B
 ];
 const layouts=[
  'aurora','royal','midnight','emerald','sunset','crystal','executive','retail','luxury','minimal',
  'ocean','violet','carbon','roseGold','teal','slate','copper','indigo','pearl','graphite'
 ];
 final names=kind==TemplateKind.invoice?inv:lab;
 return List.generate(20,(i){
   if(kind==TemplateKind.label){
     return DocumentTemplate(
       id:'${kind.name}_default_$i',name:names[i],kind:kind,builtIn:true,layout:layouts[i],accent:colors[i],
       title:'LABEL',elements:_defaultElements(kind,variant:i),
       showLabelProduct:i%7!=6,showLabelPrice:i%3!=1,showLabelBarcode:true,showLabelBusiness:i%4==0,showLabelSku:false,
     );
   }
   return DocumentTemplate(
     id:'${kind.name}_default_$i',name:names[i],kind:kind,builtIn:true,layout:layouts[i],accent:colors[i],
     title:i%6==0?'TAX INVOICE':(i%4==0?'SALES INVOICE':'INVOICE'),
     elements:_defaultElements(kind,variant:i),
     showBusiness:true,showCustomer:i%4!=3,showItems:true,showTotals:true,
     showNotes:i%5!=4,showInvoiceNumber:true,showDate:true,showPaymentStatus:i%3!=1,
     showSignature:i%3==0,showFooterMessage:i%5!=2,showDiscount:i%4!=1,showTax:i%3!=2,
     showPaid:i%4!=2,showBalance:true,showProductImages:i%6==0,
   );
 });
}
}
