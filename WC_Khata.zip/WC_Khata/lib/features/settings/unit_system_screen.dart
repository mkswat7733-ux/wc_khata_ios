import 'package:flutter/material.dart';
import '../../app/theme/app_theme.dart';
import '../../core/services/unit_repository.dart';
import '../../core/services/unit_system_service.dart';
import '../../core/widgets/app_card.dart';
import '../../core/widgets/app_message.dart';
import '../../core/widgets/modern_header.dart';
import '../../core/widgets/unit_picker.dart';

/// Settings > Inner / Outer Unit System.
///
/// ON/OFF toggle, and when ON two searchable selectors: the OUTER unit
/// (Box, Carton, Dozen...) and the INNER unit (Strip, Tablet, Piece...). Units
/// that are not in the list are created by typing their name. Saving makes
/// these the defaults used on the Product and Purchase screens.
class UnitSystemScreen extends StatefulWidget {
  const UnitSystemScreen({super.key});

  @override
  State<UnitSystemScreen> createState() => _UnitSystemScreenState();
}

class _UnitSystemScreenState extends State<UnitSystemScreen> {
  bool _loading = true;
  bool _enabled = false;
  bool _saving = false;
  final List<String> _outerUnits = [];
  final List<String> _innerUnits = [];
  String? _outer;
  String? _inner;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final cfg = await UnitSystemService.instance.load();
    if (!mounted) return;
    setState(() {
      _enabled = cfg.enabled;
      _outerUnits..clear()..addAll(cfg.outerUnits);
      _innerUnits..clear()..addAll(cfg.innerUnits);
      _outer = cfg.defaultOuter;
      _inner = cfg.defaultInner;
      _loading = false;
    });
  }

  Future<void> _pickOuter() async {
    final v = await showUnitPicker(
      context,
      title: 'Outer Unit',
      options: _outerUnits,
      selected: _outer,
      onAdd: (name) { UnitSystemService.addTo(_outerUnits, name); UnitRepository.instance.addIfMissing(name); },
    );
    if (v != null && mounted) setState(() => _outer = v);
  }

  Future<void> _pickInner() async {
    final v = await showUnitPicker(
      context,
      title: 'Inner Unit',
      options: _innerUnits,
      selected: _inner,
      onAdd: (name) { UnitSystemService.addTo(_innerUnits, name); UnitRepository.instance.addIfMissing(name); },
    );
    if (v != null && mounted) setState(() => _inner = v);
  }

  Future<void> _save() async {
    if (_saving) return;
    if (_enabled && (_outer == null || _inner == null)) {
      AppMessenger.of(context).showSnackBar(const SnackBar(content: Text('Please select both the Outer Unit and the Inner Unit.')));
      return;
    }
    if (_enabled && _outer!.toLowerCase() == _inner!.toLowerCase()) {
      AppMessenger.of(context).showSnackBar(const SnackBar(content: Text('Outer Unit and Inner Unit must be different.')));
      return;
    }
    setState(() => _saving = true);
    try {
      await UnitSystemService.instance.save(UnitSystemConfig(
        enabled: _enabled,
        outerUnits: List<String>.from(_outerUnits),
        innerUnits: List<String>.from(_innerUnits),
        defaultOuter: _outer,
        defaultInner: _inner,
      ));
      if (mounted) Navigator.pop(context, true);
    } catch (_) {
      if (mounted) AppMessenger.of(context).showSnackBar(const SnackBar(content: Text('Could not save the unit system. Please try again.')));
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Scaffold(
      backgroundColor: isDark ? AppColors.darkBackground : AppColors.lightBackground,
      body: Column(children: [
        ModernHeader(title: 'Inner / Outer Unit', onBack: () => Navigator.pop(context)),
        Expanded(
          child: _loading
              ? const Center(child: CircularProgressIndicator())
              : ListView(
                  padding: const EdgeInsets.all(AppDimensions.spaceMd),
                  children: [
                    AppCard(
                      borderColor: isDark ? null : Colors.black,
                      child: Row(children: [
                        const Icon(Icons.layers_rounded, color: AppColors.primary),
                        const SizedBox(width: AppDimensions.spaceMd),
                        const Expanded(
                          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            Text('Inner / Outer Unit', style: AppTextStyles.bodyMedium),
                            Text('Sell and buy in two units, e.g. Box and Strips', style: AppTextStyles.caption, maxLines: 2),
                          ]),
                        ),
                        Switch(
                          value: _enabled,
                          activeThumbColor: AppColors.primary,
                          onChanged: (v) => setState(() => _enabled = v),
                        ),
                      ]),
                    ),
                    if (_enabled) ...[
                      const SizedBox(height: AppDimensions.spaceMd),
                      _unitBox(
                        label: 'Outer Unit',
                        hint: 'Select outer unit (e.g. Box)',
                        value: _outer,
                        icon: Icons.inventory_2_rounded,
                        onTap: _pickOuter,
                      ),
                      const SizedBox(height: AppDimensions.spaceMd),
                      _unitBox(
                        label: 'Inner Unit',
                        hint: 'Select inner unit (e.g. Strips)',
                        value: _inner,
                        icon: Icons.view_module_rounded,
                        onTap: _pickInner,
                      ),
                      const SizedBox(height: AppDimensions.spaceMd),
                      _hint(),
                    ],
                    const SizedBox(height: AppDimensions.spaceLg),
                    SizedBox(
                      height: 52,
                      child: FilledButton.icon(
                        onPressed: _saving ? null : _save,
                        icon: _saving
                            ? const SizedBox(width: 19, height: 19, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                            : const Icon(Icons.save_rounded),
                        label: const Text('Save', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w800)),
                        style: FilledButton.styleFrom(backgroundColor: AppColors.primary, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15))),
                      ),
                    ),
                  ],
                ),
        ),
      ]),
    );
  }

  Widget _unitBox({required String label, required String hint, required String? value, required IconData icon, required VoidCallback onTap}) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        Expanded(child: Text(label, style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w800))),
        TextButton.icon(
          onPressed: onTap,
          icon: const Icon(Icons.add_circle_outline_rounded, size: 17),
          label: const Text('Add', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w800)),
          style: TextButton.styleFrom(visualDensity: VisualDensity.compact, padding: const EdgeInsets.symmetric(horizontal: 8)),
        ),
      ]),
      const SizedBox(height: 4),
      Material(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(14),
          child: Container(
            height: 52,
            padding: const EdgeInsets.symmetric(horizontal: 12),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: value != null ? AppColors.primary.withValues(alpha: .5) : AppColors.lightCardBorder),
            ),
            child: Row(children: [
              Icon(Icons.search_rounded, color: AppColors.primary, size: 20),
              const SizedBox(width: 9),
              Expanded(
                child: Text(
                  value ?? hint,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(fontSize: 13.5, fontWeight: FontWeight.w700, color: value == null ? AppColors.lightTextSecondary : AppColors.lightTextPrimary),
                ),
              ),
              const Icon(Icons.keyboard_arrow_down_rounded),
            ]),
          ),
        ),
      ),
    ]);
  }

  Widget _hint() {
    final o = _outer ?? 'Box';
    final i = _inner ?? 'Strips';
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: AppColors.primary.withValues(alpha: .06), borderRadius: BorderRadius.circular(14), border: Border.all(color: AppColors.primary.withValues(alpha: .18))),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Icon(Icons.info_outline_rounded, color: AppColors.primary, size: 19),
        const SizedBox(width: 9),
        Expanded(
          child: Text(
            'On the Product screen you choose how many $i are in one $o (for example 1 $o = 10 $i). '
            'Stock, purchase price and sale price are then counted per $i, and stock is shown as $o + $i.',
            style: const TextStyle(fontSize: 11.5, height: 1.35, fontWeight: FontWeight.w600, color: AppColors.lightTextSecondary),
          ),
        ),
      ]),
    );
  }
}
