import 'package:flutter/material.dart';
import '../../app/theme/app_theme.dart';
import '../../core/widgets/app_message.dart';
import '../../core/widgets/app_tab_screen.dart';
import 'item_repository.dart';

/// Add Product > Category sheet > "Add Category".
///
/// Same look as the Add Expense Category screen. When the category is saved
/// it pops the new [ItemCategory], so Add Product can select it right away.
class AddProductCategoryScreen extends StatefulWidget {
  const AddProductCategoryScreen({super.key});

  @override
  State<AddProductCategoryScreen> createState() => _AddProductCategoryScreenState();
}

class _AddProductCategoryScreenState extends State<AddProductCategoryScreen> {
  final _formKey = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _repo = ItemRepository();
  bool _saving = false;

  @override
  void dispose() {
    _name.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (_saving) return;
    FocusScope.of(context).unfocus();
    if (!_formKey.currentState!.validate()) return;
    setState(() => _saving = true);
    try {
      final name = _name.text.trim();
      final ok = await _repo.addCategoryChecked(name);
      if (!mounted) return;
      if (!ok) {
        AppMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('This category already exists.')),
        );
        return;
      }
      final all = await _repo.getCategories();
      ItemCategory? created;
      for (final c in all) {
        if (c.name.toLowerCase() == name.toLowerCase()) {
          created = c;
          break;
        }
      }
      if (!mounted) return;
      Navigator.pop(context, created);
    } catch (_) {
      if (!mounted) return;
      AppMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Could not save category.')),
      );
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = (MediaQuery.of(context).size.width / 390).clamp(0.86, 1.18);
    final bottomInset = MediaQuery.of(context).viewInsets.bottom;
    final safeBottom = MediaQuery.of(context).padding.bottom;
    OutlineInputBorder border(Color c, [double w = 1]) => OutlineInputBorder(
          borderRadius: BorderRadius.circular(16 * s),
          borderSide: BorderSide(color: c, width: w),
        );

    return AppTabScreen(
      title: 'Add Category',
      onBack: () => Navigator.pop(context),
      body: Column(
        children: [
          Expanded(
            child: Form(
              key: _formKey,
              child: ListView(
                padding: EdgeInsets.fromLTRB(16 * s, 20 * s, 16 * s, 16 * s),
                children: [
                  Text('Category Name', style: TextStyle(fontSize: 15 * s, fontWeight: FontWeight.w900)),
                  SizedBox(height: 8 * s),
                  TextFormField(
                    controller: _name,
                    autofocus: true,
                    textCapitalization: TextCapitalization.words,
                    textInputAction: TextInputAction.done,
                    maxLength: 40,
                    onFieldSubmitted: (_) => _save(),
                    style: TextStyle(fontSize: 15 * s, fontWeight: FontWeight.w700),
                    decoration: InputDecoration(
                      hintText: 'e.g. Beverages',
                      counterText: '',
                      filled: true,
                      fillColor: Colors.white,
                      contentPadding: EdgeInsets.symmetric(horizontal: 16 * s, vertical: 18 * s),
                      border: border(AppColors.lightCardBorder),
                      enabledBorder: border(AppColors.lightCardBorder),
                      focusedBorder: border(AppColors.primary, 1.4),
                    ),
                    validator: (v) {
                      final t = v?.trim() ?? '';
                      if (t.isEmpty) return 'Enter category name';
                      if (t.length < 2) return 'Name is too short';
                      return null;
                    },
                  ),
                ],
              ),
            ),
          ),
          Container(
            padding: EdgeInsets.fromLTRB(16 * s, 10 * s, 16 * s, (bottomInset > 0 ? 10 : 14 + safeBottom / 2) * s + bottomInset),
            decoration: const BoxDecoration(
              color: Colors.white,
              border: Border(top: BorderSide(color: AppColors.lightDivider)),
            ),
            child: SizedBox(
              width: double.infinity,
              height: 54 * s,
              child: FilledButton(
                onPressed: _saving ? null : _save,
                style: FilledButton.styleFrom(
                  backgroundColor: AppColors.primary,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(17 * s)),
                ),
                child: _saving
                    ? SizedBox(width: 20 * s, height: 20 * s, child: const CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                    : Text('Add', style: TextStyle(fontSize: 15 * s, fontWeight: FontWeight.w900)),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
