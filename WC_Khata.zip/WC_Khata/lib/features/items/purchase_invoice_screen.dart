import 'package:flutter/material.dart';

import '../purchases/purchase_repository.dart';
import '../sale/bill_context.dart';
import '../sale/sale_invoice_screen.dart';
import 'item_repository.dart';

/// Purchase receipt / invoice of one purchase record.
/// Same screen, receipt (58/80mm) and A4 invoice as a sale, but for the
/// supplier side: PURCHASE RECEIPT, PURCHASE INVOICE, "Supplier" party.
class PurchaseInvoiceScreen extends StatelessWidget {
  final PurchaseRecord purchase;
  const PurchaseInvoiceScreen({super.key, required this.purchase});

  /// The invoice screens work with a product-shaped record; this carries the
  /// purchase's own figures (its id is the purchase id).
  static ItemRecord asItem(PurchaseRecord p) => ItemRecord(
        id: p.id,
        name: p.itemName,
        categoryId: null,
        category: 'General',
        unit: p.unit,
        qty: p.qty,
        lowStock: 0,
        price: p.unitCost,
        imagePath: null,
        barcode: null,
        supplierId: p.supplierId,
        purchaseType: p.type,
        purchaseAmount: p.total,
        purchaseUnitPrice: p.unitCost,
        purchasePaid: p.paid,
        purchaseDate: p.date,
      );

  @override
  Widget build(BuildContext context) {
    final item = asItem(purchase);
    return SaleInvoiceScreen(sale: BillContext.purchaseAsSale(item), purchaseItem: item);
  }
}
