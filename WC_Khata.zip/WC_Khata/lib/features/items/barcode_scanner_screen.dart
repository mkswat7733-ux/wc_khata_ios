import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import '../../app/theme/app_theme.dart';
import '../../core/services/scanner_sound_service.dart';
import '../../core/services/scanner_settings_service.dart';

class BarcodeScannerScreen extends StatefulWidget {
  const BarcodeScannerScreen({super.key});

  @override
  State<BarcodeScannerScreen> createState() => _BarcodeScannerScreenState();
}

class _BarcodeScannerScreenState extends State<BarcodeScannerScreen> with SingleTickerProviderStateMixin {
  final MobileScannerController _controller = MobileScannerController(
    detectionSpeed: DetectionSpeed.unrestricted,
    facing: CameraFacing.back,
  );
  bool _handled = false;
  bool _closing = false;
  bool _cameraErrorReported = false;
  bool _autoClose = true;
  String _feedback = 'none';
  late final AnimationController _scanAnimation;

  Future<void> _closeWithResult(String? value) async {
    if (_closing) return;
    _closing = true;
    try { await _controller.stop(); } catch (_) {}
    if (mounted) Navigator.of(context).pop(value);
  }

  Future<void> _handleScannerFailure() async {
    if (_cameraErrorReported || _closing) return;
    _cameraErrorReported = true;
    if (mounted) setState(() => _feedback = 'error');
    unawaited(ScannerSoundService.instance.playBarcodeError());
    if (_autoClose) {
      await Future<void>.delayed(const Duration(milliseconds: 350));
      await _closeWithResult(null);
    } else {
      await Future<void>.delayed(const Duration(milliseconds: 700));
      if (mounted) {
        _cameraErrorReported = false;
        setState(() => _feedback = 'none');
      }
    }
  }

  Future<void> _onDetect(BarcodeCapture capture) async {
    if (_handled || _closing) return;
    String? value;
    for (final barcode in capture.barcodes) {
      final raw = barcode.rawValue?.trim();
      if (raw != null && raw.isNotEmpty) {
        value = raw;
        break;
      }
    }
    if (value == null) {
      unawaited(_handleScannerFailure());
      return;
    }

    _handled = true;
    if (mounted) setState(() => _feedback = 'success');
    unawaited(ScannerSoundService.instance.playBarcodeSuccess());
    if (_autoClose) {
      await Future<void>.delayed(const Duration(milliseconds: 280));
      await _closeWithResult(value);
    } else {
      await Future<void>.delayed(const Duration(milliseconds: 650));
      if (mounted && !_closing) setState(() { _handled = false; _feedback = 'none'; });
    }
  }

  @override
  void initState() {
    super.initState();
    _scanAnimation = AnimationController(vsync: this, duration: const Duration(milliseconds: 1500))..repeat();
    unawaited(ScannerSoundService.instance.warmUp());
    _loadSetting();
  }

  Future<void> _loadSetting() async {
    final value = await ScannerSettingsService.instance.getAutoClose();
    if (mounted) setState(() => _autoClose = value);
  }

  @override
  void dispose() {
    _scanAnimation.dispose();
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = (MediaQuery.of(context).size.width / 390).clamp(.85, 1.15);
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        fit: StackFit.expand,
        children: [
          MobileScanner(
            controller: _controller,
            onDetect: _onDetect,
            onDetectError: (error, stack) => unawaited(_handleScannerFailure()),
            errorBuilder: (context, error) => Container(
              color: Colors.black,
              alignment: Alignment.center,
              padding: const EdgeInsets.all(24),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                const Icon(Icons.camera_alt_rounded, color: Colors.white70, size: 40),
                const SizedBox(height: 10),
                const Text('Scanner error', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800)),
                const SizedBox(height: 4),
                Text('Camera could not be started.', textAlign: TextAlign.center, style: TextStyle(color: Colors.white.withValues(alpha:.7), fontSize: 11)),
              ]),
            ),
          ),
          Positioned.fill(
            child: IgnorePointer(
              child: AnimatedBuilder(animation: _scanAnimation, builder: (_, __) => CustomPaint(painter: _ScannerOverlayPainter(progress: _scanAnimation.value, feedback: _feedback))),
            ),
          ),
          SafeArea(
            child: Column(
              children: [
                Padding(
                  padding: EdgeInsets.fromLTRB(14 * s, 10 * s, 14 * s, 0),
                  child: Row(
                    children: [
                      _CircleButton(
                        icon: Icons.arrow_back_rounded,
                        onTap: () => Navigator.pop(context),
                      ),
                      SizedBox(width: 12 * s),
                      Expanded(
                        child: Text(
                          'Scan Barcode / QR',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 18 * s,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ),
                      _CircleButton(
                        icon: Icons.flash_on_rounded,
                        onTap: () => _controller.toggleTorch(),
                      ),
                    ],
                  ),
                ),
                const Spacer(),
                Container(
                  margin: EdgeInsets.only(bottom: 38 * s),
                  padding: EdgeInsets.symmetric(horizontal: 20 * s, vertical: 12 * s),
                  decoration: BoxDecoration(
                    color: Colors.black.withValues(alpha: .62),
                    borderRadius: BorderRadius.circular(18 * s),
                    border: Border.all(color: Colors.white.withValues(alpha: .16)),
                  ),
                  child: Text(
                    'Place the barcode inside the frame',
                    style: TextStyle(color: Colors.white, fontSize: 12 * s, fontWeight: FontWeight.w700),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _CircleButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _CircleButton({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) => Material(
        color: Colors.black.withValues(alpha: .52),
        shape: const CircleBorder(),
        child: InkWell(
          customBorder: const CircleBorder(),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Icon(icon, color: Colors.white, size: 21),
          ),
        ),
      );
}

class _ScannerOverlayPainter extends CustomPainter {
  final double progress;
  final String feedback;
  const _ScannerOverlayPainter({required this.progress, required this.feedback});

  @override
  void paint(Canvas canvas, Size size) {
    final box = Rect.fromCenter(
      center: Offset(size.width / 2, size.height / 2),
      width: size.width * .72,
      height: size.width * .72,
    );
    final overlay = Paint()..color = Colors.black.withValues(alpha: .46);
    canvas.drawRect(Rect.fromLTRB(0, 0, size.width, box.top), overlay);
    canvas.drawRect(Rect.fromLTRB(0, box.top, box.left, box.bottom), overlay);
    canvas.drawRect(Rect.fromLTRB(box.right, box.top, size.width, box.bottom), overlay);
    canvas.drawRect(Rect.fromLTRB(0, box.bottom, size.width, size.height), overlay);

    final isSuccess = feedback == 'success';
    final baseColor = isSuccess ? Colors.greenAccent : AppColors.primary;
    final pulse = .5 + .5 * math.sin(progress * math.pi * 2);
    final border = Paint()
      ..color = baseColor.withValues(alpha: .75 + .25 * pulse)
      ..style = PaintingStyle.stroke
      ..strokeWidth = isSuccess ? 5 : 4;
    canvas.drawRRect(RRect.fromRectAndRadius(box, const Radius.circular(26)), border);

    final scanY = box.top + box.height * progress;
    final scanLine = Paint()
      ..color = isSuccess ? Colors.greenAccent : Colors.white.withValues(alpha: .85)
      ..strokeWidth = isSuccess ? 4 : 2.2
      ..strokeCap = StrokeCap.round;
    canvas.drawLine(Offset(box.left + 12, scanY), Offset(box.right - 12, scanY), scanLine);

    if (isSuccess) {
      final check = Paint()
        ..color = Colors.greenAccent
        ..style = PaintingStyle.stroke
        ..strokeWidth = 7
        ..strokeCap = StrokeCap.round
        ..strokeJoin = StrokeJoin.round;
      final path = Path()
        ..moveTo(box.center.dx - 40, box.center.dy)
        ..lineTo(box.center.dx - 12, box.center.dy + 28)
        ..lineTo(box.center.dx + 44, box.center.dy - 34);
      canvas.drawPath(path, check);
    }

    final corner = Paint()
      ..color = Colors.white
      ..style = PaintingStyle.stroke
      ..strokeWidth = 5
      ..strokeCap = StrokeCap.round;
    const l = 34.0;
    final paths = [
      Path()..moveTo(box.left, box.top + l)..lineTo(box.left, box.top)..lineTo(box.left + l, box.top),
      Path()..moveTo(box.right - l, box.top)..lineTo(box.right, box.top)..lineTo(box.right, box.top + l),
      Path()..moveTo(box.left, box.bottom - l)..lineTo(box.left, box.bottom)..lineTo(box.left + l, box.bottom),
      Path()..moveTo(box.right - l, box.bottom)..lineTo(box.right, box.bottom)..lineTo(box.right, box.bottom - l),
    ];
    for (final path in paths) canvas.drawPath(path, corner);
  }

  @override
  bool shouldRepaint(covariant _ScannerOverlayPainter oldDelegate) => oldDelegate.progress != progress || oldDelegate.feedback != feedback;
}
