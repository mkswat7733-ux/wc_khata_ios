import '../../core/utils/currency_formatter.dart';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:share_plus/share_plus.dart';
import '../../app/theme/app_theme.dart';
import '../../core/widgets/app_glass_icon_button.dart';
import 'item_repository.dart';
import '../settings/template_service.dart';
import '../settings/label_sizes.dart';
import '../../data/repositories/profile_repository.dart';
import '../../core/services/thermal_printer_service.dart';
import '../printer/printer_gate.dart';
import '../../core/widgets/app_message.dart';

class BarcodeLabelScreen extends StatefulWidget {
  final ItemRecord item;
  const BarcodeLabelScreen({super.key, required this.item});

  @override
  State<BarcodeLabelScreen> createState() => _BarcodeLabelScreenState();
}

class _BarcodeLabelScreenState extends State<BarcodeLabelScreen> {
  static const MethodChannel _native = MethodChannel('wc_khata/whatsapp');
  bool _busy = false;
  int _copies = 1;
  DocumentTemplate? _template;
  String _business = 'Business Name';

  @override
  void initState() {
    super.initState();
    _loadTemplate();
  }

  Future<void> _loadTemplate() async {
    final t = await TemplateService.instance.active(TemplateKind.label);
    final profile = await ProfileRepository().getOrCreate();
    if (!mounted) return;
    setState(() {
      _template = t;
      _business = (profile.name?.trim().isNotEmpty ?? false) ? profile.name!.trim() : 'Business Name';
    });
  }

  String get _sizeText {
    final t = _template;
    if (t == null) return '50 × 30 mm';
    String n(double v) => v == v.roundToDouble() ? v.toInt().toString() : v.toStringAsFixed(1);
    return '${n(t.labelWidthMm)} × ${n(t.labelHeightMm)} mm';
  }

  String get _code => widget.item.barcode?.trim() ?? '';
  String _money(double value) => value.truncateToDouble() == value ? value.toInt().toString() : value.toStringAsFixed(2);

  Future<Uint8List> _buildPdfBytes() async {
    final template = await TemplateService.instance.active(TemplateKind.label);
    final profile = await ProfileRepository().getOrCreate();
    final business = (profile.name?.trim().isNotEmpty ?? false) ? profile.name!.trim() : 'Business Name';
    final doc = pw.Document();
    doc.addPage(LabelPdf.page(
      template: template,
      business: business,
      product: widget.item.name,
      code: _code,
      price: widget.item.price,
    ));
    return Uint8List.fromList(await doc.save());
  }

  Future<File> _buildTempPdf() async {
    final bytes = await _buildPdfBytes();
    final dir = await getTemporaryDirectory();
    final safe = widget.item.id;
    final file = File('${dir.path}/barcode_label_$safe.pdf');
    await file.writeAsBytes(bytes, flush: true);
    return file;
  }

  Future<void> _downloadPdf() async {
    if (_busy || _code.isEmpty) return;
    setState(() => _busy = true);
    try {
      final file = await _buildTempPdf();
      final result = await _native.invokeMethod<String>('saveInvoicePdf', {
        'path': file.path,
        'fileName': 'Barcode_${widget.item.id}_$_code.pdf',
      });
      if (mounted) {
        final message = switch (result) {
          null => 'Could not save barcode PDF.',
          'permission_required' => 'Storage permission is required. Please allow it and try again.',
          _ => 'Barcode label PDF saved in Downloads.',
        };
        AppMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
      }
    } catch (_) {
      if (mounted) AppMessenger.of(context).showSnackBar(const SnackBar(content: Text('Could not save barcode PDF.')));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _share() async {
    if (_busy || _code.isEmpty) return;
    setState(() => _busy = true);
    try {
      final file = await _buildTempPdf();
      await Share.shareXFiles([XFile(file.path)], text: 'Barcode label — ${widget.item.name}');
    } catch (_) {
      if (mounted) AppMessenger.of(context).showSnackBar(const SnackBar(content: Text('Could not share barcode label.')));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _print() async {
    if (_busy || _code.isEmpty) return;
    if (!await PrinterGate.ensureLabel(context)) return;
    setState(() => _busy = true);
    try {
      final template = await TemplateService.instance.active(TemplateKind.label);
      final bytes = await _buildPdfBytes();
      await ThermalPrinterService.instance.printLabelPdf(
        bytes,
        widthMm: template.labelWidthMm,
        heightMm: template.labelHeightMm,
        copies: _copies,
      );
      if (mounted) AppMessenger.of(context).showSnackBar(SnackBar(content: Text(_copies == 1 ? 'Barcode label sent to the label printer.' : '$_copies barcode labels sent to the label printer.')));
    } on PrinterException catch (e) {
      if (mounted) AppMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
    } catch (_) {
      if (mounted) AppMessenger.of(context).showSnackBar(const SnackBar(content: Text('Could not print barcode label.')));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Widget _copiesRow(double s) => Container(
    padding: EdgeInsets.symmetric(horizontal: 13*s, vertical: 8*s),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16*s), border: Border.all(color: AppColors.lightCardBorder)),
    child: Row(children: [
      Icon(Icons.copy_all_rounded, color: AppColors.primary, size: 20*s),
      SizedBox(width: 9*s),
      Expanded(child: Text('Number of labels', style: TextStyle(fontSize: 13*s, fontWeight: FontWeight.w800))),
      IconButton(onPressed: _copies > 1 ? () => setState(() => _copies--) : null, icon: const Icon(Icons.remove_circle_outline_rounded)),
      SizedBox(width: 34*s, child: Center(child: Text('$_copies', style: TextStyle(fontSize: 15*s, fontWeight: FontWeight.w900)))),
      IconButton(onPressed: _copies < 99 ? () => setState(() => _copies++) : null, icon: const Icon(Icons.add_circle_outline_rounded)),
    ]),
  );

  @override
  Widget build(BuildContext context) {
    final s = (MediaQuery.sizeOf(context).width / 390).clamp(.82, 1.2).toDouble();
    return Scaffold(
      backgroundColor: AppColors.lightBackground,
      body: Column(children: [
        SafeArea(
          bottom: false,
          child: Container(
            height: 60*s,
            padding: EdgeInsets.symmetric(horizontal: 14*s),
            decoration: const BoxDecoration(color: Colors.white, border: Border(bottom: BorderSide(color: AppColors.lightDivider))),
            child: Row(children: [
              AppGlassIconButton(icon: Icons.arrow_back_rounded, onTap: () => Navigator.pop(context)),
              Expanded(child: Center(child: Text('Barcode Label', style: TextStyle(fontSize: 18*s, fontWeight: FontWeight.w800)))),
              SizedBox(width: 42*s),
            ]),
          ),
        ),
        Expanded(child: ListView(padding: EdgeInsets.all(16*s), children: [
          _previewCard(s),
          SizedBox(height: 14*s),
          _detailCard(s),
          SizedBox(height: 14*s),
          Row(children: [
            Expanded(child: _action(s, Icons.picture_as_pdf_rounded, 'Download PDF', AppColors.primary, _downloadPdf)),
            SizedBox(width: 9*s),
            Expanded(child: _action(s, Icons.share_rounded, 'Share', const Color(0xFF2563EB), _share)),
          ]),
          SizedBox(height: 9*s),
          _copiesRow(s),
          SizedBox(height: 9*s),
          SizedBox(width: double.infinity, height: 50*s, child: FilledButton.icon(
            onPressed: _busy ? null : _print,
            icon: const Icon(Icons.print_rounded),
            label: const Text('Print Barcode Label', style: TextStyle(fontWeight: FontWeight.w800)),
            style: FilledButton.styleFrom(backgroundColor: Colors.black, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15*s))),
          )),
          SizedBox(height: 9*s),
          Center(child: Text('Label size: $_sizeText • Code 128', style: TextStyle(fontSize: 10*s, color: AppColors.lightTextSecondary, fontWeight: FontWeight.w600))),
        ])),
      ]),
    );
  }

  Widget _previewCard(double s) => Container(
    padding: EdgeInsets.all(16 * s),
    decoration: BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(22 * s),
      border: Border.all(color: AppColors.lightCardBorder),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withValues(alpha: .055),
          blurRadius: 14 * s,
          offset: Offset(0, 5 * s),
        ),
      ],
    ),
    child: Column(
      children: [
        Row(
          children: [
            Icon(Icons.preview_rounded, color: AppColors.primary, size: 20 * s),
            SizedBox(width: 8 * s),
            Text(
              'Label Preview',
              style: TextStyle(fontSize: 14 * s, fontWeight: FontWeight.w800),
            ),
            const Spacer(),
            Container(
              padding: EdgeInsets.symmetric(horizontal: 8 * s, vertical: 4 * s),
              decoration: BoxDecoration(
                color: AppColors.primary.withValues(alpha: .08),
                borderRadius: BorderRadius.circular(99),
              ),
              child: Text(
                _sizeText,
                style: TextStyle(
                  fontSize: 9 * s,
                  color: AppColors.primary,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ),
          ],
        ),
        SizedBox(height: 14 * s),
        Container(
          width: double.infinity,
          padding: EdgeInsets.all(12 * s),
          decoration: BoxDecoration(color: const Color(0xFFF1F4F8), borderRadius: BorderRadius.circular(16 * s)),
          child: _template == null
              ? SizedBox(height: 120 * s, child: const Center(child: CircularProgressIndicator()))
              : Center(
                  child: ConstrainedBox(
                    constraints: BoxConstraints(maxHeight: 300 * s),
                    child: FittedBox(
                      fit: BoxFit.contain,
                      child: Container(
                        decoration: BoxDecoration(boxShadow: const [BoxShadow(color: Color(0x22000000), blurRadius: 12, offset: Offset(0, 5))]),
                        child: LabelPreview(
                          template: _template!,
                          business: _business,
                          product: widget.item.name,
                          code: _code,
                          price: widget.item.price,
                                            ),
                      ),
                    ),
                  ),
                ),
        ),
      ],
    ),
  );

  Widget _detailCard(double s) => Container(
    padding: EdgeInsets.all(13*s),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18*s), border: Border.all(color: AppColors.lightCardBorder)),
    child: Row(children: [
      Container(width: 42*s, height: 42*s, decoration: BoxDecoration(color: AppColors.primary.withValues(alpha:.10), shape: BoxShape.circle), child: Icon(Icons.inventory_2_rounded, color: AppColors.primary, size: 20*s)),
      SizedBox(width: 10*s),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(widget.item.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 13*s, fontWeight: FontWeight.w800)), SizedBox(height: 3*s), Text('Barcode: $_code', style: TextStyle(fontSize: 10.5*s, color: AppColors.lightTextSecondary, fontWeight: FontWeight.w600))])),
      Text('${CurrencyFormatter.label} ${_money(widget.item.price)}', style: TextStyle(fontSize: 12*s, color: AppColors.primary, fontWeight: FontWeight.w900)),
    ]),
  );

  Widget _action(double s, IconData icon, String title, Color color, VoidCallback onTap) => SizedBox(height: 50*s, child: OutlinedButton.icon(onPressed: _busy ? null : onTap, icon: Icon(icon, size: 19*s, color: color), label: Text(title, style: TextStyle(fontSize: 11*s, fontWeight: FontWeight.w800, color: color)), style: OutlinedButton.styleFrom(side: BorderSide(color: color.withValues(alpha:.25)), backgroundColor: color.withValues(alpha:.05), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15*s)))));
}
