import 'package:flutter/material.dart';
import '../reports/report_repository.dart';
import '../reports/reports_screen.dart';

/// Stock In Report: every purchase that added stock (product, supplier,
/// quantity, rate, amount) with From / To dates, search, Save / Share / Print.
class StockInReportScreen extends StatelessWidget {
  const StockInReportScreen({super.key});

  @override
  Widget build(BuildContext context) => const ReportsScreen(
        initialType: ReportType.stockIn,
        singleType: true,
        title: 'Stock In Report',
      );
}
