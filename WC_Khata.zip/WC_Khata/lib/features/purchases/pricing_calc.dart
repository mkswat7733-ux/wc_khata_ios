/// Purchase-price / profit-% / retail-price formulas, in one place.
///
/// Profit % is measured on the SALE (retail) price - the way shops and
/// pharmacies quote margin:
///
///   profit        = retail - cost
///   profit %      = profit / retail * 100          (margin)
///   retail        = cost / (1 - profit % / 100)
///
/// Example: cost 90 and 10 % profit -> retail 100 (profit 10 = 10 % of 100);
///          cost 90 and retail 100  -> profit % 10.
class PricingCalc {
  PricingCalc._();

  /// 100 % margin would need an infinite retail price.
  static const double maxMargin = 99.99;

  static double r2(double v) => (v * 100).roundToDouble() / 100;

  /// Retail price for [cost] and a [marginPct] profit. 0 when cost is 0.
  static double retailFromMargin(double cost, double marginPct) {
    if (!cost.isFinite || cost <= 0) return 0;
    final m = marginPct.isFinite ? marginPct.clamp(0.0, maxMargin).toDouble() : 0.0;
    return r2(cost / (1 - m / 100));
  }

  /// Profit % of the retail price. Negative = selling below cost (a loss).
  static double marginFromRetail(double cost, double retail) {
    if (!retail.isFinite || retail <= 0) return 0;
    final c = cost.isFinite && cost > 0 ? cost : 0.0;
    return r2((retail - c) / retail * 100);
  }

  /// Profit (negative = loss) on one unit.
  static double profitPerUnit(double cost, double retail) => r2(retail - cost);

  /// Text for a percentage without useless zeros: 10, 12.5, 8.33.
  static String pctText(double v) {
    if (v == 0) return '0';
    final t = v.toStringAsFixed(2);
    return t.contains('.') ? t.replaceFirst(RegExp(r'0+$'), '').replaceFirst(RegExp(r'\.$'), '') : t;
  }
}
