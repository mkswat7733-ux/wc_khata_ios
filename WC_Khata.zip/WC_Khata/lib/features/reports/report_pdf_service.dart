import 'dart:io';
import 'dart:typed_data';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:share_plus/share_plus.dart';

import '../../core/utils/currency_formatter.dart';
import '../../data/repositories/profile_repository.dart';
import 'report_repository.dart';
import '../../core/services/thermal_printer_service.dart';

/// Builds a proper A4 report PDF and handles Save / Share / Print.
class ReportPdfService {
  ReportPdfService._();
  static final ReportPdfService instance = ReportPdfService._();

  static const MethodChannel _native = MethodChannel('wc_khata/whatsapp');

  static const _months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

  static String _date(DateTime d) => '${d.day.toString().padLeft(2, '0')} ${_months[d.month - 1]} ${d.year}';

  static String _stamp(DateTime d) {
    final h = d.hour % 12 == 0 ? 12 : d.hour % 12;
    final m = d.minute.toString().padLeft(2, '0');
    return '${_date(d)}, ${h.toString().padLeft(2, '0')}:$m ${d.hour >= 12 ? 'PM' : 'AM'}';
  }

  static String fileName(ReportData data) {
    String f(DateTime d) =>
        '${d.year}${d.month.toString().padLeft(2, '0')}${d.day.toString().padLeft(2, '0')}';
    final base = data.type.title.replaceAll(' ', '_');
    return '${base}_${f(data.from)}_${f(data.to)}.pdf';
  }

  Future<Uint8List> build(ReportData data) async {
    final profile = await ProfileRepository().getOrCreate();
    final businessName = (profile.name?.trim().isNotEmpty ?? false) ? profile.name!.trim() : 'WC Khata';
    final address = profile.address?.trim() ?? '';

    final regular = pw.Font.ttf(await rootBundle.load('assets/fonts/NotoSans-Regular.ttf'));
    final naskh = pw.Font.ttf(await rootBundle.load('assets/fonts/NotoNaskhArabic-Regular.ttf'));

    final doc = pw.Document(
      title: data.type.title,
      author: businessName,
      theme: pw.ThemeData.withFont(base: regular, bold: regular, italic: regular, boldItalic: regular, fontFallback: [naskh]),
    );

    const blue = PdfColor.fromInt(0xFF2F6FED);
    const lightBlue = PdfColor.fromInt(0xFFEAF1FF);
    const border = PdfColor.fromInt(0xFFD0D5DD);
    const textMuted = PdfColor.fromInt(0xFF667085);
    const green = PdfColor.fromInt(0xFF12805C);
    const red = PdfColor.fromInt(0xFFD92D20);
    final generated = DateTime.now();
    final symbol = CurrencyFormatter.defaultSymbol;
    // Cashbook and both ledgers carry an opening / closing balance row.
    final isCashbook = data.openingLabel != null;

    PdfColor toneColor(int? tone) => tone == 1 ? green : (tone == -1 ? red : PdfColors.black);

    pw.Widget cell(String text, {required bool numeric, bool bold = false, PdfColor? color, double size = 8, PdfColor? bg}) {
      return pw.Container(
        color: bg,
        padding: const pw.EdgeInsets.symmetric(horizontal: 4, vertical: 5),
        alignment: numeric ? pw.Alignment.centerRight : pw.Alignment.centerLeft,
        child: pw.Text(
          text,
          textAlign: numeric ? pw.TextAlign.right : pw.TextAlign.left,
          style: pw.TextStyle(fontSize: size, color: color ?? PdfColors.black, fontWeight: bold ? pw.FontWeight.bold : pw.FontWeight.normal),
        ),
      );
    }

    final columnWidths = <int, pw.TableColumnWidth>{
      for (var i = 0; i < data.widths.length; i++) i: pw.FlexColumnWidth(data.widths[i]),
    };

    final tableRows = <pw.TableRow>[];

    // Header row
    tableRows.add(pw.TableRow(
      repeat: true,
      decoration: const pw.BoxDecoration(color: blue),
      children: [
        for (var i = 0; i < data.headers.length; i++)
          cell(data.headers[i], numeric: data.numericColumns.contains(i) && i != 0, bold: true, color: PdfColors.white, size: 8.5),
      ],
    ));

    // Cashbook: opening balance row
    if (isCashbook) {
      final cells = List<String>.filled(data.headers.length, '');
      cells[2] = 'Opening Balance';
      cells[data.headers.length - 1] = data.openingLabel ?? '0.00';
      tableRows.add(pw.TableRow(
        decoration: const pw.BoxDecoration(color: lightBlue),
        children: [
          for (var i = 0; i < cells.length; i++)
            cell(cells[i], numeric: data.numericColumns.contains(i) && i != 0, bold: true, color: blue),
        ],
      ));
    }

    // Data rows
    for (var r = 0; r < data.rows.length; r++) {
      final row = data.rows[r];
      final bg = r.isOdd ? const PdfColor.fromInt(0xFFF8FAFC) : null;
      tableRows.add(pw.TableRow(
        children: [
          for (var i = 0; i < row.cells.length; i++)
            cell(
              row.cells[i],
              numeric: data.numericColumns.contains(i) && i != 0,
              bg: bg,
              // Colour only the amount columns.
              color: data.numericColumns.contains(i) && i != 0 && !(isCashbook && i == data.headers.length - 1)
                  ? _amountTone(data, i, row)
                  : null,
            ),
        ],
      ));
    }

    // Cashbook closing row / other totals row
    if (data.totals != null) {
      final totals = List<String>.from(data.totals!);
      tableRows.add(pw.TableRow(
        decoration: const pw.BoxDecoration(color: lightBlue),
        children: [
          for (var i = 0; i < totals.length; i++)
            cell(totals[i], numeric: data.numericColumns.contains(i) && i != 0, bold: true, color: blue, size: 8.5),
        ],
      ));
    }
    if (isCashbook) {
      final cells = List<String>.filled(data.headers.length, '');
      cells[2] = 'Closing Balance';
      cells[data.headers.length - 1] = data.closingLabel ?? '0.00';
      tableRows.add(pw.TableRow(
        decoration: const pw.BoxDecoration(color: blue),
        children: [
          for (var i = 0; i < cells.length; i++)
            cell(cells[i], numeric: data.numericColumns.contains(i) && i != 0, bold: true, color: PdfColors.white, size: 9),
        ],
      ));
    }

    pw.Widget summaryBox(ReportSummaryItem item) => pw.Container(
          width: 120,
          padding: const pw.EdgeInsets.symmetric(horizontal: 8, vertical: 6),
          decoration: pw.BoxDecoration(
            color: PdfColors.white,
            border: pw.Border.all(color: border, width: 0.8),
            borderRadius: pw.BorderRadius.circular(5),
          ),
          child: pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Text(item.label, style: const pw.TextStyle(fontSize: 7.5, color: textMuted)),
              pw.SizedBox(height: 3),
              pw.Text(item.value,
                  style: pw.TextStyle(fontSize: 10.5, fontWeight: pw.FontWeight.bold, color: toneColor(item.tone))),
            ],
          ),
        );

    doc.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.fromLTRB(28, 28, 28, 34),
        header: (context) {
          if (context.pageNumber > 1) {
            return pw.Container(
              padding: const pw.EdgeInsets.only(bottom: 6),
              margin: const pw.EdgeInsets.only(bottom: 8),
              decoration: const pw.BoxDecoration(border: pw.Border(bottom: pw.BorderSide(color: border, width: 0.8))),
              child: pw.Row(
                mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                children: [
                  pw.Text('$businessName  |  ${data.type.title}', style: const pw.TextStyle(fontSize: 8.5, color: textMuted)),
                  pw.Text('${_date(data.from)} - ${_date(data.to)}', style: const pw.TextStyle(fontSize: 8.5, color: textMuted)),
                ],
              ),
            );
          }
          return pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Row(
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                children: [
                  pw.Expanded(
                    child: pw.Column(
                      crossAxisAlignment: pw.CrossAxisAlignment.start,
                      children: [
                        pw.Text(businessName, style: pw.TextStyle(fontSize: 18, fontWeight: pw.FontWeight.bold, color: blue)),
                        if (address.isNotEmpty) pw.Padding(padding: const pw.EdgeInsets.only(top: 2), child: pw.Text(address, style: const pw.TextStyle(fontSize: 8.5, color: textMuted))),
                      ],
                    ),
                  ),
                  pw.Column(
                    crossAxisAlignment: pw.CrossAxisAlignment.end,
                    children: [
                      pw.Text(data.type.title.toUpperCase(), style: pw.TextStyle(fontSize: 13, fontWeight: pw.FontWeight.bold)),
                      pw.SizedBox(height: 3),
                      pw.Text('Period: ${_date(data.from)} - ${_date(data.to)}', style: const pw.TextStyle(fontSize: 8.5, color: textMuted)),
                      pw.Text('Generated: ${_stamp(generated)}', style: const pw.TextStyle(fontSize: 8.5, color: textMuted)),
                      pw.Text('Amounts in $symbol', style: const pw.TextStyle(fontSize: 8.5, color: textMuted)),
                    ],
                  ),
                ],
              ),
              pw.SizedBox(height: 8),
              pw.Divider(color: blue, thickness: 1.4),
              pw.SizedBox(height: 8),
            ],
          );
        },
        footer: (context) => pw.Container(
          padding: const pw.EdgeInsets.only(top: 6),
          decoration: const pw.BoxDecoration(border: pw.Border(top: pw.BorderSide(color: border, width: 0.8))),
          child: pw.Row(
            mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
            children: [
              pw.Text('WC Khata', style: const pw.TextStyle(fontSize: 8, color: textMuted)),
              pw.Text('Page ${context.pageNumber} of ${context.pagesCount}', style: const pw.TextStyle(fontSize: 8, color: textMuted)),
            ],
          ),
        ),
        build: (context) => [
          pw.Wrap(spacing: 8, runSpacing: 8, children: [for (final s in data.summary) summaryBox(s)]),
          pw.SizedBox(height: 12),
          if (data.rows.isEmpty)
            pw.Container(
              width: double.infinity,
              padding: const pw.EdgeInsets.symmetric(vertical: 26),
              decoration: pw.BoxDecoration(border: pw.Border.all(color: border, width: 0.8), borderRadius: pw.BorderRadius.circular(5)),
              child: pw.Center(child: pw.Text('No records found for this period.', style: const pw.TextStyle(fontSize: 10, color: textMuted))),
            ),
          if (data.rows.isNotEmpty || isCashbook)
            pw.Table(
              columnWidths: columnWidths,
              border: const pw.TableBorder(
                horizontalInside: pw.BorderSide(color: border, width: 0.4),
                bottom: pw.BorderSide(color: border, width: 0.8),
                left: pw.BorderSide(color: border, width: 0.8),
                right: pw.BorderSide(color: border, width: 0.8),
                top: pw.BorderSide(color: border, width: 0.8),
              ),
              children: tableRows,
            ),
        ],
      ),
    );

    return doc.save();
  }

  /// Colour for an amount cell: red for balances still pending, green for
  /// cash-in / profit, otherwise black.
  PdfColor? _amountTone(ReportData data, int col, ReportRow row) {
    if (data.type == ReportType.cashbook) {
      if (col == 4) return const PdfColor.fromInt(0xFF12805C);
      if (col == 5) return const PdfColor.fromInt(0xFFD92D20);
      return null;
    }
    if (data.type == ReportType.customerLedger || data.type == ReportType.supplierLedger) {
      if (col == 4) return const PdfColor.fromInt(0xFFD92D20);
      if (col == 5) return const PdfColor.fromInt(0xFF12805C);
      return null;
    }
    if (data.type == ReportType.items && col == data.headers.length - 2) {
      return row.tone == -1 ? const PdfColor.fromInt(0xFFD92D20) : const PdfColor.fromInt(0xFF12805C);
    }
    if (data.type == ReportType.stockIn && col == 4) return const PdfColor.fromInt(0xFF12805C);
    if (data.type == ReportType.stockOut && col == 5) return const PdfColor.fromInt(0xFFD92D20);
    if (data.type == ReportType.expenses && col == 4) return const PdfColor.fromInt(0xFFD92D20);
    final lastCol = data.headers.length - 1;
    if ((data.type == ReportType.sales || data.type == ReportType.purchase) && col == lastCol && row.tone == -1) {
      return const PdfColor.fromInt(0xFFD92D20);
    }
    return null;
  }

  Future<File> _writeTemp(ReportData data, Uint8List bytes) async {
    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/${fileName(data)}');
    await file.writeAsBytes(bytes, flush: true);
    return file;
  }

  /// Opens the system "Save as" dialog so the user picks the folder and file
  /// name (same as the invoice Download button). If that dialog is not
  /// available it falls back to the Downloads folder so the PDF is never lost.
  /// Returns a user message.
  Future<String> save(ReportData data) async {
    final bytes = await build(data);
    final name = fileName(data);
    try {
      final path = await FilePicker.platform.saveFile(
        dialogTitle: 'Save report',
        fileName: name,
        type: FileType.custom,
        allowedExtensions: const ['pdf'],
        bytes: bytes,
      );
      if (path == null) return 'Save cancelled.';
      return 'PDF saved successfully.';
    } catch (_) {
      // fall through to the Downloads folder
    }
    final file = await _writeTemp(data, bytes);
    final savedPath = await _native.invokeMethod<String>('saveInvoicePdf', {
      'path': file.path,
      'fileName': name,
    });
    return switch (savedPath) {
      null => 'Could not save PDF. Please try again.',
      'permission_required' => 'Storage permission is required on this Android version. Please allow it and tap Save again.',
      _ => 'PDF saved in Downloads: $name',
    };
  }

  Future<void> share(ReportData data) async {
    final bytes = await build(data);
    final file = await _writeTemp(data, bytes);
    await Share.shareXFiles([XFile(file.path, mimeType: 'application/pdf')], text: data.type.title);
  }

  Future<void> printReport(ReportData data) async {
    final bytes = await build(data);
    await ThermalPrinterService.instance.printPdf(bytes);
  }
}
