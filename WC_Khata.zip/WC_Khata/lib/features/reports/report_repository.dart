import '../../core/database/app_database.dart';
import '../../core/database/database_constants.dart';
import '../sale/sale_settlement.dart';
import '../../data/repositories/finance_category_repository.dart';
import '../../data/repositories/transaction_repository.dart';
import '../../data/models/transaction_model.dart';

enum ReportType { sales, purchase, items, cashbook, customerLedger, supplierLedger, stockIn, stockOut, expenses }

/// Report types shown as tabs on the Reports screen. Stock In / Stock Out and
/// Expenses have their own screens (Products screen and Expenses screen).
const List<ReportType> kReportTabs = [
  ReportType.sales,
  ReportType.purchase,
  ReportType.items,
  ReportType.cashbook,
  ReportType.customerLedger,
  ReportType.supplierLedger,
];

extension ReportTypeX on ReportType {
  String get title => switch (this) {
        ReportType.sales => 'Sales Report',
        ReportType.purchase => 'Purchase Report',
        ReportType.items => 'Products Wise Report',
        ReportType.cashbook => 'Cashbook Report',
        ReportType.customerLedger => 'Customer Ledger',
        ReportType.supplierLedger => 'Supplier Ledger',
        ReportType.stockIn => 'Stock In Report',
        ReportType.stockOut => 'Stock Out Report',
        ReportType.expenses => 'Expense Report',
      };

  String get tabLabel => switch (this) {
        ReportType.sales => 'Sales Report',
        ReportType.purchase => 'Purchase Report',
        ReportType.items => 'Products Wise Report',
        ReportType.cashbook => 'Cashbook Report',
        ReportType.customerLedger => 'Customer Ledger',
        ReportType.supplierLedger => 'Supplier Ledger',
        ReportType.stockIn => 'Stock In Report',
        ReportType.stockOut => 'Stock Out Report',
        ReportType.expenses => 'Expense Report',
      };

  String get searchHint => switch (this) {
        ReportType.sales => 'Search invoice, customer or payment',
        ReportType.purchase => 'Search product or supplier',
        ReportType.items => 'Search product',
        ReportType.cashbook => 'Search source, note or method',
        ReportType.customerLedger => 'Search customer or transaction',
        ReportType.supplierLedger => 'Search supplier or transaction',
        ReportType.stockIn => 'Search product or supplier',
        ReportType.stockOut => 'Search product, invoice or customer',
        ReportType.expenses => 'Search title or category',
      };
}

/// One generic report row. Every report is flattened into this shape so the
/// on-screen table and the A4 PDF can share a single renderer.
class ReportRow {
  /// Plain cell texts, in column order.
  final List<String> cells;

  /// Lower-cased text used by the search bar.
  final String searchText;

  /// Optional tint hint for amount-like cells (income = green, expense = red).
  final int? tone; // 1 = positive, -1 = negative, null = neutral

  const ReportRow({required this.cells, required this.searchText, this.tone});
}

class ReportSummaryItem {
  final String label;
  final String value;
  final int? tone;
  const ReportSummaryItem(this.label, this.value, {this.tone});
}

class ReportData {
  final ReportType type;
  final DateTime from;
  final DateTime to;
  final List<String> headers;

  /// Relative column widths (flex), same length as [headers].
  final List<double> widths;

  /// Column indexes that hold numbers (right-aligned).
  final Set<int> numericColumns;
  final List<ReportRow> rows;

  /// Totals row shown at the bottom of the table (same length as headers).
  final List<String>? totals;
  final List<ReportSummaryItem> summary;

  /// Cashbook only.
  final String? openingLabel;
  final String? closingLabel;

  const ReportData({
    required this.type,
    required this.from,
    required this.to,
    required this.headers,
    required this.widths,
    required this.numericColumns,
    required this.rows,
    required this.totals,
    required this.summary,
    this.openingLabel,
    this.closingLabel,
  });
}

class ReportRepository {
  static String _two(double v) {
    final neg = v < 0;
    final abs = v.abs();
    final fixed = abs.toStringAsFixed(2);
    final parts = fixed.split('.');
    final intPart = parts[0];
    final buf = StringBuffer();
    for (var i = 0; i < intPart.length; i++) {
      final fromEnd = intPart.length - i;
      buf.write(intPart[i]);
      if (fromEnd > 1 && fromEnd % 3 == 1) buf.write(',');
    }
    return '${neg ? '-' : ''}${buf.toString()}.${parts[1]}';
  }

  static String qty(double v) => v == v.truncateToDouble() ? v.toStringAsFixed(0) : v.toStringAsFixed(2);

  static String _d(DateTime d) {
    String p(int n) => n.toString().padLeft(2, '0');
    return '${p(d.day)}/${p(d.month)}/${d.year}';
  }

  static DateTime _start(DateTime d) => DateTime(d.year, d.month, d.day);
  static DateTime _end(DateTime d) => DateTime(d.year, d.month, d.day, 23, 59, 59, 999);

  /// [query] filters rows (and the totals follow the filtered rows), except for
  /// the Cashbook where opening/closing balances always cover the full period.
  Future<ReportData> load(ReportType type, DateTime from, DateTime to, {String query = '', int? supplierId, int? customerId, int? categoryId}) {
    final q = query.trim().toLowerCase();
    switch (type) {
      case ReportType.sales:
        return _sales(from, to, q);
      case ReportType.purchase:
        return _purchase(from, to, q);
      case ReportType.items:
        return _items(from, to, q);
      case ReportType.cashbook:
        return _cashbook(from, to, q);
      case ReportType.customerLedger:
        return _customerLedger(from, to, q, customerId: customerId);
      case ReportType.supplierLedger:
        return _supplierLedger(from, to, q, supplierId: supplierId);
      case ReportType.stockIn:
        return _stockIn(from, to, q);
      case ReportType.stockOut:
        return _stockOut(from, to, q);
      case ReportType.expenses:
        return _expenses(from, to, q, categoryId: categoryId);
    }
  }

  // ------------------------------------------------------------------ sales

  Future<ReportData> _sales(DateTime from, DateTime to, String q) async {
    final db = await AppDatabase.instance.database;
    final rows = await db.rawQuery('''
      SELECT s.id, s.invoice_no, s.date, s.payment_type, s.total, s.paid_amount, s.discount_amount,
             COALESCE(p.name, 'Walk-in') AS customer
      FROM ${DBConstants.tableSaleInvoices} s
      LEFT JOIN ${DBConstants.tableLedgerParties} p ON p.id = s.customer_id
      WHERE s.date >= ? AND s.date <= ?
      ORDER BY s.date ASC
    ''', [_start(from).toIso8601String(), _end(to).toIso8601String()]);
    // Paid = payment taken at the sale + everything the customer paid later
    // through the ledger, so a cleared khata also clears the report.
    final settled = await SaleSettlement.paidBySale(db);

    double total = 0, paid = 0, discount = 0, cash = 0, credit = 0;
    final out = <ReportRow>[];
    var n = 0;
    for (final r in rows) {
      final t = (r['total'] as num).toDouble();
      final pd = settled[r['id'] as int] ?? (r['paid_amount'] as num).toDouble();
      final dc = (r['discount_amount'] as num?)?.toDouble() ?? 0;
      final date = DateTime.tryParse(r['date'] as String) ?? from;
      final pay = (r['payment_type'] as String);
      final inv = r['invoice_no'] as String;
      final cust = r['customer'] as String;
      final payLabel = pay == 'credit' ? 'Credit' : 'Cash';
      final hay = '$inv $cust $payLabel ${_d(date)}'.toLowerCase();
      if (q.isNotEmpty && !hay.contains(q)) continue;
      n++;
      total += t;
      paid += pd;
      discount += dc;
      if (pay == 'credit') {
        credit += t;
      } else {
        cash += t;
      }
      out.add(ReportRow(
        cells: ['$n', _d(date), inv, cust, payLabel, _two(t), _two(pd), _two(t - pd)],
        searchText: '$inv $cust $payLabel ${_d(date)}'.toLowerCase(),
        tone: (t - pd) > 0.005 ? -1 : null,
      ));
    }
    return ReportData(
      type: ReportType.sales,
      from: from,
      to: to,
      headers: const ['#', 'Date', 'Invoice', 'Customer', 'Type', 'Total', 'Paid', 'Balance'],
      widths: const [0.55, 1.3, 2.3, 1.9, 1.0, 1.4, 1.4, 1.4],
      numericColumns: const {0, 5, 6, 7},
      rows: out,
      totals: ['', '', '', '', 'Total', _two(total), _two(paid), _two(total - paid)],
      summary: [
        ReportSummaryItem('Invoices', '${out.length}'),
        ReportSummaryItem('Total Sales', _two(total), tone: 1),
        ReportSummaryItem('Received', _two(paid), tone: 1),
        ReportSummaryItem('Pending', _two(total - paid), tone: (total - paid) > 0.005 ? -1 : null),
        ReportSummaryItem('Cash Sales', _two(cash)),
        ReportSummaryItem('Credit Sales', _two(credit)),
        if (discount > 0) ReportSummaryItem('Discount Given', _two(discount)),
      ],
    );
  }

  // --------------------------------------------------------------- purchase

  Future<ReportData> _purchase(DateTime from, DateTime to, String q) async {
    final db = await AppDatabase.instance.database;
    // Single-product purchases + the products of multi-item purchase bills.
    // A bill's discount and paid amount are shared between its products in
    // proportion to their cost, so the rows add up to the bill.
    final rows = await db.rawQuery('''
      SELECT * FROM (
        SELECT p.item_name AS name, p.unit AS unit, p.qty AS qty, p.purchase_type AS purchase_type,
               p.total AS purchase_amount, p.unit_cost AS purchase_unit_price, p.paid AS purchase_paid,
               p.purchase_date AS purchase_date, COALESCE(s.name, 'Cash Purchase') AS supplier
        FROM ${DBConstants.tablePurchases} p
        LEFT JOIN ${DBConstants.tableLedgerParties} s ON s.id = p.supplier_id
        WHERE p.purchase_date >= ? AND p.purchase_date <= ?
        UNION ALL
        SELECT ii.item_name, ii.unit, ii.qty, inv.payment_type,
               CASE WHEN inv.subtotal > 0 THEN ii.total * inv.total / inv.subtotal ELSE 0 END,
               ii.unit_cost,
               CASE WHEN inv.subtotal > 0 THEN inv.paid_amount * ii.total / inv.subtotal ELSE 0 END,
               inv.date, COALESCE(s2.name, 'Cash Purchase')
        FROM ${DBConstants.tablePurchaseInvoiceItems} ii
        JOIN ${DBConstants.tablePurchaseInvoices} inv ON inv.id = ii.purchase_invoice_id
        LEFT JOIN ${DBConstants.tableLedgerParties} s2 ON s2.id = inv.supplier_id
        WHERE inv.date >= ? AND inv.date <= ?
      ) ORDER BY purchase_date ASC
    ''', [_start(from).toIso8601String(), _end(to).toIso8601String(), _start(from).toIso8601String(), _end(to).toIso8601String()]);

    double total = 0, paid = 0;
    final out = <ReportRow>[];
    var n = 0;
    for (final r in rows) {
      final amount = (r['purchase_amount'] as num).toDouble();
      final pd = (r['purchase_paid'] as num?)?.toDouble() ?? 0;
      final date = DateTime.tryParse(r['purchase_date'] as String) ?? from;
      final name = r['name'] as String;
      final supplier = r['supplier'] as String;
      final unit = r['unit'] as String;
      final boughtQty = (r['qty'] as num).toDouble();
      final hay = '$name $supplier ${_d(date)}'.toLowerCase();
      if (q.isNotEmpty && !hay.contains(q)) continue;
      n++;
      total += amount;
      paid += pd;
      out.add(ReportRow(
        cells: ['$n', _d(date), name, supplier, '${qty(boughtQty)} $unit', _two(amount), _two(pd), _two(amount - pd)],
        searchText: '$name $supplier ${_d(date)}'.toLowerCase(),
        tone: (amount - pd) > 0.005 ? -1 : null,
      ));
    }
    return ReportData(
      type: ReportType.purchase,
      from: from,
      to: to,
      headers: const ['#', 'Date', 'Product', 'Supplier', 'Qty', 'Amount', 'Paid', 'Balance'],
      widths: const [0.55, 1.3, 2.2, 1.9, 1.3, 1.4, 1.4, 1.4],
      numericColumns: const {0, 5, 6, 7},
      rows: out,
      totals: ['', '', '', '', 'Total', _two(total), _two(paid), _two(total - paid)],
      summary: [
        ReportSummaryItem('Purchases', '${out.length}'),
        ReportSummaryItem('Total Purchase', _two(total)),
        ReportSummaryItem('Paid', _two(paid), tone: 1),
        ReportSummaryItem('Payable', _two(total - paid), tone: (total - paid) > 0.005 ? -1 : null),
      ],
    );
  }


  // --------------------------------------------------------------- stock in

  /// Every purchase that added stock (single-product purchases and the
  /// products of purchase bills), oldest first.
  Future<ReportData> _stockIn(DateTime from, DateTime to, String q) async {
    final db = await AppDatabase.instance.database;
    final f = _start(from).toIso8601String();
    final t = _end(to).toIso8601String();
    final rows = await db.rawQuery('''
      SELECT * FROM (
        SELECT p.item_name AS name, p.unit AS unit, p.qty AS qty, p.unit_cost AS rate,
               p.total AS amount, p.purchase_date AS dt, COALESCE(s.name, 'Cash Purchase') AS supplier
        FROM ${DBConstants.tablePurchases} p
        LEFT JOIN ${DBConstants.tableLedgerParties} s ON s.id = p.supplier_id
        WHERE p.purchase_date >= ? AND p.purchase_date <= ?
        UNION ALL
        SELECT ii.item_name, ii.unit, ii.qty, ii.unit_cost,
               CASE WHEN inv.subtotal > 0 THEN ii.total * inv.total / inv.subtotal ELSE ii.total END,
               inv.date, COALESCE(s2.name, 'Cash Purchase')
        FROM ${DBConstants.tablePurchaseInvoiceItems} ii
        JOIN ${DBConstants.tablePurchaseInvoices} inv ON inv.id = ii.purchase_invoice_id
        LEFT JOIN ${DBConstants.tableLedgerParties} s2 ON s2.id = inv.supplier_id
        WHERE inv.date >= ? AND inv.date <= ?
      ) ORDER BY dt ASC
    ''', [f, t, f, t]);

    double total = 0;
    final products = <String>{};
    final out = <ReportRow>[];
    var n = 0;
    for (final r in rows) {
      final date = DateTime.tryParse(r['dt'] as String) ?? from;
      final name = r['name'] as String;
      final supplier = r['supplier'] as String;
      final unit = (r['unit'] as String?) ?? '';
      final q0 = (r['qty'] as num).toDouble();
      final rate = (r['rate'] as num).toDouble();
      final amount = (r['amount'] as num).toDouble();
      final hay = '$name $supplier ${_d(date)}'.toLowerCase();
      if (q.isNotEmpty && !hay.contains(q)) continue;
      n++;
      total += amount;
      products.add(name.toLowerCase());
      out.add(ReportRow(
        cells: ['$n', _d(date), name, supplier, '${qty(q0)} $unit'.trim(), _two(rate), _two(amount)],
        searchText: hay,
        tone: 1,
      ));
    }
    return ReportData(
      type: ReportType.stockIn,
      from: from,
      to: to,
      headers: const ['#', 'Date', 'Product', 'Supplier', 'Qty In', 'Rate', 'Amount'],
      widths: const [0.55, 1.3, 2.4, 2.0, 1.4, 1.3, 1.5],
      numericColumns: const {0, 4, 5, 6},
      rows: out,
      totals: ['', '', '', '', '', 'Total', _two(total)],
      summary: [
        ReportSummaryItem('Entries', '${out.length}'),
        ReportSummaryItem('Products', '${products.length}'),
        ReportSummaryItem('Stock In Value', _two(total), tone: 1),
      ],
    );
  }

  // -------------------------------------------------------------- stock out

  /// Every product line sold on a sale invoice, oldest first.
  Future<ReportData> _stockOut(DateTime from, DateTime to, String q) async {
    final db = await AppDatabase.instance.database;
    final rows = await db.rawQuery('''
      SELECT s.date AS dt, s.invoice_no AS invoice, si.item_name AS name, si.qty AS qty,
             si.unit_price AS rate, si.total AS amount, COALESCE(i.unit, '') AS unit,
             COALESCE(p.name, 'Walk-in') AS customer
      FROM ${DBConstants.tableSaleItems} si
      JOIN ${DBConstants.tableSaleInvoices} s ON s.id = si.sale_id
      LEFT JOIN ${DBConstants.tableItems} i ON i.id = si.item_id
      LEFT JOIN ${DBConstants.tableLedgerParties} p ON p.id = s.customer_id
      WHERE s.date >= ? AND s.date <= ?
      ORDER BY s.date ASC, si.id ASC
    ''', [_start(from).toIso8601String(), _end(to).toIso8601String()]);

    double total = 0;
    final products = <String>{};
    final out = <ReportRow>[];
    var n = 0;
    for (final r in rows) {
      final date = DateTime.tryParse(r['dt'] as String) ?? from;
      final inv = r['invoice'] as String;
      final name = r['name'] as String;
      final customer = r['customer'] as String;
      final unit = (r['unit'] as String?) ?? '';
      final q0 = (r['qty'] as num).toDouble();
      final rate = (r['rate'] as num).toDouble();
      final amount = (r['amount'] as num).toDouble();
      final hay = '$inv $name $customer ${_d(date)}'.toLowerCase();
      if (q.isNotEmpty && !hay.contains(q)) continue;
      n++;
      total += amount;
      products.add(name.toLowerCase());
      out.add(ReportRow(
        cells: ['$n', _d(date), inv, name, customer, '${qty(q0)} $unit'.trim(), _two(rate), _two(amount)],
        searchText: hay,
        tone: -1,
      ));
    }
    return ReportData(
      type: ReportType.stockOut,
      from: from,
      to: to,
      headers: const ['#', 'Date', 'Invoice', 'Product', 'Customer', 'Qty Out', 'Rate', 'Amount'],
      widths: const [0.55, 1.3, 2.0, 2.2, 1.8, 1.4, 1.3, 1.5],
      numericColumns: const {0, 5, 6, 7},
      rows: out,
      totals: ['', '', '', '', '', '', 'Total', _two(total)],
      summary: [
        ReportSummaryItem('Entries', '${out.length}'),
        ReportSummaryItem('Products', '${products.length}'),
        ReportSummaryItem('Stock Out Value', _two(total), tone: -1),
      ],
    );
  }

  // --------------------------------------------------------------- expenses

  /// Running expenses (stock purchases / supplier payments are not expenses),
  /// optionally for one category. Used by the Expenses screen Print button.
  Future<ReportData> _expenses(DateTime from, DateTime to, String q, {int? categoryId}) async {
    final txs = await TransactionRepository().getAll(
      type: TransactionType.expense,
      from: _start(from),
      to: _end(to),
      categoryId: categoryId,
      limit: 100000,
      excludePurchases: true,
    );
    final cats = await FinanceCategoryRepository().getExpenseCategories();
    final names = {for (final c in cats) c.id: c.name};
    txs.sort((a, b) => a.date.compareTo(b.date));

    double total = 0;
    final out = <ReportRow>[];
    var n = 0;
    for (final tx in txs) {
      final cat = names[tx.categoryId] ?? 'Uncategorized';
      final title = (tx.source?.trim().isNotEmpty ?? false) ? tx.source!.trim() : cat;
      final hay = '$title $cat ${_d(tx.date)}'.toLowerCase();
      if (q.isNotEmpty && !hay.contains(q)) continue;
      n++;
      total += tx.amount;
      out.add(ReportRow(cells: ['$n', _d(tx.date), cat, title, _two(tx.amount)], searchText: hay, tone: -1));
    }
    return ReportData(
      type: ReportType.expenses,
      from: from,
      to: to,
      headers: const ['#', 'Date', 'Category', 'Title', 'Amount'],
      widths: const [0.55, 1.3, 2.0, 3.0, 1.6],
      numericColumns: const {0, 4},
      rows: out,
      totals: ['', '', '', 'Total', _two(total)],
      summary: [
        ReportSummaryItem('Expenses', '${out.length}'),
        ReportSummaryItem('Total Expense', _two(total), tone: -1),
        if (categoryId != null) ReportSummaryItem('Category', names[categoryId] ?? '-'),
      ],
    );
  }

  // ------------------------------------------------------------- items wise

  /// One line per product: what was bought (purchase date in the period) and
  /// what was sold (sale date in the period), so purchase edits and sales both
  /// show up product by product.
  Future<ReportData> _items(DateTime from, DateTime to, String q) async {
    final db = await AppDatabase.instance.database;
    final fromIso = _start(from).toIso8601String();
    final toIso = _end(to).toIso8601String();

    final saleRows = await db.rawQuery('''
      SELECT si.item_id, si.item_name,
             SUM(si.qty) AS sold_qty,
             SUM(si.total) AS sales,
             SUM(si.qty * si.unit_cost) AS cost,
             COALESCE(i.unit, '') AS unit,
             COALESCE(i.qty, 0) AS stock
      FROM ${DBConstants.tableSaleItems} si
      JOIN ${DBConstants.tableSaleInvoices} s ON s.id = si.sale_id
      LEFT JOIN ${DBConstants.tableItems} i ON i.id = si.item_id
      WHERE s.date >= ? AND s.date <= ?
      GROUP BY si.item_id, si.item_name
    ''', [fromIso, toIso]);

    final buyRows = await db.rawQuery('''
      SELECT item_id, item_name, unit, stock,
             SUM(bought_qty) AS bought_qty, SUM(bought_total) AS bought_total
      FROM (
        SELECT p.item_id AS item_id, p.item_name AS item_name, p.unit AS unit, COALESCE(i.qty, 0) AS stock,
               p.qty AS bought_qty, p.total AS bought_total
        FROM ${DBConstants.tablePurchases} p
        LEFT JOIN ${DBConstants.tableItems} i ON i.id = p.item_id
        WHERE p.purchase_date >= ? AND p.purchase_date <= ?
        UNION ALL
        SELECT ii.item_id, ii.item_name, ii.unit, COALESCE(it.qty, 0),
               ii.qty, CASE WHEN inv.subtotal > 0 THEN ii.total * inv.total / inv.subtotal ELSE 0 END
        FROM ${DBConstants.tablePurchaseInvoiceItems} ii
        JOIN ${DBConstants.tablePurchaseInvoices} inv ON inv.id = ii.purchase_invoice_id
        LEFT JOIN ${DBConstants.tableItems} it ON it.id = ii.item_id
        WHERE inv.date >= ? AND inv.date <= ?
      )
      GROUP BY item_id, item_name, unit
    ''', [fromIso, toIso, fromIso, toIso]);

    final lines = <String, _ItemLine>{};
    _ItemLine lineFor(Object? id, String name, String unit, double stock) =>
        lines.putIfAbsent(id == null ? 'n:$name' : 'i:$id', () => _ItemLine(name, unit, stock));

    for (final r in saleRows) {
      final l = lineFor(r['item_id'], r['item_name'] as String, r['unit'] as String, (r['stock'] as num).toDouble());
      l.soldQty += (r['sold_qty'] as num).toDouble();
      l.sales += (r['sales'] as num).toDouble();
      l.cost += (r['cost'] as num).toDouble();
    }
    for (final r in buyRows) {
      final l = lineFor(r['item_id'], r['item_name'] as String, r['unit'] as String, (r['stock'] as num).toDouble());
      l.boughtQty += (r['bought_qty'] as num).toDouble();
      l.purchase += (r['bought_total'] as num).toDouble();
    }

    final sorted = lines.values.toList()
      ..sort((a, b) => (b.sales + b.purchase).compareTo(a.sales + a.purchase));

    double tBought = 0, tPurchase = 0, tSold = 0, tSales = 0, tCost = 0;
    final out = <ReportRow>[];
    var n = 0;
    for (final l in sorted) {
      if (q.isNotEmpty && !l.name.toLowerCase().contains(q)) continue;
      n++;
      tBought += l.boughtQty;
      tPurchase += l.purchase;
      tSold += l.soldQty;
      tSales += l.sales;
      tCost += l.cost;
      final profit = l.sales - l.cost;
      out.add(ReportRow(
        cells: [
          '$n',
          l.name,
          l.boughtQty > 0 ? '${qty(l.boughtQty)} ${l.unit}'.trim() : '-',
          _two(l.purchase),
          l.soldQty > 0 ? '${qty(l.soldQty)} ${l.unit}'.trim() : '-',
          _two(l.sales),
          _two(profit),
          '${qty(l.stock)} ${l.unit}'.trim(),
        ],
        searchText: l.name.toLowerCase(),
        tone: l.soldQty > 0 && profit < 0 ? -1 : (l.soldQty > 0 ? 1 : null),
      ));
    }
    final profit = tSales - tCost;
    return ReportData(
      type: ReportType.items,
      from: from,
      to: to,
      headers: const ['#', 'Product', 'Bought', 'Purchase', 'Sold', 'Sales', 'Profit', 'Stock'],
      widths: const [0.5, 2.2, 1.3, 1.4, 1.3, 1.4, 1.4, 1.3],
      numericColumns: const {0, 3, 5, 6},
      rows: out,
      totals: ['', 'Total', qty(tBought), _two(tPurchase), qty(tSold), _two(tSales), _two(profit), ''],
      summary: [
        ReportSummaryItem('Products', '${out.length}'),
        ReportSummaryItem('Total Purchase', _two(tPurchase)),
        ReportSummaryItem('Total Sales', _two(tSales)),
        ReportSummaryItem(profit < 0 ? 'Loss' : 'Profit', _two(profit.abs()), tone: profit < 0 ? -1 : 1),
      ],
    );
  }

  // --------------------------------------------------------- customer ledger

  /// Customer khata: a sale / manual "Pay" raises what the customer owes
  /// (debit), a "Receive" lowers it. Balance > 0 = the customer owes you.
  Future<ReportData> _customerLedger(DateTime from, DateTime to, String q, {int? customerId}) async {
    final db = await AppDatabase.instance.database;
    final fromIso = _start(from).toIso8601String();
    final toIso = _end(to).toIso8601String();

    final openingRow = await db.rawQuery('''
      SELECT COALESCE(SUM(CASE WHEN t.type = 'pay' THEN t.amount ELSE -t.amount END), 0) AS bal
      FROM ${DBConstants.tableLedgerTransactions} t
      INNER JOIN ${DBConstants.tableLedgerParties} p ON p.id = t.party_id
      WHERE p.type = 'customer' AND t.deleted_at IS NULL AND t.date < ?
        ${customerId == null ? '' : 'AND p.id = ?'}
    ''', customerId == null ? [fromIso] : [fromIso, customerId]);
    final opening = (openingRow.first['bal'] as num?)?.toDouble() ?? 0;

    final rows = await db.rawQuery('''
      SELECT t.id, t.type, t.amount, t.note, t.date, p.name AS customer
      FROM ${DBConstants.tableLedgerTransactions} t
      INNER JOIN ${DBConstants.tableLedgerParties} p ON p.id = t.party_id
      WHERE p.type = 'customer' AND t.deleted_at IS NULL
        AND t.date >= ? AND t.date <= ?
        ${customerId == null ? '' : 'AND p.id = ?'}
      ORDER BY t.date ASC, t.id ASC
    ''', customerId == null ? [fromIso, toIso] : [fromIso, toIso, customerId]);

    double sales = 0, received = 0, running = opening;
    final out = <ReportRow>[];
    var n = 0;
    for (final r in rows) {
      final isDebit = r['type'] == 'pay';
      final amount = (r['amount'] as num).toDouble();
      final date = DateTime.tryParse(r['date'] as String) ?? from;
      final customer = (r['customer'] as String?) ?? 'Customer';
      final note = (r['note'] as String?)?.trim() ?? '';
      if (isDebit) {
        sales += amount;
        running += amount;
      } else {
        received += amount;
        running -= amount;
      }
      final label = isDebit ? 'Sale' : 'Payment';
      final hay = '$customer $note $label ${_d(date)}'.toLowerCase();
      if (q.isNotEmpty && !hay.contains(q)) continue;
      n++;
      out.add(ReportRow(
        cells: ['$n', _d(date), customer, note.isEmpty ? label : note, isDebit ? _two(amount) : '', isDebit ? '' : _two(amount), _two(running)],
        searchText: hay,
        tone: isDebit ? -1 : 1,
      ));
    }
    final closing = opening + sales - received;
    return ReportData(
      type: ReportType.customerLedger, from: from, to: to,
      headers: const ['#', 'Date', 'Customer', 'Details', 'Sale / Debit', 'Received', 'Balance'],
      widths: const [0.55, 1.3, 2.1, 2.8, 1.5, 1.4, 1.5],
      numericColumns: const {0, 4, 5, 6}, rows: out,
      totals: ['', '', '', 'Total', _two(sales), _two(received), _two(closing)],
      summary: [
        ReportSummaryItem('Opening Balance', _two(opening), tone: opening > 0 ? -1 : (opening < 0 ? 1 : null)),
        ReportSummaryItem('Sales / Debit', _two(sales), tone: -1),
        ReportSummaryItem('Received', _two(received), tone: 1),
        ReportSummaryItem('Receivable', _two(closing), tone: closing > 0 ? -1 : (closing < 0 ? 1 : null)),
      ], openingLabel: _two(opening), closingLabel: _two(closing),
    );
  }

  // --------------------------------------------------------- supplier ledger

  Future<ReportData> _supplierLedger(DateTime from, DateTime to, String q, {int? supplierId}) async {
    final db = await AppDatabase.instance.database;
    final fromIso = _start(from).toIso8601String();
    final toIso = _end(to).toIso8601String();

    final openingRow = await db.rawQuery('''
      SELECT COALESCE(SUM(CASE WHEN t.type = 'pay' THEN t.amount ELSE -t.amount END), 0) AS bal
      FROM ${DBConstants.tableLedgerTransactions} t
      INNER JOIN ${DBConstants.tableLedgerParties} p ON p.id = t.party_id
      WHERE p.type = 'supplier' AND t.deleted_at IS NULL AND t.date < ?
        ${supplierId == null ? '' : 'AND p.id = ?'}
    ''', supplierId == null ? [fromIso] : [fromIso, supplierId]);
    final opening = (openingRow.first['bal'] as num?)?.toDouble() ?? 0;

    final rows = await db.rawQuery('''
      SELECT t.id, t.type, t.amount, t.note, t.date, p.name AS supplier
      FROM ${DBConstants.tableLedgerTransactions} t
      INNER JOIN ${DBConstants.tableLedgerParties} p ON p.id = t.party_id
      WHERE p.type = 'supplier' AND t.deleted_at IS NULL
        AND t.date >= ? AND t.date <= ?
        ${supplierId == null ? '' : 'AND p.id = ?'}
      ORDER BY t.date ASC, t.id ASC
    ''', supplierId == null ? [fromIso, toIso] : [fromIso, toIso, supplierId]);

    double purchases = 0, payments = 0, running = opening;
    final out = <ReportRow>[];
    var n = 0;
    for (final r in rows) {
      final type = r['type'] as String;
      final amount = (r['amount'] as num).toDouble();
      final date = DateTime.tryParse(r['date'] as String) ?? from;
      final supplier = (r['supplier'] as String?) ?? 'Supplier';
      final note = (r['note'] as String?)?.trim() ?? '';
      final isPurchase = type == 'pay';
      if (isPurchase) { purchases += amount; running += amount; }
      else { payments += amount; running -= amount; }
      final hay = '$supplier $note ${isPurchase ? 'Purchase' : 'Payment'} ${_d(date)}'.toLowerCase();
      if (q.isNotEmpty && !hay.contains(q)) continue;
      n++;
      out.add(ReportRow(
        cells: ['$n', _d(date), supplier, note.isEmpty ? (isPurchase ? 'Purchase' : 'Payment') : note, isPurchase ? _two(amount) : '', isPurchase ? '' : _two(amount), _two(running)],
        searchText: hay,
        tone: isPurchase ? -1 : 1,
      ));
    }
    final closing = opening + purchases - payments;
    return ReportData(
      type: ReportType.supplierLedger, from: from, to: to,
      headers: const ['#', 'Date', 'Supplier', 'Details', 'Purchase', 'Payment', 'Balance'],
      widths: const [0.55, 1.3, 2.1, 2.8, 1.4, 1.4, 1.5],
      numericColumns: const {0, 4, 5, 6}, rows: out,
      totals: ['', '', '', 'Total', _two(purchases), _two(payments), _two(closing)],
      summary: [
        ReportSummaryItem('Opening Balance', _two(opening), tone: opening > 0 ? -1 : (opening < 0 ? 1 : null)),
        ReportSummaryItem('Purchases', _two(purchases), tone: -1),
        ReportSummaryItem('Payments', _two(payments), tone: 1),
        ReportSummaryItem('Closing Balance', _two(closing), tone: closing > 0 ? -1 : (closing < 0 ? 1 : null)),
      ], openingLabel: _two(opening), closingLabel: _two(closing),
    );
  }

  // --------------------------------------------------------------- cashbook

  Future<ReportData> _cashbook(DateTime from, DateTime to, String q) async {
    final db = await AppDatabase.instance.database;
    final fromIso = _start(from).toIso8601String();
    final toIso = _end(to).toIso8601String();

    // Opening balance = everything cash-in minus cash-out before the start date.
    final openRow = await db.rawQuery('''
      SELECT COALESCE(SUM(CASE WHEN type='income' THEN amount WHEN type='expense' THEN -amount ELSE 0 END), 0) AS bal
      FROM ${DBConstants.tableTransactions}
      WHERE type IN ('income','expense') AND date < ?
    ''', [fromIso]);
    final transactionOpening = (openRow.first['bal'] as num?)?.toDouble() ?? 0;

    // Include the opening balance configured on cash accounts when the
    // account already existed before the selected From date. This makes
    // Cash Book a true period ledger: Opening = all balances carried
    // forward from before From, not only transactions.
    final accountOpeningRow = await db.rawQuery('''
      SELECT COALESCE(SUM(opening_balance), 0) AS bal
      FROM ${DBConstants.tableAccounts}
      WHERE type = 'cash' AND deleted_at IS NULL AND created_at < ?
    ''', [fromIso]);
    final configuredOpening = (accountOpeningRow.first['bal'] as num?)?.toDouble() ?? 0;
    final opening = configuredOpening + transactionOpening;

    final rows = await db.rawQuery('''
      SELECT type, amount, source, payment_method, note, date
      FROM ${DBConstants.tableTransactions}
      WHERE type IN ('income','expense') AND date >= ? AND date <= ?
      ORDER BY date ASC, id ASC
    ''', [fromIso, toIso]);

    double cashIn = 0, cashOut = 0, running = opening;
    final out = <ReportRow>[];
    var n = 0;
    for (final r in rows) {
      final isIn = r['type'] == 'income';
      final amt = (r['amount'] as num).toDouble();
      final date = DateTime.tryParse(r['date'] as String) ?? from;
      final source = (r['source'] as String?)?.trim();
      final method = (r['payment_method'] as String?)?.trim();
      final note = (r['note'] as String?)?.trim();
      final detail = [
        if (source != null && source.isNotEmpty) source,
        if (note != null && note.isNotEmpty) note,
      ].join(' - ');
      final detailText = detail.isEmpty ? (isIn ? 'Cash In' : 'Cash Out') : detail;
      if (isIn) {
        cashIn += amt;
        running += amt;
      } else {
        cashOut += amt;
        running -= amt;
      }
      final hay = '$detailText ${method ?? ''} ${_d(date)}'.toLowerCase();
      if (q.isNotEmpty && !hay.contains(q)) continue;
      n++;
      out.add(ReportRow(
        cells: ['$n', _d(date), detailText, method ?? '', isIn ? _two(amt) : '', isIn ? '' : _two(amt), _two(running)],
        searchText: '$detailText ${method ?? ''} ${_d(date)}'.toLowerCase(),
        tone: isIn ? 1 : -1,
      ));
    }
    final closing = opening + cashIn - cashOut;
    return ReportData(
      type: ReportType.cashbook,
      from: from,
      to: to,
      headers: const ['#', 'Date', 'Details', 'Method', 'Cash In', 'Cash Out', 'Balance'],
      widths: const [0.55, 1.3, 2.9, 1.3, 1.4, 1.4, 1.5],
      numericColumns: const {0, 4, 5, 6},
      rows: out,
      totals: ['', '', '', 'Total', _two(cashIn), _two(cashOut), _two(closing)],
      summary: [
        ReportSummaryItem('Opening Balance', _two(opening)),
        ReportSummaryItem('Total Cash In', _two(cashIn), tone: 1),
        ReportSummaryItem('Total Cash Out', _two(cashOut), tone: -1),
        ReportSummaryItem('Closing Balance', _two(closing), tone: closing < 0 ? -1 : 1),
      ],
      openingLabel: _two(opening),
      closingLabel: _two(closing),
    );
  }
}

class _ItemLine {
  final String name;
  final String unit;
  final double stock;
  double boughtQty = 0;
  double purchase = 0;
  double soldQty = 0;
  double sales = 0;
  double cost = 0;
  _ItemLine(this.name, this.unit, this.stock);
}
