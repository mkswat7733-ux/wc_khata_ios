import 'dart:async';

import 'package:flutter/material.dart';

import '../../app/theme/app_theme.dart';
import '../../core/utils/currency_formatter.dart';
import '../../core/widgets/app_tab_screen.dart';
import 'report_pdf_service.dart';
import 'report_repository.dart';
import '../../core/services/thermal_printer_service.dart';
import '../printer/printer_gate.dart';
import '../../core/widgets/app_message.dart';

/// Reports: search bar, report tabs, From/To date + Submit, a table container
/// and Save / Share / Print buttons that produce a proper A4 PDF.
class ReportsScreen extends StatefulWidget {
  final ReportType? initialType;
  final int? supplierId;
  final String? supplierName;
  final int? customerId;
  final String? customerName;

  /// Stock In / Stock Out screens: one fixed report, no tabs, own title.
  final bool singleType;
  final String? title;

  const ReportsScreen({
    super.key,
    this.initialType,
    this.supplierId,
    this.supplierName,
    this.customerId,
    this.customerName,
    this.singleType = false,
    this.title,
  });

  @override
  State<ReportsScreen> createState() => _ReportsScreenState();
}

class _ReportsScreenState extends State<ReportsScreen> with WidgetsBindingObserver {
  final _repo = ReportRepository();
  final _searchCtrl = TextEditingController();
  Timer? _debounce;

  late ReportType _type;

  // Dates being edited vs. dates the report is actually showing.
  late DateTime _draftFrom;
  late DateTime _draftTo;
  late DateTime _from;
  late DateTime _to;

  ReportData? _data;
  bool _loading = true;
  bool _busy = false;
  String? _busyAction; // which button was pressed (only that one shows the spinner)
  int _requestId = 0;

  static const _months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

  static DateTime _day(DateTime d) => DateTime(d.year, d.month, d.day);
  static String _fmt(DateTime d) => '${d.day.toString().padLeft(2, '0')} ${_months[d.month - 1]} ${d.year % 100}';

  @override
  void initState() {
    super.initState();
    _type = widget.initialType ?? ReportType.sales;
    WidgetsBinding.instance.addObserver(this);
    final now = _day(DateTime.now());
    _from = DateTime(now.year, now.month, 1);
    _to = now;
    _draftFrom = _from;
    _draftTo = _to;
    _load();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed && mounted) _load();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _debounce?.cancel();
    _searchCtrl.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final id = ++_requestId;
    setState(() => _loading = true);
    try {
      final data = await _repo.load(_type, _from, _to, query: _searchCtrl.text, supplierId: widget.supplierId, customerId: widget.customerId);
      if (!mounted || id != _requestId) return;
      setState(() {
        _data = data;
        _loading = false;
      });
    } catch (e) {
      if (!mounted || id != _requestId) return;
      setState(() {
        _data = null;
        _loading = false;
      });
      _snack('Could not load report.');
    }
  }

  void _snack(String msg) {
    AppMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(msg)));
  }

  void _setType(ReportType t) {
    if (t == _type) return;
    setState(() => _type = t);
    _load();
  }

  void _onSearch(String _) {
    setState(() {});
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 250), _load);
  }

  Future<void> _pickDate({required bool isFrom}) async {
    final initial = isFrom ? _draftFrom : _draftTo;
    final picked = await showDatePicker(
      context: context,
      initialDate: initial,
      firstDate: DateTime(2020),
      lastDate: DateTime(DateTime.now().year + 1, 12, 31),
    );
    if (picked == null || !mounted) return;
    setState(() {
      if (isFrom) {
        _draftFrom = _day(picked);
      } else {
        _draftTo = _day(picked);
      }
    });
  }

  void _submit() {
    if (_draftFrom.isAfter(_draftTo)) {
      _snack('"From" date cannot be after "To" date.');
      return;
    }
    FocusScope.of(context).unfocus();
    _from = _draftFrom;
    _to = _draftTo;
    _load();
  }

  void _applyPreset(String key) {
    final now = _day(DateTime.now());
    DateTime from = now;
    DateTime to = now;
    switch (key) {
      case 'today':
        break;
      case 'yesterday':
        from = now.subtract(const Duration(days: 1));
        to = from;
        break;
      case 'week':
        from = now.subtract(Duration(days: now.weekday - 1));
        break;
      case 'month':
        from = DateTime(now.year, now.month, 1);
        break;
      case 'lastmonth':
        from = DateTime(now.year, now.month - 1, 1);
        to = DateTime(now.year, now.month, 0);
        break;
      case 'year':
        from = DateTime(now.year, 1, 1);
        break;
      case 'all':
        from = DateTime(2020, 1, 1);
        break;
    }
    setState(() {
      _draftFrom = from;
      _draftTo = to;
      _from = from;
      _to = to;
    });
    _load();
  }

  Future<void> _run(String key, Future<void> Function(ReportData data) action) async {
    final data = _data;
    if (_busy) return;
    if (data == null || _loading) {
      _snack('Report is still loading.');
      return;
    }
    setState(() { _busy = true; _busyAction = key; });
    try {
      await action(data);
    } on PrinterException catch (e) {
      if (mounted) _snack(e.message);
    } catch (e) {
      if (mounted) _snack('Something went wrong. Please try again.');
    } finally {
      if (mounted) setState(() { _busy = false; _busyAction = null; });
    }
  }

  Future<void> _save() => _run('save', (d) async {
        final msg = await ReportPdfService.instance.save(d);
        if (mounted) _snack(msg);
      });

  Future<void> _share() => _run('share', (d) => ReportPdfService.instance.share(d));

  Future<void> _print() async {
    if (_busy) return;
    if (!await PrinterGate.ensure(context)) return;
    await _run('print', (d) async {
      await ReportPdfService.instance.printReport(d);
      if (mounted) _snack('Report sent to the printer.');
    });
  }

  // ------------------------------------------------------------------- build

  @override
  Widget build(BuildContext context) {
    final s = (MediaQuery.of(context).size.width / 390).clamp(0.86, 1.18);
    final bottomSafe = MediaQuery.of(context).padding.bottom;

    return AppTabScreen(
      title: widget.title ?? 'Reports',
      onBack: () => Navigator.pop(context),
      body: Column(
        children: [
          Padding(
            padding: EdgeInsets.fromLTRB(14 * s, 12 * s, 14 * s, 0),
            child: Column(
              children: [
                _buildSearch(s),
                SizedBox(height: 10 * s),
                if (!widget.singleType) ...[
                  _buildTabs(s),
                  SizedBox(height: 10 * s),
                ],
                _buildDateRow(s),
                SizedBox(height: 10 * s),
              ],
            ),
          ),
          Expanded(
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 14 * s),
              child: _buildContainer(s),
            ),
          ),
          Padding(
            padding: EdgeInsets.fromLTRB(14 * s, 10 * s, 14 * s, 12 * s + bottomSafe),
            child: Row(
              children: [
                Expanded(child: _actionButton(s, 'save', 'Save', Icons.download_rounded, const [Color(0xFF4C8DFF), AppColors.primary], _save)),
                SizedBox(width: 10 * s),
                Expanded(child: _actionButton(s, 'share', 'Share', Icons.share_rounded, const [Color(0xFF2ED47A), AppColors.income], _share)),
                SizedBox(width: 10 * s),
                Expanded(child: _actionButton(s, 'print', 'Print', Icons.print_rounded, const [Color(0xFFFFB84D), AppColors.warning], _print)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSearch(double s) {
    return Container(
      height: 40 * s,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14 * s),
        border: Border.all(color: AppColors.lightCardBorder, width: 1.2),
      ),
      child: TextField(
        controller: _searchCtrl,
        onChanged: _onSearch,
        textInputAction: TextInputAction.search,
        style: TextStyle(fontSize: 13 * s, color: AppColors.lightTextPrimary),
        decoration: InputDecoration(
          isDense: true,
          border: InputBorder.none,
          hintText: _type.searchHint,
          hintStyle: TextStyle(fontSize: 12.5 * s, color: AppColors.lightTextSecondary),
          prefixIcon: Icon(Icons.search_rounded, size: 19 * s, color: AppColors.lightTextSecondary),
          prefixIconConstraints: BoxConstraints(minWidth: 40 * s, minHeight: 40 * s),
          suffixIcon: _searchCtrl.text.isEmpty
              ? null
              : GestureDetector(
                  onTap: () {
                    _searchCtrl.clear();
                    _onSearch('');
                  },
                  child: Icon(Icons.close_rounded, size: 18 * s, color: AppColors.lightTextSecondary),
                ),
          suffixIconConstraints: BoxConstraints(minWidth: 36 * s, minHeight: 40 * s),
          contentPadding: EdgeInsets.symmetric(vertical: 11 * s),
        ),
      ),
    );
  }

  Widget _buildTabs(double s) {
    return Container(
      height: 40 * s,
      padding: EdgeInsets.all(3 * s),
      decoration: BoxDecoration(color: const Color(0xFFE7EBF3), borderRadius: BorderRadius.circular(16 * s)),
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: kReportTabs.length,
        separatorBuilder: (_, __) => SizedBox(width: 4 * s),
        itemBuilder: (context, i) {
          final t = kReportTabs[i];
          final selected = t == _type;
          return GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTap: () => _setType(t),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 250),
              curve: Curves.easeOutCubic,
              padding: EdgeInsets.symmetric(horizontal: 14 * s),
              alignment: Alignment.center,
              decoration: BoxDecoration(
                gradient: selected
                    ? const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF4C8DFF), AppColors.primary])
                    : null,
                borderRadius: BorderRadius.circular(13 * s),
                boxShadow: selected
                    ? [BoxShadow(color: AppColors.primary.withValues(alpha: 0.35), blurRadius: 8 * s, offset: Offset(0, 3 * s))]
                    : null,
              ),
              child: Text(
                t.tabLabel,
                style: TextStyle(
                  color: selected ? Colors.white : AppColors.lightTextSecondary,
                  fontSize: 12.5 * s,
                  fontWeight: selected ? FontWeight.w800 : FontWeight.w600,
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildDateRow(double s) {
    return Row(
      children: [
        Expanded(child: _dateBox(s, 'From', _draftFrom, () => _pickDate(isFrom: true))),
        SizedBox(width: 8 * s),
        Expanded(child: _dateBox(s, 'To', _draftTo, () => _pickDate(isFrom: false))),
        SizedBox(width: 6 * s),
        PopupMenuButton<String>(
          tooltip: 'Quick range',
          onSelected: _applyPreset,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          itemBuilder: (_) => const [
            PopupMenuItem(value: 'today', child: Text('Today')),
            PopupMenuItem(value: 'yesterday', child: Text('Yesterday')),
            PopupMenuItem(value: 'week', child: Text('This Week')),
            PopupMenuItem(value: 'month', child: Text('This Month')),
            PopupMenuItem(value: 'lastmonth', child: Text('Last Month')),
            PopupMenuItem(value: 'year', child: Text('This Year')),
            PopupMenuItem(value: 'all', child: Text('All Time')),
          ],
          child: Container(
            width: 38 * s,
            height: 42 * s,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12 * s),
              border: Border.all(color: AppColors.primary.withValues(alpha: .35)),
            ),
            child: Icon(Icons.date_range_rounded, color: AppColors.primary, size: 20 * s),
          ),
        ),
        SizedBox(width: 6 * s),
        GestureDetector(
          onTap: _submit,
          child: Container(
            height: 42 * s,
            padding: EdgeInsets.symmetric(horizontal: 14 * s),
            alignment: Alignment.center,
            decoration: BoxDecoration(
              gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF4C8DFF), AppColors.primary]),
              borderRadius: BorderRadius.circular(12 * s),
              boxShadow: [BoxShadow(color: AppColors.primary.withValues(alpha: .30), blurRadius: 8 * s, offset: Offset(0, 3 * s))],
            ),
            child: Text('Submit', style: TextStyle(color: Colors.white, fontSize: 12.5 * s, fontWeight: FontWeight.w800)),
          ),
        ),
      ],
    );
  }

  Widget _dateBox(double s, String label, DateTime value, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 42 * s,
        padding: EdgeInsets.symmetric(horizontal: 8 * s),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12 * s),
          border: Border.all(color: AppColors.lightCardBorder, width: 1.2),
        ),
        child: Row(
          children: [
            Icon(Icons.calendar_month_rounded, size: 16 * s, color: AppColors.primary),
            SizedBox(width: 5 * s),
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(label, style: TextStyle(fontSize: 9 * s, color: AppColors.lightTextSecondary, fontWeight: FontWeight.w600)),
                  FittedBox(
                    fit: BoxFit.scaleDown,
                    alignment: Alignment.centerLeft,
                    child: Text(_fmt(value), style: TextStyle(fontSize: 12 * s, color: AppColors.lightTextPrimary, fontWeight: FontWeight.w800)),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // --------------------------------------------------------------- container

  Widget _buildContainer(double s) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18 * s),
        border: Border.all(color: AppColors.primary.withValues(alpha: .22)),
        boxShadow: [BoxShadow(color: AppColors.primary.withValues(alpha: .06), blurRadius: 14, offset: const Offset(0, 5))],
      ),
      clipBehavior: Clip.antiAlias,
      child: _loading && _data == null
          ? const Center(child: CircularProgressIndicator())
          : _data == null
              ? _empty(s, 'Could not load report.')
              : Stack(
                  children: [
                    Column(
                      children: [
                        _buildHeaderStrip(s, _data!),
                        _buildSummary(s, _data!),
                        Expanded(child: _buildTable(s, _data!)),
                      ],
                    ),
                    if (_loading)
                      Positioned.fill(
                        child: Container(color: Colors.white.withValues(alpha: .55), child: const Center(child: CircularProgressIndicator())),
                      ),
                  ],
                ),
    );
  }

  Widget _buildHeaderStrip(double s, ReportData d) {
    return Padding(
      padding: EdgeInsets.fromLTRB(12 * s, 10 * s, 12 * s, 0),
      child: Row(
        children: [
          Expanded(
            child: Text(
              '${d.type.title}  •  ${_fmt(d.from)} - ${_fmt(d.to)}',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(fontSize: 12 * s, fontWeight: FontWeight.w800, color: AppColors.lightTextPrimary),
            ),
          ),
          Text('Amounts in ${CurrencyFormatter.defaultSymbol}', style: TextStyle(fontSize: 10 * s, color: AppColors.lightTextSecondary)),
        ],
      ),
    );
  }

  Widget _buildSummary(double s, ReportData d) {
    return SizedBox(
      height: 56 * s,
      child: ListView.separated(
        padding: EdgeInsets.fromLTRB(12 * s, 8 * s, 12 * s, 8 * s),
        scrollDirection: Axis.horizontal,
        itemCount: d.summary.length,
        separatorBuilder: (_, __) => SizedBox(width: 8 * s),
        itemBuilder: (context, i) {
          final item = d.summary[i];
          final color = _tone(item.tone) ?? AppColors.lightTextPrimary;
          return Container(
            padding: EdgeInsets.symmetric(horizontal: 10 * s),
            decoration: BoxDecoration(
              color: color.withValues(alpha: .07),
              borderRadius: BorderRadius.circular(10 * s),
              border: Border.all(color: color.withValues(alpha: .18)),
            ),
            // FittedBox keeps the two lines inside the fixed-height strip at
            // any phone text-size, so it can never show "bottom overflowed".
            child: FittedBox(
              fit: BoxFit.scaleDown,
              alignment: Alignment.centerLeft,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(item.label, maxLines: 1, style: TextStyle(fontSize: 9 * s, color: AppColors.lightTextSecondary, fontWeight: FontWeight.w600)),
                  Text(item.value, maxLines: 1, style: TextStyle(fontSize: 12.5 * s, color: color, fontWeight: FontWeight.w800)),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Color? _tone(int? tone) => tone == 1 ? AppColors.income : (tone == -1 ? AppColors.expense : null);

  Widget _buildTable(double s, ReportData d) {
    final isCashbook = d.type == ReportType.cashbook;
    final isSupplierLedger = d.type == ReportType.supplierLedger || d.type == ReportType.customerLedger;
    if (d.rows.isEmpty && !isCashbook) {
      return _empty(s, _searchCtrl.text.trim().isEmpty ? 'No records in this period.' : 'No results for your search.');
    }
    final totalFlex = d.widths.fold<double>(0, (a, b) => a + b);
    final lastCol = d.headers.length - 1;

    return LayoutBuilder(
      builder: (context, constraints) {
        final tableWidth = constraints.maxWidth < 640 ? 640.0 : constraints.maxWidth;
        double w(int i) => tableWidth * d.widths[i] / totalFlex;

        Widget rowOf(List<String> cells, {Color? bg, bool bold = false, Color? color, double fontSize = 10.5, Color? Function(int col)? colorFor}) {
          return Container(
            color: bg,
            padding: EdgeInsets.symmetric(vertical: 8 * s),
            child: Row(
              children: [
                for (var i = 0; i < cells.length; i++)
                  SizedBox(
                    width: w(i),
                    child: Padding(
                      padding: EdgeInsets.symmetric(horizontal: 6 * s),
                      child: Text(
                        cells[i],
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        textAlign: d.numericColumns.contains(i) && i != 0 ? TextAlign.right : TextAlign.left,
                        style: TextStyle(
                          fontSize: fontSize * s,
                          fontWeight: bold ? FontWeight.w800 : FontWeight.w600,
                          color: colorFor?.call(i) ?? color ?? AppColors.lightTextPrimary,
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          );
        }

        Color? amountColor(ReportRow row, int col) {
          if (!d.numericColumns.contains(col) || col == 0) return null;
          switch (d.type) {
            case ReportType.cashbook:
              if (col == 4) return AppColors.income;
              if (col == 5) return AppColors.expense;
              return null;
            case ReportType.items:
              if (col == lastCol - 1) return row.tone == -1 ? AppColors.expense : AppColors.income;
              return null;
            case ReportType.stockIn:
              return col == 4 ? AppColors.income : null;
            case ReportType.stockOut:
              return col == 5 ? AppColors.expense : null;
            case ReportType.expenses:
              return col == 4 ? AppColors.expense : null;
            case ReportType.sales:
            case ReportType.purchase:
              if (col == lastCol && row.tone == -1) return AppColors.expense;
              return null;
            case ReportType.customerLedger:
            case ReportType.supplierLedger:
              if (col == 4) return AppColors.expense;
              if (col == 5) return AppColors.income;
              return null;
          }
        }

        final blank = List<String>.filled(d.headers.length, '');
        List<String> labelRow(String label, String value) {
          final c = List<String>.from(blank);
          c[2] = label;
          c[lastCol] = value;
          return c;
        }

        return SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: SizedBox(
            width: tableWidth,
            child: Column(
              children: [
                rowOf(d.headers, bg: AppColors.primary, bold: true, color: Colors.white, fontSize: 10.5),
                if (isCashbook || isSupplierLedger)
                  rowOf(labelRow('Opening Balance', d.openingLabel ?? '0.00'), bg: AppColors.primary.withValues(alpha: .08), bold: true, color: AppColors.primary),
                Expanded(
                  child: d.rows.isEmpty
                      ? Center(
                          child: Padding(
                            padding: EdgeInsets.all(14 * s),
                            child: Text(
                              _searchCtrl.text.trim().isEmpty ? 'No transactions in this period.' : 'No results for your search.',
                              style: TextStyle(fontSize: 12 * s, color: AppColors.lightTextSecondary),
                            ),
                          ),
                        )
                      : ListView.builder(
                          itemCount: d.rows.length,
                          itemBuilder: (context, i) {
                            final row = d.rows[i];
                            return rowOf(
                              row.cells,
                              bg: i.isOdd ? const Color(0xFFF8FAFC) : Colors.white,
                              colorFor: (col) => amountColor(row, col),
                            );
                          },
                        ),
                ),
                if (d.totals != null) rowOf(d.totals!, bg: AppColors.primary.withValues(alpha: .08), bold: true, color: AppColors.primary),
                if (isCashbook || isSupplierLedger) rowOf(labelRow('Closing Balance', d.closingLabel ?? '0.00'), bg: AppColors.primary, bold: true, color: Colors.white),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _empty(double s, String message) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.insert_chart_outlined_rounded, size: 44 * s, color: AppColors.lightTextSecondary.withValues(alpha: .6)),
          SizedBox(height: 8 * s),
          Text(message, style: TextStyle(fontSize: 13 * s, color: AppColors.lightTextSecondary, fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }

  Widget _actionButton(double s, String key, String label, IconData icon, List<Color> colors, VoidCallback onTap) {
    final disabled = _busy || _loading;
    return Opacity(
      opacity: disabled ? .6 : 1,
      child: GestureDetector(
        onTap: disabled ? null : onTap,
        child: Container(
          height: 46 * s,
          decoration: BoxDecoration(
            gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: colors),
            borderRadius: BorderRadius.circular(14 * s),
            boxShadow: [BoxShadow(color: colors.last.withValues(alpha: .32), blurRadius: 10 * s, offset: Offset(0, 4 * s))],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (_busy && _busyAction == key)
                SizedBox(width: 16 * s, height: 16 * s, child: const CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
              else
                Icon(icon, color: Colors.white, size: 19 * s),
              SizedBox(width: 6 * s),
              Text(label, style: TextStyle(color: Colors.white, fontSize: 13.5 * s, fontWeight: FontWeight.w800)),
            ],
          ),
        ),
      ),
    );
  }
}
