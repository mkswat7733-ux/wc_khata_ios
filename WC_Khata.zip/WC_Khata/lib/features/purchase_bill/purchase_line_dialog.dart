import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../app/theme/app_theme.dart';
import '../../core/services/item_image_store.dart';
import '../../core/services/unit_system_service.dart';
import '../../core/utils/amount_limit.dart';
import '../../core/utils/currency_formatter.dart';
import '../../core/utils/unit_math.dart';
import 'purchase_bill_repository.dart';

/// Popup shown when a product is tapped on the New Purchase screen.
///
///   Quantity  +  Rate (cost price)  ->  Total
///   [ Add ]
///
/// When the Inner / Outer unit system is ON in Settings (and the product has
/// its units) the quantity and the rate are asked in both Outer and Inner
/// units, e.g. Box + Strip.
///
/// Returns a [PurchaseLine] with the new values, or null when closed.
/// Quantity and rate are always handed back in the product's BASE (inner) unit.
Future<PurchaseLine?> showPurchaseLineDialog(
  BuildContext context, {
  required PurchaseLine line,
  required bool isEdit,
}) async {
  final cfg = await UnitSystemService.instance.load();
  if (!context.mounted) return null;
  final unitMode = cfg.enabled && line.item.hasUnitSystem;
  return showDialog<PurchaseLine>(
    context: context,
    builder: (_) => _PurchaseLineDialog(line: line, isEdit: isEdit, unitMode: unitMode),
  );
}

class _PurchaseLineDialog extends StatefulWidget {
  final PurchaseLine line;
  final bool isEdit;
  final bool unitMode;
  const _PurchaseLineDialog({required this.line, required this.isEdit, required this.unitMode});

  @override
  State<_PurchaseLineDialog> createState() => _PurchaseLineDialogState();
}

class _PurchaseLineDialogState extends State<_PurchaseLineDialog> {
  late double _qty;
  late double _unitCost;
  late double _retail;
  String? _error;

  final _qtyC = TextEditingController();
  final _outerQtyC = TextEditingController();
  final _innerQtyC = TextEditingController();
  final _unitCostC = TextEditingController();
  final _outerCostC = TextEditingController();
  final _retailC = TextEditingController();
  final _outerRetailC = TextEditingController();

  bool get _unitMode => widget.unitMode;
  double get _perOuter => widget.line.item.unitsPerOuter;

  @override
  void initState() {
    super.initState();
    _unitCost = widget.line.unitCost;
    _retail = widget.line.retailPrice;
    // A new product in unit mode starts at 1 outer unit (1 Box), not 1 strip.
    _qty = (!widget.isEdit && _unitMode) ? _perOuter : widget.line.qty;

    if (_unitMode) {
      _outerQtyC.text = _txt(UnitMath.outerPart(_qty, _perOuter));
      _innerQtyC.text = _txt(UnitMath.innerPart(_qty, _perOuter));
      _outerCostC.text = _txt(_unitCost * _perOuter);
      _outerRetailC.text = _txt(_retail * _perOuter);
      _outerQtyC.selection = TextSelection(baseOffset: 0, extentOffset: _outerQtyC.text.length);
    } else {
      _qtyC.text = _txt(_qty);
      _qtyC.selection = TextSelection(baseOffset: 0, extentOffset: _qtyC.text.length);
    }
    _unitCostC.text = _txt(_unitCost);
    _retailC.text = _txt(_retail);
  }

  @override
  void dispose() {
    for (final c in [_qtyC, _outerQtyC, _innerQtyC, _unitCostC, _outerCostC, _retailC, _outerRetailC]) {
      c.dispose();
    }
    super.dispose();
  }

  // ----------------------------------------------------------------- maths

  static double _parse(String v) => double.tryParse(v.replaceAll(',', '').trim()) ?? 0;
  static String _txt(double v) => v <= 0 ? '' : UnitMath.fmt(v, dp: 4);

  void _setText(TextEditingController c, String t) {
    if (c.text != t) c.value = TextEditingValue(text: t, selection: TextSelection.collapsed(offset: t.length));
  }

  double get _gross => PurchaseCalc.r2(_qty * _unitCost);
  double get _discount => PurchaseCalc.r2(widget.line.lineDiscount.clamp(0, _gross).toDouble());
  double get _total => PurchaseCalc.r2(_gross - _discount);

  void _onQty() {
    setState(() {
      _error = null;
      _qty = _unitMode
          ? UnitMath.toBase(_parse(_outerQtyC.text), _parse(_innerQtyC.text), _perOuter)
          : _parse(_qtyC.text);
    });
  }

  /// Rate per inner (base) unit typed: refresh the per-outer box.
  void _onUnitCost(String v) {
    setState(() {
      _error = null;
      _unitCost = _parse(v);
      if (_unitMode) _setText(_outerCostC, _txt(_unitCost * _perOuter));
    });
  }

  /// Rate per outer unit typed: refresh the per-inner box.
  void _onOuterCost(String v) {
    setState(() {
      _error = null;
      _unitCost = _perOuter > 0 ? _parse(v) / _perOuter : 0;
      _setText(_unitCostC, _txt(_unitCost));
    });
  }

  /// Retail price per inner (base) unit typed: refresh the per-outer box.
  void _onRetail(String v) {
    setState(() {
      _error = null;
      _retail = _parse(v);
      if (_unitMode) _setText(_outerRetailC, _txt(_retail * _perOuter));
    });
  }

  /// Retail price per outer unit typed: refresh the per-inner box.
  void _onOuterRetail(String v) {
    setState(() {
      _error = null;
      _retail = _perOuter > 0 ? _parse(v) / _perOuter : 0;
      _setText(_retailC, _txt(_retail));
    });
  }

  /// Profit (+) or loss (-) per base unit if sold at the retail price.
  double get _margin => PurchaseCalc.r2(_retail - _unitCost);

  void _submit() {
    if (_qty <= 0) {
      setState(() => _error = 'Enter a valid quantity.');
      return;
    }
    if (_unitCost <= 0) {
      setState(() => _error = 'Enter the cost price (rate).');
      return;
    }
    if (_retail <= 0) {
      setState(() => _error = 'Enter the retail (sale) price.');
      return;
    }
    if (_gross > AmountLimit.max || _retail * _qty > AmountLimit.max) {
      setState(() => _error = 'Amount must be 1 crore or less.');
      return;
    }
    Navigator.pop(
      context,
      PurchaseLine(item: widget.line.item, qty: _qty, unitCost: _unitCost, lineDiscount: _discount, retailPrice: _retail),
    );
  }

  // -------------------------------------------------------------------- ui

  static final _decimal = [FilteringTextInputFormatter.allow(RegExp(r'[0-9.]')), LengthLimitingTextInputFormatter(12)];

  InputDecoration _dec(double s, String label, {String? prefix, String? suffix}) => InputDecoration(
        labelText: label,
        prefixText: prefix,
        suffixText: suffix,
        isDense: true,
        filled: true,
        fillColor: AppColors.lightBackground,
        contentPadding: EdgeInsets.symmetric(horizontal: 12 * s, vertical: 13 * s),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(13 * s), borderSide: BorderSide.none),
      );

  Widget _qtyField(double s, TextEditingController c, String label, {String? suffix, bool autofocus = false}) => TextField(
        controller: c,
        autofocus: autofocus,
        onChanged: (_) => _onQty(),
        keyboardType: const TextInputType.numberWithOptions(decimal: true),
        inputFormatters: _decimal,
        decoration: _dec(s, label, suffix: suffix),
      );

  Widget _rateField(double s, TextEditingController c, String label, ValueChanged<String> onChanged) => TextField(
        controller: c,
        onChanged: onChanged,
        keyboardType: const TextInputType.numberWithOptions(decimal: true),
        inputFormatters: const [MaxAmountFormatter()],
        decoration: _dec(s, label, prefix: '${CurrencyFormatter.label} '),
      );

  @override
  Widget build(BuildContext context) {
    final s = (MediaQuery.sizeOf(context).width / 390).clamp(.82, 1.2).toDouble();
    final item = widget.line.item;
    final unit = item.baseUnit;
    final picked = ItemImageStore.resolve(item.imagePath);

    return Dialog(
      backgroundColor: Colors.white,
      insetPadding: EdgeInsets.symmetric(horizontal: 18 * s, vertical: 20 * s),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22 * s)),
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 420),
        child: SingleChildScrollView(
          padding: EdgeInsets.fromLTRB(16 * s, 14 * s, 16 * s, 16 * s),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // ---- product
              Row(children: [
                Container(
                  width: 46 * s,
                  height: 46 * s,
                  clipBehavior: Clip.antiAlias,
                  decoration: BoxDecoration(color: AppColors.lightBackground, borderRadius: BorderRadius.circular(12 * s)),
                  child: picked != null
                      ? Image.file(picked, fit: BoxFit.contain)
                      : Icon(Icons.inventory_2_rounded, color: AppColors.primary, size: 22 * s),
                ),
                SizedBox(width: 10 * s),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(item.name, maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 14 * s, fontWeight: FontWeight.w800, color: AppColors.lightTextPrimary)),
                    SizedBox(height: 2 * s),
                    Text(
                      item.trackStock ? 'In stock: ${item.stockText}' : 'Quantity not managed',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(fontSize: 10.5 * s, fontWeight: FontWeight.w600, color: AppColors.lightTextSecondary),
                    ),
                  ]),
                ),
                IconButton(
                  onPressed: () => Navigator.pop(context),
                  icon: Icon(Icons.close_rounded, size: 22 * s, color: AppColors.lightTextSecondary),
                  visualDensity: VisualDensity.compact,
                ),
              ]),
              SizedBox(height: 14 * s),

              // ---- quantity
              if (_unitMode) ...[
                Row(children: [
                  Expanded(child: _qtyField(s, _outerQtyC, '${item.outerUnit} Qty', autofocus: true)),
                  SizedBox(width: 10 * s),
                  Expanded(child: _qtyField(s, _innerQtyC, '$unit Qty')),
                ]),
                SizedBox(height: 4 * s),
                Text('1 ${item.outerUnit} = ${UnitMath.fmt(_perOuter)} $unit', style: TextStyle(fontSize: 10.5 * s, fontWeight: FontWeight.w700, color: AppColors.lightTextSecondary)),
                SizedBox(height: 10 * s),
                Row(children: [
                  Expanded(child: _rateField(s, _outerCostC, 'Rate / ${item.outerUnit}', _onOuterCost)),
                  SizedBox(width: 10 * s),
                  Expanded(child: _rateField(s, _unitCostC, 'Rate / $unit', _onUnitCost)),
                ]),
                SizedBox(height: 10 * s),
                Row(children: [
                  Expanded(child: _rateField(s, _outerRetailC, 'Retail / ${item.outerUnit}', _onOuterRetail)),
                  SizedBox(width: 10 * s),
                  Expanded(child: _rateField(s, _retailC, 'Retail / $unit', _onRetail)),
                ]),
              ] else ...[
                _qtyField(s, _qtyC, 'Quantity', suffix: unit, autofocus: true),
                SizedBox(height: 10 * s),
                _rateField(s, _unitCostC, 'Cost price (rate) / $unit', _onUnitCost),
                SizedBox(height: 10 * s),
                _rateField(s, _retailC, 'Retail price / $unit', _onRetail),
              ],
              if (_unitCost > 0 && _retail > 0) ...[
                SizedBox(height: 8 * s),
                Text(
                  _margin >= 0
                      ? 'Profit per $unit: ${CurrencyFormatter.formatCompact(_margin)}'
                      : 'Loss per $unit: ${CurrencyFormatter.formatCompact(-_margin)} (retail is below cost)',
                  style: TextStyle(fontSize: 11 * s, fontWeight: FontWeight.w800, color: _margin >= 0 ? const Color(0xFF16A34A) : const Color(0xFFDC2626)),
                ),
              ],
              SizedBox(height: 12 * s),

              // ---- total
              Container(
                padding: EdgeInsets.symmetric(horizontal: 12 * s, vertical: 10 * s),
                decoration: BoxDecoration(color: AppColors.primary.withValues(alpha: .08), borderRadius: BorderRadius.circular(13 * s)),
                child: Row(children: [
                  Text('Total', style: TextStyle(fontSize: 12 * s, fontWeight: FontWeight.w800, color: AppColors.lightTextPrimary)),
                  SizedBox(width: 10 * s),
                  Expanded(
                    child: Text(
                      CurrencyFormatter.formatCompact(_total),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      textAlign: TextAlign.right,
                      style: TextStyle(fontSize: 16 * s, fontWeight: FontWeight.w900, color: AppColors.primary),
                    ),
                  ),
                ]),
              ),
              if (_error != null) ...[
                SizedBox(height: 8 * s),
                Text(_error!, style: TextStyle(fontSize: 11 * s, fontWeight: FontWeight.w700, color: const Color(0xFFDC2626))),
              ],
              SizedBox(height: 14 * s),

              // ---- add
              SizedBox(
                height: 48 * s,
                child: FilledButton(
                  onPressed: _submit,
                  style: FilledButton.styleFrom(backgroundColor: AppColors.primary, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14 * s))),
                  child: Text(widget.isEdit ? 'Update' : 'Add', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 14 * s)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
