import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../app/theme/app_theme.dart';
import '../../core/utils/amount_limit.dart';
import '../../core/utils/currency_formatter.dart';
import '../../core/utils/unit_math.dart';
import '../../core/widgets/app_glass_icon_button.dart';
import '../../core/widgets/app_message.dart';
import '../ledger/ledger_party.dart';
import '../sale/sale_invoice_screen.dart';
import 'purchase_bill_repository.dart';

/// Step 3 of a purchase (after Next):
///   products container -> Gross Total -> Discount -> Net Total -> Payment
///   (Paid / Unpaid) -> Supplier -> Submit.
/// Submitting saves the bill (stock, supplier khata, Cashbook) and opens the
/// purchase receipt / invoice.
class PurchaseCheckoutScreen extends StatefulWidget {
  final LedgerParty supplier;
  final List<PurchaseLine> lines;
  const PurchaseCheckoutScreen({super.key, required this.supplier, required this.lines});

  @override
  State<PurchaseCheckoutScreen> createState() => _PurchaseCheckoutScreenState();
}

class _PurchaseCheckoutScreenState extends State<PurchaseCheckoutScreen> {
  final _repo = PurchaseBillRepository();
  final _discountC = TextEditingController(text: '0');
  final _discountPctC = TextEditingController(text: '0');
  final _netC = TextEditingController();
  final _paidC = TextEditingController(text: '0');

  double _discount = 0;
  bool _fullyPaid = true; // true = Paid, false = Unpaid
  bool _saving = false;

  PurchaseBreakdown get _calc => PurchaseCalc.compute(widget.lines, discount: _discount);
  double get _paidNow => _fullyPaid ? _calc.total : PurchaseCalc.r2(double.tryParse(_paidC.text.trim()) ?? 0);
  double get _remaining => PurchaseCalc.r2(_calc.total - _paidNow);

  @override
  void initState() {
    super.initState();
    _netC.text = UnitMath.fmt(_calc.total, dp: 2);
  }

  @override
  void dispose() {
    _discountC.dispose();
    _discountPctC.dispose();
    _netC.dispose();
    _paidC.dispose();
    super.dispose();
  }

  static double _parse(String v) => double.tryParse(v.replaceAll(',', '').trim()) ?? 0;
  void _setText(TextEditingController c, String t) {
    if (c.text != t) c.value = TextEditingValue(text: t, selection: TextSelection.collapsed(offset: t.length));
  }

  /// Rewrites every discount / total box except the one being typed in.
  void _sync(String source) {
    final sub = _calc.subtotal;
    _discount = _calc.discount;
    final pct = sub > 0 && _discount > 0 ? _discount / sub * 100 : 0.0;
    if (source != 'rs') _setText(_discountC, _discount <= 0 ? '0' : UnitMath.fmt(_discount, dp: 2));
    if (source != 'pct') _setText(_discountPctC, pct <= 0 ? '0' : UnitMath.fmt(PurchaseCalc.r2(pct), dp: 2));
    if (source != 'net') _setText(_netC, UnitMath.fmt(_calc.total, dp: 2));
    setState(() {});
  }

  void _onDiscountRs(String v) {
    _discount = _parse(v);
    _sync('rs');
  }

  void _onDiscountPct(String v) {
    var pct = _parse(v);
    if (pct > 100) pct = 100;
    _discount = PurchaseCalc.r2(_calc.subtotal * pct / 100);
    _sync('pct');
  }

  void _onNet(String v) {
    final sub = _calc.subtotal;
    final n = _parse(v);
    if (n > sub) {
      // The total can't go above the gross total: put the limit back.
      _discount = 0;
      _sync('');
      return;
    }
    _discount = sub - n;
    _sync('net');
  }

  void _msg(String v) => AppMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(v)));

  Future<void> _submit() async {
    if (_saving) return;
    for (final l in widget.lines) {
      if (l.unitCost <= 0 || l.qty <= 0) {
        _msg('Enter the purchase price for ${l.item.name}.');
        return;
      }
    }
    final calc = _calc;
    if (calc.total <= 0) {
      _msg('Total must be greater than zero.');
      return;
    }
    final paid = _paidNow;
    if (calc.subtotal > AmountLimit.max || calc.total > AmountLimit.max || paid > AmountLimit.max) {
      AmountLimit.showMessage(context);
      return;
    }
    if (paid < 0 || paid > calc.total + 0.005) {
      _msg('Enter a valid paid amount.');
      return;
    }
    setState(() => _saving = true);
    try {
      final saved = await _repo.savePurchase(
        supplierId: widget.supplier.id!,
        lines: widget.lines,
        discountAmount: calc.discount,
        paidAmount: paid,
      );
      if (!mounted) return;
      await Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => SaleInvoiceScreen(sale: saved, customerName: widget.supplier.name, isPurchaseBill: true)),
      );
    } on ArgumentError catch (e) {
      if (mounted) _msg(e.message.toString());
    } catch (_) {
      if (mounted) _msg('Could not save the purchase. Please try again.');
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  // -------------------------------------------------------------------- ui

  @override
  Widget build(BuildContext context) {
    final s = (MediaQuery.sizeOf(context).width / 390).clamp(.82, 1.2).toDouble();
    return Scaffold(
      backgroundColor: AppColors.lightBackground,
      body: Column(children: [
        SafeArea(bottom: false, child: _head(s)),
        Expanded(
          child: ListView(
            padding: EdgeInsets.all(14 * s),
            keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
            children: [
              _itemsCard(s),
              SizedBox(height: 12 * s),
              _totalsCard(s),
              SizedBox(height: 12 * s),
              _paymentCard(s),
              SizedBox(height: 12 * s),
              _supplierCard(s),
              SizedBox(height: 16 * s),
              SizedBox(
                height: 52 * s,
                child: FilledButton(
                  onPressed: _saving ? null : _submit,
                  style: FilledButton.styleFrom(backgroundColor: AppColors.primary, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15 * s))),
                  child: _saving
                      ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2.5))
                      : Text('Submit Purchase', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 14 * s)),
                ),
              ),
              SizedBox(height: 8 * s),
            ],
          ),
        ),
      ]),
    );
  }

  Widget _head(double s) => Container(
        height: 58 * s,
        padding: EdgeInsets.symmetric(horizontal: 14 * s),
        decoration: const BoxDecoration(color: Colors.white, border: Border(bottom: BorderSide(color: AppColors.lightDivider))),
        child: Row(children: [
          AppGlassIconButton(icon: Icons.arrow_back_rounded, onTap: () => Navigator.pop(context)),
          Expanded(child: Center(child: Text('Purchase Checkout', style: TextStyle(fontSize: 19 * s, fontWeight: FontWeight.w800, color: AppColors.lightTextPrimary)))),
          SizedBox(width: 42 * s),
        ]),
      );

  Widget _card(double s, Widget child) => Container(
        width: double.infinity,
        padding: EdgeInsets.all(15 * s),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20 * s),
          border: Border.all(color: AppColors.lightCardBorder),
          boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: .045), blurRadius: 12)],
        ),
        child: child,
      );

  Widget _title(double s, String t) => Text(t, style: TextStyle(fontSize: 14 * s, fontWeight: FontWeight.w800, color: AppColors.lightTextPrimary));

  InputDecoration _dec(double s, String label, {String? prefix, String? suffix, String? helper}) => InputDecoration(
        labelText: label,
        prefixText: prefix,
        suffixText: suffix,
        helperText: helper,
        filled: true,
        fillColor: AppColors.lightBackground,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(13 * s), borderSide: BorderSide.none),
      );

  Widget _row(double s, String label, double value, {Color? color, bool bold = false}) => Padding(
        padding: EdgeInsets.symmetric(vertical: 3 * s),
        child: Row(children: [
          Expanded(child: Text(label, style: TextStyle(fontSize: (bold ? 13 : 11.5) * s, color: bold ? AppColors.lightTextPrimary : AppColors.lightTextSecondary, fontWeight: bold ? FontWeight.w800 : FontWeight.w700))),
          Text(CurrencyFormatter.formatCompact(value), style: TextStyle(fontSize: (bold ? 16 : 12) * s, fontWeight: bold ? FontWeight.w900 : FontWeight.w800, color: color ?? (bold ? AppColors.primary : AppColors.lightTextPrimary))),
        ]),
      );

  Widget _supplierCard(double s) => _card(
        s,
        Row(children: [
          CircleAvatar(
            radius: 19 * s,
            backgroundColor: AppColors.primary.withValues(alpha: .10),
            child: Icon(Icons.local_shipping_rounded, color: AppColors.primary, size: 19 * s),
          ),
          SizedBox(width: 10 * s),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Supplier', style: TextStyle(fontSize: 10 * s, color: AppColors.lightTextSecondary)),
              Text(widget.supplier.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 14 * s, fontWeight: FontWeight.w800, color: AppColors.lightTextPrimary)),
            ]),
          ),
        ]),
      );

  String _qtyText(PurchaseLine l) {
    final it = l.item;
    if (it.hasUnitSystem) return UnitMath.describe(l.qty, it.unitsPerOuter, it.outerUnit!, it.innerUnit!);
    return '${UnitMath.fmt(l.qty, dp: 2)} ${it.unit}'.trim();
  }

  Widget _itemsCard(double s) => _card(
        s,
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Expanded(child: _title(s, 'Purchase Products')),
            Container(
              padding: EdgeInsets.symmetric(horizontal: 9 * s, vertical: 4 * s),
              decoration: BoxDecoration(color: AppColors.primary.withValues(alpha: .08), borderRadius: BorderRadius.circular(99)),
              child: Text('${widget.lines.length}', style: TextStyle(color: AppColors.primary, fontSize: 10.5 * s, fontWeight: FontWeight.w800)),
            ),
          ]),
          SizedBox(height: 6 * s),
          for (var i = 0; i < widget.lines.length; i++) ...[
            if (i > 0) const Divider(height: 1, color: AppColors.lightDivider),
            Padding(
              padding: EdgeInsets.symmetric(vertical: 8 * s),
              child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(widget.lines[i].item.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 12.5 * s, fontWeight: FontWeight.w800, color: AppColors.lightTextPrimary)),
                    SizedBox(height: 2 * s),
                    Text(
                      '${_qtyText(widget.lines[i])}  x  ${CurrencyFormatter.formatCompact(widget.lines[i].unitCost)} / ${widget.lines[i].item.baseUnit}',
                      style: TextStyle(fontSize: 10.5 * s, color: AppColors.lightTextSecondary, fontWeight: FontWeight.w600),
                    ),
                    if (widget.lines[i].discount > 0)
                      Text('Discount -${CurrencyFormatter.formatCompact(widget.lines[i].discount)}', style: TextStyle(fontSize: 10 * s, color: const Color(0xFFDC2626), fontWeight: FontWeight.w700)),
                  ]),
                ),
                SizedBox(width: 8 * s),
                Text(CurrencyFormatter.formatCompact(widget.lines[i].net), style: TextStyle(fontSize: 12.5 * s, fontWeight: FontWeight.w800, color: AppColors.primary)),
              ]),
            ),
          ],
        ]),
      );

  Widget _totalsCard(double s) {
    final c = _calc;
    return _card(
      s,
      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        _row(s, 'Gross Total', c.subtotal, bold: true, color: AppColors.lightTextPrimary),
        SizedBox(height: 10 * s),
        _title(s, 'Discount'),
        SizedBox(height: 10 * s),
        Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Expanded(
            flex: 3,
            child: TextField(
              controller: _discountC,
              onChanged: _onDiscountRs,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              inputFormatters: const [MaxAmountFormatter()],
              decoration: _dec(s, 'Discount (${CurrencyFormatter.label})', prefix: '${CurrencyFormatter.label} '),
            ),
          ),
          SizedBox(width: 10 * s),
          Expanded(
            flex: 2,
            child: TextField(
              controller: _discountPctC,
              onChanged: _onDiscountPct,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'[0-9.]')), LengthLimitingTextInputFormatter(6)],
              decoration: _dec(s, 'Discount (%)', suffix: '%'),
            ),
          ),
        ]),
        SizedBox(height: 12 * s),
        const Divider(height: 1, color: AppColors.lightDivider),
        SizedBox(height: 10 * s),
        _row(s, 'Net Total', c.total, bold: true),
        SizedBox(height: 6 * s),
        TextField(
          controller: _netC,
          onChanged: _onNet,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          inputFormatters: const [MaxAmountFormatter()],
          decoration: _dec(s, 'Net Total (editable)', prefix: '${CurrencyFormatter.label} ', helper: 'Can not be more than the gross total'),
        ),
      ]),
    );
  }

  Widget _paymentCard(double s) => _card(
        s,
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          _title(s, 'Payment'),
          SizedBox(height: 10 * s),
          Row(children: [
            Expanded(child: _payChoice(s, 'Paid', true)),
            SizedBox(width: 10 * s),
            Expanded(child: _payChoice(s, 'Unpaid', false)),
          ]),
          if (!_fullyPaid) ...[
            SizedBox(height: 12 * s),
            TextField(
              controller: _paidC,
              onChanged: (_) => setState(() {}),
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              inputFormatters: const [MaxAmountFormatter()],
              decoration: _dec(s, 'Amount paid now', prefix: '${CurrencyFormatter.label} '),
            ),
            SizedBox(height: 10 * s),
            _row(
              s,
              'Remaining Total',
              _remaining < 0 ? 0 : _remaining,
              bold: true,
              color: _remaining > 0.005 ? const Color(0xFFDC2626) : const Color(0xFF16A34A),
            ),
          ] else ...[
            SizedBox(height: 8 * s),
            Text('Full amount is paid to the supplier now.', style: TextStyle(fontSize: 10.5 * s, color: AppColors.lightTextSecondary, fontWeight: FontWeight.w600)),
          ],
        ]),
      );

  Widget _payChoice(double s, String title, bool paid) {
    final selected = _fullyPaid == paid;
    final color = paid ? const Color(0xFF16A34A) : const Color(0xFFDC2626);
    return InkWell(
      onTap: () => setState(() => _fullyPaid = paid),
      borderRadius: BorderRadius.circular(15 * s),
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 8 * s, horizontal: 8 * s),
        decoration: BoxDecoration(
          color: selected ? color.withValues(alpha: .08) : AppColors.lightBackground,
          borderRadius: BorderRadius.circular(15 * s),
          border: Border.all(color: selected ? color : AppColors.lightCardBorder, width: selected ? 1.5 : 1),
        ),
        child: Row(children: [
          Checkbox(
            value: selected,
            onChanged: (_) => setState(() => _fullyPaid = paid),
            activeColor: color,
            visualDensity: VisualDensity.compact,
            materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
          ),
          Expanded(child: Text(title, style: TextStyle(fontWeight: FontWeight.w800, fontSize: 13 * s, color: selected ? color : AppColors.lightTextPrimary))),
        ]),
      ),
    );
  }
}
