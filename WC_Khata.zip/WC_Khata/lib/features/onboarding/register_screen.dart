import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';
import '../../app/routes/root_shell.dart';
import '../../app/theme/app_theme.dart';
import '../../app/user_preferences_controller.dart';
import '../../core/routing/app_transitions.dart';
import '../../core/utils/currency_symbols.dart';
import '../../data/repositories/onboarding_repository.dart';
import '../../data/repositories/profile_repository.dart';
import '../../core/widgets/app_message.dart';

/// One-time Register screen shown right after onboarding. The details
/// entered here are the same ones found on the Profile screen (and used
/// on the Business Card and invoices), so they can be edited later.
class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  static const _g1 = Color(0xFF1E4FC4);
  static const _g2 = Color(0xFF5B3FD6);

  final _formKey = GlobalKey<FormState>();
  final _ownerCtrl = TextEditingController();
  final _designationCtrl = TextEditingController();
  final _businessCtrl = TextEditingController();
  final _taglineCtrl = TextEditingController();
  final _phoneCtrl = TextEditingController();
  final _whatsappCtrl = TextEditingController();
  final _emailCtrl = TextEditingController();
  final _websiteCtrl = TextEditingController();
  final _addressCtrl = TextEditingController();
  final _scrollCtrl = ScrollController();
  // One key per field so the page can scroll straight to the first mistake.
  final Map<TextEditingController, GlobalKey> _fieldKeys = {};
  String? _photoPath;
  bool _saving = false;
  String _currency = guessCurrencyFromLocale();

  @override
  void dispose() {
    _scrollCtrl.dispose();
    _ownerCtrl.dispose();
    _designationCtrl.dispose();
    _businessCtrl.dispose();
    _taglineCtrl.dispose();
    _phoneCtrl.dispose();
    _whatsappCtrl.dispose();
    _emailCtrl.dispose();
    _websiteCtrl.dispose();
    _addressCtrl.dispose();
    super.dispose();
  }

  Future<void> _pickPhoto() async {
    try {
      final picked = await ImagePicker().pickImage(
        source: ImageSource.gallery,
        imageQuality: 80,
        maxWidth: 720,
      );
      if (picked == null) return;
      final dir = await getApplicationDocumentsDirectory();
      final ext = picked.path.split('.').last;
      final dest = File('${dir.path}/profile_photo.$ext');
      await File(picked.path).copy(dest.path);
      if (!mounted) return;
      setState(() => _photoPath = dest.path);
    } catch (_) {
      _msg("Couldn't open the photo picker. Please try again.");
    }
  }

  void _msg(String text) {
    if (!mounted) return;
    AppMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(text)));
  }

  String? _required(String? v, String label) =>
      (v == null || v.trim().isEmpty) ? 'Please enter $label' : null;

  String? _phoneRule(String? v) {
    final value = (v ?? '').trim();
    if (value.isEmpty) return 'Please enter your mobile number';
    final digits = value.replaceAll(RegExp(r'[^0-9]'), '');
    if (digits.length < 7 || digits.length > 15) return 'Enter a valid mobile number';
    return null;
  }

  String? _optionalPhone(String? v) {
    final value = (v ?? '').trim();
    if (value.isEmpty) return null;
    final digits = value.replaceAll(RegExp(r'[^0-9]'), '');
    if (digits.length < 7 || digits.length > 15) return 'Enter a valid number';
    return null;
  }

  String? _optionalEmail(String? v) {
    final value = (v ?? '').trim();
    if (value.isEmpty) return null;
    final ok = RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$').hasMatch(value);
    return ok ? null : 'Enter a valid email address';
  }

  /// Scrolls the page to the first field that fails validation (top to bottom).
  void _scrollToFirstError() {
    final checks = <TextEditingController, String? Function(String?)>{
      _ownerCtrl: (v) => _required(v, 'your name'),
      _businessCtrl: (v) => _required(v, 'your business name'),
      _phoneCtrl: _phoneRule,
      _whatsappCtrl: _optionalPhone,
      _emailCtrl: _optionalEmail,
    };
    for (final entry in checks.entries) {
      if (entry.value(entry.key.text) == null) continue;
      final ctx = _fieldKeys[entry.key]?.currentContext;
      if (ctx != null) {
        Scrollable.ensureVisible(
          ctx,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
          alignment: 0.15,
        );
      }
      break;
    }
  }

  Future<void> _submit() async {
    if (_saving) return;
    FocusScope.of(context).unfocus();
    if (!(_formKey.currentState?.validate() ?? false)) {
      _scrollToFirstError();
      _msg('Please fix the highlighted field.');
      return;
    }
    setState(() => _saving = true);
    try {
      final repo = ProfileRepository();
      final current = await repo.getOrCreate();
      final updated = current.copyWith(
        name: _businessCtrl.text.trim(),
        ownerName: _ownerCtrl.text.trim(),
        designation: _designationCtrl.text.trim(),
        tagline: _taglineCtrl.text.trim(),
        phone: _phoneCtrl.text.trim(),
        whatsapp: _whatsappCtrl.text.trim(),
        email: _emailCtrl.text.trim(),
        website: _websiteCtrl.text.trim(),
        address: _addressCtrl.text.trim(),
        currency: _currency,
        photoPath: _photoPath,
        clearPhoto: _photoPath == null,
      );
      await repo.save(updated);
      await OnboardingRepository().setRegistrationComplete();
      if (!mounted) return;
      context.read<UserPreferencesController>().applyProfile(updated);
      Navigator.of(context).pushAndRemoveUntil(
        AppTransitions.seamless(const RootShell()),
        (route) => false,
      );
    } catch (_) {
      if (mounted) {
        setState(() => _saving = false);
        _msg('Could not save your details. Please try again.');
      }
    }
  }

  Future<void> _pickCurrency() async {
    FocusScope.of(context).unfocus();
    final picked = await showModalBottomSheet<String>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => _CurrencySheet(selected: _currency),
    );
    if (picked != null && mounted) setState(() => _currency = picked);
  }

  Widget _currencyTile() {
    final info = currencyInfoFor(_currency);
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: _pickCurrency,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          decoration: BoxDecoration(
            color: const Color(0xFFF3F5FB),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: _g1.withValues(alpha: 0.35), width: 1.2),
          ),
          child: Row(
            children: [
              Container(
                width: 42,
                height: 42,
                alignment: Alignment.center,
                decoration: BoxDecoration(color: _g1.withValues(alpha: 0.10), shape: BoxShape.circle),
                child: Text(
                  info?.symbol ?? _currency,
                  style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: _g1),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '$_currency  ${info?.flag ?? ''}',
                      style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      'Amounts, receipts and reports will use ${info?.name ?? _currency}',
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 11.5, color: AppColors.lightTextSecondary),
                    ),
                  ],
                ),
              ),
              const Icon(Icons.keyboard_arrow_down_rounded, color: _g1),
            ],
          ),
        ),
      ),
    );
  }

  InputDecoration _decoration(String label, IconData icon, {String? hint}) {
    OutlineInputBorder border(Color c, [double w = 1]) => OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: BorderSide(color: c, width: w),
        );
    return InputDecoration(
      labelText: label,
      hintText: hint,
      prefixIcon: Icon(icon, size: 20, color: _g1),
      filled: true,
      fillColor: const Color(0xFFF3F5FB),
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      enabledBorder: border(const Color(0xFFE4E8F3)),
      focusedBorder: border(_g1, 1.6),
      errorBorder: border(AppColors.expense),
      focusedErrorBorder: border(AppColors.expense, 1.6),
      labelStyle: const TextStyle(fontSize: 13.5, color: AppColors.lightTextSecondary),
    );
  }

  Widget _field(
    String label,
    TextEditingController c,
    IconData icon, {
    String? hint,
    TextInputType? type,
    TextCapitalization caps = TextCapitalization.none,
    int lines = 1,
    String? Function(String?)? validator,
    TextInputAction action = TextInputAction.next,
  }) {
    return Padding(
      key: _fieldKeys.putIfAbsent(c, () => GlobalKey()),
      padding: const EdgeInsets.only(bottom: 12),
      child: TextFormField(
        controller: c,
        scrollPadding: const EdgeInsets.fromLTRB(20, 20, 20, 160),
        keyboardType: type,
        textCapitalization: caps,
        textInputAction: lines > 1 ? TextInputAction.newline : action,
        maxLines: lines,
        validator: validator,
        decoration: _decoration(label, icon, hint: hint),
      ),
    );
  }

  Widget _section(String title, IconData icon) => Padding(
        padding: const EdgeInsets.only(top: 6, bottom: 12),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(7),
              decoration: BoxDecoration(
                color: _g1.withValues(alpha: 0.10),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(icon, size: 16, color: _g1),
            ),
            const SizedBox(width: 10),
            Text(title, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800)),
          ],
        ),
      );

  Widget _avatar() {
    final has = _photoPath != null && File(_photoPath!).existsSync();
    return GestureDetector(
      onTap: _pickPhoto,
      child: Stack(
        children: [
          Container(
            padding: const EdgeInsets.all(3),
            decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle),
            child: CircleAvatar(
              radius: 42,
              backgroundColor: const Color(0xFFE8EDFB),
              backgroundImage: has ? FileImage(File(_photoPath!)) : null,
              child: has ? null : const Icon(Icons.person_rounded, size: 42, color: _g1),
            ),
          ),
          Positioned(
            right: 0,
            bottom: 2,
            child: Container(
              padding: const EdgeInsets.all(7),
              decoration: BoxDecoration(
                color: _g1,
                shape: BoxShape.circle,
                border: Border.all(color: Colors.white, width: 2),
              ),
              child: const Icon(Icons.camera_alt_rounded, size: 14, color: Colors.white),
            ),
          ),
        ],
      ),
    );
  }

  Widget _submitButton() {
    return Container(
      height: 48,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(30),
        gradient: const LinearGradient(colors: [_g1, _g2]),
        boxShadow: [
          BoxShadow(color: _g1.withValues(alpha: 0.35), blurRadius: 14, offset: const Offset(0, 6)),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(30),
          onTap: _saving ? null : _submit,
          child: Center(
            child: _saving
                ? const SizedBox(
                    width: 22,
                    height: 22,
                    child: CircularProgressIndicator(strokeWidth: 2.4, color: Colors.white),
                  )
                : const Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        'Create Account & Continue',
                        style: TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w800),
                      ),
                      SizedBox(width: 8),
                      Icon(Icons.arrow_forward_rounded, color: Colors.white, size: 19),
                    ],
                  ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final media = MediaQuery.of(context);
    return Scaffold(
      backgroundColor: const Color(0xFFEFF2FB),
      // The body resizes above the keyboard and the whole page scrolls, so
      // every field can always be reached and typed into.
      resizeToAvoidBottomInset: true,
      body: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: SingleChildScrollView(
          controller: _scrollCtrl,
          keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
          physics: const AlwaysScrollableScrollPhysics(),
          child: Column(
            children: [
              Container(
                width: double.infinity,
                padding: EdgeInsets.fromLTRB(24, media.padding.top + 18, 24, 56),
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [_g1, _g2],
                  ),
                  borderRadius: BorderRadius.vertical(bottom: Radius.circular(34)),
                ),
                child: Column(
                  children: [
                    _avatar(),
                    const SizedBox(height: 12),
                    const Text(
                      'Create Your Account',
                      style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w800),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Tell us about you and your business. You can change this later from Profile.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.white.withValues(alpha: 0.88), fontSize: 13, height: 1.4),
                    ),
                  ],
                ),
              ),
              Transform.translate(
                offset: const Offset(0, -34),
                child: Container(
                  margin: const EdgeInsets.symmetric(horizontal: 14),
                  padding: const EdgeInsets.fromLTRB(18, 18, 18, 24),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(28),
                    boxShadow: [
                      BoxShadow(color: Colors.black.withValues(alpha: 0.08), blurRadius: 22, offset: const Offset(0, 10)),
                    ],
                  ),
                  child: Form(
                    key: _formKey,
                    autovalidateMode: AutovalidateMode.onUserInteraction,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        _section('Your Currency', Icons.payments_rounded),
                        _currencyTile(),
                        _section('Owner Details', Icons.verified_user_rounded),
                        _field('Owner / Administrator Name *', _ownerCtrl, Icons.person_rounded,
                            hint: 'Your full name',
                            caps: TextCapitalization.words,
                            validator: (v) => _required(v, 'your name')),
                        _field('Designation', _designationCtrl, Icons.badge_rounded,
                            hint: 'e.g. Owner, Manager', caps: TextCapitalization.words),
                        _section('Business Details', Icons.storefront_rounded),
                        _field('Business Name *', _businessCtrl, Icons.business_rounded,
                            hint: 'Your shop or company name',
                            caps: TextCapitalization.words,
                            validator: (v) => _required(v, 'your business name')),
                        _field('Tagline (optional)', _taglineCtrl, Icons.auto_awesome_rounded,
                            hint: 'e.g. Quality you can trust', caps: TextCapitalization.sentences),
                        _field('Mobile Number *', _phoneCtrl, Icons.phone_rounded,
                            hint: '03XX XXXXXXX', type: TextInputType.phone, validator: _phoneRule),
                        _field('WhatsApp Number (optional)', _whatsappCtrl, Icons.chat_rounded,
                            hint: 'WhatsApp number', type: TextInputType.phone, validator: _optionalPhone),
                        _field('Email (optional)', _emailCtrl, Icons.email_rounded,
                            hint: 'name@email.com', type: TextInputType.emailAddress, validator: _optionalEmail),
                        _field('Website (optional)', _websiteCtrl, Icons.language_rounded,
                            hint: 'www.yourbusiness.com', type: TextInputType.url),
                        _field('Address (optional)', _addressCtrl, Icons.location_on_rounded,
                            hint: 'Shop / office address', lines: 2, caps: TextCapitalization.sentences,
                            action: TextInputAction.done),
                        const SizedBox(height: 6),
                        _submitButton(),
                        const SizedBox(height: 12),
                        const Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.lock_rounded, size: 14, color: AppColors.lightTextSecondary),
                            SizedBox(width: 6),
                            Flexible(
                              child: Text(
                                'Your details stay only on this phone.',
                                style: TextStyle(fontSize: 12, color: AppColors.lightTextSecondary),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              // Compensates the -34 overlap above and keeps the last field
              // clear of the system navigation bar.
              SizedBox(height: media.padding.bottom),
            ],
          ),
        ),
      ),
    );
  }
}


/// Searchable currency chooser shown from the Register screen.
class _CurrencySheet extends StatefulWidget {
  const _CurrencySheet({required this.selected});
  final String selected;

  @override
  State<_CurrencySheet> createState() => _CurrencySheetState();
}

class _CurrencySheetState extends State<_CurrencySheet> {
  static const _blue = Color(0xFF1E4FC4);
  String _query = '';

  @override
  Widget build(BuildContext context) {
    final q = _query.trim().toLowerCase();
    final list = kCurrencies.where((c) {
      if (q.isEmpty) return true;
      return c.code.toLowerCase().contains(q) ||
          c.name.toLowerCase().contains(q) ||
          c.symbol.toLowerCase().contains(q);
    }).toList();
    final height = MediaQuery.of(context).size.height * 0.78;
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: Container(
        height: height,
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
        ),
        child: Column(
          children: [
            const SizedBox(height: 10),
            Container(
              width: 42,
              height: 4,
              decoration: BoxDecoration(color: const Color(0xFFD7DDEB), borderRadius: BorderRadius.circular(4)),
            ),
            const Padding(
              padding: EdgeInsets.fromLTRB(20, 16, 20, 4),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text('Choose your currency', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800)),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
              child: TextField(
                onChanged: (v) => setState(() => _query = v),
                decoration: InputDecoration(
                  hintText: 'Search e.g. PKR, Taka, Dollar',
                  prefixIcon: const Icon(Icons.search_rounded),
                  filled: true,
                  fillColor: const Color(0xFFF3F5FB),
                  contentPadding: const EdgeInsets.symmetric(vertical: 12),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(16),
                    borderSide: BorderSide.none,
                  ),
                ),
              ),
            ),
            Expanded(
              child: list.isEmpty
                  ? const Center(child: Text('No currency found'))
                  : ListView.builder(
                      padding: const EdgeInsets.fromLTRB(16, 4, 16, 20),
                      itemCount: list.length,
                      itemBuilder: (context, i) {
                        final c = list[i];
                        final selected = c.code == widget.selected;
                        return Padding(
                          padding: const EdgeInsets.only(bottom: 8),
                          child: InkWell(
                            borderRadius: BorderRadius.circular(16),
                            onTap: () => Navigator.of(context).pop(c.code),
                            child: Container(
                              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                              decoration: BoxDecoration(
                                color: selected ? _blue.withValues(alpha: 0.08) : const Color(0xFFF7F8FC),
                                borderRadius: BorderRadius.circular(16),
                                border: Border.all(color: selected ? _blue : Colors.transparent, width: 1.4),
                              ),
                              child: Row(
                                children: [
                                  Text(c.flag, style: const TextStyle(fontSize: 26)),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(c.code, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800)),
                                        Text(c.name, style: const TextStyle(fontSize: 12, color: AppColors.lightTextSecondary)),
                                      ],
                                    ),
                                  ),
                                  Text(
                                    c.symbol,
                                    style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: _blue),
                                  ),
                                  const SizedBox(width: 10),
                                  Icon(
                                    selected ? Icons.check_circle_rounded : Icons.circle_outlined,
                                    color: selected ? _blue : const Color(0xFFC9D3EA),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
