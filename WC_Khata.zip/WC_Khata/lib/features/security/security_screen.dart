import 'package:flutter/material.dart';
import '../../app/theme/app_theme.dart';
import '../../core/widgets/app_bottom_sheet.dart';
import '../../core/widgets/app_card.dart';
import '../../core/widgets/modern_header.dart';
import '../../data/repositories/security_settings_repository.dart';
import '../../core/widgets/app_button_3d.dart';
import '../../core/widgets/app_message.dart';

/// The ONLY security screen in this app. Per spec there is no
/// fingerprint / pattern / PIN / Face ID anywhere — password only.
class SecurityScreen extends StatefulWidget {
  const SecurityScreen({super.key});

  @override
  State<SecurityScreen> createState() => _SecurityScreenState();
}

class _SecurityScreenState extends State<SecurityScreen> {
  final _repo = SecuritySettingsRepository();
  bool _enabled = false;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final enabled = await _repo.isPasswordEnabled();
    setState(() {
      _enabled = enabled;
      _loading = false;
    });
  }

  Future<void> _promptEnable() async {
    final pass1 = TextEditingController();
    final pass2 = TextEditingController();
    String? error;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setState) => AlertDialog(
          title: const Text('Create Password'),
          content: AppDialogContent(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(controller: pass1, obscureText: true, decoration: const InputDecoration(hintText: 'New password')),
                const SizedBox(height: AppDimensions.spaceSm),
                TextField(controller: pass2, obscureText: true, decoration: const InputDecoration(hintText: 'Confirm password')),
                if (error != null) Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: Text(error!, style: const TextStyle(color: AppColors.expense)),
                ),
              ],
            ),
          ),
          actions: [
            AppButton3D(label: 'Cancel', outlined: true, compact: true, onPressed: () => Navigator.pop(ctx, false)),
            AppButton3D(
              compact: true,
              onPressed: () {
                if (pass1.text.length < 4) {
                  setState(() => error = 'Password must be at least 4 characters');
                  return;
                }
                if (pass1.text != pass2.text) {
                  setState(() => error = 'Passwords do not match');
                  return;
                }
                Navigator.pop(ctx, true);
              },
              label: 'Enable',
            ),
          ],
        ),
      ),
    );
    if (confirmed == true) {
      await _repo.enablePassword(pass1.text);
      await _load();
    }
  }

  Future<void> _promptChange() async {
    final current = TextEditingController();
    final next = TextEditingController();
    String? error;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setState) => AlertDialog(
          title: const Text('Change Password'),
          content: AppDialogContent(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(controller: current, obscureText: true, decoration: const InputDecoration(hintText: 'Current password')),
                const SizedBox(height: AppDimensions.spaceSm),
                TextField(controller: next, obscureText: true, decoration: const InputDecoration(hintText: 'New password')),
                if (error != null) Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: Text(error!, style: const TextStyle(color: AppColors.expense)),
                ),
              ],
            ),
          ),
          actions: [
            AppButton3D(label: 'Cancel', outlined: true, compact: true, onPressed: () => Navigator.pop(ctx, false)),
            AppButton3D(
              compact: true,
              onPressed: () async {
                if (next.text.length < 4) {
                  setState(() => error = 'Password must be at least 4 characters');
                  return;
                }
                try {
                  await _repo.changePassword(current.text, next.text);
                  if (ctx.mounted) Navigator.pop(ctx, true);
                } catch (_) {
                  setState(() => error = 'Current password is incorrect');
                }
              },
              label: 'Save',
            ),
          ],
        ),
      ),
    );
    if (confirmed == true && mounted) {
      AppMessenger.of(context).showSnackBar(const SnackBar(content: Text('Password changed')));
    }
  }

  Future<void> _promptRemove() async {
    final current = TextEditingController();
    String? error;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setState) => AlertDialog(
          title: const Text('Remove Password'),
          content: AppDialogContent(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(controller: current, obscureText: true, decoration: const InputDecoration(hintText: 'Current password')),
                if (error != null) Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: Text(error!, style: const TextStyle(color: AppColors.expense)),
                ),
              ],
            ),
          ),
          actions: [
            AppButton3D(label: 'Cancel', outlined: true, compact: true, onPressed: () => Navigator.pop(ctx, false)),
            AppButton3D(
              color: AppColors.expense,
              compact: true,
              onPressed: () async {
                try {
                  await _repo.removePassword(current.text);
                  if (ctx.mounted) Navigator.pop(ctx, true);
                } catch (_) {
                  setState(() => error = 'Incorrect password');
                }
              },
              label: 'Remove',
            ),
          ],
        ),
      ),
    );
    if (confirmed == true) await _load();
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Scaffold(
      backgroundColor: isDark ? AppColors.darkBackground : AppColors.lightBackground,
      body: Column(
        children: [
          ModernHeader(title: 'Security', onBack: () => Navigator.pop(context)),
          Expanded(
            child: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(AppDimensions.spaceMd),
              children: [
                AppCard(
                  borderColor: isDark ? null : Colors.black,
                  child: Row(
                    children: [
                      const Icon(Icons.lock, color: AppColors.primary),
                      const SizedBox(width: AppDimensions.spaceMd),
                      const Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('App Password', style: AppTextStyles.bodyMedium),
                            Text('Require a password to open the app', style: AppTextStyles.caption, maxLines: 2),
                          ],
                        ),
                      ),
                      Switch(
                        value: _enabled,
                        activeThumbColor: AppColors.primary,
                        onChanged: (v) async {
                          if (v) {
                            await _promptEnable();
                          } else {
                            await _promptRemove();
                          }
                        },
                      ),
                    ],
                  ),
                ),
                if (_enabled) ...[
                  const SizedBox(height: AppDimensions.spaceSm),
                  AppCard(
                    borderColor: isDark ? null : Colors.black,
                    onTap: _promptChange,
                    child: Row(
                      children: [
                        const Icon(Icons.vpn_key, color: AppColors.primary),
                        const SizedBox(width: AppDimensions.spaceMd),
                        const Expanded(child: Text('Change Password', style: AppTextStyles.bodyMedium)),
                        const Icon(Icons.chevron_right, size: 18, color: AppColors.lightTextSecondary),
                      ],
                    ),
                  ),
                  const SizedBox(height: AppDimensions.spaceSm),
                  AppCard(
                    borderColor: isDark ? null : Colors.black,
                    onTap: _promptRemove,
                    child: Row(
                      children: [
                        const Icon(Icons.lock_open, color: AppColors.expense),
                        const SizedBox(width: AppDimensions.spaceMd),
                        const Expanded(child: Text('Remove Password', style: AppTextStyles.bodyMedium)),
                        const Icon(Icons.chevron_right, size: 18, color: AppColors.lightTextSecondary),
                      ],
                    ),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}
