import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import '../../app/theme/app_theme.dart';
import '../../core/services/backup_service.dart';
import '../../core/widgets/app_button_3d.dart';
import '../../core/widgets/modern_header.dart';
import '../../core/widgets/app_message.dart';

class BackupScreen extends StatefulWidget {
  const BackupScreen({super.key});

  @override
  State<BackupScreen> createState() => _BackupScreenState();
}

class _BackupScreenState extends State<BackupScreen> {
  final _service = BackupService();
  bool _creating = false;

  Future<void> _createBackup() async {
    setState(() => _creating = true);
    try {
      final file = await _service.createBackup();
      if (mounted) {
        await Share.shareXFiles([XFile(file.path)], text: 'WC Khata backup');
      }
    } catch (e) {
      if (mounted) {
        AppMessenger.of(context).showSnackBar(SnackBar(content: Text('Backup failed: $e')));
      }
    } finally {
      if (mounted) setState(() => _creating = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Scaffold(
      backgroundColor: isDark ? AppColors.darkBackground : AppColors.lightBackground,
      body: Column(
        children: [
          ModernHeader(title: 'Backup', onBack: () => Navigator.pop(context)),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(AppDimensions.spaceMd),
              child: Column(
                children: [
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(AppDimensions.spaceLg),
                    decoration: BoxDecoration(color: AppColors.lightSurface, borderRadius: BorderRadius.circular(AppDimensions.radiusLg), border: Border.all(color: AppColors.lightCardBorder)),
                    child: Column(
                      children: [
                        const Icon(Icons.backup, size: 40, color: AppColors.primary),
                        const SizedBox(height: AppDimensions.spaceMd),
                        const Text('Create Backup', style: AppTextStyles.h3),
                        const SizedBox(height: 4),
                        Text(
                          'Create a local backup file of all your data — products, sales, customers, suppliers, cashbook and settings. Product photos are not included.',
                          textAlign: TextAlign.center,
                          style: AppTextStyles.caption.copyWith(color: AppColors.lightTextSecondary),
                        ),
                        const SizedBox(height: AppDimensions.spaceLg),
                        AppButton3D(
                          label: _creating ? 'Creating...' : 'Create Backup',
                          icon: Icons.backup,
                          color: AppColors.income,
                          expand: true,
                          onPressed: _creating ? null : _createBackup,
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: AppDimensions.spaceMd),
                  Text(
                    'Backups are stored only on this device unless you choose to share or save them elsewhere. Nothing is ever uploaded automatically.',
                    textAlign: TextAlign.center,
                    style: AppTextStyles.caption.copyWith(color: AppColors.lightTextSecondary),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
