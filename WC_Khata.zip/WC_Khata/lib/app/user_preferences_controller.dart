import 'package:flutter/foundation.dart';
import '../core/utils/currency_formatter.dart';
import '../core/utils/currency_symbols.dart';
import '../data/models/profile_model.dart';
import '../data/repositories/profile_repository.dart';

/// App-wide reactive cache of the profile fields that other screens
/// need to react to instantly: currency and profile photo.
///
/// The `profile` table in SQLite (via [ProfileRepository]) remains the
/// single source of truth — this controller just mirrors it in memory
/// so that the moment the Profile screen saves a change, every other
/// screen already built (home header avatar, every currency amount in
/// Finance/Goals/Budget/Reports/etc.) updates immediately without a
/// reload or app restart.
class UserPreferencesController extends ChangeNotifier {
  String _currencyCode = 'USD';
  String? _photoPath;

  String get currencyCode => _currencyCode;
  String get currencySymbol => currencySymbolFor(_currencyCode);
  String? get photoPath => _photoPath;

  Future<void> load() async {
    final profile = await ProfileRepository().getOrCreate();
    _apply(profile);
  }

  /// Called by the Profile screen immediately after it persists a
  /// change to the database.
  void applyProfile(ProfileModel profile) {
    _apply(profile);
  }

  void _apply(ProfileModel profile) {
    _currencyCode = profile.currency;
    _photoPath = profile.photoPath;
    // Every CurrencyFormatter.format/formatCompact call across the app
    // reads this shared default, so updating it here is what makes
    // "change currency" affect the whole app at once.
    CurrencyFormatter.defaultSymbol = currencySymbol;
    CurrencyFormatter.defaultCode = profile.currency;
    notifyListeners();
  }
}
