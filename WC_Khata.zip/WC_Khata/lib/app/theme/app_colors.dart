import 'package:flutter/material.dart';

/// Centralized color palette. Never hard-code colors inside widgets —
/// always reference AppColors so light/dark theming stays consistent.
///
/// The whole app now follows a plain, bank-style palette (matching the
/// UBL app reference): white app bars, blue accents, black text. No
/// green/gradient "hero" chrome anywhere in the shell UI — green is
/// only ever used as the semantic "income" color inside data (amounts,
/// tags), never as a background or brand color.
class AppColors {
  AppColors._();

  // Brand / primary — the one accent color used across the app: app
  // bar icons, the balance card, buttons, selected states.
  static const Color primary = Color(0xFF2F6FED);
  static const Color primaryDark = Color(0xFF1E4FC4);
  static const Color primaryLight = Color(0xFF5B8CFF);

  // Status / semantic — matches Income (green) and Expense (red)
  // amounts/tags. These stay green/red because that's a universal
  // financial convention, not a theme color — they never appear as a
  // screen or bar background.
  static const Color income = Color(0xFF17B26A);
  static const Color incomeLight = Color(0xFFDFF7E9);
  static const Color expense = Color(0xFFF04438);
  static const Color expenseLight = Color(0xFFFDE3E1);
  static const Color warning = Color(0xFFF79009);
  static const Color warningLight = Color(0xFFFEF0C7);

  // Category accent colors (used for category icons/chips)
  static const Color catFood = Color(0xFFFF7A59);
  static const Color catTransport = Color(0xFF2F80ED);
  static const Color catShopping = Color(0xFFB65FF0);
  static const Color catBills = Color(0xFFFFA43C);
  static const Color catHealth = Color(0xFFEF5DA8);
  static const Color catEducation = Color(0xFF17B26A);
  static const Color catEntertainment = Color(0xFF6F5AE0);
  static const Color catOther = Color(0xFF98A2B3);

  // Light theme surfaces
  static const Color lightBackground = Color(0xFFF7F8FA);
  static const Color lightSurface = Color(0xFFFFFFFF);
  static const Color lightCardBorder = Color(0xFFEEF1F4);
  static const Color lightTextPrimary = Color(0xFF101828);
  static const Color lightTextSecondary = Color(0xFF667085);
  static const Color lightDivider = Color(0xFFE4E7EC);

  // Dark theme surfaces
  static const Color darkBackground = Color(0xFF0F1115);
  static const Color darkSurface = Color(0xFF1A1D24);
  static const Color darkCardBorder = Color(0xFF2A2E37);
  static const Color darkTextPrimary = Color(0xFFF2F4F7);
  static const Color darkTextSecondary = Color(0xFF98A2B3);
  static const Color darkDivider = Color(0xFF2A2E37);

  static const List<Color> balanceGradient = [
    Color(0xFF2F6FED),
    Color(0xFF5B8CFF),
  ];

  // App bar — always blue icons. Background/text flip with the
  // theme: white bg + black text in light mode, black bg + white
  // text in dark mode (see [barBackground]/[barText]). Used by both
  // Home's own top bar and ModernHeader (Finance/Tasks/Profile
  // sheets), so every screen's top bar reads as one consistent bar.
  static const Color appBarBackground = Color(0xFFFFFFFF);
  static const Color appBarIcon = primary;
  static const Color appBarText = lightTextPrimary;

  /// App bar / main-screen background for the given theme — white in
  /// light mode, black in dark mode.
  static Color barBackground(bool isDark) => isDark ? darkBackground : appBarBackground;

  /// App bar / main-screen title & body text for the given theme —
  /// black in light mode, white in dark mode. Icons stay blue in
  /// both (see [appBarIcon]) — only background/text flip.
  static Color barText(bool isDark) => isDark ? Colors.white : appBarText;

  // Solid dark-blue fill for the balance card's pill buttons (currency
  // chip, Add Income/Add Expense) — replaces the old dark-green fill.
  static const Color heroButtonBg = primaryDark;

  /// Theme-aware tint for a status accent color (income/expense/warning,
  /// etc). Use this instead of a hardcoded pastel color (like the old
  /// [incomeLight]/[expenseLight]) for any card or chip background: it
  /// blends the accent into a soft pastel on light surfaces and a subtle
  /// dark tint on dark surfaces automatically, so the same card never
  /// looks "stuck" light when the app is in dark mode.
  static Color tint(Color accent, {required bool isDark}) {
    return accent.withValues(alpha: isDark ? 0.18 : 0.12);
  }
}
