import 'package:flutter/material.dart';
import '../../features/home/home_screen.dart';
import '../../core/widgets/app_bottom_nav.dart';
import '../../core/widgets/app_tab_screen.dart';
import '../../features/ledger/ledger_screen.dart';
import '../../features/sale/sale_screen.dart';
import '../../features/items/items_screen.dart';
import '../../features/more/more_screen.dart';
import '../../core/services/app_navigator.dart';
import '../../core/widgets/app_sidebar.dart';
import '../theme/app_theme.dart';

/// Root of the app: five full-screen tabs behind an Easy-Khata style
/// bottom bar. Tabs stay alive (IndexedStack) so Home keeps its state.
class RootShell extends StatefulWidget {
  const RootShell({super.key});

  @override
  State<RootShell> createState() => _RootShellState();
}

class _RootShellState extends State<RootShell> {
  int _index = 0;
  final GlobalKey<HomeScreenState> _homeKey = GlobalKey<HomeScreenState>();
  final GlobalKey<LedgerScreenState> _ledgerKey = GlobalKey<LedgerScreenState>();
  final GlobalKey<ItemsScreenState> _itemsKey = GlobalKey<ItemsScreenState>();

  static const _items = [
    AppNavItem(icon: Icons.home_outlined, activeIcon: Icons.home_rounded, label: 'Home'),
    AppNavItem(icon: Icons.menu_book_outlined, activeIcon: Icons.menu_book_rounded, label: 'Ledger'),
    AppNavItem(icon: Icons.point_of_sale_outlined, activeIcon: Icons.point_of_sale_rounded, label: 'Sale'),
    AppNavItem(icon: Icons.inventory_2_outlined, activeIcon: Icons.inventory_2_rounded, label: 'Products'),
    AppNavItem(icon: Icons.grid_view_outlined, activeIcon: Icons.grid_view_rounded, label: 'More'),
  ];

  void _openTab(int index) {
    setState(() => _index = index);
    _homeKey.currentState?.onTabChanged(index == 0);
    if (index == 0) {
      _homeKey.currentState?.refreshLedgerTotals();
    } else if (index == 1) {
      _ledgerKey.currentState?.reload();
    } else if (index == 3) {
      _itemsKey.currentState?.reload();
    }
  }

  void _goHome() => _openTab(0);

  List<Widget> _pages() => [
        HomeScreen(key: _homeKey, onOpenTab: _openTab),
        LedgerScreen(key: _ledgerKey, onBack: _goHome),
        AppTabScreen(title: 'Sale', onBack: _goHome, body: const SaleScreen()),
        AppTabScreen(title: 'Products', onBack: _goHome, body: ItemsScreen(key: _itemsKey)),
        AppTabScreen(title: 'More', onBack: _goHome, body: const MoreScreen()),
      ];

  Future<bool> _handleBack() async {
    final route = ModalRoute.of(context);
    if (route != null && !route.isCurrent) return true;
    if (_index != 0) {
      setState(() => _index = 0);
      _homeKey.currentState?.onTabChanged(true);
      return false;
    }
    return true;
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: _handleBack,
      child: Scaffold(
        key: rootScaffoldKey,
        resizeToAvoidBottomInset: false,
        backgroundColor: AppColors.lightBackground,
        drawer: const AppSidebar(),
        drawerScrimColor: Colors.black.withValues(alpha: 0.5),
        drawerEdgeDragWidth: 28,
        drawerEnableOpenDragGesture: _index == 0,
        body: Column(
          children: [
            Expanded(child: IndexedStack(index: _index, children: _pages())),
            AppBottomNav(
              currentIndex: _index,
              onTap: _openTab,
              items: _items,
            ),
          ],
        ),
      ),
    );
  }
}
