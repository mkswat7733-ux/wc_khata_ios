import '../core/utils/branding.dart';
import 'package:flutter/material.dart';
import '../core/routing/app_transitions.dart';
import '../data/repositories/onboarding_repository.dart';
import '../features/onboarding/onboarding_screen.dart';
import 'launch_gate.dart';
import 'theme/app_theme.dart';

/// Splash screen — animates the app identity in one grouped block
/// (name → version → tagline → company → progress bar), each line
/// fading and sliding in with a staggered delay, then automatically
/// navigates on after exactly [_splashDuration] (2 seconds) to:
///
///   * [OnboardingScreen] (5 slides) -> [RegisterScreen] -> Home, the first time the app is ever
///     opened (registration not complete yet), which flows on into
///     Register -> Set Password -> Home.
///   * [LaunchGate] — every launch after that, which routes straight
///     to the Home Dashboard (no password set) or the password unlock
///     screen (password set), exactly as before.
///
/// The progress line fills from empty to full over the 2 seconds; the moment
/// it is full the next screen opens.
///
/// There is no login step — Register/Set Password only ever run once.
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  static const _splashDuration = Duration(seconds: 2);

  late final AnimationController _controller;
  late final Animation<double> _appNameAnim;
  late final Animation<double> _versionAnim;
  late final Animation<double> _taglineAnim;
  late final Animation<double> _companyAnim;
  late final Animation<double> _progressAnim;

  @override
  void initState() {
    super.initState();

    // One controller drives everything for exactly 2 seconds: the texts fade
    // in during the first moments and the progress line fills the whole time.
    _controller = AnimationController(vsync: this, duration: _splashDuration);

    _appNameAnim = CurvedAnimation(parent: _controller, curve: const Interval(0.0, 0.25, curve: Curves.easeOut));
    _versionAnim = CurvedAnimation(parent: _controller, curve: const Interval(0.08, 0.32, curve: Curves.easeOut));
    _taglineAnim = CurvedAnimation(parent: _controller, curve: const Interval(0.14, 0.4, curve: Curves.easeOut));
    _companyAnim = CurvedAnimation(parent: _controller, curve: const Interval(0.22, 0.48, curve: Curves.easeOut));
    _progressAnim = CurvedAnimation(parent: _controller, curve: const Interval(0.0, 0.15, curve: Curves.easeOut));

    // The saved "registered" flag is read while the line is filling, so
    // nothing waits after it is full.
    _registered = _checkRegistered();
    _controller.forward().whenComplete(_openNext);
  }

  late final Future<bool> _registered;

  Future<bool> _checkRegistered() async {
    // If this check ever fails the app still opens (never stays on splash).
    try {
      return await OnboardingRepository().isRegistrationComplete().timeout(const Duration(seconds: 5));
    } catch (_) {
      return true;
    }
  }

  Future<void> _openNext() async {
    final registered = await _registered;
    if (!mounted) return;
    Navigator.of(context).pushReplacement(
      AppTransitions.seamless(registered ? const LaunchGate() : const OnboardingScreen()),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Widget _fadeSlideIn(Animation<double> animation, Widget child) {
    return FadeTransition(
      opacity: animation,
      child: SlideTransition(
        position: Tween<Offset>(
          begin: const Offset(0, 0.3),
          end: Offset.zero,
        ).animate(animation),
        child: child,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.darkBackground,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 32),
          child: AnimatedBuilder(
            animation: _controller,
            builder: (context, _) {
              return Column(
                children: [
                  const Spacer(flex: 5),
                  _fadeSlideIn(
                    _appNameAnim,
                    Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(30),
                        boxShadow: [
                          BoxShadow(
                            color: const Color(0xFF2F6FED).withValues(alpha: 0.45),
                            blurRadius: 36,
                            offset: const Offset(0, 14),
                          ),
                        ],
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(30),
                        child: Image.asset('assets/icons/app_icon.png', width: 124, height: 124),
                      ),
                    ),
                  ),
                  const SizedBox(height: 26),
                  _fadeSlideIn(
                    _appNameAnim,
                    const Text(
                      'WC Khata',
                      style: TextStyle(
                        fontSize: 30,
                        fontWeight: FontWeight.w700,
                        color: Colors.white,
                        height: 1.2,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                  const SizedBox(height: 14),
                  _fadeSlideIn(
                    _versionAnim,
                    Text(
                      'v${Branding.appVersion}',
                      style: AppTextStyles.body.copyWith(
                        color: Colors.white.withValues(alpha: 0.65),
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                  const SizedBox(height: 10),
                  _fadeSlideIn(
                    _taglineAnim,
                    Text(
                      'Your Smart Business Khata',
                      style: AppTextStyles.body.copyWith(
                        color: Colors.white.withValues(alpha: 0.85),
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                  const SizedBox(height: 22),
                  _fadeSlideIn(
                    _companyAnim,
                    Text(
                      'Powered by Webdsoft Company',
                      style: AppTextStyles.caption.copyWith(
                        color: Colors.white.withValues(alpha: 0.55),
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                  const SizedBox(height: 14),
                  FadeTransition(
                    opacity: _progressAnim,
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(4),
                      child: LinearProgressIndicator(
                        // 0 -> 1 over the 2 seconds; full = home opens.
                        value: _controller.value,
                        minHeight: 5,
                        backgroundColor: const Color(0xFF33505C),
                        valueColor: const AlwaysStoppedAnimation<Color>(Color(0xFF2E7BEF)),
                      ),
                    ),
                  ),
                  const Spacer(flex: 5),
                ],
              );
            },
          ),
        ),
      ),
    );
  }
}
