import 'package:flutter/material.dart';
import 'package:animations/animations.dart';

/// Page transitions built around one core idea — the "UBL-app" feel:
/// navigating should NOT look like a new screen sliding or popping in
/// from somewhere. It should feel like the CURRENT screen's content
/// gradually dissolves away, and the destination's content gradually
/// gathers into focus in that same place — nothing ever visibly
/// "arrives from a direction".
///
/// [seamless]/[fadeThrough] are built on Material's own official
/// FadeThroughTransition (from the `animations` package) rather than
/// hand-rolled fade logic — it's the exact, properly-coordinated
/// implementation of this pattern: the outgoing content fades out
/// first, and only once it's mostly gone does the incoming content
/// start fading + growing into place. Hand-rolling this with a plain
/// PageRouteBuilder is easy to get subtly wrong (both screens briefly
/// double-exposed, or the timing racing itself); this is the tested,
/// correct version of the same idea.
///
/// [slideFromBottom] is kept as the one deliberate exception — a
/// sheet-like "new form" feel is still expected for Add/Create
/// screens — but every browsing/drill-down navigation uses the
/// seamless fade-through instead of a slide.
///
/// Usage: `Navigator.push(context, AppTransitions.seamless(const AccountsScreen()))`
class AppTransitions {
  AppTransitions._();

  static const Duration _duration = Duration(milliseconds: 900);

  /// The default, used almost everywhere.
  static Route<T> seamless<T>(Widget page) {
    return PageRouteBuilder<T>(
      transitionDuration: _duration,
      reverseTransitionDuration: _duration,
      pageBuilder: (context, animation, secondaryAnimation) => page,
      transitionsBuilder: (context, animation, secondaryAnimation, child) {
        return FadeThroughTransition(
          animation: animation,
          secondaryAnimation: secondaryAnimation,
          child: child,
        );
      },
    );
  }

  /// Same fade-through pattern — kept as its own name for call sites
  /// that specifically want to signal "this is a full context change"
  /// (e.g. History, long ledgers), even though it behaves identically
  /// to [seamless] today.
  static Route<T> fadeThrough<T>(Widget page) => seamless(page);

  /// The one deliberate exception — used only for full-screen forms
  /// (Add Transaction, Add Task, Transfer, etc.), which are meant to
  /// feel like a distinct sheet being raised on top of things, not a
  /// dissolve into a sibling screen.
  static Route<T> slideFromBottom<T>(Widget page) {
    return PageRouteBuilder<T>(
      transitionDuration: _duration,
      reverseTransitionDuration: _duration,
      pageBuilder: (context, animation, secondaryAnimation) => page,
      transitionsBuilder: (context, animation, secondaryAnimation, child) {
        final curved = CurvedAnimation(parent: animation, curve: Curves.easeInOutCubic, reverseCurve: Curves.easeInOutCubic);
        return SlideTransition(
          position: Tween(begin: const Offset(0, 1), end: Offset.zero).animate(curved),
          child: FadeTransition(opacity: curved, child: child),
        );
      },
    );
  }

  // --- Back-compat aliases: everything now resolves to the same
  // seamless fade-through, so every existing call site across the app
  // picks up the new feel automatically without needing to touch each
  // one individually. ---
  static Route<T> slideFromRight<T>(Widget page) => seamless(page);
  static Route<T> slideFromLeft<T>(Widget page) => seamless(page);
  static Route<T> slideFromTop<T>(Widget page) => seamless(page);
  static Route<T> scaleFromCenter<T>(Widget page) => seamless(page);
}
