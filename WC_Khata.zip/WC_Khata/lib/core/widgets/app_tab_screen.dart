import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../app/theme/app_theme.dart';
import 'app_glass_icon_button.dart';

/// Shared root-tab screen: same top bar style as Home, but with a back
/// button (returns to the Home tab) and no notification button.
/// Used by Ledger, Sale, Items and More.
class AppTabScreen extends StatelessWidget {
  final String title;
  final Widget? body;
  final VoidCallback onBack;

  /// Optional widget on the right side of the top bar (e.g. a delete button).
  final Widget? trailing;

  const AppTabScreen({super.key, required this.title, required this.onBack, this.body, this.trailing});

  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: const SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        statusBarIconBrightness: Brightness.dark,
        statusBarBrightness: Brightness.light,
        systemStatusBarContrastEnforced: false,
      ),
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        backgroundColor: AppColors.lightBackground,
        body: Column(
          children: [
            _buildAppBar(context),
            Expanded(child: body ?? const SizedBox.expand()),
          ],
        ),
      ),
    );
  }

  Widget _buildAppBar(BuildContext context) {
    return Container(
      width: double.infinity,
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(bottom: BorderSide(color: AppColors.lightDivider)),
      ),
      child: SafeArea(
        bottom: false,
        child: Padding(
          padding: const EdgeInsets.symmetric(
            horizontal: AppDimensions.spaceMd,
            vertical: AppDimensions.spaceSm,
          ),
          child: SizedBox(
            height: 45,
            child: Stack(
              alignment: Alignment.center,
              children: [
                Center(
                  child: Text(
                    title,
                    style: const TextStyle(
                      color: AppColors.lightTextPrimary,
                      fontSize: 19,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
                Positioned(
                  left: 0,
                  child: AppGlassIconButton(
                    icon: Icons.arrow_back_rounded,
                    onTap: onBack,
                  ),
                ),
                if (trailing != null) Positioned(right: 0, child: trailing!),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
