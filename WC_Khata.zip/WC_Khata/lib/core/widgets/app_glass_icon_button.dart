import 'package:flutter/material.dart';
import '../../app/theme/app_theme.dart';

/// The small white floating circular icon button used on Home's header
/// (menu, theme toggle, notifications) — pulled out into its own
/// reusable widget so every header across the app (back buttons
/// included) gets the exact same "3D glass chip" look instead of each
/// screen hand-rolling its own icon button style.
class AppGlassIconButton extends StatelessWidget {
  const AppGlassIconButton({
    super.key,
    required this.icon,
    required this.onTap,
    this.scale = 1.0,
    this.iconColor,
    this.rotationTurns = 0.0,
  });

  final IconData icon;
  final VoidCallback onTap;
  final double scale;
  final Color? iconColor;
  final double rotationTurns;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      shape: const CircleBorder(),
      elevation: 5,
      shadowColor: Colors.black.withValues(alpha: 0.4),
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onTap,
        child: Padding(
          padding: EdgeInsets.all(11 * scale),
          child: AnimatedRotation(
            turns: rotationTurns,
            duration: const Duration(milliseconds: 320),
            curve: Curves.easeOutCubic,
            child: Icon(icon, color: iconColor ?? AppColors.appBarIcon, size: 21 * scale),
          ),
        ),
      ),
    );
  }
}
