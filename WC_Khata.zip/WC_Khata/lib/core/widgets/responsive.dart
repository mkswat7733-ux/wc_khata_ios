import 'package:flutter/material.dart';

/// App-wide overflow-safety toolkit.
///
/// Every "RIGHT OVERFLOWED BY N PIXELS" banner in this app comes from one
/// of two mistakes:
///
///  1. A plain `Row` holding several `Text` widgets (label + label + amount,
///     often with a `Spacer()`) with none of them wrapped in `Expanded` /
///     `Flexible`. This works fine while the text is short, then breaks the
///     moment a number gets longer or the screen gets narrower.
///  2. A fixed-width layout (a `SizedBox`/`Container` sized to an exact
///     pixel width) that then adds *more* content on top — padding, an
///     icon, extra text — without including that extra content in the
///     width budget.
///
/// The widgets below are drop-in replacements that make both mistakes
/// structurally impossible: content either wraps to a new line, or shrinks
/// to fit, instead of spilling past the edge of the screen. Use these
/// anywhere you're laying out a label + a value (especially money), on any
/// screen size.

/// A single line of text that shrinks to fit the space it's given instead
/// of overflowing. Use this for anything whose length isn't fully under
/// your control — currency amounts, user-entered names, totals — where a
/// bigger number or a smaller phone should never be able to break the
/// layout.
///
/// Unlike a bare `Text(..., overflow: TextOverflow.ellipsis)`, this never
/// truncates: it scales the font down instead, so the full value is always
/// visible. Only shrinks (never grows past [style]'s size), so normal-sized
/// content still looks exactly like a normal `Text`.
class AutoSizeText extends StatelessWidget {
  final String text;
  final TextStyle? style;
  final TextAlign textAlign;
  final int maxLines;

  const AutoSizeText(
    this.text, {
    super.key,
    this.style,
    this.textAlign = TextAlign.left,
    this.maxLines = 1,
  });

  @override
  Widget build(BuildContext context) {
    final alignment = switch (textAlign) {
      TextAlign.right || TextAlign.end => Alignment.centerRight,
      TextAlign.center => Alignment.center,
      _ => Alignment.centerLeft,
    };
    return FittedBox(
      fit: BoxFit.scaleDown,
      alignment: alignment,
      child: Text(
        text,
        style: style,
        textAlign: textAlign,
        maxLines: maxLines,
        overflow: TextOverflow.ellipsis,
      ),
    );
  }
}

/// A drop-in replacement for a `Row` of short stat/label texts (e.g.
/// "Income Rs10,000.00", "Expense Rs0.00", "+Rs10,000.00"). Instead of
/// overflowing off the right edge when the items don't all fit on one
/// line, the items that don't fit wrap onto the next line automatically —
/// on every screen size, with any amount of text.
///
/// This is the fix for the classic `Row(children: [Text(...), Text(...),
/// Spacer(), Text(...)])` pattern, which has no way to recover once the
/// content is wider than the screen.
class StatWrap extends StatelessWidget {
  final List<Widget> children;
  final double spacing;
  final double runSpacing;
  final WrapAlignment alignment;
  final WrapCrossAlignment crossAxisAlignment;

  const StatWrap({
    super.key,
    required this.children,
    this.spacing = 12,
    this.runSpacing = 4,
    this.alignment = WrapAlignment.start,
    this.crossAxisAlignment = WrapCrossAlignment.center,
  });

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: spacing,
      runSpacing: runSpacing,
      alignment: alignment,
      crossAxisAlignment: crossAxisAlignment,
      children: children,
    );
  }
}

/// A label + value pair (e.g. "Income" / "Rs10,000.00") that lays itself
/// out safely inside a [StatWrap] or any other loose-width parent. The
/// value auto-shrinks via [AutoSizeText] rather than overflowing.
class InlineStat extends StatelessWidget {
  final String label;
  final String value;
  final Color color;
  final TextStyle? labelStyle;
  final TextStyle? valueStyle;

  const InlineStat({
    super.key,
    required this.label,
    required this.value,
    required this.color,
    this.labelStyle,
    this.valueStyle,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text('$label ', style: labelStyle ?? TextStyle(fontSize: 12, color: color)),
        ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 160),
          child: AutoSizeText(
            value,
            style: valueStyle ?? TextStyle(fontSize: 12, color: color, fontWeight: FontWeight.w600),
          ),
        ),
      ],
    );
  }
}

/// Column-width spec for a [ResponsiveTable].
class TableColumnSpec {
  /// Header label.
  final String label;

  /// The narrowest this column is ever allowed to be — used on small
  /// screens (the table scrolls horizontally once columns hit this floor).
  final double minWidth;

  final TextAlign align;

  /// Whether this column should stretch to absorb any extra width once
  /// the screen is wide enough that the table would otherwise float in a
  /// sea of empty space (tablets, foldables, desktop windows). Usually
  /// set this on exactly one "description"-style column.
  final bool grows;

  const TableColumnSpec({
    required this.label,
    required this.minWidth,
    this.align = TextAlign.left,
    this.grows = false,
  });
}

/// A table that can never produce a "RIGHT OVERFLOWED" error, on any
/// screen size:
///  - Column widths are fixed minimums, and the row padding is *always*
///    counted as part of the total width budget (the #1 cause of
///    off-by-a-few-pixels overflow bugs in hand-built fixed-width rows).
///  - On a screen too narrow to fit every column at its minimum width, the
///    table scrolls horizontally, like a normal bank statement.
///  - On a screen wide enough to fit everything (large phones, tablets),
///    the column(s) marked [TableColumnSpec.grows] stretch to fill the
///    space instead of leaving the table stuck at a tiny width with dead
///    space next to it, and no scrolling is needed at all.
class ResponsiveTable extends StatelessWidget {
  final List<TableColumnSpec> columns;
  final int rowCount;
  final Widget Function(BuildContext context, int columnIndex, double width) headerCellBuilder;
  final Widget Function(BuildContext context, int rowIndex, int columnIndex, double width) cellBuilder;
  final Decoration? Function(int rowIndex)? rowDecoration;
  final EdgeInsets rowPadding;
  final Decoration? headerDecoration;
  final Widget? emptyState;

  const ResponsiveTable({
    super.key,
    required this.columns,
    required this.rowCount,
    required this.headerCellBuilder,
    required this.cellBuilder,
    this.rowDecoration,
    this.rowPadding = const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
    this.headerDecoration,
    this.emptyState,
  });

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final available = constraints.maxWidth.isFinite ? constraints.maxWidth : double.infinity;
        final minContentWidth = columns.fold<double>(0, (sum, c) => sum + c.minWidth);
        final hPad = rowPadding.horizontal;
        final minTotalWidth = minContentWidth + hPad;

        final widths = columns.map((c) => c.minWidth).toList(growable: false);
        var contentWidth = minContentWidth;

        if (available.isFinite && available > minTotalWidth) {
          final growers = columns.where((c) => c.grows).length;
          if (growers > 0) {
            final extra = (available - minTotalWidth) / growers;
            for (var i = 0; i < columns.length; i++) {
              if (columns[i].grows) widths[i] = widths[i] + extra;
            }
            contentWidth = available - hPad;
          }
        }

        final totalWidth = contentWidth + hPad;
        final needsScroll = available.isFinite && totalWidth > available + 0.5;

        Widget buildRow({required bool isHeader, int? rowIndex}) {
          return Padding(
            padding: rowPadding,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                for (var i = 0; i < columns.length; i++)
                  SizedBox(
                    width: widths[i],
                    child: isHeader
                        ? headerCellBuilder(context, i, widths[i])
                        : cellBuilder(context, rowIndex!, i, widths[i]),
                  ),
              ],
            ),
          );
        }

        final body = SizedBox(
          width: totalWidth,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(decoration: headerDecoration, child: buildRow(isHeader: true)),
              if (rowCount == 0 && emptyState != null)
                emptyState!
              else
                for (var r = 0; r < rowCount; r++)
                  Container(
                    decoration: rowDecoration != null ? rowDecoration!(r) : null,
                    child: buildRow(isHeader: false, rowIndex: r),
                  ),
            ],
          ),
        );

        if (!needsScroll) return body;
        return SingleChildScrollView(scrollDirection: Axis.horizontal, child: body);
      },
    );
  }
}
