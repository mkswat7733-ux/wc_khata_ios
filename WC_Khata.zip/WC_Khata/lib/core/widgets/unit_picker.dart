import 'package:flutter/material.dart';
import '../../app/theme/app_theme.dart';

/// Searchable unit selector. Shows the saved units; if the typed name is not in
/// the list a "Add <name>" row appears, so a brand new unit is created just by
/// typing its name and tapping it.
///
/// Returns the chosen unit name, or null if the sheet was dismissed.
/// [onAdd] is called with the final name when a NEW unit was created, so the
/// caller can remember it in its saved list.
Future<String?> showUnitPicker(
  BuildContext context, {
  required String title,
  required List<String> options,
  String? selected,
  required void Function(String name) onAdd,
}) {
  return showModalBottomSheet<String>(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (ctx) {
      var query = '';
      return StatefulBuilder(builder: (ctx, setSheet) {
        final q = query.trim();
        final lower = q.toLowerCase();
        final list = options.where((e) => lower.isEmpty || e.toLowerCase().contains(lower)).toList()
          ..sort((a, b) => a.toLowerCase().compareTo(b.toLowerCase()));
        final exists = options.any((e) => e.toLowerCase() == lower);
        final canAdd = q.isNotEmpty && !exists;
        final bottom = MediaQuery.viewInsetsOf(ctx).bottom;
        return Padding(
          padding: EdgeInsets.only(bottom: bottom),
          child: Container(
            height: MediaQuery.sizeOf(ctx).height * .62,
            decoration: const BoxDecoration(color: Colors.white, borderRadius: BorderRadius.vertical(top: Radius.circular(26))),
            child: Column(children: [
              const SizedBox(height: 10),
              Container(width: 42, height: 4, decoration: BoxDecoration(color: AppColors.lightDivider, borderRadius: BorderRadius.circular(99))),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 14, 16, 8),
                child: Align(alignment: Alignment.centerLeft, child: Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800))),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Container(
                  height: 46,
                  decoration: BoxDecoration(color: AppColors.lightBackground, borderRadius: BorderRadius.circular(13)),
                  child: TextField(
                    autofocus: false,
                    onChanged: (v) => setSheet(() => query = v),
                    decoration: const InputDecoration(border: InputBorder.none, prefixIcon: Icon(Icons.search_rounded, size: 20), hintText: 'Search or type a new name'),
                  ),
                ),
              ),
              const SizedBox(height: 6),
              Expanded(
                child: ListView(children: [
                  if (canAdd)
                    ListTile(
                      onTap: () {
                        onAdd(q);
                        Navigator.pop(ctx, q);
                      },
                      leading: CircleAvatar(backgroundColor: AppColors.primary.withValues(alpha: .12), child: Icon(Icons.add_rounded, color: AppColors.primary)),
                      title: Text('Add "$q"', style: TextStyle(fontWeight: FontWeight.w800, color: AppColors.primary)),
                      subtitle: const Text('Create as a new unit', style: TextStyle(fontSize: 11.5)),
                    ),
                  for (final u in list)
                    ListTile(
                      onTap: () => Navigator.pop(ctx, u),
                      leading: Icon(Icons.straighten_rounded, color: AppColors.primary),
                      title: Text(u, style: const TextStyle(fontWeight: FontWeight.w700)),
                      trailing: Icon(selected == u ? Icons.check_circle_rounded : Icons.chevron_right_rounded, color: selected == u ? AppColors.primary : AppColors.lightTextSecondary),
                    ),
                  if (list.isEmpty && !canAdd)
                    const Padding(
                      padding: EdgeInsets.all(28),
                      child: Center(child: Text('No saved units yet. Type a name to add one.', textAlign: TextAlign.center, style: TextStyle(color: AppColors.lightTextSecondary, fontWeight: FontWeight.w600))),
                    ),
                ]),
              ),
            ]),
          ),
        );
      });
    },
  );
}
