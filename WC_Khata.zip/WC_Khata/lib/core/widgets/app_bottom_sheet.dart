import 'package:flutter/material.dart';
import '../../app/theme/app_theme.dart';

/// Shows a modal bottom sheet whose content is ALWAYS wrapped in a
/// scroll view and constrained to a safe maximum height.
///
/// This is the single source of truth for "add/edit" forms across the
/// app (accounts, bills, goals, subscriptions, task items, etc). Using
/// it everywhere guarantees that no sheet can ever produce
/// a `BOTTOM OVERFLOWED BY xx PIXELS` error, regardless of:
///  - small screens / large screens
///  - the on-screen keyboard opening
///  - large accessibility font scales
///  - long validation/error text
///  - extra optional fields being added later
///
/// [builder] should return just the *content* column (title, fields,
/// button) — padding, scrolling, keyboard-avoidance and the max-height
/// clamp are all handled here so every call site stays consistent.
Future<T?> showAppBottomSheet<T>({
  required BuildContext context,
  required WidgetBuilder builder,
  bool isDismissible = true,
  bool enableDrag = true,
}) {
  return showModalBottomSheet<T>(
    context: context,
    isScrollControlled: true,
    isDismissible: isDismissible,
    enableDrag: enableDrag,
    useSafeArea: true,
    backgroundColor: Theme.of(context).scaffoldBackgroundColor,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(AppDimensions.radiusLg)),
    ),
    builder: (ctx) {
      final media = MediaQuery.of(ctx);
      // Never let the sheet try to be taller than ~90% of the usable
      // screen height (minus the keyboard). Anything beyond that
      // scrolls instead of overflowing.
      final maxHeight = media.size.height * 0.9;
      return ConstrainedBox(
        constraints: BoxConstraints(maxHeight: maxHeight),
        child: SingleChildScrollView(
          padding: EdgeInsets.only(
            left: AppDimensions.spaceLg,
            right: AppDimensions.spaceLg,
            top: AppDimensions.spaceLg,
            // Push content above the keyboard when it's visible.
            bottom: media.viewInsets.bottom + AppDimensions.spaceLg,
          ),
          child: builder(ctx),
        ),
      );
    },
  );
}

/// Wraps `AlertDialog` content in a scrollable, height-constrained box
/// so dialogs with several fields, long lists, or large font scales
/// never overflow the dialog surface either.
class AppDialogContent extends StatelessWidget {
  const AppDialogContent({super.key, required this.child, this.maxHeightFraction = 0.6});

  final Widget child;
  final double maxHeightFraction;

  @override
  Widget build(BuildContext context) {
    final maxHeight = MediaQuery.of(context).size.height * maxHeightFraction;
    return ConstrainedBox(
      constraints: BoxConstraints(maxHeight: maxHeight),
      child: SingleChildScrollView(child: child),
    );
  }
}
