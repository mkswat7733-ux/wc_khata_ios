import 'dart:convert';
import 'dart:math';
import 'package:crypto/crypto.dart';

/// The ONLY app-lock mechanism in this app is a password. There is no
/// fingerprint/biometric/PIN/pattern anywhere — do not add any.
/// Passwords are never stored in plain text: only a random salt and the
/// salted SHA-256 hash are persisted (see SecuritySettingsRepository).
class PasswordService {
  PasswordService._();

  static String generateSalt({int length = 16}) {
    final random = Random.secure();
    final bytes = List<int>.generate(length, (_) => random.nextInt(256));
    return base64Url.encode(bytes);
  }

  static String hash(String password, String salt) {
    final bytes = utf8.encode('$salt::$password');
    return sha256.convert(bytes).toString();
  }

  static bool verify(String password, String salt, String expectedHash) {
    return hash(password, salt) == expectedHash;
  }
}
