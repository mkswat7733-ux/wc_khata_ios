import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/foundation.dart';
import 'package:flutter/painting.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:printing/printing.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../features/printer/receipt_settings.dart';
import 'print_mode_service.dart';
import 'thermal_logo.dart';

/// A Bluetooth device as reported by the native side.
class PrinterDevice {
  final String name;
  final String address;
  final bool paired;

  const PrinterDevice({required this.name, required this.address, required this.paired});

  String get displayName => name.trim().isEmpty ? 'Unknown device' : name.trim();

  factory PrinterDevice.fromMap(Map<dynamic, dynamic> m) => PrinterDevice(
        name: (m['name'] as String?) ?? '',
        address: (m['address'] as String?) ?? '',
        paired: (m['paired'] as bool?) ?? false,
      );
}

/// Thrown with a user-readable (Roman Urdu) message.
class PrinterException implements Exception {
  final String message;
  const PrinterException(this.message);
  @override
  String toString() => message;
}

/// Command language of a label printer.
///   TSPL   - most label printers (Xprinter, Gprinter, TSC, Munbyn, HPRT...)
///   ESC/POS - dual printers running in receipt style (labels via raster + form feed)
///   ZPL    - Zebra and clones
///   CPCL   - portable label printers
enum LabelLanguage { tspl, escpos, zpl, cpcl }

extension LabelLanguageX on LabelLanguage {
  String get title => switch (this) {
        LabelLanguage.tspl => 'TSPL',
        LabelLanguage.escpos => 'ESC/POS',
        LabelLanguage.zpl => 'ZPL',
        LabelLanguage.cpcl => 'CPCL',
      };
}

/// How the printer finds the start of the next label.
enum LabelMedia { gap, blackMark, continuous }

extension LabelMediaX on LabelMedia {
  String get title => switch (this) {
        LabelMedia.gap => 'Gap labels',
        LabelMedia.blackMark => 'Black mark',
        LabelMedia.continuous => 'Continuous',
      };
}

/// Bluetooth thermal printer: connect, remember, and print every kind of
/// document (receipt image / PDF) directly in ESC/POS raster format.
/// 58mm paper = 384 dots wide, 80mm paper = 576 dots wide.
class ThermalPrinterService extends ChangeNotifier {
  ThermalPrinterService._() {
    _ch.setMethodCallHandler(_onNative);
  }

  static final ThermalPrinterService instance = ThermalPrinterService._();

  static const MethodChannel _ch = MethodChannel('wc_khata/printer');

  // Same key the receipt screen already uses for its 58/80 tabs.
  static const String paperPref = 'receipt_paper_mm';
  static const String _addressPref = 'thermal_printer_address';
  static const String _namePref = 'thermal_printer_name';

  final StreamController<PrinterDevice> _found = StreamController<PrinterDevice>.broadcast();
  final StreamController<void> _scanDone = StreamController<void>.broadcast();

  Stream<PrinterDevice> get onDeviceFound => _found.stream;
  Stream<void> get onScanFinished => _scanDone.stream;

  bool _loaded = false;
  String? _address;
  String? _name;
  int _paperMm = 58;
  bool _connected = false;

  bool get hasSavedPrinter => _address != null && _address!.isNotEmpty;
  String? get printerName => _name;
  String? get printerAddress => _address;
  int get paperMm => _paperMm;
  bool get connected => _connected;

  // ------------------------------------------------------- label printer
  // Dual printers do receipts AND labels on the same device ("same printer").
  // Otherwise a second Bluetooth printer is remembered just for labels.
  bool _labelSame = true;
  String? _labelAddress;
  String? _labelName;
  LabelLanguage _labelLang = LabelLanguage.tspl;
  LabelMedia _labelMedia = LabelMedia.gap;
  double _labelGapMm = 2;
  int _labelDensity = 8; // 1..15
  int _labelSpeed = 3; // 1..5
  int _labelDpi = 203; // 203 or 300
  bool _labelInvert = false;
  bool _labelRotate = false;
  // Fine alignment (mm): + moves the print right / down. Fixes labels that
  // print a little off-centre or get their border cut at an edge.
  double _labelOffXmm = 0;
  double _labelOffYmm = 0;

  bool get labelSamePrinter => _labelSame;
  String? get labelAddress => _labelSame ? _address : _labelAddress;
  String? get labelName => _labelSame ? _name : _labelName;
  bool get hasLabelPrinter => (labelAddress ?? '').isNotEmpty;
  LabelLanguage get labelLanguage => _labelLang;
  LabelMedia get labelMedia => _labelMedia;
  double get labelGapMm => _labelGapMm;
  int get labelDensity => _labelDensity;
  int get labelSpeed => _labelSpeed;
  int get labelDpi => _labelDpi;
  bool get labelInvert => _labelInvert;
  bool get labelRotate => _labelRotate;
  double get labelOffsetX => _labelOffXmm;
  double get labelOffsetY => _labelOffYmm;

  Future<void> _putPref(String key, Object value) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      if (value is int) {
        await prefs.setInt(key, value);
      } else if (value is bool) {
        await prefs.setBool(key, value);
      } else if (value is double) {
        await prefs.setDouble(key, value);
      } else if (value is String) {
        await prefs.setString(key, value);
      }
    } catch (_) {}
  }

  Future<void> setLabelSamePrinter(bool v) async {
    _labelSame = v;
    notifyListeners();
    await _putPref('label_same_printer', v);
  }

  Future<void> setLabelLanguage(LabelLanguage v) async {
    _labelLang = v;
    notifyListeners();
    await _putPref('label_lang', v.index);
  }

  Future<void> setLabelMedia(LabelMedia v) async {
    _labelMedia = v;
    notifyListeners();
    await _putPref('label_media', v.index);
  }

  Future<void> setLabelGap(double mm) async {
    _labelGapMm = mm.clamp(0.0, 10.0).toDouble();
    notifyListeners();
    await _putPref('label_gap_mm', _labelGapMm);
  }

  Future<void> setLabelDensity(int v) async {
    _labelDensity = v.clamp(1, 15);
    notifyListeners();
    await _putPref('label_density', _labelDensity);
  }

  Future<void> setLabelSpeed(int v) async {
    _labelSpeed = v.clamp(1, 5);
    notifyListeners();
    await _putPref('label_speed', _labelSpeed);
  }

  Future<void> setLabelDpi(int v) async {
    _labelDpi = v == 300 ? 300 : 203;
    notifyListeners();
    await _putPref('label_dpi', _labelDpi);
  }

  Future<void> setLabelInvert(bool v) async {
    _labelInvert = v;
    notifyListeners();
    await _putPref('label_invert', v);
  }

  Future<void> setLabelOffsetX(double mm) async {
    _labelOffXmm = (mm.clamp(-6.0, 6.0) * 2).round() / 2;
    notifyListeners();
    await _putPref('label_off_x_mm', _labelOffXmm);
  }

  Future<void> setLabelOffsetY(double mm) async {
    _labelOffYmm = (mm.clamp(-6.0, 6.0) * 2).round() / 2;
    notifyListeners();
    await _putPref('label_off_y_mm', _labelOffYmm);
  }

  Future<void> setLabelRotate(bool v) async {
    _labelRotate = v;
    notifyListeners();
    await _putPref('label_rotate', v);
  }

  // Standard head widths: 58mm paper = 384 dots, 80mm paper = 576 dots.
  // Some printers print wider/narrower, so the width can be tuned per paper.
  static int defaultDots(int mm) => mm == 80 ? 576 : 384;
  static int minDots(int mm) => mm == 80 ? 480 : 320;
  static int maxDots(int mm) => mm == 80 ? 640 : 448;

  final Map<int, int> _dotsByPaper = {};

  // Compatibility: some (mostly 80mm) printers choke on the standard raster
  // command or on fast data, so both can be changed from the Printer screen.
  //   mode 0 = Standard (GS v 0 raster)   mode 1 = Compatible (ESC * 24-dot)
  //   speed 0 = Fast  1 = Normal (default)  2 = Safe (small chunks, long pauses)
  //   powerSafe = halftone on dark areas + rests after heavy rows, so the
  //               printer's battery / power supply is never overloaded
  //               (solid black blocks are what makes cheap printers switch off).
  int _mode = 0;
  int _speed = 0; // Fast is the default
  bool _powerSafe = true;
  // 58 / 80 mm bills as printer-font TEXT (1-2 KB) instead of a picture (~100 KB):
  // the printer gets the whole bill instantly and prints it in one run.
  bool _textFast = true;
  bool get textFastPrint => _textFast;
  // Logo stored in the printer's own memory (sent once, then 4 bytes per bill).
  bool _logoNv = false;
  bool get logoInPrinter => _logoNv;
  int get printMode => _mode;
  int get printSpeed => _speed;
  bool get powerSafe => _powerSafe;

  // Bytes per Bluetooth write and pause after each write.
  // Fast: big writes, almost no pause, no halftone and no rests (full speed on
  // both 58 mm and 80 mm). Normal / Safe keep the gentle behaviour.
  //
  // Fast sends the whole job in big 8 KB writes with NO pause (the Bluetooth
  // link itself throttles the data), so an 80 mm bill streams out in one go.
  // Normal / Safe were far too slow before (7 KB/s and 2 KB/s): the printer
  // starved between chunks and printed "step by step". They are now ~64 KB/s
  // and ~16 KB/s: still gentle, but continuous.
  int get _chunk => const [8192, 1024, 512][_speed];
  int get _pause => const [0, 16, 30][_speed];
  /// Halftone + head rests only in Normal / Safe. Fast never waits.
  bool get _gentle => _powerSafe && _speed != 0;
  // Labels: printers with a large buffer, so a little faster.
  int get _labelChunk => const [1024, 512, 256][_speed];
  int get _labelPause => const [5, 12, 30][_speed];
  // Dots the head may burn per millisecond of rest (bigger = shorter rests).
  double get _dotsPerMs => const [2000.0, 900.0, 450.0][_speed];

  Future<void> setLogoInPrinter(bool v) async {
    _logoNv = v;
    notifyListeners();
    await _putPref('thermal_logo_nv', v);
    // Turning it on always sends the logo again on the next bill.
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove('thermal_logo_nv_key');
    } catch (_) {}
  }

  Future<void> setTextFastPrint(bool v) async {
    _textFast = v;
    notifyListeners();
    await _putPref('thermal_text_fast', v);
  }

  Future<void> setPowerSafe(bool v) async {
    _powerSafe = v;
    notifyListeners();
    await _putPref('thermal_power_safe', v);
  }

  Future<void> setPrintMode(int mode) async {
    _mode = mode == 1 ? 1 : 0;
    notifyListeners();
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setInt('thermal_print_mode', _mode);
    } catch (_) {}
  }

  Future<void> setPrintSpeed(int speed) async {
    _speed = speed.clamp(0, 2);
    notifyListeners();
    await _putPref('thermal_print_speed_v4', _speed);
  }

  int dotsFor(int mm) => _dotsByPaper[mm] ?? defaultDots(mm);
  int get printDots => dotsFor(_paperMm);

  Future<void> setPrintDots(int mm, int dots) async {
    final v = (dots ~/ 8) * 8; // must be a multiple of 8
    _dotsByPaper[mm] = v.clamp(minDots(mm), maxDots(mm));
    notifyListeners();
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setInt('thermal_print_dots_$mm', _dotsByPaper[mm]!);
    } catch (_) {}
  }

  Future<dynamic> _onNative(MethodCall call) async {
    switch (call.method) {
      case 'deviceFound':
        final args = call.arguments;
        if (args is Map) _found.add(PrinterDevice.fromMap(args));
        break;
      case 'scanFinished':
        _scanDone.add(null);
        break;
      case 'linkLost':
        // Android reported that the printer really went away (switched off,
        // out of range, auto power-off...). Forget the dead link so the next
        // print reconnects cleanly instead of writing into a dead socket.
        final lost = call.arguments;
        if (lost is String && lost == _address) {
          _connected = false;
          notifyListeners();
        }
        break;
    }
    return null;
  }

  Future<T?> _invoke<T>(String method, [Map<String, dynamic>? args]) async {
    try {
      return await _ch.invokeMethod<T>(method, args);
    } on MissingPluginException {
      return null;
    } on PlatformException {
      return null;
    }
  }

  // ------------------------------------------------------------------ state

  Future<void> load() async {
    if (_loaded) return;
    _loaded = true;
    try {
      final prefs = await SharedPreferences.getInstance();
      _address = prefs.getString(_addressPref);
      _name = prefs.getString(_namePref);
      final mm = prefs.getInt(paperPref);
      if (mm == 58 || mm == 80) _paperMm = mm!;
      _mode = prefs.getInt('thermal_print_mode') == 1 ? 1 : 0;
      // v4: the speeds were re-tuned, so everybody starts again on Fast
      // (old Normal / Safe choices were made to work around the slow 80 mm print).
      _speed = (prefs.getInt('thermal_print_speed_v4') ?? 0).clamp(0, 2);
      _powerSafe = prefs.getBool('thermal_power_safe') ?? true;
      _textFast = prefs.getBool('thermal_text_fast') ?? true;
      _logoNv = prefs.getBool('thermal_logo_nv') ?? false;
      for (final p in const [58, 80]) {
        final d = prefs.getInt('thermal_print_dots_$p');
        if (d != null) _dotsByPaper[p] = d.clamp(minDots(p), maxDots(p));
      }
      _labelSame = prefs.getBool('label_same_printer') ?? true;
      _labelAddress = prefs.getString('label_printer_address');
      _labelName = prefs.getString('label_printer_name');
      final lang = prefs.getInt('label_lang');
      if (lang != null && lang >= 0 && lang < LabelLanguage.values.length) _labelLang = LabelLanguage.values[lang];
      final media = prefs.getInt('label_media');
      if (media != null && media >= 0 && media < LabelMedia.values.length) _labelMedia = LabelMedia.values[media];
      _labelGapMm = (prefs.getDouble('label_gap_mm') ?? 2).clamp(0.0, 10.0).toDouble();
      _labelDensity = (prefs.getInt('label_density') ?? 8).clamp(1, 15);
      _labelSpeed = (prefs.getInt('label_speed') ?? 3).clamp(1, 5);
      _labelDpi = prefs.getInt('label_dpi') == 300 ? 300 : 203;
      _labelInvert = prefs.getBool('label_invert') ?? false;
      _labelRotate = prefs.getBool('label_rotate') ?? false;
      _labelOffXmm = (prefs.getDouble('label_off_x_mm') ?? 0).clamp(-6.0, 6.0).toDouble();
      _labelOffYmm = (prefs.getDouble('label_off_y_mm') ?? 0).clamp(-6.0, 6.0).toDouble();
    } catch (_) {}
    _connected = hasSavedPrinter && (await _invoke<bool>('isConnected', {'address': _address}) ?? false);
    notifyListeners();
  }

  Future<void> setPaper(int mm) async {
    if (mm != 58 && mm != 80) return;
    _paperMm = mm;
    notifyListeners();
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setInt(paperPref, mm);
    } catch (_) {}
  }

  Future<void> _savePrinter(PrinterDevice d) async {
    _address = d.address;
    _name = d.displayName;
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_addressPref, d.address);
      await prefs.setString(_namePref, d.displayName);
    } catch (_) {}
  }

  /// Disconnects and forgets the saved printer.
  Future<void> forget() async {
    await _invoke<bool>('disconnect', {'address': _address});
    _connected = false;
    _address = null;
    _name = null;
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove(_addressPref);
      await prefs.remove(_namePref);
    } catch (_) {}
    notifyListeners();
  }

  // -------------------------------------------------------------- bluetooth

  Future<bool> isSupported() async => await _invoke<bool>('isSupported') ?? false;
  Future<bool> isBluetoothOn() async => await _invoke<bool>('isEnabled') ?? false;
  Future<bool> hasPermissions() async => await _invoke<bool>('hasPermissions') ?? false;
  Future<bool> requestPermissions() async => await _invoke<bool>('requestPermissions') ?? false;

  /// Shows the system "turn on Bluetooth" prompt.
  Future<bool> enableBluetooth() async => await _invoke<bool>('enable') ?? false;

  Future<List<PrinterDevice>> pairedDevices() async {
    final raw = await _invoke<List<dynamic>>('pairedDevices') ?? const [];
    return raw.whereType<Map>().map(PrinterDevice.fromMap).toList();
  }

  Future<bool> startScan() async => await _invoke<bool>('startScan') ?? false;
  Future<void> stopScan() async => _invoke<bool>('stopScan');

  Future<bool> pair(PrinterDevice d) async => await _invoke<bool>('pair', {'address': d.address}) ?? false;

  /// Connects and remembers this printer.
  Future<bool> connect(PrinterDevice d) async {
    final ok = await _invoke<bool>('connect', {'address': d.address}) ?? false;
    _connected = ok;
    if (ok) await _savePrinter(d);
    notifyListeners();
    return ok;
  }

  /// Reconnects to the remembered printer without any UI.
  Future<bool> silentReconnect() async {
    await load();
    if (!hasSavedPrinter) return false;
    if (_connected && (await _invoke<bool>('isConnected', {'address': _address}) ?? false)) return true;
    if (!await isBluetoothOn() || !await hasPermissions()) {
      _connected = false;
      notifyListeners();
      return false;
    }
    final ok = await _invoke<bool>('connect', {'address': _address}) ?? false;
    _connected = ok;
    notifyListeners();
    return ok;
  }

  Future<void> disconnect() async {
    await _invoke<bool>('disconnect', {'address': _address});
    _connected = false;
    notifyListeners();
  }

  // --------------------------------------------------------------- printing

  /// Prints a PNG (e.g. the captured receipt) on the thermal paper.
  Future<void> printPng(Uint8List png, {int? paperMm}) async {
    await PrintModeService.instance.load();
    if (PrintModeService.instance.external) {
      return ExternalPrint.png(png, paperMm: paperMm ?? _paperMm);
    }
    final mm = paperMm ?? _paperMm;
    final dots = dotsFor(mm);
    final bitmap = await _bitmapFromPng(png, dots);
    await _send(_wrap([bitmap], mm));
  }

  /// Prints every page of a PDF (A4 reports, invoices, labels, cards...)
  /// scaled to the paper width.
  Future<void> printPdf(Uint8List pdf, {int? paperMm}) async {
    await PrintModeService.instance.load();
    if (PrintModeService.instance.external) {
      return ExternalPrint.pdf(pdf, paperMm: paperMm);
    }
    final mm = paperMm ?? _paperMm;
    final dots = dotsFor(mm);
    final pages = <_Bitmap>[];
    await for (final raster in Printing.raster(pdf, dpi: 200)) {
      final png = await raster.toPng();
      pages.add(await _bitmapFromPng(png, dots));
    }
    if (pages.isEmpty) throw const PrinterException('Nothing to print.');
    await _send(_wrap(pages, mm));
  }

  /// True when bills may be sent as printer text (see [textFastPrint]).
  Future<bool> canPrintText(int paperMm) async {
    await PrintModeService.instance.load();
    await load();
    return (paperMm == 58 || paperMm == 80) && _textFast && !PrintModeService.instance.external;
  }

  /// The logo part of a text bill: either the small raster block, or (when
  /// "logo in printer" is on) the 4-byte command that prints the logo stored in
  /// the printer, uploading it first if it is new or changed.
  Future<Uint8List?> logoBlock(ReceiptSettings design, int paperMm) async {
    if (!design.hasLogo) return null;
    final dots = dotsFor(paperMm);
    if (_logoNv && hasSavedPrinter) {
      final nv = await ThermalLogo.nv(design, dots: dots);
      if (nv != null) {
        final want = '${nv.key}|$_address';
        String? stored;
        SharedPreferences? prefs;
        try {
          prefs = await SharedPreferences.getInstance();
          stored = prefs.getString('thermal_logo_nv_key');
        } catch (_) {}
        if (stored != want) {
          final out = _Out();
          out.add(nv.upload);
          await _send(out);
          // Writing to the printer's memory takes a moment; wait before the bill.
          await Future<void>.delayed(const Duration(milliseconds: 1500));
          try {
            await prefs?.setString('thermal_logo_nv_key', want);
          } catch (_) {}
        }
        return nv.print;
      }
    }
    return ThermalLogo.escpos(design, dots: dots);
  }

  /// Sends a ready ESC/POS text job (see ThermalTextReceipt) in one piece.
  Future<void> printEscpos(Uint8List bytes) async {
    final out = _Out();
    out.add(bytes);
    await _send(out);
  }

  /// The test page as printer text (instant, no step-by-step). The framed line
  /// shows whether both edges of the paper are used; the picture version is
  /// still used when fast text printing is switched off.
  Uint8List _testText(int mm, int dots) {
    final c = (dots ~/ 12).clamp(32, 64);
    final b = BytesBuilder();
    String clean(String s) => s.replaceAll(RegExp(r'[^\x20-\x7E]'), '?');
    void raw(String s) => b.add(ascii.encode('$s\n'));
    void style({bool bold = false, int size = 0, int align = 0}) {
      b.add([0x1B, 0x61, align]);
      b.add([0x1B, 0x45, bold ? 1 : 0]);
      b.add([0x1D, 0x21, size]);
    }
    void center(String s, {bool bold = false, int size = 0}) {
      style(bold: bold, size: size, align: 1);
      raw(clean(s));
      style();
    }

    b.add(const [0x1B, 0x40]);
    center('WC KHATA', bold: true, size: 0x11);
    center('TEST PRINT', bold: true, size: 0x01);
    raw('-' * c);
    raw(clean('Printer: ${_name ?? 'Thermal Printer'}'));
    raw('Paper size: ${mm}mm ($dots dots)');
    raw(DateFormat('dd MMM yyyy, hh:mm a').format(DateTime.now()));
    raw('-' * c);
    raw('|${'=' * (c - 2)}|'); // both ends visible = full width is used
    raw('-' * c);
    center('Printer successfully', bold: true);
    center('connected!', bold: true);
    b.add(const [0x1B, 0x64, 0x04]);
    if (mm == 80) b.add(const [0x1D, 0x56, 0x42, 0x00]);
    return b.toBytes();
  }

  Future<void> printTest() async {
    await PrintModeService.instance.load();
    await load();
    final mm = _paperMm;
    final dots = dotsFor(mm);
    if (_textFast && !PrintModeService.instance.external) {
      await printEscpos(_testText(mm, dots));
      return;
    }
    final bitmap = await _testBitmap(dots, mm);
    await _send(_wrap([bitmap], mm));
  }

  Future<void> _send(_Out job) async {
    await load();
    if (!hasSavedPrinter) {
      throw const PrinterException('Printer is not connected. Connect one from More > Printer.');
    }
    await _sendTo(_address!, job.toBytes(), 'printer', marks: job.marks, markDelays: job.delays);
  }

  // Jobs are queued one after another: two prints (or a print and a test
  // page) can never interleave their bytes on the same Bluetooth link.
  Future<void> _queue = Future<void>.value();

  Future<void> _sendTo(String address, Uint8List bytes, String what,
      {List<int> marks = const [], List<int> markDelays = const [], int? chunk, int? pause}) {
    final run = _queue.then((_) => _sendNow(address, bytes, what, marks, markDelays, chunk ?? _chunk, pause ?? _pause));
    _queue = run.then((_) {}, onError: (_) {});
    return run;
  }

  Future<void> _sendNow(String address, Uint8List bytes, String what, List<int> marks, List<int> markDelays, int chunk, int pause) async {
    // Gives the exact reason (no permission / Bluetooth off / printer unreachable).
    await _requireLink(address, what);
    final res = await _invoke<Map<dynamic, dynamic>>('write', {
      'address': address,
      'bytes': bytes,
      'chunk': chunk,
      'delay': pause,
      'marks': marks,
      'markDelays': markDelays,
    });
    final ok = res?['ok'] == true;
    final sent = (res?['sent'] as int?) ?? 0;
    if (ok) {
      if (address == _address && !_connected) {
        _connected = true;
        notifyListeners();
      }
      return;
    }
    if (address == _address) {
      _connected = false;
      notifyListeners();
    }
    if (sent > 0) {
      // Never resend a half-printed job: it would print twice / send a broken
      // command stream that can hang the printer.
      throw PrinterException(what == 'label printer'
          ? 'Printing stopped half-way. Check the printer (power, labels, cover), then print again.'
          : 'Printing stopped half-way. Check the printer (power, paper, cover), then print again.');
    }
    throw PrinterException(what == 'label printer'
        ? 'Label printing failed. Check that the printer is on, labels are loaded and the cover is closed.'
        : 'Could not reach the printer. Is the printer on and Bluetooth enabled?');
  }

  // ------------------------------------------------------------ label print

  /// Connects and remembers a SEPARATE label printer.
  Future<bool> connectLabelPrinter(PrinterDevice d) async {
    final ok = await _invoke<bool>('connect', {'address': d.address}) ?? false;
    if (ok) {
      _labelAddress = d.address;
      _labelName = d.displayName;
      _labelSame = d.address == _address;
      if (d.address != _address) _connected = false;
      await _putPref('label_printer_address', d.address);
      await _putPref('label_printer_name', d.displayName);
      await _putPref('label_same_printer', _labelSame);
    }
    notifyListeners();
    return ok;
  }

  /// Forgets the separate label printer; labels then use the receipt printer.
  Future<void> forgetLabelPrinter() async {
    if (_labelAddress != null && _labelAddress != _address) {
      await _invoke<bool>('disconnect', {'address': _labelAddress});
    }
    _labelAddress = null;
    _labelName = null;
    _labelSame = true;
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove('label_printer_address');
      await prefs.remove('label_printer_name');
      await prefs.setBool('label_same_printer', true);
    } catch (_) {}
    notifyListeners();
  }

  Future<bool> isLabelPrinterLinked() async {
    final a = labelAddress;
    if (a == null || a.isEmpty) return false;
    return await _invoke<bool>('isConnected', {'address': a}) ?? false;
  }

  /// Makes sure the Bluetooth link to [address] is up; otherwise throws a
  /// message that says exactly what is wrong.
  Future<void> _requireLink(String address, String what) async {
    if (await _invoke<bool>('isConnected', {'address': address}) ?? false) return;
    if (!await isSupported()) {
      throw const PrinterException('This phone does not support Bluetooth.');
    }
    if (!await hasPermissions()) {
      throw const PrinterException('Bluetooth permission is missing. Allow it from phone Settings > Apps > WC Khata > Permissions.');
    }
    if (!await isBluetoothOn()) {
      throw const PrinterException('Bluetooth is turned off. Turn it on and try again.');
    }
    final ok = await _invoke<bool>('connect', {'address': address}) ?? false;
    if (!ok) {
      throw PrinterException('Could not connect to the $what. Make sure it is turned on, close to the phone and not connected to another phone.');
    }
  }

  String _requireLabelPrinter() {
    final a = labelAddress;
    if (a == null || a.isEmpty) {
      throw PrinterException(_labelSame
          ? 'No printer is set up for labels. Connect your printer from More > Printer first.'
          : 'Label printer is not connected. Open More > Printer > Label Printer and connect it.');
    }
    return a;
  }

  void _checkLabelSize(double widthMm, double heightMm) {
    if (widthMm.isNaN || heightMm.isNaN || widthMm < 10 || widthMm > 210 || heightMm < 5 || heightMm > 300) {
      throw const PrinterException('Label size is not valid. Choose a label size between 10x5 mm and 210x300 mm.');
    }
  }

  int _labelDotsW(double mm) => math.max(8, ((mm / 25.4 * _labelDpi) / 8).round() * 8);
  int _labelDotsH(double mm) => math.max(8, (mm / 25.4 * _labelDpi).round());

  /// Prints every page of [pdf] as one label each. [pageCopies] gives how many
  /// copies of each page (multi-label printing); otherwise every page is printed
  /// [copies] times. Big jobs are sent in parts so memory stays small and a
  /// failure tells how many labels were already printed.
  Future<void> printLabelPdf(
    Uint8List pdf, {
    required double widthMm,
    required double heightMm,
    int copies = 1,
    List<int>? pageCopies,
    void Function(int done, int total)? onProgress,
  }) async {
    await PrintModeService.instance.load();
    if (PrintModeService.instance.external) {
      return ExternalPrint.label(pdf, widthMm: widthMm, heightMm: heightMm);
    }
    await load();
    _checkLabelSize(widthMm, heightMm);
    final addr = _requireLabelPrinter();
    final w = _labelDotsW(widthMm);
    final h = _labelDotsH(heightMm);
    final total = pageCopies?.fold<int>(0, (a, b) => a + b);
    var out = BytesBuilder();
    var pending = 0; // labels inside [out]
    var sent = 0;
    var page = 0;

    Future<void> flush() async {
      if (out.length == 0) return;
      try {
        await _sendLabel(addr, out.toBytes());
      } on PrinterException catch (e) {
        if (sent > 0) throw PrinterException('${e.message} $sent label${sent == 1 ? '' : 's'} were printed before the problem.');
        rethrow;
      }
      sent += pending;
      pending = 0;
      out = BytesBuilder();
      onProgress?.call(sent, total ?? sent);
    }

    try {
      await for (final raster in Printing.raster(pdf, dpi: _labelDpi.toDouble())) {
        final c = ((pageCopies != null && page < pageCopies.length) ? pageCopies[page] : copies).clamp(1, 99);
        page++;
        final png = await raster.toPng();
        final bmp = await _labelBitmapFromPng(png, w, h);
        out.add(_encodeLabel(bmp, widthMm, heightMm, c));
        pending += c;
        if (out.length > 96 * 1024) await flush();
      }
    } on PrinterException {
      rethrow;
    } catch (_) {
      throw const PrinterException('Could not prepare the label for printing.');
    }
    if (page == 0) throw const PrinterException('Nothing to print.');
    await flush();
  }

  /// A test label with border, size, bars and a corner mark, so alignment,
  /// darkness and size can be checked on the real label.
  Future<void> printLabelTest({required double widthMm, required double heightMm}) async {
    await load();
    _checkLabelSize(widthMm, heightMm);
    final addr = _requireLabelPrinter();
    final w = _labelDotsW(widthMm);
    final h = _labelDotsH(heightMm);
    final bmp = await _labelTestBitmap(w, h, widthMm, heightMm);
    await _sendLabel(addr, _encodeLabel(bmp, widthMm, heightMm, 1));
  }

  /// Asks the printer to measure the label length / gap.
  Future<void> calibrateLabels({double? widthMm, double? heightMm}) async {
    await load();
    final addr = _requireLabelPrinter();
    if (_labelMedia == LabelMedia.continuous) {
      throw const PrinterException('Continuous labels do not need calibration.');
    }
    String n(double v) => v == v.roundToDouble() ? v.toInt().toString() : v.toStringAsFixed(1);
    final size = (widthMm != null && heightMm != null) ? 'SIZE ${n(widthMm)} mm,${n(heightMm)} mm\r\n' : '';
    final List<int> bytes;
    switch (_labelLang) {
      case LabelLanguage.tspl:
        bytes = ascii.encode('${size}${_labelMedia == LabelMedia.blackMark ? 'BLINEDETECT' : 'GAPDETECT'}\r\n');
      case LabelLanguage.escpos:
        bytes = const [0x1D, 0x0C];
      case LabelLanguage.zpl:
        bytes = ascii.encode('~JC\r\n');
      case LabelLanguage.cpcl:
        throw const PrinterException('Auto calibration is not available in CPCL mode. Use the calibrate button on the printer.');
    }
    await _sendLabel(addr, Uint8List.fromList(bytes));
  }

  Future<void> _sendLabel(String addr, Uint8List bytes) async {
    await _sendTo(addr, bytes, 'label printer', chunk: _labelChunk, pause: _labelPause);
    _connected = addr == _address ? true : _connected;
    notifyListeners();
  }

  Future<_Bitmap> _labelBitmapFromPng(Uint8List png, int w, int h) async {
    final codec = await ui.instantiateImageCodec(png, targetWidth: w);
    final frame = await codec.getNextFrame();
    final image = frame.image;
    final data = await image.toByteData(format: ui.ImageByteFormat.rawRgba);
    final iw = image.width;
    final ih = image.height;
    image.dispose();
    codec.dispose();
    if (data == null) throw const PrinterException('Could not prepare the label image.');
    return _labelMono(data, iw, ih, w, h);
  }

  /// RGBA -> exact [w] x [h] dots bitmap (1 = ink). Rows missing from the
  /// source stay white; rotate / invert settings are applied here.
  _Bitmap _labelMono(ByteData rgba, int iw, int ih, int w, int h) {
    final bpr = w >> 3;
    final bits = Uint8List(bpr * h);
    final offX = (_labelOffXmm / 25.4 * _labelDpi).round();
    final offY = (_labelOffYmm / 25.4 * _labelDpi).round();
    for (var y = 0; y < h; y++) {
      final ry = y - offY; // position inside the artwork after the alignment shift
      for (var x = 0; x < w; x++) {
        final rx = x - offX;
        var ink = false;
        if (rx >= 0 && rx < w && ry >= 0 && ry < h) {
          final sx = _labelRotate ? w - 1 - rx : rx;
          final sy = _labelRotate ? h - 1 - ry : ry;
          if (sx < iw && sy < ih) {
            final i = (sy * iw + sx) * 4;
            final a = rgba.getUint8(i + 3) / 255.0;
            final lum = (0.299 * rgba.getUint8(i) + 0.587 * rgba.getUint8(i + 1) + 0.114 * rgba.getUint8(i + 2)) * a + 255.0 * (1 - a);
            ink = lum < 160;
          }
        }
        if (_labelInvert) ink = !ink;
        if (ink) bits[y * bpr + (x >> 3)] |= 0x80 >> (x & 7);
      }
    }
    return _Bitmap(bits, w, h);
  }

  Future<_Bitmap> _labelTestBitmap(int w, int h, double widthMm, double heightMm) async {
    final recorder = ui.PictureRecorder();
    final canvas = ui.Canvas(recorder);
    final white = ui.Paint()..color = const ui.Color(0xFFFFFFFF);
    final black = ui.Paint()..color = const ui.Color(0xFF000000);
    canvas.drawRect(ui.Rect.fromLTWH(0, 0, w.toDouble(), h.toDouble()), white);
    final stroke = ui.Paint()
      ..color = const ui.Color(0xFF000000)
      ..style = ui.PaintingStyle.stroke
      ..strokeWidth = 3;
    canvas.drawRect(ui.Rect.fromLTWH(2, 2, w - 4.0, h - 4.0), stroke);
    final unit = math.min(w, h) / 100.0;
    canvas.drawRect(ui.Rect.fromLTWH(8 * unit, 8 * unit, 10 * unit, 10 * unit), black); // top-left corner mark
    String n(double v) => v == v.roundToDouble() ? v.toInt().toString() : v.toStringAsFixed(1);
    final lines = <(String, double, bool)>[
      ('WC KHATA', 13, true),
      ('LABEL TEST', 10, true),
      ('${n(widthMm)} x ${n(heightMm)} mm  |  $_labelDpi dpi', 7.5, false),
      ('${_labelLang.title}  |  ${_labelMedia.title}', 7.5, false),
    ];
    var y = 10.0 * unit;
    for (final l in lines) {
      final tp = TextPainter(
        text: TextSpan(text: l.$1, style: TextStyle(color: const ui.Color(0xFF000000), fontSize: l.$2 * unit, fontWeight: l.$3 ? ui.FontWeight.w900 : ui.FontWeight.w600)),
        textAlign: ui.TextAlign.center,
        textDirection: ui.TextDirection.ltr,
      )..layout(minWidth: w - 24.0 * unit, maxWidth: w - 24.0 * unit);
      tp.paint(canvas, ui.Offset(12 * unit, y));
      y += tp.height + 1.5 * unit;
    }
    // Bars of different widths to judge darkness / sharpness.
    final barTop = math.min(y + 2 * unit, h - 22 * unit);
    final barH = math.max(6 * unit, h - barTop - 10 * unit);
    var x = 12 * unit;
    var bw = 0.6 * unit;
    while (x < w - 12 * unit) {
      canvas.drawRect(ui.Rect.fromLTWH(x, barTop, bw, barH), black);
      x += bw * 2;
      bw = bw >= 3 * unit ? 0.6 * unit : bw + 0.5 * unit;
    }
    final image = await recorder.endRecording().toImage(w, h);
    final data = await image.toByteData(format: ui.ImageByteFormat.rawRgba);
    image.dispose();
    if (data == null) throw const PrinterException('Could not prepare the test label.');
    return _labelMono(data, w, h, w, h);
  }

  Uint8List _encodeLabel(_Bitmap b, double widthMm, double heightMm, int copies) {
    final out = BytesBuilder();
    final bpr = b.width >> 3;
    String n(double v) => v == v.roundToDouble() ? v.toInt().toString() : v.toStringAsFixed(1);
    switch (_labelLang) {
      case LabelLanguage.tspl:
        final g = n(_labelGapMm);
        final tsplMedia = switch (_labelMedia) {
          LabelMedia.gap => 'GAP $g mm,0 mm',
          LabelMedia.blackMark => 'BLINE $g mm,0 mm',
          LabelMedia.continuous => 'GAP 0 mm,0 mm',
        };
        out.add(ascii.encode('SIZE ${n(widthMm)} mm,${n(heightMm)} mm\r\n$tsplMedia\r\nDIRECTION 1,0\r\nDENSITY $_labelDensity\r\nSPEED $_labelSpeed\r\nCLS\r\n'));
        out.add(ascii.encode('BITMAP 0,0,$bpr,${b.rows},0,'));
        // TSPL bitmap: 0 = black dot, 1 = white.
        final inv = Uint8List(b.bits.length);
        for (var i = 0; i < inv.length; i++) {
          inv[i] = (~b.bits[i]) & 0xFF;
        }
        out.add(inv);
        out.add(ascii.encode('\r\nPRINT $copies,1\r\n'));
      case LabelLanguage.escpos:
        for (var k = 0; k < copies; k++) {
          out.add(const [0x1B, 0x40]);
          final tmp = _Out();
          _addRaster(tmp, b, 58);
          out.add(tmp.toBytes());
          out.add(_labelMedia == LabelMedia.continuous ? const [0x1B, 0x64, 0x03] : const [0x1D, 0x0C]);
        }
      case LabelLanguage.zpl:
        final total = bpr * b.rows;
        final hex = StringBuffer();
        for (final v in b.bits) {
          hex.write(v.toRadixString(16).padLeft(2, '0').toUpperCase());
        }
        final zplMedia = switch (_labelMedia) {
          LabelMedia.gap => '^MNY',
          LabelMedia.blackMark => '^MNM',
          LabelMedia.continuous => '^MNN',
        };
        final dark = ((_labelDensity - 8) * 3).clamp(-30, 30);
        out.add(ascii.encode('^XA\r\n^PW${b.width}\r\n^LL${b.rows}\r\n$zplMedia\r\n^MD$dark\r\n^PR${_labelSpeed + 1}\r\n'));
        out.add(ascii.encode('^FO0,0^GFA,$total,$total,$bpr,$hex^FS\r\n^PQ$copies\r\n^XZ\r\n'));
      case LabelLanguage.cpcl:
        out.add(ascii.encode('! 0 $_labelDpi $_labelDpi ${b.rows} $copies\r\nPAGE-WIDTH ${b.width}\r\nTONE ${_labelDensity * 10}\r\nSPEED ${_labelSpeed - 1}\r\n'));
        out.add(ascii.encode('CG $bpr ${b.rows} 0 0 '));
        out.add(b.bits);
        final sense = switch (_labelMedia) {
          LabelMedia.gap => 'GAP-SENSE\r\n',
          LabelMedia.blackMark => 'BAR-SENSE\r\n',
          LabelMedia.continuous => '',
        };
        out.add(ascii.encode('\r\n${sense}FORM\r\nPRINT\r\n'));
    }
    return out.toBytes();
  }

  // ----------------------------------------------------------- ESC/POS data

  Future<_Bitmap> _bitmapFromPng(Uint8List png, int dots) async {
    final codec = await ui.instantiateImageCodec(png, targetWidth: dots);
    final frame = await codec.getNextFrame();
    final image = frame.image;
    final data = await image.toByteData(format: ui.ImageByteFormat.rawRgba);
    final w = image.width;
    final h = image.height;
    image.dispose();
    codec.dispose();
    if (data == null) throw const PrinterException('Could not prepare the print image.');
    return _toMono(data, w, h);
  }

  /// RGBA -> 1 bit per pixel (1 = black), bottom blank space trimmed.
  _Bitmap _toMono(ByteData rgba, int w, int h) {
    final bpr = (w + 7) >> 3;
    final bits = Uint8List(bpr * h);
    var lastInk = -1;
    // Typed-list view: much faster than ByteData.getUint8 per channel, so the
    // bill is ready for the printer sooner (no wait before the paper moves).
    final px = rgba.buffer.asUint8List(rgba.offsetInBytes, rgba.lengthInBytes);
    for (var y = 0; y < h; y++) {
      for (var x = 0; x < w; x++) {
        final i = (y * w + x) * 4;
        final a = px[i + 3] / 255.0;
        final lum = (0.299 * px[i] + 0.587 * px[i + 1] + 0.114 * px[i + 2]) * a + 255.0 * (1 - a);
        final bool ink;
        if (_gentle) {
          // Text / lines (dark) stay solid; coloured fills and greys become a
          // halftone pattern, so the head never has to burn a big black block.
          if (lum < 70) {
            ink = true;
          } else if (lum >= 215) {
            ink = false;
          } else {
            final t = 70 + (_bayer[((y & 3) << 2) | (x & 3)] + 0.5) / 16 * 145;
            ink = lum < t;
          }
        } else {
          // Slightly generous: thin lines / small text that anti-alias to light
          // grey while scaling to the printer's dots must still print solid.
          ink = lum < 196;
        }
        if (ink) {
          bits[y * bpr + (x >> 3)] |= 0x80 >> (x & 7);
          if (y > lastInk) lastInk = y;
        }
      }
    }
    final rows = lastInk < 0 ? math.min(h, 8) : math.min(h, lastInk + 1 + 12);
    return _Bitmap(bits, w, rows);
  }

  static const List<int> _bayer = [0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5];

  static const List<int> _pop = [
    0, 1, 1, 2, 1, 2, 2, 3, 1, 2, 2, 3, 2, 3, 3, 4, 1, 2, 2, 3, 2, 3, 3, 4, 2, 3, 3, 4, 3, 4, 4, 5,
  ];

  _Out _wrap(List<_Bitmap> pages, int mm) {
    final out = _Out();
    out.add(const [0x1B, 0x40]); // initialise
    out.add(const [0x1B, 0x61, 0x00]); // left aligned
    if (_mode == 1) {
      for (final p in pages) {
        _addColumnMode(out, p);
      }
    } else {
      for (final p in pages) {
        _addRaster(out, p, mm);
      }
    }
    out.add(const [0x1B, 0x64, 0x05]); // feed 5 lines
    if (mm == 80) out.add(const [0x1D, 0x56, 0x42, 0x00]); // partial cut (ignored if no cutter)
    return out;
  }

  /// Standard GS v 0 raster, in bands so small printer buffers keep up.
  void _addRaster(_Out out, _Bitmap p, int mm) {
    final bpr = (p.width + 7) >> 3;
    // Fast + 80 mm: the whole receipt is ONE raster command (2300 rows is the
    // ESC/POS limit, so a normal bill is never split). Many 80 mm printers stop
    // and restart the paper between raster commands, which is exactly the
    // "step by step" printing. 58 mm keeps its proven 255-row bands.
    final band = _speed == 0
        ? (mm == 80 ? 2300 : 255)
        : (_powerSafe ? 64 : (_speed == 2 ? 64 : 255));
    for (var y0 = 0; y0 < p.rows; y0 += band) {
      final rows = math.min(band, p.rows - y0);
      out.add([0x1D, 0x76, 0x30, 0x00, bpr & 0xFF, (bpr >> 8) & 0xFF, rows & 0xFF, (rows >> 8) & 0xFF]);
      final slice = Uint8List.sublistView(p.bits, y0 * bpr, (y0 + rows) * bpr);
      out.add(slice);
      if (_gentle) {
        // Rest after heavy rows: time the head needs to burn this many dots.
        var ink = 0;
        for (final v in slice) {
          ink += _ink8(v);
        }
        out.rest((ink / _dotsPerMs).round().clamp(0, 400));
      }
    }
  }

  static int _ink8(int v) => _pop[v & 31] + _pop[v >> 5];

  /// Compatible mode: ESC * 33 (24-dot double-density bit image), one 24-row
  /// strip per line. Understood by virtually every ESC/POS printer.
  void _addColumnMode(_Out out, _Bitmap p) {
    final bpr = (p.width + 7) >> 3;
    final w = p.width;
    out.add(const [0x1B, 0x33, 24]); // line spacing = 24 dots
    for (var y0 = 0; y0 < p.rows; y0 += 24) {
      out.add([0x1B, 0x2A, 33, w & 0xFF, (w >> 8) & 0xFF]);
      final strip = Uint8List(w * 3);
      for (var x = 0; x < w; x++) {
        final xByte = x >> 3;
        final xMask = 0x80 >> (x & 7);
        for (var k = 0; k < 3; k++) {
          var b = 0;
          for (var j = 0; j < 8; j++) {
            final y = y0 + k * 8 + j;
            if (y < p.rows && (p.bits[y * bpr + xByte] & xMask) != 0) b |= 0x80 >> j;
          }
          strip[x * 3 + k] = b;
        }
      }
      out.add(strip);
      out.add(const [0x0A]);
    }
    out.add(const [0x1B, 0x32]); // default line spacing
  }

  Future<_Bitmap> _testBitmap(int dots, int mm) async {
    final scale = dots / 384.0;
    final w = dots;
    final recorder = ui.PictureRecorder();
    final canvas = ui.Canvas(recorder);
    final paint = ui.Paint()..color = const ui.Color(0xFFFFFFFF);
    final lines = <(String, double, bool)>[
      ('WC KHATA', 28, true),
      ('TEST PRINT', 22, true),
      ('--------------------------', 20, false),
      ('Printer: ${_name ?? 'Thermal Printer'}', 20, false),
      ('Paper size: ${mm}mm  ($dots dots)', 20, false),
      (DateFormat('dd MMM yyyy, hh:mm a').format(DateTime.now()), 20, false),
      ('--------------------------', 20, false),
      ('Printer successfully', 22, true),
      ('connected!', 22, true),
    ];
    final painters = <TextPainter>[];
    var y = 16.0 * scale;
    for (final l in lines) {
      final tp = TextPainter(
        text: TextSpan(
          text: l.$1,
          style: TextStyle(
            color: const ui.Color(0xFF000000),
            fontSize: l.$2 * scale,
            fontWeight: l.$3 ? ui.FontWeight.w900 : ui.FontWeight.w600,
          ),
        ),
        textAlign: ui.TextAlign.center,
        textDirection: ui.TextDirection.ltr,
      )..layout(minWidth: w - 24.0 * scale, maxWidth: w - 24.0 * scale);
      painters.add(tp);
      y += tp.height + 6 * scale;
    }
    final h = (y + 16 * scale).ceil();
    canvas.drawRect(ui.Rect.fromLTWH(0, 0, w.toDouble(), h.toDouble()), paint);
    var dy = 16.0 * scale;
    for (final tp in painters) {
      tp.paint(canvas, ui.Offset(12 * scale, dy));
      dy += tp.height + 6 * scale;
    }
    // Border touching the left/right edges of the print area, so the real
    // printable width is visible when calibrating.
    final border = ui.Paint()
      ..color = const ui.Color(0xFF000000)
      ..style = ui.PaintingStyle.stroke
      ..strokeWidth = 4;
    canvas.drawRect(ui.Rect.fromLTWH(2, 2, w - 4.0, h - 4.0), border);
    final image = await recorder.endRecording().toImage(w, h);
    final data = await image.toByteData(format: ui.ImageByteFormat.rawRgba);
    image.dispose();
    if (data == null) throw const PrinterException('Could not prepare the test print.');
    return _toMono(data, w, h);
  }
}

/// Print data plus "rest" marks: after [marks][i] bytes the sender pauses
/// [delays][i] ms (used to let the print head cool after dense rows).
class _Out {
  final BytesBuilder _b = BytesBuilder();
  final List<int> marks = [];
  final List<int> delays = [];

  void add(List<int> d) => _b.add(d);
  void rest(int ms) {
    if (ms > 0) {
      marks.add(_b.length);
      delays.add(ms);
    }
  }

  Uint8List toBytes() => _b.toBytes();
}

class _Bitmap {
  final Uint8List bits;
  final int width;
  final int rows;
  const _Bitmap(this.bits, this.width, this.rows);
}
