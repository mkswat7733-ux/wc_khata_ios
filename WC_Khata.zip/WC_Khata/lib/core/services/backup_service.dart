import 'dart:convert';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import '../database/app_database.dart';
import '../database/database_constants.dart';
import '../../features/items/item_repository.dart';
import 'unit_repository.dart';

class BackupService {
  /// Every table that holds user data, ordered PARENTS FIRST (so rows can be
  /// inserted in this order and deleted in reverse order without breaking
  /// foreign keys). Restore only accepts tables from this list.
  /// security_settings is intentionally NOT included (password/biometric
  /// settings must never be overwritten by a file).
  static const List<String> tables = [
    DBConstants.tableProfile,
    DBConstants.tableAppSettings,
    DBConstants.tableAccounts,
    DBConstants.tableCategories,
    DBConstants.tableItemCategories,
    DBConstants.tableItemUnits,
    DBConstants.tableLedgerParties,
    DBConstants.tableItems,
    DBConstants.tablePurchases,
    DBConstants.tableSaleInvoices,
    DBConstants.tableSaleItems,
    DBConstants.tablePurchaseInvoices,
    DBConstants.tablePurchaseInvoiceItems,
    DBConstants.tableTransactions,
    DBConstants.tableLedgerTransactions,
    DBConstants.tableCheques,
    DBConstants.tableChequeHistory,
    DBConstants.tableBudgets,
    DBConstants.tableSavingsGoals,
    DBConstants.tableGoalActivity,
    DBConstants.tableBills,
    DBConstants.tableSubscriptions,
    DBConstants.tableTasks,
    DBConstants.tableTaskItems,
    DBConstants.tableRoutineItems,
    DBConstants.tableRoutineCompletions,
  ];

  static Set<String> _lower(Iterable<String> v) => v.map((e) => e.trim().toLowerCase()).toSet();

  /// Backup format 4+: built-in (app-defined) categories and units are NOT
  /// stored as user data. Only the ones the user created / renamed are saved,
  /// plus the list of built-ins the user deleted, so restore can rebuild the
  /// exact same list without ever duplicating or resurrecting defaults.
  /// Products carry their category NAME so they re-link correctly even though
  /// ids differ after a reinstall.
  Future<String> createBackupJson() async {
    final db = await AppDatabase.instance.database;
    final data = <String, dynamic>{
      'app': 'wc_khata',
      'backup_version': 4,
      'created_at': DateTime.now().toIso8601String(),
      'tables': <String, dynamic>{},
    };
    final builtInCats = _lower(ItemRepository.builtInCategories);
    final builtInUnits = _lower(UnitRepository.builtInUnits);
    final removed = <String, List<String>>{};

    for (final table in tables) {
      if (table == DBConstants.tableItemCategories || table == DBConstants.tableItemUnits) {
        final isCat = table == DBConstants.tableItemCategories;
        final builtIns = isCat ? ItemRepository.builtInCategories : UnitRepository.builtInUnits;
        final builtInSet = isCat ? builtInCats : builtInUnits;
        final rows = await db.query(table);
        final present = <String>{for (final r in rows) (r['name'] as String).trim().toLowerCase()};
        data['tables'][table] = rows
            .where((r) => !builtInSet.contains((r['name'] as String).trim().toLowerCase()))
            .toList();
        // Built-ins the user deleted (or renamed away) stay gone after restore.
        removed[table] = builtIns.where((n) => !present.contains(n.toLowerCase())).toList();
      } else if (table == DBConstants.tableItems) {
        final rows = await db.rawQuery(
          'SELECT i.*, c.name AS category_name FROM ${DBConstants.tableItems} i '
          'LEFT JOIN ${DBConstants.tableItemCategories} c ON c.id = i.category_id',
        );
        data['tables'][table] = rows;
      } else {
        data['tables'][table] = await db.query(table);
      }
    }
    data['defaults_removed'] = removed;
    return jsonEncode(data);
  }

  Future<File> createBackup() async {
    final json = await createBackupJson();
    final dir = await getApplicationDocumentsDirectory();
    final file = File('${dir.path}/wc_khata_backup.json');
    await file.writeAsString(json, flush: true);
    return file;
  }
}
