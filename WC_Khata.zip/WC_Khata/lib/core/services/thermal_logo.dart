import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui' as ui;

import '../../features/printer/receipt_settings.dart';

/// The shop logo as ESC/POS data.
///
/// Why the logo used to print "on its own, then the bill": a picture is a lot
/// more data than text, and the printer's Bluetooth chip is slow, so the logo
/// crawled in and printed by itself while the (tiny) text waited. Two fixes:
///
///  1. [escpos]: the logo is a small raster block (max ~16 mm tall, ~5-9 KB),
///     sent in the same stream as the text.
///  2. [nv]: optional "store the logo in the printer" mode. The picture is sent
///     to the printer's own memory ONCE; every bill then only sends a 4-byte
///     "print stored logo" command, so logo + bill print in one single go.
class ThermalLogo {
  ThermalLogo._();

  /// Tallest logo in printer dots (16 mm). Taller logos are scaled down.
  static const int _maxRows = 128;

  static const List<int> _bayer = [0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5];

  static final Map<String, _Prepared> _cache = {};

  static Future<_Prepared?> _prepare(ReceiptSettings d, int dots) async {
    if (!d.hasLogo) return null;
    try {
      final file = File(d.logoPath!);
      final stat = await file.stat();
      if (stat.type == FileSystemEntityType.notFound) return null;
      final key = '${d.logoPath}|${stat.modified.millisecondsSinceEpoch}|$dots|${d.logoWidthPct}|${d.logoAlign}|${d.logoHighContrast}';
      final hit = _cache[key];
      if (hit != null) return hit;

      final src = await file.readAsBytes();
      final width = (((dots * d.logoWidthPct / 100).floor()) ~/ 8 * 8).clamp(64, dots).toInt();

      var codec = await ui.instantiateImageCodec(src, targetWidth: width);
      var image = (await codec.getNextFrame()).image;
      if (image.height > _maxRows) {
        image.dispose();
        codec.dispose();
        codec = await ui.instantiateImageCodec(src, targetHeight: _maxRows);
        image = (await codec.getNextFrame()).image;
      }
      final iw = image.width;
      final ih = image.height;
      final data = await image.toByteData(format: ui.ImageByteFormat.rawRgba);
      image.dispose();
      codec.dispose();
      if (data == null) return null;
      final px = data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes);

      final bpr = dots >> 3; // full head width, so alignment is part of the data
      final rows = ((ih + 6) + 7) ~/ 8 * 8; // white space under the logo; multiple of 8 rows
      final bits = Uint8List(bpr * rows);
      final x0 = switch (d.logoAlign) {
        0 => 0,
        2 => math.max(0, dots - iw),
        _ => math.max(0, (dots - iw) ~/ 2),
      };
      for (var y = 0; y < ih; y++) {
        for (var x = 0; x < iw; x++) {
          final i = (y * iw + x) * 4;
          final a = px[i + 3] / 255.0;
          final lum = (0.299 * px[i] + 0.587 * px[i + 1] + 0.114 * px[i + 2]) * a + 255.0 * (1 - a);
          final bool ink;
          if (d.logoHighContrast) {
            ink = lum < 165;
          } else {
            // Greys / colours become a halftone pattern, like a newspaper photo.
            ink = lum < 20 + (_bayer[((y & 3) << 2) | (x & 3)] + 0.5) / 16 * 215;
          }
          if (ink) {
            final xx = x0 + x;
            if (xx < dots) bits[y * bpr + (xx >> 3)] |= 0x80 >> (xx & 7);
          }
        }
      }
      final p = _Prepared(key, bits, bpr, rows);
      if (_cache.length > 4) _cache.clear();
      _cache[key] = p;
      return p;
    } catch (_) {
      return null; // a broken logo never blocks the bill
    }
  }

  /// The logo as a small raster block that is sent together with the text,
  /// or null when there is no (readable) logo.
  static Future<Uint8List?> escpos(ReceiptSettings d, {required int dots}) async {
    final p = await _prepare(d, dots);
    if (p == null) return null;
    final out = BytesBuilder();
    out.add(const [0x1B, 0x61, 0x00]); // left: position is already in the data
    out.add([0x1D, 0x76, 0x30, 0x00, p.bpr & 0xFF, (p.bpr >> 8) & 0xFF, p.rows & 0xFF, (p.rows >> 8) & 0xFF]);
    out.add(p.bits);
    return out.toBytes();
  }

  /// "Store in printer" version: [NvLogo.upload] is sent once (ESC/POS
  /// `FS q`), then every bill only sends [NvLogo.print] (`FS p`).
  static Future<NvLogo?> nv(ReceiptSettings d, {required int dots}) async {
    final p = await _prepare(d, dots);
    if (p == null) return null;
    final yUnits = p.rows >> 3; // FS q counts height in 8-dot units
    final upload = BytesBuilder()
      ..add(const [0x1C, 0x71, 0x01])
      ..add([p.bpr & 0xFF, (p.bpr >> 8) & 0xFF, yUnits & 0xFF, (yUnits >> 8) & 0xFF])
      ..add(p.bits);
    return NvLogo(
      key: p.key,
      upload: upload.toBytes(),
      print: Uint8List.fromList(const [0x1B, 0x61, 0x00, 0x1C, 0x70, 0x01, 0x00]),
    );
  }
}

class NvLogo {
  final String key;
  final Uint8List upload;
  final Uint8List print;
  const NvLogo({required this.key, required this.upload, required this.print});
}

class _Prepared {
  final String key;
  final Uint8List bits;
  final int bpr;
  final int rows;
  const _Prepared(this.key, this.bits, this.bpr, this.rows);
}
