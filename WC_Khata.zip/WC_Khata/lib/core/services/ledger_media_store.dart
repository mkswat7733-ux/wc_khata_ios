import 'dart:io';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

/// Keeps Pay / Receive voice notes and customer/supplier photos in the app's
/// own permanent storage (same idea as [ItemImageStore] for product pictures).
///
/// image_picker returns files in a temporary cache folder that Android can
/// clear at any time, so every picked photo is COPIED into
/// `<app documents>/ledger_media/` and only that permanent path is saved in
/// the database.
class LedgerMediaStore {
  LedgerMediaStore._();

  static Directory? _dir;

  static Future<void> init() async {
    final docs = await getApplicationDocumentsDirectory();
    final dir = Directory(p.join(docs.path, 'ledger_media'));
    if (!await dir.exists()) await dir.create(recursive: true);
    _dir = dir;
  }

  static Future<Directory> _ensureDir() async {
    if (_dir == null) await init();
    return _dir!;
  }

  /// Copies a picked / captured photo into permanent storage.
  static Future<String> savePhoto(String sourcePath) async {
    final dir = await _ensureDir();
    var ext = p.extension(sourcePath).toLowerCase();
    if (ext.isEmpty || ext.length > 5) ext = '.jpg';
    final dest = File(p.join(dir.path, 'photo_${DateTime.now().microsecondsSinceEpoch}$ext'));
    await File(sourcePath).copy(dest.path);
    return dest.path;
  }

  /// A fresh permanent path the voice recorder can write straight into.
  static Future<String> newVoicePath() async {
    final dir = await _ensureDir();
    return p.join(dir.path, 'voice_${DateTime.now().microsecondsSinceEpoch}.m4a');
  }

  /// The file for a stored path, or null when it is missing.
  static File? resolve(String? stored) {
    if (stored == null || stored.isEmpty) return null;
    final direct = File(stored);
    if (direct.existsSync()) return direct;
    final dir = _dir;
    if (dir != null) {
      final byName = File(p.join(dir.path, p.basename(stored)));
      if (byName.existsSync()) return byName;
    }
    return null;
  }

  /// Deletes a file, but only if it lives in our own folder.
  static Future<void> delete(String? stored) async {
    if (stored == null || stored.isEmpty) return;
    final dir = _dir;
    if (dir == null) return;
    try {
      final file = File(stored);
      if (p.isWithin(dir.path, file.path) && await file.exists()) {
        await file.delete();
      }
    } catch (_) {}
  }
}
