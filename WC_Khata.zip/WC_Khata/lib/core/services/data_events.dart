import 'dart:async';
import 'package:flutter/foundation.dart';

/// App-wide "something in the books changed" signal.
///
/// Every repository calls [changed] after it writes (sale, product, ledger
/// entry, cashbook transaction, day closing ...). The long-lived tab screens
/// (Home, Ledger, Sale, Products) listen with [listen] and reload themselves,
/// so figures and stock are always current - no app restart, no tab hopping.
class DataEvents {
  DataEvents._();

  static final ValueNotifier<int> revision = ValueNotifier<int>(0);

  static void changed() => revision.value++;

  /// Calls [onChange] (debounced, so a multi-step save reloads once) every
  /// time data changes. Call the returned function from dispose().
  static VoidCallback listen(VoidCallback onChange, {Duration delay = const Duration(milliseconds: 150)}) {
    Timer? timer;
    void handler() {
      timer?.cancel();
      timer = Timer(delay, onChange);
    }

    revision.addListener(handler);
    return () {
      timer?.cancel();
      revision.removeListener(handler);
    };
  }
}
