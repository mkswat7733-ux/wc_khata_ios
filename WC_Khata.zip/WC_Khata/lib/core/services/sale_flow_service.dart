import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// What happens right after a new sale is submitted (Settings > Soft Settings).
enum SaleFlowMode {
  /// Default (all toggles off): open the bill preview, nothing is printed.
  normal,

  /// Print the receipt straight away, then open the bill preview.
  printThenPreview,

  /// Print the receipt straight away, then go back to a fresh New Sale screen.
  printThenNewSale,

  /// Do not print and do not open the bill: go back to a fresh New Sale screen.
  newSaleOnly,
}

/// Remembers the chosen [SaleFlowMode]. Only one mode can be active at a time;
/// "all off" is [SaleFlowMode.normal].
class SaleFlowService extends ChangeNotifier {
  SaleFlowService._();
  static final SaleFlowService instance = SaleFlowService._();

  static const String _key = 'sale_flow_mode';

  SaleFlowMode _mode = SaleFlowMode.normal;
  bool _loaded = false;

  SaleFlowMode get mode => _mode;

  Future<void> load() async {
    if (_loaded) return;
    _loaded = true;
    try {
      final prefs = await SharedPreferences.getInstance();
      final i = prefs.getInt(_key) ?? 0;
      if (i >= 0 && i < SaleFlowMode.values.length) _mode = SaleFlowMode.values[i];
    } catch (_) {}
    notifyListeners();
  }

  Future<void> setMode(SaleFlowMode mode) async {
    _loaded = true;
    _mode = mode;
    notifyListeners();
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setInt(_key, mode.index);
    } catch (_) {}
  }
}
