/// Holds the payload of a notification that opened/resumed the app
/// (`'bill:<id>'` or `'subscription:<id>'`), so whichever screen ends
/// up resolving the app's home destination — `LaunchGate` on a fresh
/// launch, `UnlockScreen` right after a correct password — can send
/// the user to the Notifications screen instead of straight to Home.
///
/// Deliberately a tiny, dependency-free holder (just two static
/// methods) so it can be imported by `NotificationService` and by the
/// screens that consume it without creating an import cycle between
/// them.
class PendingNotification {
  PendingNotification._();

  static String? _payload;

  static void set(String? payload) => _payload = payload;

  /// Reads and clears the pending payload in one step — each
  /// notification tap is only ever acted on once.
  static String? consume() {
    final value = _payload;
    _payload = null;
    return value;
  }
}
