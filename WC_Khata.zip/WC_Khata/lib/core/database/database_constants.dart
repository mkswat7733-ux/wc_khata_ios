/// Central place for table and column names so repositories never
/// hard-code raw strings scattered across the codebase.
class DBConstants {
  DBConstants._();

  static const String dbName = 'wc_khata.db';
  // v1 -> v2: added `photo_path` to `profile` (see DatabaseMigrations).
  // v2 -> v3: `categories` becomes a two-level tree (`parent_id` added).
  // Pre-defined/default categories are no longer seeded — users build
  // their own main categories + sub-categories (see DatabaseMigrations).
  // v3 -> v4: Shopping Lists removed. Replaced by `task_items` — items
  // nested under a Task (Tasks > tap a task > add items with an
  // estimated price; marking one done posts a real Expense and asks
  // which account paid for it).
  // v4 -> v5: added `deleted_at` to `accounts` for the Recycle Bin —
  // deleting an account now soft-deletes it (hidden everywhere, kept
  // in Recycle Bin, restorable) instead of removing the row.
  // v5 -> v6: added `address` to `profile`. Profile screen no longer
  // shows Start Day (column stays, unused, defaulted to Sunday) and
  // its Email field was replaced by Address.
  // v6 -> v7: Cheque Book Management. New `cheques` table holds
  // pending Receive/Sent cheques (a cheque only affects account
  // balances once it's actually cashed — see ChequeRepository). New
  // `cheque_history` table logs every Cashed/Canceled/Transferred
  // action, independent of the `cheques` row it came from.
  // v7 -> v8: Credit Card accounts. `accounts` gains `credit_limit`,
  // `card_type` (Visa/MasterCard/etc.), and `linked_bank_account_id`
  // (which Bank actually funds this card). A card is funded for real
  // at creation — its full limit moves out of that Bank via an
  // ordinary Transfer — so from then on its own `current_balance` IS
  // its available credit (see AccountModel.availableCredit), and every
  // purchase/renewal is just the same generic expense/transfer logic
  // every other account already uses. No schema changes were needed
  // anywhere else.
  // v9 -> v10: Ledger parties and transactions.
  // v10 -> v11: Soft-delete ledger transactions for a 60-day Recycle Bin.
  // v8 -> v9: Fingerprint unlock. `security_settings` gains
  // `fingerprint_enabled` — a convenience unlock method layered on top
  // of the password (never a replacement for it): the password stays
  // the one real secret, and a successful fingerprint scan on the
  // Unlock screen just skips typing it in. Turning fingerprint on/off
  // never touches the password itself.
  // v20 -> v21: profile gains owner_name, designation, tagline, website
  // and whatsapp (used by the Business Card feature).
  // v22 -> v23: `ledger_transactions.is_system` marks entries that the app
  // posts by itself (sale bills, stock purchases). Only manual customer
  // "Pay" entries move cash out of the Cashbook (refund to a customer).
    // v23 -> v24: `ledger_transactions.item_id` links the supplier-ledger rows
  // (purchase bill + payment) to the product they came from, so editing a
  // product updates its supplier ledger entries instead of leaving them stale.
  // v24 -> v25: `items.purchase_cash_tx_id` = cash-out row of a purchase
  // made without a supplier, so editing the product updates the Cashbook.
  // v25 -> v26: `purchases` table (every purchase is its own record, so one
  // product can be bought again and again), `items.track_stock` (the
  // "I manage quantity" switch) and `ledger_transactions.purchase_id`.
  // v26 -> v27: Inner/Outer unit system. `items` gains `outer_unit` (e.g. Box),
  // `inner_unit` (e.g. Strip) and `units_per_outer` (how many inner units are
  // in one outer unit). Stock, cost and sale price are ALWAYS stored per
  // INNER (base) unit, so sales / purchases / reports keep working unchanged.
  // v27 -> v28: Multi-item purchase bills. `purchase_invoices` (one bill per
  // supplier purchase: gross, discount, net, paid) and `purchase_invoice_items`
  // (the products on that bill).
  // v28 -> v29: `item_units` - the user's own list of units (Piece, Box, Kg ...)
  // managed from More > Category/Units.
  // v29 -> v30: `items.scan_text` - the words read from the product picture,
  // used to recognise the product when it is scanned with the camera.
  static const int dbVersion = 31;

  // Tables
  static const String tableProfile = 'profile';
  static const String tableSecuritySettings = 'security_settings';
  static const String tableAppSettings = 'app_settings';

  static const String tableAccounts = 'accounts';
  static const String tableCategories = 'categories';
  static const String tableItemCategories = 'item_categories';
  static const String tableItemUnits = 'item_units';
  static const String tableItems = 'items';
  static const String tableTransactions = 'transactions';

  static const String tableBudgets = 'budgets';
  static const String tableSavingsGoals = 'savings_goals';
  static const String tableGoalActivity = 'goal_activity';

  static const String tableBills = 'bills';
  static const String tableSubscriptions = 'subscriptions';

  static const String tableTasks = 'tasks';
  static const String tableTaskItems = 'task_items';
  static const String tableRoutineItems = 'routine_items';
  static const String tableRoutineCompletions = 'routine_completions';

  static const String tableActivityHistory = 'activity_history';

  static const String tableLedgerParties = 'ledger_parties';
  static const String tableLedgerTransactions = 'ledger_transactions';

  static const String tablePurchases = 'purchases';
  static const String tableSaleInvoices = 'sale_invoices';
  static const String tableSaleItems = 'sale_items';
  static const String tablePurchaseInvoices = 'purchase_invoices';
  static const String tablePurchaseInvoiceItems = 'purchase_invoice_items';

  static const String tableCheques = 'cheques';
  static const String tableChequeHistory = 'cheque_history';
}
