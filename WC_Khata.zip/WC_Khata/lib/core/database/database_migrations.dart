import 'package:sqflite/sqflite.dart';
import 'database_constants.dart';

/// Every schema change ships as a numbered migration here — never alter
/// _onCreate for existing installs, and never drop/recreate tables,
/// since that would destroy the user's local financial data.
class DatabaseMigrations {
  DatabaseMigrations._();

  static Future<void> onUpgrade(Database db, int oldVersion, int newVersion) async {
    if (oldVersion < 2) {
      await db.execute('ALTER TABLE ${DBConstants.tableProfile} ADD COLUMN photo_path TEXT');
    }
    if (oldVersion < 3) {
      // Categories become a 2-level tree: a main category (parent_id
      // NULL, e.g. "ABC Restaurant") can hold sub-categories (e.g.
      // "Electricity Bill") that are usable from both Income and
      // Expense — that's what makes per-category profit/loss possible.
      // Existing rows (including the old seeded defaults) simply become
      // main categories; nothing is deleted, so no old data is lost.
      await db.execute(
        'ALTER TABLE ${DBConstants.tableCategories} ADD COLUMN parent_id INTEGER '
        'REFERENCES ${DBConstants.tableCategories}(id) ON DELETE CASCADE',
      );
    }
    if (oldVersion < 4) {
      // Shopping Lists is replaced by task_items (items nested under a
      // Task, with an estimated price and a real Expense posted when
      // marked done). Old shopping_lists/shopping_items tables are left
      // in place untouched — no data is deleted — the app just stops
      // reading/writing them.
      await db.execute('''
        CREATE TABLE ${DBConstants.tableTaskItems} (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          task_id INTEGER NOT NULL,
          name TEXT NOT NULL,
          estimated_price REAL NOT NULL DEFAULT 0,
          actual_price REAL,
          is_done INTEGER NOT NULL DEFAULT 0,
          account_id INTEGER,
          transaction_id INTEGER,
          created_at TEXT NOT NULL,
          FOREIGN KEY (task_id) REFERENCES ${DBConstants.tableTasks}(id) ON DELETE CASCADE
        )
      ''');
      await db.execute('CREATE INDEX idx_task_items_task ON ${DBConstants.tableTaskItems}(task_id)');
    }
    if (oldVersion < 5) {
      // Recycle Bin for accounts: deleting an account now sets
      // `deleted_at` instead of removing the row, so it can be
      // restored later. NULL = not deleted (existing rows stay NULL).
      await db.execute('ALTER TABLE ${DBConstants.tableAccounts} ADD COLUMN deleted_at TEXT');
    }
    if (oldVersion < 6) {
      // Profile: Email field replaced by Address in the UI.
      await db.execute('ALTER TABLE ${DBConstants.tableProfile} ADD COLUMN address TEXT');
    }
    if (oldVersion < 7) {
      // Cheque Book Management. A cheque is purely a pending
      // instrument until it's cashed — creating one never touches an
      // account balance, so from/to are required but nothing is
      // reversed on cancel. `parent_cheque_id` links a Sent cheque
      // that was created by endorsing ("Transfer") a Receive cheque
      // back to the original one it came from.
      await db.execute('''
        CREATE TABLE ${DBConstants.tableCheques} (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          direction TEXT NOT NULL, -- receive | sent
          status TEXT NOT NULL DEFAULT 'pending', -- pending | cashed | canceled | transferred
          cheque_number TEXT NOT NULL,
          bank_name TEXT NOT NULL,
          cheque_date TEXT NOT NULL,
          from_account_id INTEGER NOT NULL,
          to_account_id INTEGER NOT NULL,
          amount REAL NOT NULL,
          transaction_id INTEGER,
          parent_cheque_id INTEGER,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL,
          FOREIGN KEY (from_account_id) REFERENCES ${DBConstants.tableAccounts}(id) ON DELETE CASCADE,
          FOREIGN KEY (to_account_id) REFERENCES ${DBConstants.tableAccounts}(id) ON DELETE CASCADE,
          FOREIGN KEY (transaction_id) REFERENCES ${DBConstants.tableTransactions}(id) ON DELETE SET NULL,
          FOREIGN KEY (parent_cheque_id) REFERENCES ${DBConstants.tableCheques}(id) ON DELETE SET NULL
        )
      ''');
      await db.execute(
        'CREATE INDEX idx_cheques_direction_status ON ${DBConstants.tableCheques}(direction, status)',
      );

      // A permanent, independent log — kept even if the cheque row it
      // references is ever removed, so "Cheque History" never loses a
      // past action.
      await db.execute('''
        CREATE TABLE ${DBConstants.tableChequeHistory} (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          cheque_id INTEGER NOT NULL,
          action TEXT NOT NULL, -- cashed | canceled | transferred
          direction TEXT NOT NULL,
          cheque_number TEXT NOT NULL,
          bank_name TEXT NOT NULL,
          cheque_date TEXT NOT NULL,
          from_account_id INTEGER NOT NULL,
          to_account_id INTEGER NOT NULL,
          amount REAL NOT NULL,
          acted_at TEXT NOT NULL
        )
      ''');
      await db.execute(
        'CREATE INDEX idx_cheque_history_cheque ON ${DBConstants.tableChequeHistory}(cheque_id)',
      );
    }
    if (oldVersion < 8) {
      // Credit Card accounts. `current_balance` doubles as the card's
      // available credit (funded for real from a Bank at creation —
      // see AccountFormScreen) via the same generic expense/transfer
      // logic every other account uses — these three columns just add
      // the extra facts a credit card needs on top: its limit, its
      // kind, and which Bank actually funds it.
      await db.execute('ALTER TABLE ${DBConstants.tableAccounts} ADD COLUMN credit_limit REAL');
      await db.execute('ALTER TABLE ${DBConstants.tableAccounts} ADD COLUMN card_type TEXT');
      await db.execute('ALTER TABLE ${DBConstants.tableAccounts} ADD COLUMN linked_bank_account_id INTEGER');
    }
    if (oldVersion < 9) {
      // Fingerprint unlock toggle — off by default for every existing
      // installation, so nothing changes for anyone until they turn it
      // on themselves in Security.
      await db.execute(
        'ALTER TABLE ${DBConstants.tableSecuritySettings} ADD COLUMN fingerprint_enabled INTEGER NOT NULL DEFAULT 0',
      );
    }
    if (oldVersion < 10) {
      await db.execute('''
        CREATE TABLE ${DBConstants.tableLedgerParties} (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT NOT NULL,
          phone TEXT,
          type TEXT NOT NULL,
          reminder_date TEXT,
          reminder_amount REAL,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL
        )
      ''');
      await db.execute('CREATE INDEX idx_ledger_parties_type ON ${DBConstants.tableLedgerParties}(type)');
      await db.execute('''
        CREATE TABLE ${DBConstants.tableLedgerTransactions} (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          party_id INTEGER NOT NULL,
          type TEXT NOT NULL,
          amount REAL NOT NULL,
          note TEXT,
          date TEXT NOT NULL,
          created_at TEXT NOT NULL,
          FOREIGN KEY (party_id) REFERENCES ${DBConstants.tableLedgerParties}(id) ON DELETE CASCADE
        )
      ''');
      await db.execute('CREATE INDEX idx_ledger_transactions_party ON ${DBConstants.tableLedgerTransactions}(party_id)');
      await db.execute('CREATE INDEX idx_ledger_transactions_date ON ${DBConstants.tableLedgerTransactions}(date)');
    }

    if (oldVersion < 11) {
      await db.execute(
        'ALTER TABLE ${DBConstants.tableLedgerTransactions} ADD COLUMN deleted_at TEXT',
      );
      await db.execute(
        'CREATE INDEX idx_ledger_transactions_deleted_at ON ${DBConstants.tableLedgerTransactions}(deleted_at)',
      );
    }

    if (oldVersion < 12) {
      await db.execute('''CREATE TABLE ${DBConstants.tableItemCategories} (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE, created_at TEXT NOT NULL)''');
      await db.execute('''CREATE TABLE ${DBConstants.tableItems} (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, category_id INTEGER, unit TEXT NOT NULL, qty REAL NOT NULL DEFAULT 0, low_stock REAL NOT NULL DEFAULT 0, price REAL NOT NULL DEFAULT 0, image_path TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL, FOREIGN KEY (category_id) REFERENCES ${DBConstants.tableItemCategories}(id) ON DELETE SET NULL)''');
      await db.execute('CREATE INDEX idx_items_category ON ${DBConstants.tableItems}(category_id)');
    }


    if (oldVersion < 13) {
      await db.execute(
        'ALTER TABLE ${DBConstants.tableItems} ADD COLUMN barcode TEXT',
      );
      await db.execute(
        "CREATE UNIQUE INDEX IF NOT EXISTS idx_items_barcode ON ${DBConstants.tableItems}(barcode) WHERE barcode IS NOT NULL AND barcode != ''",
      );
    }

    if (oldVersion < 14) {
      await db.execute('ALTER TABLE ${DBConstants.tableItems} ADD COLUMN supplier_id INTEGER');
      await db.execute('ALTER TABLE ${DBConstants.tableItems} ADD COLUMN purchase_type TEXT');
      await db.execute('ALTER TABLE ${DBConstants.tableItems} ADD COLUMN purchase_amount REAL NOT NULL DEFAULT 0');
      await db.execute('ALTER TABLE ${DBConstants.tableItems} ADD COLUMN purchase_paid REAL NOT NULL DEFAULT 0');
      await db.execute('ALTER TABLE ${DBConstants.tableItems} ADD COLUMN purchase_date TEXT');
      await db.execute('''CREATE TABLE ${DBConstants.tableSaleInvoices} (id INTEGER PRIMARY KEY AUTOINCREMENT, invoice_no TEXT NOT NULL UNIQUE, customer_id INTEGER, payment_type TEXT NOT NULL, total REAL NOT NULL, paid_amount REAL NOT NULL DEFAULT 0, date TEXT NOT NULL, created_at TEXT NOT NULL)''');
      await db.execute('''CREATE TABLE ${DBConstants.tableSaleItems} (id INTEGER PRIMARY KEY AUTOINCREMENT, sale_id INTEGER NOT NULL, item_id INTEGER NOT NULL, item_name TEXT NOT NULL, qty REAL NOT NULL, unit_price REAL NOT NULL, total REAL NOT NULL, FOREIGN KEY (sale_id) REFERENCES ${DBConstants.tableSaleInvoices}(id) ON DELETE CASCADE, FOREIGN KEY (item_id) REFERENCES ${DBConstants.tableItems}(id) ON DELETE RESTRICT)''');
      await db.execute('CREATE INDEX idx_sale_items_sale ON ${DBConstants.tableSaleItems}(sale_id)');
      await db.execute('CREATE INDEX idx_sale_invoices_date ON ${DBConstants.tableSaleInvoices}(date)');
    }

    if (oldVersion < 16) {
      // Store the unit purchase cost used for inventory profit/loss.
      // Existing rows get the best available unit cost from their saved
      // purchase total and current quantity; new purchases write it directly.
      await db.execute(
        'ALTER TABLE ${DBConstants.tableItems} ADD COLUMN purchase_unit_price REAL NOT NULL DEFAULT 0',
      );
      await db.execute(
        'UPDATE ${DBConstants.tableItems} SET purchase_unit_price = CASE WHEN qty > 0 THEN purchase_amount / qty ELSE 0 END WHERE purchase_unit_price = 0',
      );
    }

    if (oldVersion < 17) {
      // Store the exact purchase cost used by each sale line. Historical
      // P/L must not change when an item's current purchase price changes.
      await db.execute(
        'ALTER TABLE ${DBConstants.tableSaleItems} ADD COLUMN unit_cost REAL NOT NULL DEFAULT 0',
      );
      await db.execute('''
        UPDATE ${DBConstants.tableSaleItems}
        SET unit_cost = COALESCE((
          SELECT purchase_unit_price
          FROM ${DBConstants.tableItems} i
          WHERE i.id = ${DBConstants.tableSaleItems}.item_id
        ), 0)
        WHERE unit_cost = 0
      ''');
    }

    if (oldVersion < 15) {
      // Customer/supplier dual-role linking. Two role rows can represent
      // the same real person while keeping Customer and Supplier ledgers
      // distinct for display. Balances are reconciled across linked rows.
      await db.execute(
        'ALTER TABLE ${DBConstants.tableLedgerParties} ADD COLUMN linked_party_id INTEGER',
      );
      await db.execute(
        'CREATE INDEX IF NOT EXISTS idx_ledger_parties_linked ON ${DBConstants.tableLedgerParties}(linked_party_id)',
      );
    }

    if (oldVersion < 19) {
      // Wire ledger Pay/Receive records to the real cash transaction that
      // changes an account balance. Existing ledger rows remain valid and
      // simply have no linked cash transaction.
      await db.execute(
        'ALTER TABLE ${DBConstants.tableLedgerTransactions} ADD COLUMN cash_transaction_id INTEGER',
      );
      await db.execute(
        'CREATE INDEX idx_ledger_transactions_cash_tx ON ${DBConstants.tableLedgerTransactions}(cash_transaction_id)',
      );
    }

    if (oldVersion < 18) {
      // Sale pricing adjustments: tax is kept separate from revenue/profit,
      // while discount reduces the actual selling revenue used for P/L.
      await db.execute('ALTER TABLE ${DBConstants.tableSaleInvoices} ADD COLUMN subtotal REAL NOT NULL DEFAULT 0');
      await db.execute('ALTER TABLE ${DBConstants.tableSaleInvoices} ADD COLUMN discount_amount REAL NOT NULL DEFAULT 0');
      await db.execute('ALTER TABLE ${DBConstants.tableSaleInvoices} ADD COLUMN tax_rate REAL NOT NULL DEFAULT 0');
      await db.execute('ALTER TABLE ${DBConstants.tableSaleInvoices} ADD COLUMN tax_amount REAL NOT NULL DEFAULT 0');
      await db.execute('UPDATE ${DBConstants.tableSaleInvoices} SET subtotal = total WHERE subtotal = 0');
    }

    if (oldVersion < 20) {
      await db.execute(
        'ALTER TABLE ${DBConstants.tableProfile} ADD COLUMN phone TEXT',
      );
    }

    if (oldVersion < 21) {
      for (final column in const ['owner_name', 'designation', 'tagline', 'website', 'whatsapp']) {
        await db.execute(
          'ALTER TABLE ${DBConstants.tableProfile} ADD COLUMN $column TEXT',
        );
      }
    }

    if (oldVersion < 22) {
      // Voice note + customer/supplier photo on Pay / Receive entries.
      // Existing rows simply have no voice note or photo (NULL).
      await db.execute('ALTER TABLE ${DBConstants.tableLedgerTransactions} ADD COLUMN voice_path TEXT');
      await db.execute('ALTER TABLE ${DBConstants.tableLedgerTransactions} ADD COLUMN attachment_path TEXT');
    }

    if (oldVersion < 23) {
      // Entries posted automatically by sales / stock purchases are flagged
      // so they never move cash twice. Existing rows are back-filled from
      // the notes those flows always wrote; nothing else is changed.
      await db.execute('ALTER TABLE ${DBConstants.tableLedgerTransactions} ADD COLUMN is_system INTEGER NOT NULL DEFAULT 0');
      await db.execute("""
        UPDATE ${DBConstants.tableLedgerTransactions} SET is_system = 1
        WHERE note LIKE 'Sale INV-%' OR note LIKE 'Payment for INV-%'
           OR note LIKE 'Stock purchase%' OR note LIKE 'Supplier payment %'
      """);
    }

    if (oldVersion < 24) {
      // Link supplier-ledger rows to the product they were posted for.
      await db.execute('ALTER TABLE ${DBConstants.tableLedgerTransactions} ADD COLUMN item_id INTEGER');
      await db.execute('CREATE INDEX IF NOT EXISTS idx_ledger_transactions_item ON ${DBConstants.tableLedgerTransactions}(item_id)');
      // Best-effort back-fill for existing purchases: only when exactly one
      // product of that supplier matches the note, so nothing is mislinked.
      await db.execute("""
        UPDATE ${DBConstants.tableLedgerTransactions} SET item_id = (
          SELECT i.id FROM ${DBConstants.tableItems} i
          WHERE i.supplier_id = ${DBConstants.tableLedgerTransactions}.party_id
            AND ((${DBConstants.tableLedgerTransactions}.type = 'pay' AND ${DBConstants.tableLedgerTransactions}.note LIKE 'Stock purchase • ' || i.name || ' •%')
              OR (${DBConstants.tableLedgerTransactions}.type = 'receive' AND ${DBConstants.tableLedgerTransactions}.note LIKE 'Supplier payment • ' || i.name || ' •%'))
        )
        WHERE is_system = 1 AND item_id IS NULL AND (
          SELECT COUNT(*) FROM ${DBConstants.tableItems} i
          WHERE i.supplier_id = ${DBConstants.tableLedgerTransactions}.party_id
            AND ((${DBConstants.tableLedgerTransactions}.type = 'pay' AND ${DBConstants.tableLedgerTransactions}.note LIKE 'Stock purchase • ' || i.name || ' •%')
              OR (${DBConstants.tableLedgerTransactions}.type = 'receive' AND ${DBConstants.tableLedgerTransactions}.note LIKE 'Supplier payment • ' || i.name || ' •%'))
        ) = 1
      """);
    }

    if (oldVersion < 25) {
      // Cash-out row of a purchase made WITHOUT a supplier (kept in step when
      // the product is edited). Guarded so it is safe on any earlier build.
      final cols = await db.rawQuery('PRAGMA table_info(${DBConstants.tableItems})');
      if (!cols.any((c) => c['name'] == 'purchase_cash_tx_id')) {
        await db.execute('ALTER TABLE ${DBConstants.tableItems} ADD COLUMN purchase_cash_tx_id INTEGER');
      }
    }

    if (oldVersion < 26) {
      // Stock tracking switch (existing products keep managing quantity).
      final itemCols = await db.rawQuery('PRAGMA table_info(${DBConstants.tableItems})');
      if (!itemCols.any((c) => c['name'] == 'track_stock')) {
        await db.execute('ALTER TABLE ${DBConstants.tableItems} ADD COLUMN track_stock INTEGER NOT NULL DEFAULT 1');
      }
      // Link supplier-ledger purchase rows to a purchase record.
      final ledgerCols = await db.rawQuery('PRAGMA table_info(${DBConstants.tableLedgerTransactions})');
      if (!ledgerCols.any((c) => c['name'] == 'purchase_id')) {
        await db.execute('ALTER TABLE ${DBConstants.tableLedgerTransactions} ADD COLUMN purchase_id INTEGER');
      }
      await db.execute('CREATE INDEX IF NOT EXISTS idx_ledger_transactions_purchase ON ${DBConstants.tableLedgerTransactions}(purchase_id)');
      await db.execute('''CREATE TABLE IF NOT EXISTS ${DBConstants.tablePurchases} (id INTEGER PRIMARY KEY AUTOINCREMENT, item_id INTEGER NOT NULL, item_name TEXT NOT NULL, unit TEXT NOT NULL DEFAULT '', supplier_id INTEGER, purchase_type TEXT NOT NULL DEFAULT 'cash', qty REAL NOT NULL DEFAULT 0, unit_cost REAL NOT NULL DEFAULT 0, total REAL NOT NULL DEFAULT 0, paid REAL NOT NULL DEFAULT 0, purchase_date TEXT NOT NULL, note TEXT, cash_tx_id INTEGER, created_at TEXT NOT NULL, updated_at TEXT NOT NULL)''');
      await db.execute('CREATE INDEX IF NOT EXISTS idx_purchases_item ON ${DBConstants.tablePurchases}(item_id)');
      await db.execute('CREATE INDEX IF NOT EXISTS idx_purchases_date ON ${DBConstants.tablePurchases}(purchase_date)');
      // Every product that already has a purchase becomes a purchase record.
      await backfillPurchases(db);
    }

    if (oldVersion < 27) {
      // Inner/Outer unit system (existing products keep their single unit).
      final cols = await db.rawQuery('PRAGMA table_info(${DBConstants.tableItems})');
      if (!cols.any((c) => c['name'] == 'outer_unit')) {
        await db.execute('ALTER TABLE ${DBConstants.tableItems} ADD COLUMN outer_unit TEXT');
      }
      if (!cols.any((c) => c['name'] == 'inner_unit')) {
        await db.execute('ALTER TABLE ${DBConstants.tableItems} ADD COLUMN inner_unit TEXT');
      }
      if (!cols.any((c) => c['name'] == 'units_per_outer')) {
        await db.execute('ALTER TABLE ${DBConstants.tableItems} ADD COLUMN units_per_outer REAL NOT NULL DEFAULT 1');
      }
    }

    if (oldVersion < 28) {
      // Multi-item purchase bills.
      await db.execute('''CREATE TABLE IF NOT EXISTS ${DBConstants.tablePurchaseInvoices} (id INTEGER PRIMARY KEY AUTOINCREMENT, invoice_no TEXT NOT NULL, supplier_id INTEGER, payment_type TEXT NOT NULL DEFAULT 'cash', subtotal REAL NOT NULL DEFAULT 0, discount_amount REAL NOT NULL DEFAULT 0, total REAL NOT NULL DEFAULT 0, paid_amount REAL NOT NULL DEFAULT 0, date TEXT NOT NULL, created_at TEXT NOT NULL, FOREIGN KEY (supplier_id) REFERENCES ${DBConstants.tableLedgerParties}(id) ON DELETE SET NULL)''');
      await db.execute('''CREATE TABLE IF NOT EXISTS ${DBConstants.tablePurchaseInvoiceItems} (id INTEGER PRIMARY KEY AUTOINCREMENT, purchase_invoice_id INTEGER NOT NULL, item_id INTEGER NOT NULL, item_name TEXT NOT NULL, unit TEXT NOT NULL DEFAULT '', qty REAL NOT NULL, unit_cost REAL NOT NULL DEFAULT 0, line_discount REAL NOT NULL DEFAULT 0, total REAL NOT NULL DEFAULT 0, FOREIGN KEY (purchase_invoice_id) REFERENCES ${DBConstants.tablePurchaseInvoices}(id) ON DELETE CASCADE)''');
      await db.execute('CREATE INDEX IF NOT EXISTS idx_purchase_invoice_items_invoice ON ${DBConstants.tablePurchaseInvoiceItems}(purchase_invoice_id)');
      await db.execute('CREATE INDEX IF NOT EXISTS idx_purchase_invoices_date ON ${DBConstants.tablePurchaseInvoices}(date)');
    }

    if (oldVersion < 29) {
      // The user's own unit list (More > Category/Units).
      await db.execute('''CREATE TABLE IF NOT EXISTS ${DBConstants.tableItemUnits} (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE, created_at TEXT NOT NULL)''');
    }

    if (oldVersion < 31) {
      // Customer / supplier address (shown on the bill when the shop turns it on).
      final cols = await db.rawQuery('PRAGMA table_info(${DBConstants.tableLedgerParties})');
      if (!cols.any((c) => c['name'] == 'address')) {
        await db.execute('ALTER TABLE ${DBConstants.tableLedgerParties} ADD COLUMN address TEXT');
      }
    }

    if (oldVersion < 30) {
      // Words read from the product picture (picture scanning).
      final cols = await db.rawQuery('PRAGMA table_info(${DBConstants.tableItems})');
      if (!cols.any((c) => c['name'] == 'scan_text')) {
        await db.execute('ALTER TABLE ${DBConstants.tableItems} ADD COLUMN scan_text TEXT');
      }
    }

  }

  /// Turns the purchase kept on each product (older versions) into purchase
  /// records and links their supplier-ledger rows to them. Also used after
  /// restoring an older backup that has no purchase records.
  static Future<void> backfillPurchases(DatabaseExecutor db) async {
      await db.execute('''
        INSERT INTO ${DBConstants.tablePurchases}
          (item_id, item_name, unit, supplier_id, purchase_type, qty, unit_cost, total, paid, purchase_date, cash_tx_id, created_at, updated_at)
        SELECT i.id, i.name, i.unit, i.supplier_id, COALESCE(i.purchase_type, 'cash'),
               CASE WHEN i.purchase_unit_price > 0 THEN i.purchase_amount / i.purchase_unit_price ELSE i.qty END,
               i.purchase_unit_price, i.purchase_amount, i.purchase_paid, i.purchase_date,
               i.purchase_cash_tx_id, i.created_at, i.updated_at
        FROM ${DBConstants.tableItems} i
        WHERE i.purchase_amount > 0 AND i.purchase_date IS NOT NULL
      ''');
      await db.execute('''
        UPDATE ${DBConstants.tableLedgerTransactions} SET purchase_id = (
          SELECT p.id FROM ${DBConstants.tablePurchases} p
          WHERE p.item_id = ${DBConstants.tableLedgerTransactions}.item_id ORDER BY p.id DESC LIMIT 1
        )
        WHERE item_id IS NOT NULL AND purchase_id IS NULL AND is_system = 1
      ''');
  }

}
