import 'package:intl/intl.dart';

/// Central currency formatting for the whole app.
///
/// [defaultSymbol] is kept in sync with the user's chosen currency
/// (Profile screen → Currency) by `UserPreferencesController`. Every
/// call site in the app calls `format`/`formatCompact` WITHOUT passing
/// a symbol, so changing currency in Profile and tapping Save updates
/// every screen's currency symbol immediately, app-wide — no restart
/// needed.
class CurrencyFormatter {
  CurrencyFormatter._();

  /// Current app-wide currency symbol. Updated by
  /// `UserPreferencesController` on load and whenever the user saves a
  /// new currency on the Profile screen.
  static String defaultSymbol = '\$';

  /// ISO code of the current currency (kept in sync with [defaultSymbol]).
  static String defaultCode = 'USD';

  /// Short label used in input boxes and captions ("Rs 500", "\$ 500").
  /// Rupee currencies read "Rs"; every other currency uses its own symbol,
  /// so changing the currency changes it everywhere.
  static String get label {
    if (defaultSymbol == '₨') return 'Rs';
    return defaultSymbol;
  }

  /// Same label but safe for PDF fonts (falls back to the ISO code when the
  /// symbol is not plain ASCII).
  static String get pdfLabel {
    final l = label;
    return RegExp(r'^[\x20-\x7E]+$').hasMatch(l) ? l : defaultCode;
  }

  /// The single ceiling used everywhere an amount is entered or shown:
  /// payment entry validation won't let the user type past its screen-specific limit, and
  /// display formatting treats anything at or beyond it (which should
  /// never legitimately happen once input is capped) as a data problem
  /// rather than a number to show. Comfortably past any real personal
  /// or small-business balance, so it never gets in the user's way.
  static const double maxAmount = 100000000.0; // 100,000,000 (Rs 10 crore)

  static String format(double amount, {String? symbol}) {
    final safe = _safe(amount);
    final formatter = NumberFormat.currency(symbol: symbol ?? defaultSymbol, decimalDigits: 2);
    return formatter.format(safe);
  }

  /// The one formatter every screen uses for amounts. Always shows the
  /// full, exact number with thousands separators — e.g. `$1,250,000.00`
  /// — never an abbreviated `$1.25M`. Abbreviating a real balance or
  /// transaction amount hides precision that matters for money, which
  /// is worse than a long string; the fix for a long string is a
  /// layout that can shrink to fit (`AutoSizeText`), not rounding the
  /// number itself.
  static String formatCompact(double amount, {String? symbol}) => format(amount, symbol: symbol);

  /// NaN/Infinite should never reach here in normal use — the input
  /// side is capped by [CurrencyInputFormatter] and [maxAmount] — but
  /// if a calculation bug ever produces one, showing "0" is far safer
  /// for a finance app than showing "∞" (which reads as "unlimited
  /// money/debt") or crashing the formatter.
  static double _safe(double amount) {
    if (amount.isNaN || amount.isInfinite) return 0;
    if (amount > maxAmount) return maxAmount;
    if (amount < -maxAmount) return -maxAmount;
    return amount;
  }
}
