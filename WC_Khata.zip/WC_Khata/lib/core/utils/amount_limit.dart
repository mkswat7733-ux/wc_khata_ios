import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../services/app_navigator.dart';
import '../widgets/app_message.dart';

/// App-wide money ceiling: 1 Crore = 1,00,00,000 (10,000,000).
/// Every screen that takes an amount uses this one place, so the limit and
/// the message are always the same.
class AmountLimit {
  AmountLimit._();

  static const double max = 10000000.0;
  static const String message = 'Maximum amount is 1 Crore (1,00,00,000).';

  /// True when [value] is a real number above the 1 Crore ceiling.
  static bool exceeds(double? value) =>
      value != null && value.isFinite && value > max;

  /// Shows the standard "Maximum amount is 1 Crore" error dialog.
  static void showMessage([BuildContext? context]) {
    final ctx = (context != null && context.mounted)
        ? context
        : appNavigatorKey.currentContext;
    if (ctx == null) return;
    AppMessenger.showError(ctx, message);
  }
}

/// Use on any amount [TextField]: a key press that would push the number
/// above 1 Crore is rejected (the old text stays) and the message is shown.
class MaxAmountFormatter extends TextInputFormatter {
  const MaxAmountFormatter();

  @override
  TextEditingValue formatEditUpdate(
    TextEditingValue oldValue,
    TextEditingValue newValue,
  ) {
    final parsed = double.tryParse(newValue.text.replaceAll(',', '').trim());
    if (AmountLimit.exceeds(parsed)) {
      Future.microtask(AmountLimit.showMessage);
      return oldValue;
    }
    return newValue;
  }
}
