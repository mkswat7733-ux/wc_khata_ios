import 'dart:ui' show PlatformDispatcher;

/// One selectable currency.
class CurrencyInfo {
  final String code;
  final String name; // used on receipts, e.g. "Taka"
  final String symbol;
  final String country; // ISO-3166 alpha-2, used for the flag + locale default

  const CurrencyInfo(this.code, this.name, this.symbol, this.country);

  /// Flag emoji built from the country code (no image assets needed).
  String get flag => String.fromCharCodes(
        country.toUpperCase().codeUnits.map((c) => 0x1F1E6 + (c - 0x41)),
      );
}

/// Every currency the app supports. Add new ones here only — the Register
/// screen, Currency settings screen and receipts all read from this list.
const List<CurrencyInfo> kCurrencies = [
  CurrencyInfo('PKR', 'Rupees', '₨', 'PK'),
  CurrencyInfo('INR', 'Rupees', '₹', 'IN'),
  CurrencyInfo('BDT', 'Taka', '৳', 'BD'),
  CurrencyInfo('AFN', 'Afghani', '؋', 'AF'),
  CurrencyInfo('NPR', 'Rupees', 'Rs', 'NP'),
  CurrencyInfo('LKR', 'Rupees', 'Rs', 'LK'),
  CurrencyInfo('USD', 'Dollars', '\$', 'US'),
  CurrencyInfo('EUR', 'Euro', '€', 'DE'),
  CurrencyInfo('GBP', 'Pounds', '£', 'GB'),
  CurrencyInfo('AED', 'Dirhams', 'د.إ', 'AE'),
  CurrencyInfo('SAR', 'Riyals', '﷼', 'SA'),
  CurrencyInfo('QAR', 'Riyals', 'ر.ق', 'QA'),
  CurrencyInfo('KWD', 'Dinars', 'د.ك', 'KW'),
  CurrencyInfo('OMR', 'Rials', 'ر.ع.', 'OM'),
  CurrencyInfo('BHD', 'Dinars', 'د.ب', 'BH'),
  CurrencyInfo('CAD', 'Canadian Dollars', 'CA\$', 'CA'),
  CurrencyInfo('AUD', 'Australian Dollars', 'A\$', 'AU'),
  CurrencyInfo('SGD', 'Singapore Dollars', 'S\$', 'SG'),
  CurrencyInfo('MYR', 'Ringgit', 'RM', 'MY'),
  CurrencyInfo('TRY', 'Lira', '₺', 'TR'),
  CurrencyInfo('CNY', 'Yuan', '¥', 'CN'),
  CurrencyInfo('JPY', 'Yen', '¥', 'JP'),
  CurrencyInfo('EGP', 'Pounds', 'E£', 'EG'),
  CurrencyInfo('ZAR', 'Rand', 'R', 'ZA'),
  CurrencyInfo('NGN', 'Naira', '₦', 'NG'),
  CurrencyInfo('KES', 'Shillings', 'KSh', 'KE'),
];

/// Code -> symbol (kept for the many existing call sites).
final Map<String, String> kCurrencySymbols = {
  for (final c in kCurrencies) c.code: c.symbol,
};

String currencySymbolFor(String code) => kCurrencySymbols[code] ?? code;

CurrencyInfo? currencyInfoFor(String code) {
  for (final c in kCurrencies) {
    if (c.code == code) return c;
  }
  return null;
}

/// Word used on receipts for the amount, e.g. "Taka", "Rupees".
String currencyNameFor(String code) => currencyInfoFor(code)?.name ?? code;

/// Best-guess currency from the phone's region (falls back to USD).
String guessCurrencyFromLocale() {
  final region = PlatformDispatcher.instance.locale.countryCode?.toUpperCase();
  if (region != null) {
    for (final c in kCurrencies) {
      if (c.country == region) return c.code;
    }
    const eurozone = {'FR', 'IT', 'ES', 'NL', 'BE', 'AT', 'PT', 'IE', 'FI', 'GR'};
    if (eurozone.contains(region)) return 'EUR';
  }
  return 'USD';
}

/// Pakistan / India / Bangladesh / Nepal / Sri Lanka read big numbers as
/// lakh and crore instead of million and billion.
bool currencyUsesLakhCrore(String code) =>
    const {'PKR', 'INR', 'BDT', 'NPR', 'LKR'}.contains(code);
