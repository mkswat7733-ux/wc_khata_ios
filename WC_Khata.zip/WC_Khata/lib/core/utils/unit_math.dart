/// Conversions for the Inner / Outer unit system.
///
/// Everything is stored in the INNER (base) unit. Example: 1 Box = 10 Strips,
/// stock of 50 Box + 5 Strips is stored as 505 (strips) and shown as
/// "Total 50.5 Box".
class UnitMath {
  UnitMath._();

  static const double _eps = 0.000001;

  static String fmt(double v, {int dp = 4}) {
    if (!v.isFinite) return '0';
    if ((v - v.roundToDouble()).abs() < _eps) return v.round().toString();
    final t = v.toStringAsFixed(dp).replaceFirst(RegExp(r'0+$'), '');
    return t.endsWith('.') ? t.substring(0, t.length - 1) : t;
  }

  /// outer + inner quantities -> base (inner) quantity.
  static double toBase(double outer, double inner, double perOuter) => outer * perOuter + inner;

  /// base (inner) quantity -> whole outer units.
  static double outerPart(double base, double perOuter) {
    if (perOuter <= 0) return 0;
    return ((base + _eps) / perOuter).floorToDouble();
  }

  /// base (inner) quantity -> loose inner units left after the whole outers.
  static double innerPart(double base, double perOuter) {
    if (perOuter <= 0) return base;
    final r = base - outerPart(base, perOuter) * perOuter;
    if (r < _eps) return 0;
    return (r.roundToDouble() - r).abs() < _eps ? r.roundToDouble() : r;
  }

  /// base (inner) quantity -> total expressed in outer units (505 -> 50.5).
  static double totalInOuter(double base, double perOuter) => perOuter <= 0 ? base : base / perOuter;

  /// total expressed in outer units (50.5) -> base (505).
  static double outerTotalToBase(double totalOuter, double perOuter) => totalOuter * perOuter;

  /// "50 Box 5 Strips" (zero parts are skipped).
  static String describe(double base, double perOuter, String outerName, String innerName) {
    final o = outerPart(base, perOuter);
    final i = innerPart(base, perOuter);
    final parts = <String>[];
    if (o > 0) parts.add('${fmt(o)} $outerName');
    if (i > 0) parts.add('${fmt(i)} $innerName');
    return parts.isEmpty ? '0 $outerName' : parts.join(' ');
  }
}
