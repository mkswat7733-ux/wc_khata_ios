import java.io.FileInputStream
import java.util.Properties

plugins {
    id("com.android.application")
    // The Flutter Gradle Plugin must be applied after the Android and Kotlin Gradle plugins.
    id("dev.flutter.flutter-gradle-plugin")
}

// ---------------------------------------------------------------------
// Release signing (Google Play upload key)
//
// The passwords and the keystore path are NOT written in this file. They
// are read from android/key.properties, which is private to your PC and
// is never committed or zipped (see android/.gitignore).
// Copy android/key.properties.example to android/key.properties and fill
// it in. Full steps: PLAY_STORE_SETUP.md in the project root.
// ---------------------------------------------------------------------
val keystoreProperties = Properties()
val keystorePropertiesFile = rootProject.file("key.properties")
val keyPropertiesFound = keystorePropertiesFile.exists()
if (keyPropertiesFound) {
    FileInputStream(keystorePropertiesFile).use { keystoreProperties.load(it) }
}
val keystorePath: String = keystoreProperties.getProperty("storeFile") ?: ""
// The release key is used only when key.properties exists AND the keystore
// file it points to has really been created.
val hasReleaseKey = keyPropertiesFound && keystorePath.isNotBlank() && file(keystorePath).exists()

android {
    namespace = "com.webdsoft.wckhata"
    // Google Play requires targetSdk 36 (Android 16) for new apps/updates.
    compileSdk = maxOf(flutter.compileSdkVersion, 36)
    ndkVersion = flutter.ndkVersion

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
        // flutter_local_notifications requires core library desugaring
        isCoreLibraryDesugaringEnabled = true
    }

    defaultConfig {
        // TODO: Specify your own unique Application ID (https://developer.android.com/studio/build/application-id.html).
        applicationId = "com.webdsoft.wckhata"
        // You can update the following values to match your application needs.
        // For more information, see: https://flutter.dev/to/review-gradle-config.
        minSdk = flutter.minSdkVersion
        targetSdk = maxOf(flutter.targetSdkVersion, 36)
        // Uses the version code from pubspec.yaml. When using split APKs, 1000 * ABI_VERSION
        // is added automatically by Flutter. (https://developer.android.com/studio/build/configure-apk-splits#configure-APK-versions)
        // You can force using the value of versionCode by specifying the `-P force-version-code-ignoring-abi=true`
        // flag during build.
        versionCode = flutter.versionCode
        versionName = flutter.versionName
    }

    signingConfigs {
        if (hasReleaseKey) {
            create("release") {
                keyAlias = keystoreProperties.getProperty("keyAlias")
                keyPassword = keystoreProperties.getProperty("keyPassword")
                storeFile = file(keystoreProperties.getProperty("storeFile"))
                storePassword = keystoreProperties.getProperty("storePassword")
            }
        }
    }

    buildTypes {
        release {
            // Signed with your upload key when key.properties exists.
            // Without it, plain `flutter run --release` still works (debug
            // key) but a Play Store bundle is refused - see the check below.
            signingConfig = if (hasReleaseKey) {
                signingConfigs.getByName("release")
            } else {
                signingConfigs.getByName("debug")
            }
            // Code shrinking (R8) is OFF. With it on, the release build can strip
            // parts of the plugins (saved settings, database, text reading)
            // that work fine in debug, so the Play version opens with no data.
            // The cost is only a slightly bigger app file.
            isMinifyEnabled = false
            isShrinkResources = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
}

// Safety net: never produce a Play Store bundle signed with the debug key.
gradle.taskGraph.whenReady {
    val buildingBundle = allTasks.any { it.name == "bundleRelease" }
    if (buildingBundle && !hasReleaseKey) {
        val reason = if (!keyPropertiesFound) {
            "android/key.properties was not found."
        } else {
            "The keystore file was not found at: '$keystorePath'. Create it first and check storeFile in android/key.properties."
        }
        throw GradleException("$reason See PLAY_STORE_SETUP.md, then run: flutter build appbundle --release")
    }
}

kotlin {
    compilerOptions {
        jvmTarget = org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17
    }
}

flutter {
    source = "../.."
}

dependencies {
    // Required by flutter_local_notifications (isCoreLibraryDesugaringEnabled above).
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.5")
}